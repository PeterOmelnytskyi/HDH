$(document).ready(function() {
	//show faq con
		$(".faq_content ul li ul li .show_con").click(function() {
			$('.faq_content ul li ul li').removeClass('active');
			parent_div = $(this).parents('li');		
			$(parent_div).addClass('active');		
		});
	//hide faq con (click on close icon)
	$(".faq_content ul li ul li .close").click(function() {			
			parent_div = $(this).parents('li');		
			$(parent_div).removeClass('active');		
		});
		//tarif_types
	    $('#tarif_types .tab_control').click(function() {
        var click_id=$(this).attr('id');
        if (click_id != $('#tarif_types .tab_control.active').attr('id') ) {
            $('#tarif_types .tab_control').removeClass('active');
            $(this).addClass('active');
            $('#tarif_types .tab_content').removeClass('active');
            $('#con_' + click_id).addClass('active');
        }
    });	
	//show tarif types
		$("#tarif_types .tab_content ul li .left .read_more").click(function() {
			if ($(this).hasClass('opened')) {
				$(this).parents('li').removeClass('opened');
				$(this).html('Подробнее');	
				$(this).removeClass('opened');	
			} else {
				$(this).parents('li').addClass('opened');
				$(this).html('Свернуть');	
				$(this).addClass('opened');	
			}		
		});
		//show razm list
		$(".razm_dop_list ul li .show_con").click(function() {
			if ($(this).parents('li').hasClass('active')) {
				$(this).parents('li').removeClass('active');	
			} else {
				$(this).parents('li').addClass('active');	
			}		
		});
		//tarif_types-1
	    $('#tarif_types-1 .tab_control').click(function() {
        var click_id=$(this).attr('id');
        if (click_id != $('#tarif_types-1 .tab_control.active').attr('id') ) {
            $('#tarif_types-1 .tab_control').removeClass('active');
            $(this).addClass('active');
            $('#tarif_types-1 .tab_content').removeClass('active');
            $('#con_' + click_id).addClass('active');
        }
    });	
	//show tarif types
		$("#tarif_types-1 .tab_content ul li .left .read_more").click(function() {
			if ($(this).hasClass('opened')) {
				$(this).parents('li').removeClass('opened');
				$(this).html('Подробнее');	
				$(this).removeClass('opened');	
			} else {
				$(this).parents('li').addClass('opened');
				$(this).html('Свернуть');	
				$(this).addClass('opened');	
			}		
		});
		//show razm list
		$(".razm_dop_list ul li .show_con").click(function() {
			if ($(this).parents('li').hasClass('active')) {
				$(this).parents('li').removeClass('active');	
			} else {
				$(this).parents('li').addClass('active');	
			}		
		});
});