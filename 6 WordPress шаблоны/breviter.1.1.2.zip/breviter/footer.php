<?php do_action( 'breviter_footer' ); ?>
</div> <!-- /.page-wrapper -->

<?php wp_footer(); ?>

</body>
</html>