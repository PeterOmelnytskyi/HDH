<h1>Регистрация</h1>
<h1 style="font-size: 16px; color: #000">Добро пожаловать на наш проект! Создайте свою Шоколадную Фабрику и зарабатывайте, продавая шоколад!</h1>
<p class=small>Через несколько минут вы сможете присоединиться к нам как игрок и полноценно включиться в игровой процесс.
А пока оставьте некоторую информацию о себе.</p>
<br><br>
<form name=user_register action="user_register_form.php" method=post>
<input type=hidden name=action value=register>
<table cellspacing="1px" align="left" border=0px width=100%>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>логин*</p>
    <p class=small>(разрешены только цифры, буквы латинского языка, знаки _ -, от 6 до 16 символов включительно)*</p></td>
    <td width=260px align=center class=info_cell><input type=text name=user_login style="width: 240px" value="<?if(!empty($_SESSION["user_login"])) echo $_SESSION["user_login"];?>"></td>
</tr>
<?if($_REQUEST['result']=="login_exists"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>Введенный логин уже занят, попробуйте выбрать другой!</p>
    </td>
</tr>
<?}?>
<?if($_REQUEST['false_login']=="true"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>Введенный логин пуст либо не удовлетворяет вышеописанным правилам!</p>
    </td>
</tr>
<?}?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>пароль*</p>
    <p class=small>(разрешены только цифры, буквы латинского языка, знаки _ -, от 6 до 16 символов включительно)*</p>
    </td>
    <td width=260px align=center class=info_cell><input type=text name=user_pwd class=search_from_element style="width: 240px"></td>
</tr>
<?if($_REQUEST['false_password']=="true"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>Введенный пароль пуст либо не удовлетворяет вышеописанным правилам!</p>
    </td>
</tr>
<?}?>
<?if(!empty($_SESSION['register_referer'])){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Пригласивший игрок</p></td>
    <td width=260px align=left class=info_cell><p class=small><b><?=$_SESSION['register_referer']?></b></p></td>
</tr>
<?}?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>пол*</p></td>
    <td width=260px align=center class=info_cell>
    <p class=small><img src="images/design/male.png" style="vertical-align: middle"> м
    <input type=radio name=sex class=search_from_element value="1" style="width: 50px" <?if($_SESSION["sex"]=='1') echo "checked";?>>
    <input type=radio name=sex value="2" class=search_from_element style="width: 50px" <?if($_SESSION["sex"]=='2') echo "checked";?>>ж
    <img src="images/design/female.png" style="vertical-align: middle"></p>
    </td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>электронная почта*</p></td>
    <td width=260px align=center class=info_cell><input type=text id="user_mail_field" name=user_mail class=search_from_element style="width: 240px"
     value="<?if(!empty($_SESSION["user_mail"])) echo $_SESSION["user_mail"];?>"></td>
</tr>
<?if($_REQUEST['result']=="mail_exists"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>Введенная почта уже занята, попробуйте выбрать другую!</p>
    </td>
</tr>
<?}?>
<?if($_REQUEST['result']=="mail_failed"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>Введенный почтовый ящик не соответствует шаблону стандартных почтовых ящиков!</p>
    </td>
</tr>
<?}?>
<?if($_REQUEST['result']=="mail_blocked"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>К сожалению, почтовые ящики с сервера mail.ru недоступны для использования на нашем сайте!
    Пожалуйста, используйте почтовый ящик другого почтового сервера!.</p>
    </td>
</tr>
<?}?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>контактный телефон</p></td>
    <td width=260px align=center class=info_cell><input type=text id="user_phone_field" name=user_phone class=search_from_element style="width: 240px"
    value="<?if(!empty($_SESSION["user_phone"])) echo $_SESSION["user_phone"];?>"></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>номер icq</p></td>
    <td width=260px align=center class=info_cell><input type=text name=user_icq id="user_icq_field" class=search_from_element style="width: 240px"
    value="<?if(!empty($_SESSION["user_icq"])) echo $_SESSION["user_icq"];?>"></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>скайп</p></td>
    <td width=260px align=center class=info_cell><input type=text id="user_skype_field" name=user_skype class=search_from_element style="width: 240px"
    value="<?if(!empty($_SESSION["user_skype"])) echo $_SESSION["user_skype"];?>"></td>
</tr>
<tr style="vertical-align: top">
    <td colspan=2 class=info_cell align=center>
    <button type=submit class=search_from_element style="width: 240px">
    <img src="images/design/logo.png" style="vertical-align: middle" width=50px><b> Зарегистрироваться</b></button>
    <p class=small>Поля, отмеченные *, обязательны для заполнения!</p> </td>
    </tr>
</table>
</form>
<br>