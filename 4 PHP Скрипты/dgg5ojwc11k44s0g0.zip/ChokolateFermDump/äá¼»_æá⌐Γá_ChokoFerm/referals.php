<?
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
?>
<h1>Партнерам</h1>
<p class=wide_small>
Приглашая в игру своих друзей и знакомых, Вы будете получать 10% от каждой покупки или увеличения уровня Шоколадной Фабрики приглашенным Вами человеком.
Доход ничем не ограничен. Даже всего 10 приглашенных могут Вам принести доход более 100000 золота. Всё зависит от их активности в игре.
Ниже представлена ссылка для приглашения пользователей в игру, а также список приглашенных Вами людей.
</p>
<div style="margin: auto; text-align: center">
<br>
<!--
<textarea style="width: 500px; height: 50px">
<?=htmlspecialchars('<a href="http://'.$sitename.'/?ref='.$login.'" target="_blank"><img src="http://'.$sitename.'/images/banners/banner.jpg" width="468" height="60" border="0"></a>')?>
</textarea><br>

<img src="images/design/banner_small.gif"><br>
<textarea style="width: 500px; height: 50px">
<?=htmlspecialchars('<a href="http://'.$sitename.'/?ref='.$login.'" target="_blank"><img src="http://'.$sitename.'/images/design/banner_small.gif" width="100" height="100" border="0"></a>')?>
</textarea>-->
</div>
<!--
<div style="margin: auto; text-align: center">
<img src="images/design/banner_100_100.gif"><br>
<textarea style="width: 500px; height: 50px">
<?=htmlspecialchars('<a href="http://'.$sitename.'/?ref='.$login.'" target="_blank"><img src="http://'.$sitename.'/images/design/banner_100_100.gif" width="100" height="100" border="0"></a>')?>
</textarea><br>

<img src="images/design/banner_small.gif"><br>
<textarea style="width: 500px; height: 50px">
<?=htmlspecialchars('<a href="http://blackgoldmoney.ru/?ref='.$login.'" target="_blank"><img src="http://blackgoldmoney.ru/images/design/banner_small.gif" width="100" height="100" border="0"></a>')?>
</textarea>
</div>
-->

<br>
<p class="middle">Cсылка для приглашения: <span class="inwork">http://<?=$sitename?>/?ref=<?=$login?></span></p>
<p class="middle">Доход от рефералов</p>
<?
$ref_page = $_REQUEST['ref_page'];
$ref_counter=0;
$select_refs_count=mysqli_query($connector, "SELECT count(*) AS counter FROM clients WHERE client_referal='$current_admin_id'");
while($ref_data=mysqli_fetch_assoc($select_refs_count)){
  $ref_counter  = $ref_data['counter'];
  }
if(empty($ref_page)) $ref_page=1;
if(empty($show_ref_count)) $show_ref_count=20;
$page_count=floor($ref_counter/$show_ref_count);
$limit_start=($ref_page-1)*$show_ref_count;
$limit_count=$show_ref_count;
/*
while($select_refs_data=mysql_fetch_assoc($select_refs_query)){
  if($ref_counter==0) echo "<div style='display: inline-table; width: 240px'>";
  elseif($ref_counter==40) echo "</div><div style='display: inline-table; width: 240px'>";
  elseif($ref_counter==80) echo "</div><div style='display: inline-table; width: 240px'>";
  elseif($ref_counter==160) echo "</div>"; */
?>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td>Имя [Логин]</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Дата</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Доход</td></tr></table></td>
    </tr>
<?
$ref[8] = "Доход от реферала (покупка Шоколадной Фабрики)";
$ref[9] = "Доход от реферала (апгрейд Шоколадной Фабрики)";
$ref_data_query_text="SELECT client_id, login, add_date FROM clients WHERE client_referal = $current_admin_id
ORDER BY add_date LIMIT $limit_start, $limit_count";
$ref_data_query = mysqli_query($connector, $ref_data_query_text);
while($ref_data=mysqli_fetch_assoc($ref_data_query)){
  $ref_login = $ref_data['login'];
  $add_date  = $ref_data['add_date'];
  $ref_id    = $ref_data['client_id'];

$balance_actions_query_text="SELECT sum(balance_actions.gold) AS total_gold FROM balance_actions
WHERE client_id = $current_admin_id AND (action_type=8 OR action_type=9 OR action_type=12 OR action_type=13) AND ref_id=$ref_id";

$balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
while($balance_actions_data=mysqli_fetch_assoc($balance_actions_query)){
   $gold        = $balance_actions_data['total_gold'];
}
if(empty($gold)) $gold=0;
$sum  = $gold."<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ";
?>

    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td><a class=minilink href="?mode=client_profile&client_id=<?=$ref_id?>"><b class=success><?=$ref_login?></b></a></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$add_date?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$sum?></td></tr></table></td>
    </tr>
<?}?>
</table>
<div style="margin: 0px auto; width: 320px;"><span class=small>Страницы:</span>
<?if($ref_page!=1){?>
<a class="microlink" href="?mode=referals&ref_page=1"><<</a>
<?}?>
<?while ($u<=$page_count+1){?>
<a class="microlink" href="?mode=referals&ref_page=<?=$u?>" <?if($ref_page==$u) {?> style="text-decoration: underline" <?}?>><?=$u?></a>
<? $u++;}?>
<?if($ref_page!=$page_count+1){?>
<a class="microlink" href="?mode=referals&ref_page=<?=$page_count+1?>">>></a>
<?}?>
</div>