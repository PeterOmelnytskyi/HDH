<?
session_start();
require_once("dbconnect.php");
require_once("functions.php");
require_once("setup.php");
require_once ("config.php");
$action =  $_REQUEST['action'];
$login =   $_POST["login"];
$login     = mysqli_real_escape_string($connector,$login);
if ($action=="authorize")
	{
                $password=htmlspecialchars(substr($_POST["password"],0,32));
                $password=md5($password);
                $login=htmlspecialchars(substr($login,0,32));
                $check_ip=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!");

                $authorize="SELECT login, password, client_stat FROM clients WHERE login='$login'";
                $authorize=mysqli_query($connector, $authorize);
                while($row=mysqli_fetch_assoc($authorize)){
                    $real_pass  = $row['password'];
                    $real_login = $row['login'];
                    $client_stat= $row['client_stat'];

                 }
                if($client_stat!="2"){
                   header("Location: index.php?mode=home&blocked=true&not_activated=true");
                   exit;
                }
                 if (!strcmp($login, $real_login) && !strcmp($password, $real_pass))
                {
                        $_SESSION[$session_login]       = $real_login;
			            $_SESSION[$session_pass]      = $real_pass;
                        $_SESSION["user_checker"]   = $check_ip;
                        //echo "работает";
                //die("логин ".$_SESSION["log"]);
			    header("Location: index.php?mode=home&true");
                }
                else header("Location: index.php?mode=home&blocked=true&error_logorpass=true");
    }
    ?>
