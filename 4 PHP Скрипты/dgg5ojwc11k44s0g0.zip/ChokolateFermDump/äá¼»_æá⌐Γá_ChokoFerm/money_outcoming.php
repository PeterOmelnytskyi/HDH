<?
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}?>
<h1>Вывод средств</h1>
<p class=small>На данный момент возможен вывод на различные платежные системы. Выплата производится в течении 3-х рабочих дней.
Минимум на вывод от 10 рублей (1000 золота). При выводе средств из игры администрацией не берется комиссия, таким образом,
в отличии от остальных подобных проектов Вы выводите все денежные средства без каких-либо потерь! Список способов вывода со временем будет увеличиваться.
Отдаем предпочтение киви и вебмани. Через эти платежные системы вы получите выводы в максимально короткие сроки.</p>
<?
$last_payment_outcoming_query_text="SELECT UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP((payment_datetime)) AS last_payment FROM payment_outcoming
WHERE payment_client_id = $current_admin_id ORDER BY payment_datetime DESC LIMIT 1";
$last_payment_outcoming_query = mysqli_query($connector, $last_payment_outcoming_query_text);
while($last_payment_outcoming_data=mysqli_fetch_assoc($last_payment_outcoming_query)){
   $last_payment = $last_payment_outcoming_data['last_payment'];
}
if(($last_payment>60*60*24) or (empty($last_payment))){
?>
<form name="payment" action="payment_outcoming.php" method="get">
<input type="hidden" name="action" value="money_outcoming">
<input type="text" name="payment_amount" value="" placeholder="введите сумму в рублях" style="width: 160px" >
<select name="payment_system">
<option value=1>Webmoney</option>
<option value=2>Яндекс-деньги</option>
<option value=5>Qiwi-кошелек</option>
</select>
<input type="text" name="payment_system_id" value="" style="width: 300px" placeholder="введите номер вашего кошелька или счета">
<input type="submit" value="Вывести" class=input_button>
</form>
<?if($_REQUEST['error']=='not_enough_money'){?><p class=wide_small><span class=attention>Внимание!</span>
У вас недостаточно средств для вывода указанной суммы.</p><?}?>
<?if($_REQUEST['error']=='wrong_amount'){?><p class=wide_small><span class=attention>Внимание!</span>
Выводимая сумма должна быть не меньше 10 рублей.</p><?}?>
<?if($_REQUEST['error']=='empty_system_id'){?><p class=wide_small><span class=attention>Внимание!</span>
Вы не указали номер счета / кошелька для вывода средств.</p><?}?>
<?if($_REQUEST['result']=='request'){?><p class=wide_small><span class=success>
Запрос на выведение средств отправлен на обработку.</span> </p><?}?>
<?}else{?>
<p class=wide_small><span class=attention>Внимание!</span>
C последней выплаты еще не прошло 24 часа. Выплаты заказывать возможно не чаще чем раз в сутки!</p>
<?}?>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td>Дата</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Сумма</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Система</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Счет / кошелек</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Статус</td></tr></table></td>
    </tr>
<?
$system[1] = "Webmoney";
$system[2] = "Яндекс-деньги";
$system[4] = "liqpay.com";
$system[5] = "Qiwi-кошелек";
$system[10] = "Perfect Money";
$payment_status[0] = "<p class=inwork>запрос вывода принят в обработку</p>";
$payment_status[1] = "<p class=attention>запрос вывода отвергнут</p>";
$payment_status[2] = "<p class=success>вывод средств успешно проведен</p>";
$payment_outcoming_query_text="SELECT sum(payment_summ) AS total_money FROM payment_outcoming WHERE payment_client_id = $current_admin_id AND payment_stat = 2";
$payment_outcoming_query = mysqli_query($connector, $payment_outcoming_query_text);
while($payment_outcoming_data=mysqli_fetch_assoc($payment_outcoming_query)){
  $payment_total_summ   = $payment_outcoming_data['total_money'];
}
if(empty($payment_total_summ)) $payment_total_summ = 0;
if($_REQUEST['limit']=='no'){
$payment_outcoming_query_text="SELECT * FROM payment_outcoming WHERE payment_client_id = $current_admin_id ORDER BY payment_datetime DESC";
}
else {
$payment_outcoming_query_text="SELECT * FROM payment_outcoming WHERE payment_client_id = $current_admin_id ORDER BY payment_datetime DESC LIMIT 20";
}
$payment_outcoming_query = mysqli_query($connector, $payment_outcoming_query_text);
while($payment_outcoming_data=mysqli_fetch_assoc($payment_outcoming_query)){
   $payment_datetime    = $payment_outcoming_data['payment_datetime'];
   $payment_stat        = $payment_outcoming_data['payment_stat'];
   $payment_system_id   = $payment_outcoming_data['payment_system_id'];
   $payment_summ        = $payment_outcoming_data['payment_summ'];
   $payment_type        = $payment_outcoming_data['payment_type'];
?>

    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td><?=$payment_datetime?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$payment_summ?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><span class=small><?=$system[$payment_type]?></span></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$payment_system_id?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$payment_status[$payment_stat]?></td></tr></table></td>
    </tr>
<?}?>
</table>
<p class=small>Всего Вами из проекта выведено средств на сумму <b><?=$payment_total_summ?> рублей.</b></p>