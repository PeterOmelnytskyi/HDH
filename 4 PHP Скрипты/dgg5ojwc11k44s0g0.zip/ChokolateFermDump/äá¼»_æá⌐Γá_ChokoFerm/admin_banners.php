<h1>Баннеры</h1>
<?
$banners_query_text="SELECT * FROM banners ORDER By banner_id DESC";
$banners_query=mysqli_query($connector, $banners_query_text);?>
<table border="0" width="990" class="levelsTable"  cellspacing=0px>
<?
$system[1] = "Webmoney";
$system[2] = "Яндекс-деньги";
$system[3] = "Мобильный телефон";
$system[4] = "liqpay.com";
$system[5] = "Qiwi-кошелек";
$system[10] = "Perfect-money";
$banner_status[0] = "<p class=inwork>баннер взят на проверку</p>";
$banner_status[1] = "<p class=attention>баннер отвергнут</p>";
$banner_status[2] = "<p class=success>баннер успешно принят к показу</p>";
while($banners_data=@mysqli_fetch_assoc($banners_query)){
   $start_datetime    = $banners_data['start_datetime'];
   $end_datetime      = $banners_data['end_datetime'];
   $show_datetime     = $banners_data['show_datetime'];
   $mail              = $banners_data['mail'];
   $url               = $banners_data['url'];
   $file              = $banners_data['file'];
   $description       = $banners_data['description'];
   $pay_type          = $banners_data['pay_type'];
   $counter           = $banners_data['counter'];
   $banner_id         = $banners_data['banner_id'];
   $stat              = $banners_data['stat'];
   $pay_stat          = $banners_data['pay_stat'];
//payment_client_id
?>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>id баннера</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Начала показа</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Окончания показа</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Удалить баннер</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Операции</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Статус</td></tr></table></td>
    </tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><?=$banner_id?><br></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=rus_calendar($start_datetime)?><br></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=rus_calendar($end_datetime)?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>
        <a class="minilink" href="request_banner_controller.php?action=delete_banner&banner_id=<?=$banner_id?>"><span class=attention>Удалить</span></a>
        </td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>
         <?if($stat=='1'){?>
        <a class="minilink" href="request_banner_controller.php?action=edit_stat&banner_id=<?=$banner_id?>&stat=0"><span class=success>Не показывать</span></a>
        <?}else {?>
        <a class="minilink" href="request_banner_controller.php?action=edit_stat&banner_id=<?=$banner_id?>&stat=1"><span class=attention>Показывать</span></a>
        <?}?>
        <?if($pay_stat=='1'){?>
        <a class="minilink" href="request_banner_controller.php?action=edit_pay_stat&banner_id=<?=$banner_id?>&pay_stat=0"><span class=success>Не оплачен</span></a>
        <?}else {?>
        <a class="minilink" href="request_banner_controller.php?action=edit_pay_stat&banner_id=<?=$banner_id?>&pay_stat=1"><span class=attention>Оплачен</span></a>
        <?}?>
         </td></tr></table></td>
         <td><table class="levelsTableCell" border=0px><tr><td>
          <?if($pay_stat=='1'){?> <span class=success>Оплачен</span><?} else {?><span class=attention>Не оплачен</span><?}?>
         / <?if($stat=='1'){?> <span class=success>Показывается</span><?} else {?><span class=attention>Не показывается</span><?}?>
         </td></tr></table></td>
    </tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Показов</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Файл</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Период показа, дней</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Email</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>URl</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Описание</td></tr></table></td>
    </tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><?=$counter?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><img src='<?="images/banners/".$file?>' width=234px></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$show_datetime?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$mail?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$url?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$description?></td></tr></table></td>
    </tr>
        <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td> </td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td></td></tr></table></td>
    </tr>



<?}?>
</table>
