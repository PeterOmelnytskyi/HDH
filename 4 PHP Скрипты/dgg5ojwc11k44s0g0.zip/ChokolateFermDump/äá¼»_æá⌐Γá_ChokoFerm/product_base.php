<?
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
$client_trees_query=mysqli_query($connector, "SELECT * FROM trees WHERE client_id = $current_admin_id ORDER BY start_time DESC");
$tree_count = mysqli_num_rows($client_trees_query);
?>

<h1>Шоколадная Фабрика</h1>
<?//гость
if(!empty($_SESSION[$session_login])){?>
<p class=wide_small>Шоколадная Фабрика — это специально оборудованное место для производства шоколада.
Ниже отображаются все ваши фабрики, не забывайте вовремя посещать их чтобы забрать готовый шоколад.
Повышая  уровень Шоколадной Фабрики, Вы будете получать больше шоколада, а также дополнительные бонусы (Таблица уровней).</p>
<div class=button><a href="ferm_form.php?action=get_all_harvest">Сбор шоколада</a></div>
 <?if($_REQUEST['success']=='success_harvest'){?><p class=wide_small><span class=success>Поздравляем!</span>
Шоколад успешно собран!
 <?if(!empty($_REQUEST['harvest_counter'])) echo "собрано шоколада - <b>".$_REQUEST['harvest_counter']."</b>.";?></p>
<?}?>
 <table border=0px style="border-top: 2px dotted #888; border-left: 0px; border-right: 0px;">
<tr height=2px>
    <td width=640px>
</td>
</tr>
</table>
<table border=0px>
<?while($client_trees_data=mysqli_fetch_assoc($client_trees_query)){
                $current_tree_id        = $client_trees_data['client_tree_id'];
                $current_start_time     = $client_trees_data['start_time'];
                $current_last_free_time = $client_trees_data['last_free_time'];
                $current_level          = $client_trees_data['level'];
                $current_tree_lifetime  = $client_trees_data['tree_lifetime'];
?>
<tr height=20px>
    <td width=125px><img src="images/design/rudnik.png" width=80px style="vertical-align: middle"> </td>
    <td><p class=middle>Шоколадная фабрика, <?=$current_level?> уровень</p>
    <p class=small>Срок использования истекает <?=rus_calendar($current_tree_lifetime);?></p></td>
    <td width=160px><div class=button><a href="?mode=product_manager&product_id=<?=$current_tree_id?>">Проверить</a></div></td>
</tr>
<? } ?>
</table>
<table border=0px style="border-top: 2px dotted #888; border-left: 0px; border-right: 0px;">
<tr height=2px>
    <td width=640px>
</td>
</tr>
</table>
<p class=small>У вас <b><?=$tree_count?></b> Шоколадных Фабрик из <b><?=$client_max_trees?></b> возможных.</p>

<? if($check_combine>0){?>
<p class="middle"><span class=success>Используется помощник</span></p>
<p class=small>Срок работы помощника истечет <?=rus_calendar($combine_stop)?>.</p>
<img src="images/design/telejka.png" style="vertical-align: middle">
<?}?>
<? if($check_autoreferal>0){?>
<p class="middle"><span class=success>Используется автореферал</span></p>
<p class=small>Срок действия автореферала истечет <?=rus_calendar($autoreferal_stop)?>.</p>
<p class=small>Всего текущий автореферал вам привел <?=$autoreferal_client_counter?> игроков.</p>
<img src="images/design/autoreferal.png" style="vertical-align: middle">
<?}?>
<?}else{?>
<p class=wide_small style="color: red">Шоколадных фабрик нет!</p>
<a href="?mode=register"><img src="images/design/gribi.png" border=0px></a>
<?}?>