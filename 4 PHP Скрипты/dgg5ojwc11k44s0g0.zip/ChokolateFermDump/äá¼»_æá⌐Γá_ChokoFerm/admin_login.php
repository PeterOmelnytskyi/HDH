<?
require_once("dbconnect.php");
require_once("functions.php");
if($_REQUEST["authorize"]=="1")
	{           $password=$_REQUEST["mng_pwd"];
                $password=md5($password);
                $login=$_REQUEST["mng_login"];
                 $authorize="SELECT login, password FROM admin WHERE login='$login'";
                $authorize=mysqli_query($connector, $authorize);
                while($row=mysqli_fetch_assoc($authorize)){
                    $real_pass=$row['password'];
                    $real_login=$row['login'];
                 }

                 if (!strcmp($login, $real_login) && !strcmp($password, $real_pass))
                {       session_start();
                        $_SESSION["admin_log"] = $real_login;
			            $_SESSION["admin_pass"] = $real_pass;
                        $_SESSION["admin_mode"] = md5($_SERVER["REMOTE_ADDR"]."admin_mode");
                        $data = array('auth_result' => "success");
                }
                else
                {
                       $data = array('auth_result' => "false_key");
                }
                exit(json_encode($data));
    }
?>