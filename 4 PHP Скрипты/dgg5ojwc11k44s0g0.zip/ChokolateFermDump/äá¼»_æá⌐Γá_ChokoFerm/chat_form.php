<?
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("config.php");
require_once ("current_settings.php");
//mb_internal_encoding("UTF-8");
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
$_SESSION[$session_login]= '';
$_SESSION[$session_pass] = '';
$_SESSION["user_checker"]= '';
unset($_SESSION);
header("Location: index.php");
exit;
}
$message_text = $_REQUEST['message_text'];
$action       = $_REQUEST['action'];
if($action=="add_message"){
$settings_query="SELECT apples_per_message FROM settings";
$settings_query=mysqli_query($connector, $settings_query);
while($settings=mysqli_fetch_assoc($settings_query)){
$apples_per_message = $settings['apples_per_message'];
}
      $error="";
      if((strlen($message_text)<1)) $error.="&chat_error=wrong_message";
      if(!empty($error)) {header("Location: index.php?mode=chat".$error);
      exit;}
      else {
        $check_chat_message_query_text="SELECT * FROM chat WHERE UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(add_date)<=1*60 AND client_id = '$current_admin_id'";
        $check_chat_message_query = mysqli_query($connector, $check_chat_message_query_text);
        $check_chat_message_result = mysqli_num_rows($check_chat_message_query);

        if(!$check_chat_message_result){
              if(($current_client_gold>=$apples_per_message) AND ($current_client_gold>0)){
            $add_chat_message_query_text="INSERT INTO chat (message_text, message_stat, add_date, client_id)
            VALUES ('".mysqli_real_escape_string($connector, $message_text)."', 1, NOW(), '$current_admin_id')";
                  if($add_chat_message_query=mysqli_query($connector, $add_chat_message_query_text)){
                  $update_gold=mysqli_query($connector, "UPDATE clients SET gold=gold-$apples_per_message WHERE client_id='$current_admin_id'");
                  header("Location: index.php?mode=chat");
                  exit();
                  }
            }
            else {$error.="&chat_error=not_enough_gold";
              header("Location: index.php?mode=chat".$error);
                  exit();
            }
        }
        else {header("Location: index.php?mode=chat".$error);
        exit;}
      exit();
      }
}
?>