<h1>Входящие сообщения:</h1>
<a href="?mode=outcoming_messages" class=message_link>Показать отправленные сообщения</a>
<?if($_REQUEST['result']=='not_deleted'){?><p class=wide_small><span class=attention>Внимание!</span>
Сообщение не было удалено!<br><?=$_REQUEST['data']?></p><?}?>
<?if($_REQUEST['result']=='deleted'){?>
<p class=wide_small><span class=success>Сообщение успешно удалено</span>
 </p><?}?>
 <table border=0px style="border-top: 2px dotted #888; border-left: 0px; border-right: 0px;">
<tr height=2px>
    <td width=640px>
</td>
</tr>
</table>
<?if($mtq_count==0){?><p class=small>Сообщения отсутствуют, вы еще ни с кем не переписывались.</p><?}?>
<table width=650px border=0px cellpadding=2px cellspasing=0px>
<?if(!empty($_REQUEST['message_id'])){
    $current_message_id=$_REQUEST['message_id'];
    $make_readed_query=mysqli_query($connector, "UPDATE messages SET messages.message_to_stat=1 WHERE messages.message_to = $current_admin_id
    AND messages.message_id=$current_message_id");
    //проверка типа сообщения - рассылка или личное
    $outcoming_messages=mysqli_query($connector, "SELECT message_from FROM messages WHERE message_id=$current_message_id");
    while($outcoming_messages_data = mysqli_fetch_assoc($outcoming_messages)){
      $message_type = $outcoming_messages_data['message_from'];
    }
    if($message_type=="0"){
      $incoming_messages=mysqli_query($connector, "SELECT message_content, date_sent FROM messages WHERE message_id=$current_message_id");
    while($incoming_messages_data = mysqli_fetch_assoc($incoming_messages)){?>
    <tr valign=top style="vertical-align: top">
    <td valign=top style="text-align: left; vertical-align: top" width=185px>
    <p class="small"><b>Рекламная рассылка</b></p>
    <p class="small"><b><?=rus_calendar($incoming_messages_data['date_sent'])?></b></p></td>
    <td valign=top style="vertical-align: top"><p class=small>
    <?
   $current_message = $incoming_messages_data['message_content'];
    $current_message_text=preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a class=minilink href="\\0">\\0</a>',$current_message);
    echo $current_message_text;
    ?></p></td>
    <td valign=top width=120px style="vertical-align: top"><a href="message_delete_form.php?action=delete_received_message&message_id=<?=$current_message_id?>" class=minilink>удалить сообщение</a></td>
    </tr>
    <?}?>
    <?}
    else {?>
    <? $outcoming_messages=mysqli_query($connector, "SELECT client_id, login, message_from, message_content, active_message, date_sent FROM messages,
            clients WHERE messages.message_to = $current_admin_id AND messages.message_from=clients.client_id AND messages.message_id=$current_message_id");
    while($outcoming_messages_data = mysqli_fetch_assoc($outcoming_messages)){
      $active_message = $outcoming_messages_data['active_message'];?>
    <tr valign=top style="vertical-align: top">
    <td valign=top style="text-align: left; vertical-align: top" width=185px>
    <p class="small"><b><?=$outcoming_messages_data['login']?></b></p>
    <p class="small"><b><?=rus_calendar($outcoming_messages_data['date_sent'])?></b></p></td>
    <td valign=top style="vertical-align: top"><p class=small>
    <?
    $current_message = $outcoming_messages_data['message_content'];
    $current_message_text=preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a class=minilink href="\\0">\\0</a>',$current_message);
    echo $current_message_text;
    ?></p></td>
    <td valign=top width=120px style="vertical-align: top"><a href="message_delete_form.php?action=delete_received_message&message_id=<?=$current_message_id?>" class=minilink>удалить сообщение</a></td>
    </tr>
    <tr valign=top style="vertical-align: top">
    <td></td>
        <td>
            <form name="new_message_form" method="post" action="message_sending_form.php">
            <input type=hidden name="action" value="send">
            <p class="small">Ответить пользователю <b><?=$outcoming_messages_data['login']?></b>:</p>
            <textarea cols=45 rows=14 name=message_content <?if($active_message==1) echo "disabled";?>>
            <?if($active_message==1) echo "Пользователь отключил возможность приема сообщений.";?>
            </textarea>
            <input type=hidden name="message_to" value="<?=$outcoming_messages_data['client_id']?>">
            <input type=submit value="Отправить" <?if($active_message==1) echo "disabled";?>>
            </form>
        </td>
        </tr>
    <?}
    }?>
<?}else{?>
<?
 $incoming_messages_query=mysqli_query($connector, "SELECT message_to, message_content,
    date_sent, message_id, message_to_stat, message_from FROM messages WHERE messages.message_to = $current_admin_id
    AND messages.message_from=0 AND messages.message_to_stat<>2 ORDER BY date_sent DESC");
    while($incoming_messages_data = mysqli_fetch_assoc($incoming_messages_query)) {
     $current_message = $incoming_messages_data['message_content'];
     $current_date_sent = $incoming_messages_data['date_sent'];
     $current_message_id = $incoming_messages_data['message_id'];
     $current_message_from = $incoming_messages_data['message_from'];
     $current_message_stat = $incoming_messages_data['message_to_stat'];
 ?>
    <tr message_id=<?=$current_message_id?> valign=top style="vertical-align: top; <?if($current_message_stat=='0') echo "background-color: rgba(7, 28, 8, 0.5);";?>">
    <td valign=top style="text-align: left; vertical-align: top" width=185px>
    <a class="minilink" href="?mode=client_profile&client_id=<?=$current_message_from?>"><b><?=$current_client_login?></b></a>
    <p class="small"><b><?=rus_calendar($current_date_sent)?></b></p></td>
    <td valign=top style="vertical-align: top"><a href="?mode=incoming_messages&message_id=<?=$current_message_id?>" class=message_link>
    <?if($current_message_stat=='0') echo "<b>";?>
    <? if(strlen($current_message)>400){
    $current_message = substr($current_message,0, strrpos(substr($current_message,0,400), " "));
    }
   echo $current_message;?>
    <?if($current_message_stat=='0') echo "</b>";?></a></td>
    <td valign=top style="vertical-align: top" width=120px><a href="message_delete_form.php?action=delete_received_message&message_id=<?=$current_message_id?>" class=minilink>удалить сообщение</a></td>
    </tr>
<?}?>
    <? $incoming_messages_query=mysqli_query($connector, "SELECT login, message_to, message_content,
    date_sent, message_id, message_to_stat, message_from FROM messages INNER JOIN clients WHERE messages.message_to = $current_admin_id
    AND messages.message_from=clients.client_id  AND messages.message_to_stat<>2 ORDER BY date_sent DESC");
    while($incoming_messages_data = mysqli_fetch_assoc($incoming_messages_query)) {
     $current_client_login = $incoming_messages_data['login'];
     $current_message = $incoming_messages_data['message_content'];
     $current_date_sent = $incoming_messages_data['date_sent'];
     $current_message_id = $incoming_messages_data['message_id'];
     $current_message_stat = $incoming_messages_data['message_to_stat'];
     $current_message_from = $incoming_messages_data['message_from'];
 ?>
    <tr message_id=<?=$current_message_id?> valign=top style="vertical-align: top; <?if($current_message_stat=='0') echo "background-color: rgba(7, 28, 8, 0.5); ";?>">
    <td valign=top style="text-align: left; vertical-align: top" width=185px>
    <a class="minilink" href="?mode=client_profile&client_id=<?=$current_message_from?>"><b><?=$current_client_login?></b></a>
    <p class="small"><b><?=rus_calendar($current_date_sent)?></b></p></td>
    <td valign=top style="vertical-align: top"><a href="?mode=incoming_messages&message_id=<?=$current_message_id?>" class=message_link>
    <?if($current_message_stat=='0') echo "<b>";?>
    <? if(strlen($current_message)>400){
    $current_message = substr($current_message,0, strrpos(substr($current_message,0,400), " "));
    }
    echo $current_message;?>
    <?if($current_message_stat=='0') echo "</b>";?></a></td>
    <td valign=top style="vertical-align: top" width=120px><a href="message_delete_form.php?action=delete_received_message&message_id=<?=$current_message_id?>" class=minilink>удалить сообщение</a></td>
    </tr>

<?}
}?>
</table>