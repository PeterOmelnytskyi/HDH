<h1>Заказ рекламного баннера</h1>
<?if($_REQUEST['result']=='wrong_description'){?><p class=wide_small><span class=attention>Ошибка!</span>
Описание баннера не должно быть пустым</p>
<?}?>
<?if($_REQUEST['result']=='wrong_url'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана ссылка (url)</p>
<?}?>
<?if($_REQUEST['result']=='wrong_show_datetime'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указано количество показов баннера</p>
<?}?>
<?if($_REQUEST['result']=='wrong_start_datetime'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана дата начала показов баннера</p>
<?}?>
<?if($_REQUEST['result']=='wrong_mail'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана почта для контроля баннера</p>
<?}?>
<?if($_REQUEST['result']=='wrong_pay_type'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана система оплаты за показ баннера</p>
<?}?>
<?if($_REQUEST['result']=='too_large_file'){?><p class=wide_small><span class=attention>Ошибка!</span>
Файл очень велик. Разрешена загрузка баннеров не более чем в 300 килобайт.</p>
<?}?>
<?if($_REQUEST['result']=='upload_file_error'){?><p class=wide_small><span class=attention>Ошибка!</span>
Ошибка загрузки файла.</p>
<?}?>
<?if($_REQUEST['result']=='empty_file'){?><p class=wide_small><span class=attention>Ошибка!</span>
Отсутствует файл для загрузки.</p>
<?}?>
<?if($_REQUEST['result']=='error_filetype'){?><p class=wide_small><span class=attention>Внимание!</span>
Изображение аватары может иметь расширение только следующих типов: jpg, gif, png, jpeg.</p>
<?}?>
<?if($_REQUEST['result']=='success'){?><p class=wide_small><span class=success>Поздравляем!</span>
Баннер был успешно загружен, ему присвоен номер в системе <b><?=$_REQUEST['data']?></b>, он ожидает проверки со стороны администрации сайта.
Как только он будет оплачен, будет произведено его добавление в список активных баннеров и он будет виден на сайте
с указанной вами даты начала показа (с момента полуночи). Информация о том, как смотреть статистику по баннеру и как
контроллировать показ баннера отправлена на указанный почтовый ящик.
Оплатить показ баннера вы можете следующими способами:<br>
- <b>Qiwi</b> (номер <b><?=$qiwi_account?></b>)<br>
- <b>Яндекс-деньги </b> (номер <b><?=$yandex_account?></b>)<br>
При оплате обязательно указывается в комментарии "Оплата счета за баннер #<?=$_REQUEST['data']?>"<br>
<?if($wm_attestat_status){?>
<a href="?mode=wm_payment&service_mode=B&banner_id=<?=$_REQUEST['data']?>&count=<?=$_REQUEST['show_datetime']?>">Оплатить через webmoney в автоматическом режиме</a>
<?}?>
Благодарим за сотрудничество!
C уважением, администрация сайта <?=$sitename?></p>
<?}?>
<br>
<form name=user_register action="request_banner_controller.php" method=post enctype="multipart/form-data">
<input type=hidden name=action value=banner_request>
<table cellspacing="1px" align="center" border=0px>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Описание баннера*</p></td>
    <td width=260px align=center class=info_cell><input type=text name=description style="width: 240px"></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>url ссылки*</p></td>
    <td width=260px align=center class=info_cell><input type=text name=url style="width: 240px"></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Срок показа, дни*</p></td>
    <td width=260px align=center class=info_cell>
<select name=show_datetime>
<?$x=0;
while($x<90){
  $x++;?>
<option value="<?=$x?>"><?=$x?></option>
<?}?>
</select>
    </td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Дата начала показа</p></td>
    <td width=260px align=center class=info_cell>
<div id="datepicker" style="width: 200px"></div>
<input type=hidden name=start_datetime>
</td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Файл баннера (<b>соблюдение размера/пропорций 468*60 строго обязательно!</b>)(максимальный вес - 300кб)*</p></td>
    <td width=260px align=center class=info_cell>
    <input type=file name=banner_file class=search_from_element style="width: 240px"></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Ваш email*</p></td>
    <td width=260px align=center class=info_cell>
    <input type=text name=mail class=search_from_element style="width: 240px">
    </td>
</tr>
<!--
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Докажи что не робот :)*</p></td>
    <td width=260px align=center class=info_cell>
    <span class=inwork>без труда не выловишь и <input type=text name=captcha id="captcha" class=search_from_element style="width: 40px"> из пруда</span></td>
</tr>
-->
<tr style="vertical-align: top">
    <td colspan=2 class=info_cell align=center>
    <button type=submit class=search_from_element style="width: 140px">
    <img src="images/design/money_small.png" style="vertical-align: middle"> Заказать</button></td>
    </tr>
</table>
</form>
<p class=small>Поля, отмеченные *, обязательны для заполнения!</p>
<br>
