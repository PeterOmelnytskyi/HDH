<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
require_once ("config.php");
require_once ("current_settings.php");

$system            = htmlspecialchars($_REQUEST['system']);
$sid               = htmlspecialchars($_REQUEST['sid']);
$mode              = htmlspecialchars($_REQUEST['mode']);
$success           = htmlspecialchars($_REQUEST['success']);
$admin             = htmlspecialchars($_REQUEST['admin']);
$glade_id          = htmlspecialchars($_REQUEST['product_id']);
$action            = htmlspecialchars($_REQUEST['action']);
$client_id         = htmlspecialchars($_REQUEST['client_id']);
$banner_id         = htmlspecialchars($_REQUEST['banner_id']);
$ref               = htmlspecialchars(trim($_REQUEST['ref']));
$client_id = mysqli_real_escape_string($connector,$client_id);
$banner_id = mysqli_real_escape_string($connector,$banner_id);
$glade_id  = mysqli_real_escape_string($connector,$glade_id);
$ref = mysqli_real_escape_string($connector,$ref);
$avatar_path       = "images/avatars/";
$default_avatar    = "ava1.gif";

if ($mode=="logout")
	{
		$_SESSION[$session_login] = "";
		$_SESSION[$session_pass] = "";
        $_SESSION["user_checker"] = "";
		unset($_SESSION[$session_login]);
		unset($_SESSION[$session_pass]);
        unset($_SESSION["user_checker"]);
        session_destroy();
		die("<script>window.location='index.php';</script>");
	}
//проверка реферала
if ((!empty($ref)) and (empty($_SESSION[$session_login])))
	{
        if((strlen($ref)<=16) and (strlen($ref)>=2))
        $ref_query_text="SELECT * FROM clients WHERE login='$ref'";
        $ref_query=mysqli_query($connector, $ref_query_text);
        $ref_check=mysqli_num_rows($ref_query);
        if($ref_check>0){
          $_SESSION['register_referer']=$ref;
        }
	}
if ($action=="authorize")
	{

                $password=$_POST["password"];
                $password=md5($password);
                $login=$_POST["login"];
                $authorize="SELECT login, password FROM clients WHERE login='$login'";
                $authorize=mysqli_query($connector, $authorize);
                while($row=mysqli_fetch_assoc($authorize)){
                    $real_pass=$row['password'];
                    $real_login=$row['login'];
                 }

                 if (!strcmp($login, $real_login) && !strcmp($password, $real_pass))
                {
                        $_SESSION[$session_login] = $real_login;
			            $_SESSION[$session_pass] = $real_pass;
                        //echo "работает";
                die($_SESSION[$session_login]);
			    //header("Location: index.php?mode=home&true");
                }
                else header("Location: index.php?mode=home&blocked=true&error_logorpass=true");
    }
//жесткая установка параметра mode
$valid_mode=array('home', 'banned', 'balance_actions', 'settings', 'market', 'help', 'shop', 'user_statistic', 'clients', 'register', 'register_last_step',
'register_complete','chat', 'product_base', 'outcoming_messages', 'payment_failed', 'payment_success', 'payment_controller', 'change_password','change_mail',
 'incoming_messages', 'new_message', 'user_profile', 'money_incoming', 'money_outcoming', 'levels', 'product_manager', 'security', 'client_profile',
 'user_online', 'referals', 'contacts', 'newsline', 'project_info', 'payments', 'request_banner', 'check_banner', 'get_password', 'wm_payment',
'wm_payment_success', 'wm_payment_failed', 'request_link', 'check_link', 'request_mailer','actions','feedback');
if(!empty($ban_end) and ($mode!='banned')){
header("Location: index.php?mode=banned");
}

elseif((!isset($mode))||(!in_array($mode, $valid_mode)))
{
header("Location: index.php?mode=home");
}

$settings_query="SELECT * FROM settings";
            $settings_query=mysqli_query($connector, $settings_query);
            while($settings=mysqli_fetch_assoc($settings_query)){
$timezone                   =   $settings['timezone'];
$apples_per_gold            =   $settings['apples_per_gold'];
$sms_key                    =   $settings['sms_key'];
$total_money_balance_percent=   $settings['total_money_balance_percent'];
$settings_admin_fio         =   $settings['admin_fio'];
$director_fio               =   $settings['director_fio'];
$admin_mail                 =   $settings['admin_mail'];
$apples_per_message         =   $settings['apples_per_message'];
$user_key                   =   $settings['user_key'];
$client_max_trees           =   $settings['client_max_trees'];
$rub_usd                    =   $settings['rub_usd'];
$reserv_change              =   $settings['reserv_change'];
$combine_price              =   $settings['combine_price'];
$autoreferal_price          =   $settings['autoreferal_price'];
$banner_per_day             =   $settings['banner_per_day'];
$link_per_day               =   $settings['link_per_day'];
$mailer_price               =   $settings['mailer_price'];
$user_count                 =   $settings['user_count'];
$keywords                   =   $settings['keywords'];
$description                =   $settings['description'];
$cock_price                 =   $settings['cock_price'];
}

$project_start_day_query_text="SELECT TO_DAYS(NOW()) - TO_DAYS(MIN(add_date)) AS start_day FROM clients";
            $project_start_day_query=mysqli_query($connector, $project_start_day_query_text);
            while($project_start_day_data=mysqli_fetch_assoc($project_start_day_query)){
$start_day = $project_start_day_data['start_day'];
              }

	/**
	 * @param string f1 - существительное для числа 1 - 1 голос
	 * @param string f2 - существительное для чисел в диапазоне от 2 до 4-х: 2 голоса
	 * @param string f3 - существительное для остальных чисел:5 голосов
	 * @param int v - число
	 */
function word_render($f1, $f2, $f3, $v)
	{
		$v = str_pad((int)$v, 2, '0', STR_PAD_LEFT);
		$s2 = intval(substr($v, -2, 1));
		$s1 = intval(substr($v, -1, 1));
		if ($s2 == 1 || $s1 == 0 || ($s1 > 4 && $s1 <= 9)) return $f3;
		if ($s1 == 1) return $f1;
		if ($s1 >= 2 && $s1 <= 4) return $f2;
	}

$client_counter_query_text="SELECT count(*) AS client_counter FROM clients";
            $client_counter_query=mysqli_query($connector, $client_counter_query_text);
            while($client_counter_data=mysqli_fetch_assoc($client_counter_query)){
$client_counter = $client_counter_data['client_counter'];
              }
$total_money_out_query_text="SELECT sum(payment_summ) AS total_money_out FROM payment_outcoming WHERE payment_stat=2 AND payment_client_id!=1";
            $total_money_out_query=mysqli_query($connector, $total_money_out_query_text);
            while($total_money_out_data=mysqli_fetch_assoc($total_money_out_query)){
$total_money_out = $total_money_out_data['total_money_out']+0;
              }
$total_money_in_query_text="SELECT sum(payment_summ) AS total_money_in FROM payment_incoming WHERE stat=1";
            $total_money_in_query=mysqli_query($connector, $total_money_in_query_text);
            while($total_money_in_data=mysqli_fetch_assoc($total_money_in_query)){
$total_money_in = $total_money_in_data['total_money_in']+0;
              }
//подсчет резерва для выплат (суммируется весь запас золота для покупок)
$total_money_balance = $total_money_in*0.9 - $total_money_out;

echo mysqli_error($connector);
//новые и все входящие сообщения
if(!empty($current_admin_id)){
  //обновление последней активности
$last_activity=mysqli_query($connector, "UPDATE clients SET last_activity=NOW() WHERE client_id=$current_admin_id");
$message_to_query="SELECT * FROM messages WHERE message_to=$current_admin_id AND message_to_stat<>2";
            $message_to_query=mysqli_query($connector, $message_to_query);
            $mtq_count=0;
            while($mtq=mysqli_fetch_assoc($message_to_query)){
                $message_id=$mtq['message_id'];
                $message_from=$mtq['message_from'];
                $message_to=$mtq['message_to'];
                $date_sent=$mtq['date_sent'];
                $date_received=$mtq['date_received'];
                $message_importance=$mtq['message_importance'];
                $message_content=$mtq['message_content'];
                $mtq_count++;
                 }
$new_message_to_query="SELECT * FROM messages WHERE message_to=$current_admin_id AND message_to_stat=0";
            $new_message_to_query=mysqli_query($connector, $new_message_to_query);
            $nmtq_count=0;
            while($nmtq=mysqli_fetch_assoc($new_message_to_query)){
                $message_id=$nmtq['message_id'];
                $message_from=$nmtq['message_from'];
                $message_to=$nmtq['message_to'];
                $date_sent=$nmtq['date_sent'];
                $date_received=$nmtq['date_received'];
                $message_importance=$nmtq['message_importance'];
                $message_content=$nmtq['message_content'];
                $nmtq_count++;
                 }
}
//выключение рабочих просроченных если имеются комбайнов
if(!empty($current_admin_id)){
$stop_old_combines=mysqli_query($connector, "UPDATE client_combines SET stat=0 WHERE end_time<NOW()");
/*сбор всего урожая при наличии комбайна*/

$check_combine_query=mysqli_query($connector, "SELECT * FROM client_combines WHERE client_id='$current_admin_id' AND stat=1");
$check_combine = mysqli_num_rows($check_combine_query);
 while($check_combine_data=mysqli_fetch_assoc($check_combine_query))
           {
              $combine_stop = $check_combine_data['end_time'];
           }
if($check_combine>0){
    //получаем все деревья игрока
    $check_apples_query=mysqli_query($connector, "SELECT client_tree_id FROM trees WHERE client_id='$current_admin_id'");
           while($check_apples_data=mysqli_fetch_assoc($check_apples_query))
           {
    $current_tree_id=$check_apples_data['client_tree_id'];
    $tree_control_query_text="SELECT *, UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(last_free_time) AS harvest_time, NOW() AS ntime FROM trees
    INNER JOIN levels WHERE trees.client_tree_id = $current_tree_id AND levels.level_id = trees.level";
    $tree_control_query = mysqli_query($connector, $tree_control_query_text);
    while($tree_control_data=mysqli_fetch_assoc($tree_control_query)){
                    $start_time     = $tree_control_data['start_time'];
                    $last_free_time = $tree_control_data['last_free_time'];
                    $level          = $tree_control_data['level'];
                    $bonus          = $tree_control_data['bonus'];
                    $harvest        = $tree_control_data['harvest'];
                    $current_htime  = $tree_control_data['harvest_time'];
                    $ntime          = $tree_control_data['ntime'];
                    $current_harvest= floor($current_htime/(60*5))*($harvest+$bonus);
                    }
          if($current_harvest>0){
            /*
              $check_cock_query=mysqli_query($connector, "SELECT * FROM cocks WHERE client_id='$current_admin_id' AND end_time>NOW()");
              $check_cock = mysqli_num_rows($check_cock_query);

              if($check_cock>0) {
                $current_harvest = $current_harvest*1.3;
              }
          */
              $update_apples_query_text = "UPDATE clients SET barrels = barrels+$current_harvest WHERE client_id='$current_admin_id'";
              if($update_apples_query = mysqli_query($connector, $update_apples_query_text)){
                    $update_last_free_time_query_text = "UPDATE trees SET last_free_time = NOW() WHERE client_tree_id='$current_tree_id'";
                    $update_last_free_time_query = mysqli_query($connector, $update_last_free_time_query_text);
                   $harvest_counter += $current_harvest;
              }
          }
    }
    if($harvest_counter>0){
    $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
    barrels, gold, gold_market, add_date) VALUES($current_admin_id, 3, $harvest_counter, 0, 0, NOW())";
    $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
    }
    //когда все плоды собраны производим переадресацию
    //header("Location: ".$_SERVER['HTTP_REFERER']."&success=success_harvest&harvest_counter=".$harvest_counter);

}

/*сбор всего урожая при наличии комбайна*/
$check_autoreferal_query=mysqli_query($connector, "SELECT * FROM autoreferal WHERE client_id='$current_admin_id' AND end_time>NOW()");
$check_autoreferal = mysqli_num_rows($check_autoreferal_query);
 while($check_autoreferal_data=mysqli_fetch_assoc($check_autoreferal_query))
           {
              $autoreferal_stop = $check_autoreferal_data['end_time'];
              $autoreferal_client_counter   = $check_autoreferal_data['client_counter'];
           }
/*
$check_cock_query=mysqli_query($connector, "SELECT * FROM cocks WHERE client_id='$current_admin_id' AND end_time>NOW()");
$check_cock = mysqli_num_rows($check_cock_query);
 while($check_cock_data=mysqli_fetch_assoc($check_cock_query))
           {
              $cock_stop = $check_cock_data['end_time'];
           }
*/
}



/*баннер*/
$banner_query=mysqli_query($connector, "SELECT * FROM banners WHERE start_datetime<NOW() AND end_datetime>NOW()
AND stat=1 ORDER BY lastview ASC LIMIT 1");
 while($banner_data=@mysqli_fetch_assoc($banner_query))
     {
        $cur_banner_id = $banner_data['banner_id'];
        $banner_url = $banner_data['url'];
        $banner_desc = $banner_data['description'];
        $banner_file = $banner_data['file'];
     }
$update_banner_counter_query_text = "UPDATE banners SET counter = counter+1, lastview = NOW() WHERE banner_id=$cur_banner_id";
$update_banner_counter_query=mysqli_query($connector,$update_banner_counter_query_text);
?>
<!DOCTYPE html>
<html>
<head>
	<title><?=$description?></title>

<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="js/jquery-ui-1.8.14.custom.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<META Name="keywords" Content="<?=$keywords?>">
<link rel="shortcut icon" href="images/design/favicon.ico" />
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/jquery.treeview.js"></script>
<script src="js/jquery-ui-all.js"></script>
<script src="js/jquery-ui-widget.js"></script>
<script src="js/jquery-ui-1.8.14.custom.min.js"></script>
<script src="js/jquery.ui.datepicker-ru.js"></script>
<script src="js/style-edit.js"></script>
</head>
<body>

<div id=top></div>
<div id=center><br></div>
<?if($cur_banner_id>0){?>
<div id=banner style="position: absolute; z-index: 1000; text-align: right; width: 1000px; height: 60px; top: 40px;">
<a href="<?=$banner_url?>" target="_blank"><img src="<?="images/banners/".$banner_file?>" width="468" height="60" border="0"
title="<?=$banner_desc?>"></a>
</div>
<?}?>

<div id=main_window>

<?
$login = $_SESSION[$session_login];?>

<div id="mainlinks">
   
</div>

<div id="top_info" style="position: absolute; z-index: 1000; text-align: left; width: 1000px; height: 70px; top: 133px; left: 36px;">

     </div>
  
  
<div style="left: 120.5px;" id="mainlinks1">&nbsp;
<a class="navigate" href="?mode=home">Начало</a><span style="color: #66aa00"> |</span>
<a class="navigate" href="?mode=chat">Чат</a> <span style="color: #66aa00"> |</span>
<a class="navigate" href="?mode=newsline">Новости</a> <span style="color: #66aa00"> |</span>
<a class="navigate" href="?mode=project_info">О проекте</a> <span style="color: #66aa00"> |</span>
<a class="navigate" href="?mode=payments">Выплаты</a><span style="color: #66aa00"> |</span>
<a class="navigate" href="?mode=user_statistic">Статистика</a><span style="color: #66aa00"> |</span>
<a class="navigate" href="?mode=feedback">Отзывы</a><span style="color: #66aa00"> |</span>
<a class="navigate" href="?mode=contacts">Контакты</a>
</div>

<table>
<tr style="vertical-align: top">

<td>
<div id="leftbar">
<?php if (isset($_SESSION[$session_login]) && isset($_SESSION[$session_login])) {?>
<h1>Личный кабинет</h1>
<a class=minilink href="?mode=client_profile"> Мой профиль (<span class=red_text><?=$login?></span>)</a><br>
<a class=minilink href="?mode=incoming_messages"> Мои сообщения<?if($nmtq_count>0){?>(<span class=red_text><?=$nmtq_count?></span>)<?}?></a><br>
<a class=minilink href="?mode=product_base"> Шоколадная Фабрика</a><br>
<a class=minilink href="?mode=shop"> Магазин</a><br>
<a class=minilink href="?mode=market"> Рынок</a><br>
<a class=minilink href="?mode=levels"> Таблица уровней</a><br>
<a class=minilink href="?mode=referals"> Партнерам</a><br>
<a class=minilink href="?mode=money_incoming"> Пополнить баланс</a><br>
<a class=minilink href="?mode=money_outcoming"> Вывод средств</a><br>
<a class=minilink href="?mode=balance_actions"> Операции с балансом</a><br>
<a class=minilink href="?mode=security"> Безопасность</a><br>
<a class=minilink href="?mode=logout"> Выход</a>
<h1>Ваш баланс</h1>
<table border=0px align=left>
  <tr>
  <td>
    <img src="images/design/coins.png" width=50px>
    </td>
    <td>
    <span class=big><?=$current_client_gold_market?></span><span class=small><br>для покупок</span>
    </td>
  </tr>
  <tr>
  <td>
    <img src="images/design/coins.png" width=50px>
  <td>
    <span class=big><?=$current_client_gold?></span><span class=small><br>для покупок и вывода</span>
  </td>
  </tr>
    <tr>
  <td align=center>
      <img src="images/design/almaz.png" width=50>
  <td>
    <span class=big><?=$current_client_barrels?></span><span class=small><br>для покупок и вывода</span>
  </td>
  </tr>
</table>
<?}else{?>
<div id="login_form">
<form name="login_form" method="post" action="auth.php">
<input type="hidden" name="action" value="authorize">
<h1><img src="images/design/keys.gif" width=20px style="vertical-align: middle"> Вход</h1><br>
<table border=0px align=center>
  <tr>
  <td>
    <span class=header>ЛОГИН:</span>
    </td>
    <td>
    <input type=text class=input name="login"><br>
    </td>
  </tr>
  <tr>
  <td>
    <span class=header>ПАРОЛЬ:</span>
  </td>
  <td>
    <input class=input name=password type=password>
  </td>
  </tr>
  <tr>
  <td colspan=2>
   <input id="submit" value="войти" type=submit>
    </td>
  </tr>
</table>
</form>
<a class=minilink href="?mode=get_password">Забыли пароль?</a> / <a class=minilink href="?mode=register">Присоединиться</a>
<div id="login_info">
<p class=header><b>
<?php if ($_REQUEST['blocked']=="true") {?> Ошибка авторизации!<br>
<?if (isset($_REQUEST['wrong_browser'])){?>К сожалению, корректное функционирование
данной сборки системы не поддерживается в браузере Microsoft Internet Explorer, пожалуйста, используйте для работы в системе другой браузер.<?}?>
<?if (isset($_REQUEST['error_logorpass'])){?>Логин и/или пароль неверны. Попробуйте снова.<?}?>
<?if(isset($_REQUEST['not_activated'])){?>Ваш аккаунт не был активирован, для активации аккаунта
пройдите по ссылке активации, отправленной вам на электронную почту при регистрации.<?}?>
<?if(isset($_REQUEST['ip'])){?>Вы пытаетесь зайти на сайт с ip-адреса <b><?=$_REQUEST['ip'];?></b>, который не входит в список дозволенных ip-адресов.
Для получения доступа к системе обратитесь к администратору.<?}?><br>
<?if(isset($_REQUEST['banned'])){?>Вы был закрыт доступ к системе, для получения доступа к системе обратитесь к администратору.<?}?>
<?}?></b>
</p>
</div>
</div>
<?}?>
<h1>Информация</h1>
<?
$server_time_query=mysqli_query($connector, "SELECT NOW() AS server_time");
        while($server_time_data=mysqli_fetch_assoc($server_time_query)){
            $server_time = $server_time_data['server_time'];
}
?>
<p class=small><img src="/images/icons/user.png"/>&nbsp;Количество игроков : <b><?=$client_counter+$user_count?></b></p>
<p class=small><img src="/images/icons/money_dollar.png"/>&nbsp;Выплачено : <b><?=$total_money_out?> руб.</b></p>
<p class=small><img src="/images/icons/coins.png"/>&nbsp;Резерв : <b><?=$total_money_balance-$reserv_change?> руб.</b></p>
<p class=small><img src="/images/icons/alarm.png"/>&nbsp;Проект работает : <b><?=$start_day." ".word_render('день','дня','дней',$start_day);?></b></p>
<p class=small><img src="/images/icons/calendar_1.png"/>&nbsp;Сейчас : <b><?=rus_calendar($server_time)?></b></p>
<!--LiveInternet Counter Goes Here-->
<?/*
<!-- begin WebMoney Transfer : accept label -->
<a href="http://www.megastock.ru/" target="_blank"><img src="/images/design/webmoney.png" alt="www.megastock.ru" border="0"></a>
<!-- end WebMoney Transfer : accept label -->
<!-- begin WebMoney Transfer : attestation label -->
<a href="http://passport.webmoney.ru/asp/certview.asp?wmid=795116370657" target="_blank"><img src="images/design/webmoney2.png" border="0"></a>
<!-- end WebMoney Transfer : attestation label -->*/
?>
<br>
<a class=minilink href="?mode=request_link"><img src="images/design/coins.png" border=0px style="vertical-align: top" width=25px> Заказать показ ссылок</a><br>

<?
/*показ ссылки*/
$link_query=mysqli_query($connector, "SELECT * FROM links WHERE start_datetime<NOW() AND end_datetime>NOW()
AND stat=1 ORDER BY lastview ASC LIMIT 40");
 while($link_data=mysqli_fetch_assoc($link_query))
     {
        $cur_link_id = $link_data['link_id'];
        $link_url = $link_data['url'];
        $link_desc = $link_data['description'];
?>
<div style="width: 245px; height: 30px; display: inline-table; border: 1px dashed #ccc; margin-bottom: 2px"><a href="external_link.php?link_id=<?=$cur_link_id?>" class="minilink" target="_blank"><?=$link_desc?></a></div>
<?
$update_banner_counter_query_text = "UPDATE links SET counter = counter+1, lastview = NOW() WHERE link_id=$cur_link_id";
$update_banner_counter_query=mysqli_query($connector,$update_banner_counter_query_text);
}?>
</div>
</td>
<td>
<div id="rightbar">
<?php if (($mode=="home") or (empty($mode))){
  require_once ("home.php");
}
if ($mode=="feedback"){
  require_once ("feedback.php");
}
if ($mode=="register_complete"){
  require_once ("user_register_complete.php");
}
if ($mode=="register_last_step"){
  require_once ("user_register_last_step.php");
}
if ($mode=="register"){
  require_once ("register.php");
}
if ($mode=="chat"){
  require_once ("chat.php");
}
if ($mode=="product_base"){
  require_once ("product_base.php");
}
if ($mode=="levels"){
  require_once ("levels.php");
}
if ($mode=="product_manager"){
  require_once ("product_manager.php");
}
if ($mode=="market"){
  require_once ("market.php");
}
if ($mode=="shop"){
  require_once ("shop.php");
}
if ($mode=="balance_actions"){
  require_once ("balance_actions.php");
}
if ($mode=="money_incoming"){
  require_once ("money_incoming.php");
}
if ($mode=="money_outcoming"){
  require_once ("money_outcoming.php");
}
if ($mode=="payment_failed"){
  require_once ("payment_failed.php");
}
if ($mode=="payment_success"){
  require_once ("payment_success.php");
}
if ($mode=="security"){
  require_once ("security.php");
}
if ($mode=="change_password"){
  require_once ("change_password.php");
}
if ($mode=="change_mail"){
  require_once ("change_mail.php");
}
if ($mode=="incoming_messages"){
  require_once ("incoming_messages.php");
}
if ($mode=="outcoming_messages"){
  require_once ("outcoming_messages.php");
}
if ($mode=="new_message"){
  require_once ("new_message.php");
}
if ($mode=="client_profile"){
  require_once ("client_profile.php");
}
if ($mode=="user_online"){
  require_once ("online.php");
}
if ($mode=="banned"){
  require_once ("banned.php");
}
if ($mode=="referals"){
  require_once ("referals.php");
}
if ($mode=="contacts"){
  require_once ("contacts.php");
}
if ($mode=="newsline"){
  require_once ("newsline.php");
}
if ($mode=="project_info"){
  require_once ("project_info.php");
}
if ($mode=="payments"){
  require_once ("payments.php");
}
 if ($mode=="top"){
  require_once ("user_top.php");
}
 if ($mode=="request_banner"){
  require_once ("request_banner.php");
}
 if ($mode=="request_link"){
  require_once ("request_link.php");
}
 if ($mode=="request_mailer"){
  require_once ("request_mailer.php");
}
 if ($mode=="check_link"){
  require_once ("check_link.php");
}
 if ($mode=="check_banner"){
  require_once ("check_banner.php");
}
 if ($mode=="get_password"){
  require_once ("get_password.php");
}
 if ($mode=="wm_payment"){
  require_once ("wm_payment.php");
}
if ($mode=="wm_payment_failed"){
  require_once ("wm_payment_failed.php");
}
if ($mode=="wm_payment_success"){
  require_once ("wm_payment_success.php");
}
if ($mode=="user_statistic"){
  require_once ("user_statistic.php");
}
?>
</div>
</td>
</tr>
</table>
</div>
<div id=contacts style="text-align: center">
<h1><span class=header>&copy; <?=$sitename?> 2013г All Rights Reserved.</span></h1>
</div>

</body>
</html>
