<?if($_REQUEST['user_id']>0){
$curr_user_id=$_REQUEST['user_id'];
$admin_users_query_text="SELECT * FROM clients WHERE client_id=$curr_user_id";
$admin_users_query=mysqli_query($connector, $admin_users_query_text);
$sex[1] = "images/design/male.png";
$sex[2] = "images/design/female.png";
$sex_text[1] = "мужской";
$sex_text[2] = "женский";
while($admin_users_data=mysqli_fetch_assoc($admin_users_query)){
    $cur_admin_login        =   $admin_users_data['login'];
    $cur_admin_sex          =   $admin_users_data['client_sex'];
    $cur_admin_fio          =   $admin_users_data['client_fio'];
    $cur_admin_stat         =   $admin_users_data['client_stat'];
    $cur_admin_referal      =   $admin_users_data['client_referal'];
    $cur_client_apples      =   $admin_users_data['barrels'];
    $cur_client_gold        =   $admin_users_data['gold'];
    $cur_client_gold_market =   $admin_users_data['gold_market'];
    $cur_client_mail        =   $admin_users_data['client_mail'];
    $cur_client_skype       =   $admin_users_data['client_skype'];
    $cur_client_icq         =   $admin_users_data['client_icq'];
    $cur_client_phone       =   $admin_users_data['client_phone_number'];
    $cur_client_city        =   $admin_users_data['client_city'];
    $cur_client_avatar      =   $admin_users_data['client_avatar'];
    $cur_client_add_date    =   $admin_users_data['add_date'];
    $cur_client_last_act    =   $admin_users_data['last_activity'];
    $cur_client_bday        =   $admin_users_data['client_bday'];
$cur_admin_referal_query_text="SELECT login FROM clients WHERE client_id=$cur_admin_referal";
$cur_admin_referal_query=mysqli_query($connector, $cur_admin_referal_query_text);
while($cur_admin_referal_data=mysqli_fetch_assoc($cur_admin_referal_query)){
     $cur_admin_referal_login = $cur_admin_referal_data['login'];
 }
    }
?>
<h1>Игрок → <?=$cur_admin_fio?>[<?=$cur_admin_login?>]</h1>

<div class=info_block style="display: inline-table; width: 280px; height:800px; vertical-align: top">
<p class=middle>Общая информация</p>
<table width=280px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=75px><p class="admin_table_text"><b>ID игрока:</b></p></td>
<td width=100px><p class="admin_table_text">логин игрока:</p></td>
<td width=100px><p class="admin_table_text">Пригласил:</p></td>

</tr>
<tr>
<td width=75px><p class="inwork admin_table_text"><b><?=$curr_user_id?></b></p></td>
<td width=100px><p class="inwork admin_table_text"><b><?=$cur_admin_login?></b></p></td>
<td width=100px><p class="inwork admin_table_text"><b><?=$cur_admin_referal_login?></b></p></td>

</tr>
</table>
<table width=280px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=140px><p class="admin_table_text"><b>Последняя<br> активность:</b></p></td>
<td width=180px><p class="inwork admin_table_text"><b><?=rus_calendar($cur_client_last_act)?></b></p></td>
</tr>
</table>
<table width=280px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=80px><p class="admin_table_text"><b>Пол:</b></p></td>
<td width=120px><p class="admin_table_text">Дата рождения:</p></td>
<td width=120px><p class="admin_table_text">Добавлен(а) в систему:</p></td>
</tr>
<tr>
<td width=80px><img src="<?=$sex[$cur_admin_sex]?>" alt="<?=$sex_text[$cur_admin_sex]?>" title="<?=$sex_text[$cur_admin_sex]?>"></td>
<td width=120px><p class="inwork admin_table_text"><b><?=$cur_client_bday?></b></p></td>
<td width=120px><p class="inwork admin_table_text"><b><?=$cur_client_add_date?></b></p></td>

</tr>
</table>

<table width=280px border=0px cellpadding=2px cellspasing=0px class=no_orange style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=150px><p class="admin_table_text"><b>Город:</b></p></td>
<td width=150px><p class="admin_table_text"><b>Телефон:</b></p></td>
</tr>
<tr>
<td width=150px>
<p class="inwork admin_table_text"><b><?=$cur_client_city?></b></p>
</td>
<td width=160px>
<p class="inwork admin_table_text"><b><?=$cur_client_phone?></b></p>
</td>
</tr>
</table>

<table width=280px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 2px;">
<tr>
<td width=150px>
    <p class="admin_table_text"><b>Электронная почта:</b></p>
</td>
<td width=150px>
    <p class="inwork admin_table_text"><b><?=$cur_client_mail?></b></p>
</td>
</tr>
<tr>
<td width=150px>
    <p class="admin_table_text"><b>Icq:</b></p>
</td>
<td width=150px>
    <p class="inwork admin_table_text"><b><?=$cur_client_icq?></b></p>
</td>
</tr>
<tr>
<td width=150px>
    <p class="admin_table_text"><b>Skype:</b></p>
</td>
<td width=150px>
    <p class="inwork admin_table_text"><b><?=$cur_client_skype?></b></p>
</td>
</tr>
</table>
<?
$chat_message_counter_query_text="SELECT count(*) AS counter FROM chat WHERE client_id=$curr_user_id";
$chat_message_counter_query = mysqli_query($connector, $chat_message_counter_query_text);
while($chat_message_counter_data=mysqli_fetch_assoc($chat_message_counter_query)){
 $chat_message_counter = $chat_message_counter_data['counter'];
  }
  ?>
<table width=280px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=270px><p class=admin_table_text><b>Сообщений на форуме:</b></p></td>
<td width=50px><p class="admin_table_text inwork"><b><?=$chat_message_counter?></b></p></td>
</tr>
</table>
<table width=280px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 2px;">
<tr>
<td width=280px>
    <p class="admin_table_text"><b>Рефералы:</b></p>
    <?$balance_actions_query_text="SELECT sum(gold) as sum_gold FROM balance_actions WHERE client_id = $curr_user_id AND (action_type = 8 OR
action_type = 9)";
$balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
while($balance_actions_data=mysqli_fetch_assoc($balance_actions_query)){
   $gold        = $balance_actions_data['sum_gold'];
}if($gold>0){?>
<p class=small style="text-align: center">Рефералы принесли игроку <?=$gold?> золота.</p>
<?}
$ref_counter=0;
$referer_users_query_text="SELECT client_id, login FROM clients WHERE client_referal=$curr_user_id";
$referer_users_query=mysqli_query($connector, $referer_users_query_text);
while($referer_users_data=mysqli_fetch_assoc($referer_users_query)){
$ref_counter++;
$ref_id     = $referer_users_data['client_id'];
$ref_login  = $referer_users_data['login'];
?>
<a class="minilink" href="adminka.php?mode=users&user_id=<?=$ref_id?>"><b class=inwork><?=$ref_name?>[<?=$ref_login?>]</b></a>
<?}
if($ref_counter==0){?><p class=admin_table_text style="text-align: center">отсутствуют</p><?}?>
</td>
</tr>
</table>
</div>

<div class=info_block style="display: inline-table; width: 330px;height: 800px; vertical-align: top">
<p class=middle>Статистика и бан</p>
<table width=320px border=0px cellpadding=0px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=40px><img src="images/design/almaz.png" width=15px></td>
<td width=110px><p class="admin_table_text"><img src="images/design/coins.png" width=22px> для покупок:</p></td>
<td width=170px><p class="admin_table_text"><img src="images/design/coins.png" width=22px> для покупок и вывода:</p></td>
</tr>
<tr>
<td width=40px><p class="inwork admin_table_text"><b><?=$cur_client_apples?></b></p></td>
<td width=110px><p class="inwork admin_table_text"><b><?=$cur_client_gold_market?></b></p></td>
<td width=170px><p class="inwork admin_table_text"><b><?=$cur_client_gold?></b></p></td>
</tr>
</table>
<?
$user_payment_summ_query_text="SELECT sum(payment_summ) AS total_user_payment_summ FROM payment_outcoming
WHERE payment_stat=2 AND payment_client_id=$curr_user_id";
$user_payment_summ_query = mysqli_query($connector, $user_payment_summ_query_text);
while($user_payment_summ_data=mysqli_fetch_assoc($user_payment_summ_query)){
 $user_payment_summ = $user_payment_summ_data['total_user_payment_summ']+0;
  }
  ?>
<table width=320px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=270px><p class=admin_table_text><b>Выведено средств из игры (руб):</b></p></td>
<td width=50px><p class="admin_table_text inwork"><b><?=$user_payment_summ?></b></p></td>
</tr>
</table>
<?
$user_payment_summ_query_text="SELECT sum(payment_summ) AS total_user_payment_summ FROM payment_incoming
WHERE stat=1 AND payment_client_id=$curr_user_id";
$user_payment_summ_query = mysqli_query($connector, $user_payment_summ_query_text);
while($user_payment_summ_data=mysqli_fetch_assoc($user_payment_summ_query)){
 $user_payment_summ = $user_payment_summ_data['total_user_payment_summ']+0;
  }
  ?>
<table width=320px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=270px><p class=admin_table_text><b>Внесено средств в игру (руб):</b></p></td>
<td width=50px><p class="admin_table_text inwork"><b><?=$user_payment_summ?></b></p></td>
</tr>
</table>
<p class=middle>Ульи</p>

<table width=320px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=70px><p class=admin_table_text>Уровень:</p></td>
<td width=80px><p class=admin_table_text>Куплено:</p></td>
<td width=170px><p class=admin_table_text>Срок жизни (дней):</p></td>
</tr>
<?
//$tree_control_query_text = "SELECT client_id FROM trees WHERE tree_id = "
$tree_control_query_text="SELECT *, UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(last_free_time) AS harvest_time,
UNIX_TIMESTAMP(tree_lifetime) - UNIX_TIMESTAMP(NOW()) AS tree_lifetime_sec,
NOW() AS ntime FROM trees INNER JOIN levels
WHERE trees.client_tree_id IN (SELECT client_tree_id FROM trees WHERE client_id=$curr_user_id) AND levels.level_id = trees.level";
$tree_control_query = mysqli_query($connector, $tree_control_query_text);
while($tree_control_data=mysqli_fetch_assoc($tree_control_query)){
                $start_time     = $tree_control_data['start_time'];
                $last_free_time = $tree_control_data['last_free_time'];
                $level          = $tree_control_data['level'];
                $harvest        = $tree_control_data['harvest'];
                $current_htime  = $tree_control_data['harvest_time'];
                $tree_lifetime_sec  = $tree_control_data['tree_lifetime_sec'];
                $ntime          = $tree_control_data['ntime'];
                $current_harvest= floor($current_htime/(60*5))*$harvest;
                $tree_lifetime_sec = floor($tree_lifetime_sec/(60*60*24));
?>

<tr>
<td width=70px><p class=admin_table_text><b><?=$level?></b></p></td>
<td width=80px><p class=admin_table_text><b><?=substr($start_time, 0, 11);?></b></p></td>
<td width=170px><p class=admin_table_text><b><?=$tree_lifetime_sec?></b></p></td>
</tr>
<?}?>
</table>

<p class=middle>Автореферал</p>

<table width=320px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td><p class=admin_table_text>От:</p></td>
<td><p class=admin_table_text>До:</p></td>
<td width=50px><p class=admin_table_text>Удалить:</p></td>
</tr>
<?
//$tree_control_query_text = "SELECT client_id FROM trees WHERE tree_id = "
$autoref_query_text="SELECT * FROM autoreferal WHERE client_id=$curr_user_id";
$autoref_query = mysqli_query($connector, $autoref_query_text);
while($autoref_data=mysqli_fetch_assoc($autoref_query)){
        $autoref_id     = $autoref_data['autoref_id'];
        $start_time     = $autoref_data['start_time'];
        $end_time       = $autoref_data['end_time'];
        $client_counter = $autoref_data['client_counter'];
?>

<tr>
<td><p class=admin_table_text><b><?=rus_calendar($start_time);?></b></p></td>
<td><p class=admin_table_text><b><?=rus_calendar($end_time);?></b></p></td>
<td width=50px><a class="minilink" href="user_data_form.php?action=delete_auturef&autoref_id=<?=$autoref_id?>&user_id=<?=$curr_user_id?>"><img src="images/design/delete.png" width=16px></a></td>
</tr>
<?}?>
</table>

<p class=middle>Помощники</p>

<table width=320px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td><p class=admin_table_text>От:</p></td>
<td><p class=admin_table_text>До:</p></td>
<td width=50px><p class=admin_table_text>Удалить:</p></td>
</tr>
<?
//$tree_control_query_text = "SELECT client_id FROM trees WHERE tree_id = "
$autoref_query_text="SELECT * FROM client_combines WHERE client_id=$curr_user_id";
$autoref_query = mysqli_query($connector, $autoref_query_text);
while($autoref_data=mysqli_fetch_assoc($autoref_query)){
        $autoref_id     = $autoref_data['client_combine_id'];
        $start_time     = $autoref_data['start_time'];
        $end_time       = $autoref_data['end_time'];
        $client_counter = $autoref_data['client_counter'];
?>

<tr>
<td><p class=admin_table_text><b><?=rus_calendar($start_time);?></b></p></td>
<td><p class=admin_table_text><b><?=rus_calendar($end_time);?></b></p></td>
<td width=50px><a class="minilink" href="user_data_form.php?action=delete_auturef&client_combine_id=<?=$autoref_id?>&user_id=<?=$curr_user_id?>"><img src="images/design/delete.png" width=16px></a></td>
</tr>
<?}?>
</table>

<p class=middle>Бан</p>
<?
$user_ban_query_text="SELECT * FROM user_ban_list WHERE user_id=$curr_user_id";
$user_ban_query = mysqli_query($connector, $user_ban_query_text);
while($user_ban_data=mysqli_fetch_assoc($user_ban_query)){
 $ban_end = $user_ban_data['ban_end'];
 $ban_start = $user_ban_data['ban_start'];
 $ban_couse = $user_ban_data['ban_couse'];
  }
if(!empty($ban_end)){?>
<p class="admin_table_text attention"><b>Забанен от: <?=rus_calendar($ban_start)?></b></p>
<p class="admin_table_text attention"><b>Забанен до: <?=rus_calendar($ban_end)?></b></p>
<p class="admin_table_text attention"><b>Причина: <?=$ban_couse?></b></p>
<br>
<a class="minilink" href="user_ban_form.php?action=delete_ban&user_id=<?=$curr_user_id?>"><img src="images/design/delete.png" width=16px>
<span class=attention> снять бан</span></a>

<?}?>
<form action="user_ban_form.php" method="post">
<input type=hidden name=user_id value="<?=$curr_user_id?>">
<input type=hidden name=action value="user_ban">
<table width=320px border=0px cellpadding=2px cellspasing=0px class=no_orange style="border: 1px solid #ccc; margin: 4px;">
<tr>
<td width=80px><p class=admin_table_text><b>Годы:</b></p></td>
<td width=80px><p class=admin_table_text><b>Дни:</b></p></td>
<td width=80px><p class=admin_table_text><b>Часы:</b></p></td>
<td width=80px><p class=admin_table_text><b>Минуты:</b></p></td>
</tr>
<tr>
<td width=80px>
<select name="years" style="width: 70px">
<?for ($i=0;$i<=10;$i++) {?>
<option value="<?=$i?>"><?=$i?></option>
<?}?>
</select>
</td>
<td width=80px>
<select name="days" style="width: 70px">
<?for ($i=0;$i<=364;$i++) {?>
<option value="<?=$i?>"><?=$i?></option>
<?}?>
</select>
</td>
<td width=80px>
<select name="hours" style="width: 70px">
<?for ($i=0;$i<=23;$i++) {?>
<option value="<?=$i?>"><?=$i?></option>
<?}?>
</select>
</td>
<td width=80px>
<select name="minutes" style="width: 70px">
<?for ($i=0;$i<=59;$i++) {?>
<option value="<?=$i?>"><?=$i?></option>
<?}?>
</select>
</td>
</tr>
<tr>
<td colspan=4>
<textarea name="ban_couse" style="width: 300px; height: 60px" placeholder="опишите причину бана"></textarea>
</td>
</tr>
</table>
<div style="text-align: center; margin: auto"><input type=submit value="Забанить" class=input_button></div>
</form>





<p class=middle>Переписка с игроком</p>
<table width=320px border=0px cellpadding=2px cellspasing=0px>
<? $incoming_messages_query=mysqli_query($connector, "SELECT message_to, message_content,
    date_sent, message_id, message_to_stat, message_from FROM messages WHERE (messages.message_to = 1
    AND messages.message_from=$curr_user_id) OR (messages.message_to = $curr_user_id
    AND messages.message_from=1) AND messages.message_to_stat<>2 ORDER BY date_sent DESC");
    while($incoming_messages_data = mysqli_fetch_assoc($incoming_messages_query)) {
     $current_message = $incoming_messages_data['message_content'];
     $current_date_sent = $incoming_messages_data['date_sent'];
     $current_message_id = $incoming_messages_data['message_id'];
     $current_message_from = $incoming_messages_data['message_from'];
     $current_message_stat = $incoming_messages_data['message_to_stat'];?>
    <tr valign=top style="vertical-align: top;">

    <td style="text-align: left; vertical-align: top">
    <p class="small"><b><?if($current_message_from==1) echo "<u>от Вас</u>"; else echo "<u>Вам</u>";?></b></p></td>
    <td style="text-align: left; vertical-align: top">
    <p class="small"><b><?=rus_calendar($current_date_sent)?></b></p></td>
    <td style="vertical-align: top" width=120px><a href="message_delete_form.php?action=delete_received_message&message_id=<?=$current_message_id?>" class=minilink>удалить сообщение</a></td>
    </tr>
    <tr valign=top style="vertical-align: top;">
    <td colspan=2>
    <p class=small>
    <? $current_message_text=preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a class=minilink href="\\0">\\0</a>',$current_message);
    echo $current_message_text;
    ?></p></td>
    </tr>
<?}?>
</table>

<p class=middle>Написать новое сообщение:</p>

<form name="new_message_form" method="get" action="adminka.php">
<input type=hidden name="action" value="send">
<input name=message_to type=hidden value='<?=$curr_user_id?>'>
<table width=300px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px; text-align: left">
<tr valign=top style="vertical-align: top"><td>
<p class="small">Ваше сообщение:</p>
<textarea name=message_content style="width: 300px; height: 160px"></textarea>
</td>
</tr>
</table>
<input type=submit value="Отправить">
</form>





<form action="user_ban_form.php" method="post">
<input type=hidden name=user_id value="<?=$curr_user_id?>">
<input type=hidden name=action value="full_delete">
<br>
<input type=submit value="Полностью удалить игрока и все данные" class=input_button style="width: 300px">
</form>
</div>

<div class=info_block style="display: inline-table; width: 340px; height: 800px; vertical-align: top">
<p class=middle>Пополнение счета игрока (золото для покупок)</p>
<form name="payment" action="admin_money_payments_form.php" method="get">
<input type="hidden" name="action" value="money_incoming">
<input type="hidden" name="user_id" value="<?=$curr_user_id?>">
<input type="text" name="payment_amount" value="" placeholder="введите сумму в рублях" style="width: 160px" >
<select name="payment_system">
<option value=1>Интеркасса</option>
<option value=2>Яндекс-деньги</option>
<option value=3>Мобильный телефон</option>
<option value=4>liqpay.com</option>
<option value=5>Qiwi-кошелек</option>
<option value=6>Webmoney</option>
<option value=10>Perfect Money</option>
</select>
<input type="submit" value="Пополнить счет" class=input_button style="width: 150px">
</form>
<p class=middle>Пополнение (золото для вывода)</p>
<form name="payment" action="admin_money_payments_form.php" method="get">
<input type="hidden" name="action" value="increase_gold">
<input type="hidden" name="user_id" value="<?=$curr_user_id?>">
<input type="text" name="payment_amount" value="" placeholder="введите сумму в рублях" style="width: 160px" >
<input type="submit" value="Пополнить" class=input_button style="width: 150px">
</form>

<p class=middle>Изьятие (золото для покупок)</p>
<form name="payment" action="admin_money_payments_form.php" method="get">
<input type="hidden" name="action" value="decrease_gold_market">
<input type="hidden" name="user_id" value="<?=$curr_user_id?>">
<input type="text" name="payment_amount" value="" placeholder="введите сумму в рублях" style="width: 160px" >
<input type="submit" value="Изьять" class=input_button style="width: 150px">
</form>

<p class=middle>Изьятие (золото для вывода)</p>
<form name="payment" action="admin_money_payments_form.php" method="get">
<input type="hidden" name="action" value="decrease_gold">
<input type="hidden" name="user_id" value="<?=$curr_user_id?>">
<input type="text" name="payment_amount" value="" placeholder="введите сумму в рублях" style="width: 160px" >
<input type="submit" value="Изьять" class=input_button style="width: 150px">
</form>
_____________________________________
<p class=middle>Последние операции с балансом</p>
<table width=330px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px; text-align: left">
    <tr align="left">
        <td><p class=admin_table_text>Дата</p></td>
        <td><p class=admin_table_text>Сумма</p></td>
        <td><p class=admin_table_text>Операция</p></td>
    </tr>
<?
$action[1] = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> Продажа шоколада";
$action[2] = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> Сбор шоколада";
$action[3] = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> Сбор шоколада со всех фабрик";
$action[4] = "Перевод золота на счет для покупок";
$action[5] = "Покупка Шоколадной Фабрики";
$action[6] = "Повышение уровня Шоколадной Фабрики";
$action[7] = "Пополнение баланса с реквизитов";
$action[8] = "Доход от реферала (апгрейд Шоколадной Фабрики)";
$action[9] = "Доход от реферала (покупка Шоколадной Фабрики)";
$action[10] = "Аренда автосборщика шоколада";
$action[11] = "Приобретение автореферала";
$action[20] = "Вывод средств";

$balance_actions_query_text="SELECT * FROM balance_actions WHERE client_id = $curr_user_id ORDER BY add_date DESC";
$balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
while($balance_actions_data=mysqli_fetch_assoc($balance_actions_query)){
   $add_date    = $balance_actions_data['add_date'];
   $action_type = $balance_actions_data['action_type'];
   $apples      = $balance_actions_data['barrels'];
   $gold        = $balance_actions_data['gold'];
   $gold_market = $balance_actions_data['gold_market'];
$sum[1]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'>+".$gold;
$sum[2]    = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'>+".$apples;
$sum[3]    = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'>+".$apples;
$sum[4]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[5]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[6]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[7]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold_market;
$sum[8]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[9]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[10]   = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[11]   = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[12]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[13]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[14]   = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> ".$apples;
$sum[15]   = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> ".$apples;
$sum[20]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> -".$gold;

?>

    <tr align="left">
        <td><p class=admin_table_text><?=$add_date?></p></td>
        <td><p class=admin_table_text><?=$sum[$action_type]?></p></td>
        <td><p class=admin_table_text><?=$action[$action_type]?></p></td>
    </tr>
<?}?>
</table>
</div>



<?}elseif(empty($_REQUEST['user_id'])){?>
<h1>Игроки</h1>
<?
$search_user = $_REQUEST['search_user'];
if(!empty($search_user)){
$admin_users_query_text="SELECT * FROM clients WHERE login LIKE '%$search_user%' ORDER By $users_select_sort $users_select_direction LIMIT $users_select_count";
}
else{
$admin_users_query_text="SELECT * FROM clients ORDER By $users_select_sort $users_select_direction LIMIT $users_select_count";
}
$admin_users_query=mysqli_query($connector, $admin_users_query_text);
$admin_users_count=mysqli_num_rows($admin_users_query);
?>
<div>
<form name="users_sort" action="adminka.php" method="get">
<input type=hidden name="action" value="sort_users">
<table cellpadding=2px cellspacing=0px style="text-align: center">
<tr>
    <td width=100px>
<p class="small">Сортировать по</p></td>
<td width=150px>
<div class="transparent">
<select name=select_sort_users onchange="if(this.options[this.selectedIndex].value != -1){ document.users_sort.submit() }">
<option value=login <? if($users_select_sort=="login") echo "selected";?>>Логину игрока</option>
<option value=barrels <? if($users_select_sort=="barrels") echo "selected";?>>Кол-ву золота</option>
<option value=gold <? if($users_select_sort=="gold") echo "selected";?>>Кол-ву золота для покупок/вывода</option>
<option value=gold_market <? if($users_select_sort=="gold_market") echo "selected";?>>Кол-ву золота для покупок</option>
<option value=client_phone_number <? if($users_select_sort=="client_phone_number") echo "selected";?>>Номеру телефона</option>
<option value=add_date <? if($users_select_sort=="add_date") echo "selected";?>>Дате регистрации</option>
<option value=last_activity <? if($users_select_sort=="last_activity") echo "selected";?>>Последней активности</option>
</select>

</div>
</td><td width=80px>
<p class="small"> Отображать </p>
</td><td width=40px>
<div class="transparent">
<select name=select_count_users onchange="if(this.options[this.selectedIndex].value != -1){ document.users_sort.submit() }">
<option value=10 <? if($users_select_count=="10") echo "selected";?>>10</option>
<option value=20 <? if($users_select_count=="20") echo "selected";?>>20</option>
<option value=40 <? if($users_select_count=="40") echo "selected";?>>40</option>
<option value=99999999 <? if($users_select_count=="99999999") echo "selected";?>>Все</option>
</select>

</div>
</td><td width=170px>
<p class="small"> клиентов. Упорядочить по
</p>
</td>
<td width=120px>
<div class="transparent">
<select name=select_direction_users onchange="if(this.options[this.selectedIndex].value != -1){ document.users_sort.submit() }">
<option value=asc <? if($users_select_direction=="asc") echo "selected";?>>Увеличению</option>
<option value=desc <? if($users_select_direction=="desc") echo "selected";?>>Уменьшению</option>
</select>
</div>
</td>
<td>
<input id="client_search" name=client_search placeholder='Введите имя/логин' style="width: 110px">
<!--<input type=button id="client_search_button" value="Искать"> -->
</td>
</tr>
</table>
</form>
</div>
<table border="0" width="990" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Логин</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Пол</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>e-mail</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Номер телефона</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Регистрация</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Был(а) на сайте</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Подробный профиль</td></tr></table></td>
    </tr>
<?
$sex[1] = "images/design/male.png";
$sex[2] = "images/design/female.png";
while($admin_users_data=mysqli_fetch_assoc($admin_users_query)){
    $cur_admin_id           =   $admin_users_data['client_id'];
    $cur_admin_login        =   $admin_users_data['login'];
    $cur_admin_sex          =   $admin_users_data['client_sex'];
    $cur_admin_fio          =   $admin_users_data['client_fio'];
    $cur_admin_stat         =   $admin_users_data['client_stat'];
    $cur_client_apples      =   $admin_users_data['barrels'];
    $cur_client_gold        =   $admin_users_data['gold'];
    $cur_client_gold_market =   $admin_users_data['gold_market'];
    $cur_client_mail        =   $admin_users_data['client_mail'];
    $cur_client_skype       =   $admin_users_data['client_skype'];
    $cur_client_icq         =   $admin_users_data['client_icq'];
    $cur_client_phone       =   $admin_users_data['client_phone_number'];
    $cur_client_city        =   $admin_users_data['client_city'];
    $cur_client_avatar      =   $admin_users_data['client_avatar'];
    $cur_client_add_date    =   $admin_users_data['add_date'];
    $cur_client_last_act    =   $admin_users_data['last_activity'];
//payment_client_id
?>

    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><a class=minilink href="adminka.php?mode=users&user_id=<?=$cur_admin_id?>"><b><?=$cur_admin_login?></b></a></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><img src="<?=$sex[$cur_admin_sex]?>" alt="мужской" title="мужской"></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$cur_client_mail?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$cur_client_phone?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=rus_calendar($cur_client_add_date)?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=rus_calendar($cur_client_last_act)?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><a href="adminka.php?mode=users&user_id=<?=$cur_admin_id?>"><img src="images/design/setup.png"></a></td></tr></table></td>
    </tr>
<?}?>
</table>
<?}?>