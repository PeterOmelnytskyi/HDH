<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("config.php");
require_once ("current_settings.php");
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}

$action         =   $_REQUEST['action'];
$message_from   =   $_REQUEST['message_from'];
$message_to     =   $_REQUEST['message_to'];
$message_content=   $_REQUEST['message_content'];

$message_from = mysqli_real_escape_string($connector,$message_from);
$message_to = mysqli_real_escape_string($connector,$message_to);
$message_content = mysqli_real_escape_string($connector,$message_content);
$error          =   "";
if($action=="send")
	{
		if($message_content=="") $error.="Вы не ввели сообщение<br>";
        if($message_to=="") $error.="Вы не выбрали адресата сообщения<br>";
		if(!empty($error))
		{
			echo "Произошли следующие ошибки: ".$error."<br><a href='index.php?mode=new_message'>вернуться обратно</a>";
			exit();
		}
		$message_sending="INSERT INTO messages (message_from, message_to, message_from_stat, message_to_stat, date_sent, message_content)
        VALUES($current_admin_id, '$message_to', 0, 0, NOW(), '$message_content')";
        $message_sending = mysqli_query($connector, $message_sending);
		$error.=mysqli_error($connector);
		if(empty($error)){
			header("Location: index.php?mode=outcoming_messages&success=true");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
?>