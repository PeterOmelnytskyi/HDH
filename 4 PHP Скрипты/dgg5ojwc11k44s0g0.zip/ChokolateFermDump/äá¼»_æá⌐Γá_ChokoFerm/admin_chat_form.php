<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
$action     = $_REQUEST['action'];
$message_id    = $_REQUEST['message_id'];
$message_text = $_REQUEST['message_text'];
if ((empty($_SESSION["admin_log"])) OR (empty($_SESSION["admin_pass"])))
	{
		die("<script>window.location='admin_init.php';</script>");
	}
if ($mode=="logout")
	{
		$_SESSION["admin_log"] = "";
		$_SESSION["admin_pass"] = "";
		unset($_SESSION["admin_log"]);
		unset($_SESSION["admin_pass"]);
        session_destroy();
		die("<script>window.location='admin_init.php';</script>");
	}
if($action=="add_message"){

        $add_chat_message_query_text="INSERT INTO chat (message_text, message_stat, add_date, client_id)
        VALUES ('".mysqli_real_escape_string($connector, $message_text)."', 1, NOW(), 1)";
        $add_chat_message_query = mysqli_query($connector, $add_chat_message_query_text);
        header("Location: adminka.php?mode=chat");

}
    	if($action=="delete_message")
	{
        if(!empty($message_id)){
            $delete_news_query_text="DELETE FROM chat WHERE message_id = $message_id";
            $delete_news_query = mysqli_query($connector, $delete_news_query_text);
        }
		$error.=mysqli_error($connector);
		if(empty($error)){
			header("Location: adminka.php?mode=chat");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
    	if($action=="delete_feedback")
	{
        if(!empty($message_id)){
            $delete_news_query_text="DELETE FROM feedback WHERE feedback_id = $message_id";
            $delete_news_query = mysqli_query($connector, $delete_news_query_text);
        }
		$error.=mysqli_error($connector);
		if(empty($error)){
			header("Location: adminka.php?mode=chat");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
?>