<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
require_once ("config.php");

$system            = $_REQUEST['system'];
$sid               = $_REQUEST['sid'];
$mode              = $_REQUEST['mode'];
$success           = $_REQUEST['success'];
$admin             = $_REQUEST['admin'];
$tree_id           = $_REQUEST['tree_id'];
$action            = $_REQUEST['action'];
$client_id         = $_REQUEST['client_id'];
$avatar_path       = "images/avatars/";
$default_avatar    = "ava1.gif";
if ((empty($_SESSION["admin_log"])) OR (empty($_SESSION["admin_pass"])))
	{
		die("<script>window.location='admin_init.php';</script>");
	}
if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
if ($mode=="logout")
	{
		$_SESSION["log"] = "";
		$_SESSION["pass"] = "";
         $_SESSION["admin_mode"] =  "";
		unset($_SESSION["log"]);
		unset($_SESSION["pass"]);
        unset($_SESSION["admin_mode"]);
        session_destroy();
		die("<script>window.location='admin_init.php';</script>");
	}

//жесткая установка параметра mode
$valid_mode=array('admin_settings', 'balance_actions', 'settings', 'market', 'help', 'shop', 'statistic', 'clients', 'register', 'register_last_step',
'admin_newsline','chat', 'newsline', 'outcoming_messages', 'payment_failed', 'payment_success', 'payment_controller', 'change_password','change_mail',
 'incoming_messages', 'new_message', 'user_profile', 'money_incoming', 'money_outcoming', 'levels', 'admin_market', 'admin_security', 'client_profile',
 'user_online', 'users', 'banners', 'links','mailer','admin_actions', 'credits');
if((!isset($mode))||(!in_array($mode, $valid_mode)))
{
  header("Location: adminka.php?mode=admin_settings");
}
$settings_query="SELECT * FROM settings";
            $settings_query=mysqli_query($connector, $settings_query);
            while($settings=mysqli_fetch_assoc($settings_query)){
$timezone                   =   $settings['timezone'];
$apples_per_gold            =   $settings['apples_per_gold'];
$description                =   $settings['description'];
$total_money_balance_percent=   $settings['total_money_balance_percent'];
$keywords                   =   $settings['keywords'];
$admin_mail                 =   $settings['admin_mail'];
$apples_per_message         =   $settings['apples_per_message'];
$client_max_trees           =   $settings['client_max_trees'];
$rub_usd                    =   $settings['rub_usd'];
$harvest_time               =   $settings['harvest_time'];
$tree_lifetime              =   $settings['tree_lifetime'];
$reserv_change              =   $settings['reserv_change'];
$combine_price              =   $settings['combine_price'];
$autoreferal_price          =   $settings['autoreferal_price'];
$banner_per_day             =   $settings['banner_per_day'];
$link_per_day               =   $settings['link_per_day'];
$mailer_price               =   $settings['mailer_price'];
$user_count                 =   $settings['user_count'];
$ticket_price               =   $settings['ticket_price'];
}
$client_counter_query_text="SELECT count(*) AS client_counter FROM clients";
            $client_counter_query=mysqli_query($connector, $client_counter_query_text);
            while($client_counter_data=mysqli_fetch_assoc($client_counter_query)){
$client_counter = $client_counter_data['client_counter'];
              }
$total_money_out_query_text="SELECT sum(payment_summ) AS total_money_out FROM payment_outcoming WHERE payment_stat=2";
            $total_money_out_query=mysqli_query($connector, $total_money_out_query_text);
            while($total_money_out_data=mysqli_fetch_assoc($total_money_out_query)){
$total_money_out = $total_money_out_data['total_money_out']+0;
              }
$total_money_in_query_text="SELECT sum(payment_summ) AS total_money_in FROM payment_incoming WHERE stat=1";
            $total_money_in_query=mysqli_query($connector, $total_money_in_query_text);
            while($total_money_in_data=mysqli_fetch_assoc($total_money_in_query)){
$total_money_in = $total_money_in_data['total_money_in']+0;
              }
//подсчет резерва для выплат (суммируется весь запас золота для покупок)
$total_money_balance = $total_money_in - $total_money_out;
$login=$_SESSION["admin_log"];
$cur_admin_id=mysqli_query($connector, "SELECT admin_id, admin_fio, stat FROM admin WHERE login='$login'");
while($cai=mysqli_fetch_assoc($cur_admin_id)){
                $current_admin_id=$cai['admin_id'];
                $current_admin_fio=$cai['admin_fio'];
                $current_admin_stat=$cai['stat'];
                 }
echo mysqli_error($connector);


if($action=="edit_outcoming_payment"){
$new_stat   = $_REQUEST['new_stat'];
$payment_id = $_REQUEST['payment_id'];
if(($new_stat>0) or ($new_stat<2) AND ($payment_id>0)){
    $edit_outcoming_payment_query_text = "UPDATE payment_outcoming SET payment_stat = $new_stat WHERE payment_id = $payment_id";
    $edit_outcoming_payment_query = mysqli_query($connector, $edit_outcoming_payment_query_text);
    header("Location: ".$_SERVER['HTTP_REFERER']);
    exit();

} else{
   header("Location: ".$_SERVER['HTTP_REFERER']);
    exit();
}
}



$message_from   =   $_REQUEST['message_from'];
$message_to     =   $_REQUEST['message_to'];
$message_content=   $_REQUEST['message_content'];
$message_from = mysqli_real_escape_string($connector,$message_from);
$message_to = mysqli_real_escape_string($connector,$message_to);
$message_content = mysqli_real_escape_string($connector,$message_content);
$error          =   "";
if($action=="send")
	{
		if($message_content=="") $error.="Вы не ввели сообщение<br>";
        if($message_to=="") $error.="Вы не выбрали адресата сообщения<br>";
		if(!empty($error))
		{
			echo "Произошли следующие ошибки: ".$error."<br><a href='index.php?mode=new_message'>вернуться обратно</a>";
			exit();
		}
		$message_sending="INSERT INTO messages (message_from, message_to, message_from_stat, message_to_stat, date_sent, message_content)
        VALUES(1, '$message_to', 0, 0, NOW(), '$message_content')";
        $message_sending = mysqli_query($connector, $message_sending);
		$error.=mysqli_error($connector);
		if(empty($error)){
			header("Location: ".$_SERVER['HTTP_REFERER']);
            exit;
			}
		else echo "Произошли следующие ошибки: ".$error;
	}

//логирование точек доступа
$ip=$_SERVER["REMOTE_ADDR"];
if($ip=="::1"){$ip="127.0.0.1";}
if(!empty($current_admin_id)){
    $ip_find=mysqli_query($connector, "SELECT DISTINCT ip FROM admin_ip_list WHERE admin_id=$current_admin_id");
    $all_ips=array();
    while($ip_check=mysqli_fetch_assoc($ip_find)){
                    $all_ips[]=$ip_check['ip'];
                     }
                     if(!in_array($ip, $all_ips)) {
    $os_type = is_mobile();
    $browser = user_check_browser();
    $ip_add=mysqli_query($connector, "INSERT INTO admin_ip_list (ip, admin_id, os, browser, visit_time) VALUES ('$ip', $current_admin_id, $os_type, '$browser', NOW())");
                     }
    }



//Обработчик сортировок отображаемых выводов средств
$select_count_clients        = $_REQUEST['select_count_clients'];
$select_sort_clients         = $_REQUEST['select_sort_clients'];
$select_direction_clients    = $_REQUEST['select_direction_clients'];
$sort_type                   = $_REQUEST['sort_type'];
//$select_stat_page_client_count    = $_REQUEST['select_stat_page_client_count'];
$clients_valid_show_counts[] = '10';
$clients_valid_show_counts[] = '20';
$clients_valid_show_counts[] = '40';
$clients_valid_show_counts[] = '100';
$clients_valid_show_counts[] = '200';
$clients_valid_show_counts[] = '500';
$clients_valid_show_counts[] = '99999999';
$clients_valid_sort_values[] = 'payment_client_id';
$clients_valid_sort_values[] = 'payment_datetime';
$clients_valid_sort_values[] = 'payment_summ';
$clients_valid_sort_values[] = 'payment_stat';
$clients_valid_sort_values[] = 'payment_type';
$clients_valid_direction_values[] = 'asc';
$clients_valid_direction_values[] = 'desc';

if($action=="sort_clients"){
  if(in_array($select_count_clients, $clients_valid_show_counts))
  {
    $clients_select_count=$select_count_clients;
  }
  else $clients_select_count=10;
  if(in_array($select_sort_clients, $clients_valid_sort_values))
  {
    $clients_select_sort=$select_sort_clients;
  }
  else $clients_select_sort="payment_datetime";
  if(in_array($select_direction_clients, $clients_valid_direction_values))
  {
    $clients_select_direction=$select_direction_clients;
  }
  else $clients_select_direction="asc";
  if($sort_type=="money_outcoming"){
  header("Location: adminka.php?mode=money_outcoming&select_count_clients=".$clients_select_count."&select_sort_clients=".$clients_select_sort."&select_direction_clients=".$clients_select_direction."");
  }
  elseif($sort_type=="money_incoming"){
   header("Location: adminka.php?mode=money_incoming&select_count_clients=".$clients_select_count."&select_sort_clients=".$clients_select_sort."&select_direction_clients=".$clients_select_direction."");
  }
  die();
  }
if((isset($select_count_clients))&&(isset($select_sort_clients))&&(isset($select_direction_clients))){
  if(in_array($select_count_clients, $clients_valid_show_counts))
  {
    $clients_select_count=$select_count_clients;
  }
  else $clients_select_count=10;
  if(in_array($select_sort_clients, $clients_valid_sort_values))
  {
    $clients_select_sort=$select_sort_clients;
  }
  else $clients_select_sort="payment_datetime";
  if(in_array($select_direction_clients, $clients_valid_direction_values))
  {
    $clients_select_direction=$select_direction_clients;
  }
  else $clients_select_direction="asc";

  }
else {$clients_select_count=10; $clients_select_sort="payment_datetime"; $clients_select_direction='desc';}




//Обработчик сортировок отображаемых игроков
$select_count_users        = $_REQUEST['select_count_users'];
$select_sort_users         = $_REQUEST['select_sort_users'];
$select_direction_users    = $_REQUEST['select_direction_users'];
//$select_stat_page_user_count    = $_REQUEST['select_stat_page_user_count'];
$users_valid_show_counts[] = '10';
$users_valid_show_counts[] = '20';
$users_valid_show_counts[] = '40';
$users_valid_show_counts[] = '100';
$users_valid_show_counts[] = '200';
$users_valid_show_counts[] = '500';
$users_valid_show_counts[] = '99999999';
$users_valid_sort_values[] = 'last_activity';
$users_valid_sort_values[] = 'add_date';
$users_valid_sort_values[] = 'client_phone_number';
$users_valid_sort_values[] = 'gold_market';
$users_valid_sort_values[] = 'gold';
$users_valid_sort_values[] = 'barrels';
$users_valid_sort_values[] = 'login';
$users_valid_direction_values[] = 'asc';
$users_valid_direction_values[] = 'desc';

if($action=="sort_users"){
  if(in_array($select_count_users, $users_valid_show_counts))
  {
    $users_select_count=$select_count_users;
  }
  else $users_select_count=10;
  if(in_array($select_sort_users, $users_valid_sort_values))
  {
    $users_select_sort=$select_sort_users;
  }
  else $users_select_sort="login";
  if(in_array($select_direction_users, $users_valid_direction_values))
  {
    $users_select_direction=$select_direction_users;
  }
  else $users_select_direction="asc";

  header("Location: adminka.php?mode=users&select_count_users=".$users_select_count."&select_sort_users=".$users_select_sort."&select_direction_users=".$users_select_direction."");
  die();
  }
if((isset($select_count_users))&&(isset($select_sort_users))&&(isset($select_direction_users))){
  if(in_array($select_count_users, $users_valid_show_counts))
  {
    $users_select_count=$select_count_users;
  }
  else $users_select_count=10;
  if(in_array($select_sort_users, $users_valid_sort_values))
  {
    $users_select_sort=$select_sort_users;
  }
  else $users_select_sort="login";
  if(in_array($select_direction_users, $users_valid_direction_values))
  {
    $users_select_direction=$select_direction_users;
  }
  else $users_select_direction="asc";

  }
else {$users_select_count=10; $users_select_sort="login"; $users_select_direction='desc';}


//сортировка акций
$select_count_actions        = $_REQUEST['select_count_actions'];
$select_sort_actions         = $_REQUEST['select_sort_actions'];
$select_direction_actions    = $_REQUEST['select_direction_actions'];
$sort_type                   = $_REQUEST['sort_type'];
$actions_valid_show_counts[] = '10';
$actions_valid_show_counts[] = '20';
$actions_valid_show_counts[] = '40';
$actions_valid_show_counts[] = '100';
$actions_valid_show_counts[] = '200';
$actions_valid_show_counts[] = '500';
$actions_valid_show_counts[] = '99999999';
$actions_valid_sort_values[] = 'client_id';
$actions_valid_sort_values[] = 'bank_id';
$actions_valid_sort_values[] = 'start_time';
$actions_valid_sort_values[] = 'action_id';
$actions_valid_direction_values[] = 'asc';
$actions_valid_direction_values[] = 'desc';
if($action=="sort_actions"){
  if(in_array($select_count_actions, $actions_valid_show_counts))
  {
    $actions_select_count=$select_count_actions;
  }
  else $actions_select_count=10;
  if(in_array($select_sort_actions, $actions_valid_sort_values))
  {
    $actions_select_sort=$select_sort_actions;
  }
  else $actions_select_sort="action_id";
  if(in_array($select_direction_actions, $actions_valid_direction_values))
  {
    $actions_select_direction=$select_direction_actions;
  }
  else $actions_select_direction="asc";
  header("Location: adminka.php?mode=bank_actions&select_count_actions=".$actions_select_count."&select_sort_actions=".$actions_select_sort."&select_direction_actions=".$actions_select_direction."");
  die();
  }
if((isset($select_count_actions))&&(isset($select_sort_actions))&&(isset($select_direction_actions))){
  if(in_array($select_count_actions, $actions_valid_show_counts))
  {
    $actions_select_count=$select_count_actions;
  }
  else $actions_select_count=10;
  if(in_array($select_sort_actions, $actions_valid_sort_values))
  {
    $actions_select_sort=$select_sort_actions;
  }
  else $actions_select_sort="action_id";
  if(in_array($select_direction_actions, $actions_valid_direction_values))
  {
    $actions_select_direction=$select_direction_actions;
  }
  else $actions_select_direction="asc";

  }
else {$actions_select_count=10; $actions_select_sort="action_id"; $actions_select_direction='desc';}


//Обработчик сортировок кредитов
$select_count_credits        = $_REQUEST['select_count_credits'];
$select_sort_credits         = $_REQUEST['select_sort_credits'];
$select_direction_credits    = $_REQUEST['select_direction_credits'];
$credits_valid_show_counts[] = '10';
$credits_valid_show_counts[] = '20';
$credits_valid_show_counts[] = '40';
$credits_valid_show_counts[] = '100';
$credits_valid_show_counts[] = '200';
$credits_valid_show_counts[] = '500';
$credits_valid_show_counts[] = '99999999';
$credits_valid_sort_values[] = 'start_time';
$credits_valid_sort_values[] = 'end_time';
$credits_valid_sort_values[] = 'client_id';
$credits_valid_sort_values[] = 'count';
$credits_valid_sort_values[] = 'stat';
$credits_valid_sort_values[] = 'ostatok';
$credits_valid_direction_values[] = 'asc';
$credits_valid_direction_values[] = 'desc';

if($action=="sort_credits"){
  if(in_array($select_count_credits, $credits_valid_show_counts))
  {
    $credits_select_count=$select_count_credits;
  }
  else $credits_select_count=10;
  if(in_array($select_sort_credits, $credits_valid_sort_values))
  {
    $credits_select_sort=$select_sort_credits;
  }
  else $credits_select_sort="start_time";
  if(in_array($select_direction_credits, $credits_valid_direction_values))
  {
    $credits_select_direction=$select_direction_credits;
  }
  else $credits_select_direction="asc";
  header("Location: adminka.php?mode=credits&select_count_credits=".$credits_select_count."&select_sort_credits=".$credits_select_sort."&select_direction_credits=".$credits_select_direction."");
  die();
  }
if((isset($select_count_credits))&&(isset($select_sort_credits))&&(isset($select_direction_credits))){
  if(in_array($select_count_credits, $credits_valid_show_counts))
  {
    $credits_select_count=$select_count_credits;
  }
  else $credits_select_count=10;
  if(in_array($select_sort_credits, $credits_valid_sort_values))
  {
    $credits_select_sort=$select_sort_credits;
  }
  else $credits_select_sort="start_time";
  if(in_array($select_direction_credits, $credits_valid_direction_values))
  {
    $credits_select_direction=$select_direction_credits;
  }
  else $credits_select_direction="asc";

  }
else {$credits_select_count=10; $credits_select_sort="start_time"; $credits_select_direction='desc';}

?>
<!DOCTYPE html>
<html>
<head>
	<title><?=$sitename?> - администраторская панель</title>

<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="js/jquery-ui-1.8.14.custom.css">
<META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
<meta name='robots' content='noindex'>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/jquery.treeview.js"></script>
<script src="js/jquery-ui-all.js"></script>
<script src="js/jquery-ui-widget.js"></script>
<script src="js/jquery-ui-1.8.14.custom.min.js"></script>
<script src="js/jquery.ui.datepicker-ru.js"></script>
<script src="jquery-ui-1.8.14.custom.min.js"></script>
<script>
$(document).ready(function(){

var docwidth = $(document).width();
var docheight = $(document).height();
var windowwidth = $(window).width();
var windowheight = $(window).height();
var main_window_bottom = $("#admin_main_window").height();
//$('#top').css('left', windowwidth*0.5-1200*0.5);


$('#client_search').keyup(function(){
if($('#client_search').val().length >= 3){
var client_search=encodeURI($('#client_search').val());
location.href="adminka.php?mode=users&search_user="+client_search;
}
});
$("#datepicker").datepicker({
onSelect: function(date) {
//$("#datepicker").datepicker( "option", "dateFormat", 'yy-mm-dd' );
var ready_date = date.replace('.', '-');
var ready_date_2 = ready_date.replace('.', '-');
var ready_date_3 = ready_date_2.split("-");
var ready_date_4 = ready_date_3[2]+"-"+ready_date_3[1]+"-"+ready_date_3[0];
$("input[name=last_payment]").val(ready_date_4);
 }});

});
</script>
<script type="text/javascript" src="js/access-style-edit.js"></script>
</head>
<body>
<div id=admin_main_window>
<h1 style="text-align: center">Панель администрирования</h1>
<div id="admin_mainlinks">&nbsp;
<a class=minilink href="?mode=main_settings">Настройки</a> |
<a class=minilink href="?mode=admin_newsline">Новости</a> |
<a class=minilink href="?mode=money_outcoming">Вывод средств</a> |
<a class=minilink href="?mode=money_incoming">Внесение средств</a> |
<a class=minilink href="?mode=users">Игроки</a> |
<a class=minilink href="?mode=admin_actions">Акции</a> |
<a class=minilink href="?mode=chat">Форум</a> |
<a class=minilink href="?mode=levels">Уровни</a> |
<a class=minilink href="?mode=banners">Баннеры</a> |
<a class=minilink href="?mode=links">Ссылки</a> |
<a class=minilink href="?mode=mailer">Рассылки</a> |
<a class=minilink href="?mode=admin_security">Безопасность</a> |
<a class=minilink href="?mode=logout">Выход</a>
</div>
<table>
<tr style="vertical-align: top">
<td>
</td>
<td>
<?

 if ($mode=="admin_actions"){
  require_once ("admin_actions.php");
}
 if ($mode=="admin_settings"){
  require_once ("admin_settings.php");
}
if ($mode=="actions"){
  require_once ("admin_actions.php");
}
if ($mode=="chat"){
  require_once ("admin_chat.php");
}
if ($mode=="levels"){
  require_once ("admin_levels.php");
}
if ($mode=="newsline"){
  require_once ("newsline.php");
}

if ($mode=="money_outcoming"){
  require_once ("admin_money_outcoming.php");
}
if ($mode=="money_incoming"){
  require_once ("admin_money_incoming.php");
}
if ($mode=="admin_security"){
  require_once ("admin_security.php");
}
if ($mode=="change_password"){
  require_once ("admin_change_password.php");
}
if ($mode=="incoming_messages"){
  require_once ("incoming_messages.php");
}
if ($mode=="client_profile"){
  require_once ("client_profile.php");
}
if ($mode=="users"){
  require_once ("admin_users.php");
}
if ($mode=="admin_newsline"){
  require_once ("admin_newsline.php");
}
if ($mode=="banners"){
  require_once ("admin_banners.php");
}
if ($mode=="links"){
  require_once ("admin_links.php");
}
if ($mode=="mailer"){
  require_once ("admin_mailer.php");
}
?>
</td>
</tr>
</table>
</div>
</body>
</html>