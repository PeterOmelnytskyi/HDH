<?php
//session_start();
//require_once("dbconnect.php");
//require_once("setup.php");
//require_once("functions.php");
$ip_access_query=mysqli_query($connector, "SELECT ip_list FROM ip_access");
$Allow_Ip_Range=array();
$ip=$_SERVER["REMOTE_ADDR"];
if($ip=="::1"){$ip="127.0.0.1";}
while($ipq=mysqli_fetch_assoc($ip_access_query)){
$Allow_Ip_Range[]=$ipq['ip_list'];
                 }
if(!empty($_SESSION[$session_login])){
$login = $_SESSION[$session_login];
$current_client_query=mysqli_query($connector, "SELECT * FROM clients WHERE login='$login'");
$current_client_check = mysqli_num_rows($current_client_query);
if($current_client_check<1) die("not authorized!");
while($current_client_data=mysqli_fetch_assoc($current_client_query)){
                $current_admin_id   =   $current_client_data['client_id'];
                $current_admin_fio  =   $current_client_data['client_fio'];
                $current_admin_stat =   $current_client_data['client_stat'];
                $current_client_barrels=   $current_client_data['barrels'];
                $current_client_gold   =   $current_client_data['gold'];
                $current_client_gold_market=$current_client_data['gold_market'];
                $current_client_mail   =   $current_client_data['client_mail'];
                $current_client_skype  =   $current_client_data['client_skype'];
                $current_client_icq    =   $current_client_data['client_icq'];
                $current_client_phone  =   $current_client_data['client_phone_number'];
                $current_client_city   =   $current_client_data['client_city'];
                $current_client_avatar =   $current_client_data['client_avatar'];
                $current_client_add_date = $current_client_data['add_date'];
                $current_client_last_act = $current_client_data['last_activity'];
                $current_client_actmes = $current_client_data['active_message'];
                $current_client_referal = $current_client_data['client_referal'];
                $current_account_key = $current_client_data['account_key'];
}
//проверка бана
$user_ban_query_text="SELECT * FROM user_ban_list WHERE user_id=$current_admin_id AND ban_end>NOW()";
$user_ban_query = mysqli_query($connector, $user_ban_query_text);
while($user_ban_data=mysqli_fetch_assoc($user_ban_query)){
 $ban_end = $user_ban_data['ban_end'];
 $ban_start = $user_ban_data['ban_start'];
 $ban_couse = $user_ban_data['ban_couse'];
  }

if(!empty($current_admin_id)){
    $ip_find=mysqli_query($connector, "SELECT DISTINCT ip FROM ip_list WHERE admin_id=$current_admin_id");
    $all_ips=array();
    while($ip_check=mysqli_fetch_assoc($ip_find)){
                    $all_ips[]=$ip_check['ip'];
                     }
                     if(!in_array($ip, $all_ips)) {
    $os_type = is_mobile();
    $browser = user_check_browser();
    $ip_add=mysqli_query($connector, "INSERT INTO ip_list (ip, admin_id, os, browser, visit_time) VALUES ('$ip', $current_admin_id, $os_type, '$browser', NOW())");
                     }
    }
}
echo mysqli_error($connector);
?>