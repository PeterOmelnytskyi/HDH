<?
require_once ("config.php");
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
$message_text = htmlspecialchars($_REQUEST['message_text']);
$email        = htmlspecialchars($_REQUEST['email']);
$username     = htmlspecialchars($_REQUEST['username']);
$message_text = mysqli_real_escape_string($connector, $message_text);
$username     = mysqli_real_escape_string($connector, $username);
$email        = mysqli_real_escape_string($connector, $email);
$ip           = $_SERVER["REMOTE_ADDR"];
if($ip=="::1"){$ip="127.0.0.1";}
$action       = $_REQUEST['action'];
if($action=="feedback"){
          if(!empty($message_text)){
          $add_chat_message_query_text="INSERT INTO feedback (message_text, username, email, add_date, ip)
          VALUES ('$message_text','$username','$email', NOW(), '$ip')";
          if($add_chat_message_query=mysqli_query($connector, $add_chat_message_query_text)){
          header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
          exit();
          }
  }
}

require_once ("current_settings.php");
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
$_SESSION[$session_login]= '';
$_SESSION[$session_pass] = '';
$_SESSION["user_checker"]= '';
unset($_SESSION);
header("Location: index.php");
exit;
}
if($action=="public_feedback"){
          if(!empty($message_text)){
          $add_chat_message_query_text="INSERT INTO public_feedback (message, client_id, add_date, message_stat)
          VALUES ('$message_text',$current_admin_id, NOW(), 1)";
          if($add_chat_message_query=mysqli_query($connector, $add_chat_message_query_text)){
          $update_gold=mysqli_query($connector, "UPDATE clients SET barrels=barrels-1 WHERE client_id='$current_admin_id'");
          header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
          exit();
          }
  }
}
?>