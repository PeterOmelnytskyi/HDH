<h1>Безопасность</h1>
<p class=small>История активности показывает информацию о том, в какое время и с каких браузеров производилась авторизация на Ваш профиль.</p>
<a href=?mode=change_password class=minilink>Изменить пароль</a>
<a href=?mode=change_mail class=minilink>Изменить email</a>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td>Дата/время</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Устройство</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Браузер</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>ip-адрес</td></tr></table></td>
    </tr>
<?
$device[1] = "images/browsers/mobile.png";
$device[2] = "images/browsers/mobile.png";
$device[3] = "images/browsers/mobile.png";
$device[0] = "images/browsers/pc.png";
$system[3] = "Мобильный телефон";
$system[4] = "liqpay.com";
$system[5] = "Qiwi-кошелек";
$browser['opera']='Opera';
$browser['mozilla']='Mozilla Firefox';
$browser['ie']='Microsoft Internet Explorer';
$browser['konqueror']='Konqueror';
$browser['maxton']='Maxton';
$browser['chrome']='Google Chrome';
$browser['unknown']='unknown browser';
if($_REQUEST['limit']=='no'){
$user_ip_list_query_text="SELECT DISTINCT ip, os, visit_time, browser FROM ip_list
WHERE admin_id = $current_admin_id ORDER BY visit_time DESC";
}
else {
$user_ip_list_query_text="SELECT DISTINCT ip, os, visit_time, browser FROM ip_list
WHERE admin_id = $current_admin_id ORDER BY visit_time DESC LIMIT 20";
}
$user_ip_list_query = mysqli_query($connector, $user_ip_list_query_text);
                while ($user_ip_list_data = mysqli_fetch_assoc($user_ip_list_query)) {
                  $ip           = $user_ip_list_data['ip'];
                  $browser_type = $user_ip_list_data['browser'];
                  $os           = $user_ip_list_data['os'];
                  $visit_time   = $user_ip_list_data['visit_time'];
?>

    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td><?=$visit_time?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><img src='<?=$device[$os]?>'></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><span class=small><?=$browser[$browser_type]?></span></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$ip?></td></tr></table></td>
    </tr>
<?}?>
</table>
