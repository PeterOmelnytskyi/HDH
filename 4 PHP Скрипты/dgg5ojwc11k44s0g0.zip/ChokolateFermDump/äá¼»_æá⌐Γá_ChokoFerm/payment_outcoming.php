<?
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("config.php");
require_once ("current_settings.php");
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
$action         = $_REQUEST['action'];
$payment_system = $_REQUEST['payment_system'];
$payment_amount = floor($_REQUEST['payment_amount']);
$payment_system_id = $_REQUEST['payment_system_id'];

$payment_system = mysqli_real_escape_string($connector,$payment_system);
$payment_amount = mysqli_real_escape_string($connector,$payment_amount);
$payment_system_id = mysqli_real_escape_string($connector,$payment_system_id);
if($action=='money_outcoming'){
if((empty($payment_amount)) OR (intval($payment_amount)<10)) {
              header("Location: index.php?mode=money_outcoming&error=wrong_amount");
              exit();
          }
if(empty($payment_system_id)) {
              header("Location: index.php?mode=money_outcoming&error=empty_system_id");
              exit();
          }
$check_gold_query_text="SELECT gold FROM clients WHERE client_id = $current_admin_id";
           $check_gold_query=mysqli_query($connector, $check_gold_query_text);
           while($check_gold_data=mysqli_fetch_assoc($check_gold_query)){
              $client_gold = $check_gold_data['gold'];
          }
           $settings_query="SELECT * FROM settings";
           $settings_query=mysqli_query($connector, $settings_query);
           while($settings=mysqli_fetch_assoc($settings_query)){
              $rub_usd = $settings['rub_usd'];
          }
          if($client_gold/100>=$payment_amount){
                  $insert_outcoming_payment_query_text = "INSERT INTO payment_outcoming (payment_datetime, payment_client_id,
                  payment_summ, payment_type, payment_system_id, payment_stat, payment_target)
                  VALUES (NOW(), $current_admin_id, '$payment_amount', $payment_system, '$payment_system_id',0, 0)";
                      if($insert_outcoming_payment_query = mysqli_query($connector, $insert_outcoming_payment_query_text)){
                          //уведомление об успешном платеже
                          $gold_decrease = $payment_amount*100;
                         $edit_client_gold_query_text = "UPDATE clients SET gold = gold - $gold_decrease WHERE client_id = $current_admin_id";
                         $edit_client_gold_query = mysqli_query($connector, $edit_client_gold_query_text);
                         echo mysqli_error($connector);
                         header("Location: index.php?mode=money_outcoming&result=request");
                         exit();
                      }
          }
          else {
              header("Location: index.php?mode=money_outcoming&error=not_enough_money");
          }
}
?>
