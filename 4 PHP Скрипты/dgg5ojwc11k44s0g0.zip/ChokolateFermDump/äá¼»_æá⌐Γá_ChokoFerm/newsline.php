<?
$news_query=mysqli_query($connector, "SELECT * FROM newsline ORDER BY add_date DESC");?>
<h1>Новости проекта</h1>
<table border=0px width=100%>
<?while($news_data=mysqli_fetch_assoc($news_query)){
                $news_id    = $news_data['news_id'];
                $news_text  = $news_data['news_text'];
                $add_date   = $news_data['add_date'];
                $news_name  = $news_data['news_name'];?>
<tr>
    <td><p class=small><b><?=$news_name?></b></p></td><td width=200px><p class=small>новость опубликована: <br><b><?=rus_calendar($add_date)?></b></p></td>
</tr>
<tr>
    <td colspan=2><p class=small><?
    $filtered_news_text=preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a class=minilink href="\\0">\\0</a>',$news_text);
    echo $filtered_news_text;
    ?>
    </p><br><br></td>
</tr>
<? } ?>
</table>