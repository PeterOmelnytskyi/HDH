<h1>Профиль → изменить пароль</h1>
<form name="password" action="user_profile.php" method="post">
<input type="hidden" name="action" value="change_password">
<table>
<tr height=20px>
    <td width=140px><p class=small>Старый пароль</p></td>
    <td width=100px><input type=password name=old_pass value=""></td>
</tr>
<tr height=20px>
    <td width=140px><p class=small>Новый пароль</p></td>
    <td width=100px><input type=password name=new_pass value=""></td>
</tr>
<tr height=20px>
    <td width=140px><p class=small>Новый пароль (повтор)</p></td>
    <td width=100px><input type=password name=new_pass_2 value=""></td>
</tr>
</table>
<input type=submit value="Изменить" class=input_button>
</form>

<?if($_REQUEST['error']=='wrong_password'){?><p class=wide_small><span class=attention>Внимание!</span>
Вы вводите неверный пароль!<br><?=$_REQUEST['data']?></p><?}?>
<?if($_REQUEST['result']=='success'){?><p class=wide_small><span class=success>Пароль был успешно изменен</span>
 </p><?}?>
<?//гость
if(!empty($_SESSION["log"])){?>

<?}?>