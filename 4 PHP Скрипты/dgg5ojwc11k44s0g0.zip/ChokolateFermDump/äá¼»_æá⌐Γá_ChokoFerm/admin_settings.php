<h1>Общие настройки</h1>
<?if($_REQUEST['result']=='success'){?>
<p class="wide_small"><span class=success>Настройки были успешно изменены</span></p><?}?>
<?if($_REQUEST['result']=='error'){?>
<p class="wide_small"><span class=attention>Настройки не были изменены! Возника ошибка при редактировании настроек!</span></p><?}?>
<?if($_REQUEST['data']=='harvest_time'){?>
<p class="wide_small"><span class=attention>Срок сбора шоколада должен быть не меньше 1 минуты</span></p>
<?}?>
<?if($_REQUEST['data']=='apples_per_gold'){?>
<p class="wide_small"><span class=attention>Стоимость 1 золота в шоколаде не может быть меньше 1 шоколада</span></p>
<?}?>
<?if($_REQUEST['data']=='client_max_trees'){?>
<p class="wide_small"><span class=attention>Максимум шоколадных фабрик у игрока должно быть не меньше одного</span></p>
<?}?>
<?if($_REQUEST['data']=='tree_lifetime'){?>
<p class="wide_small"><span class=attention>Срок жизни шоколадной фабрики должен быть не меньше одного дня</span></p>
<?}?>
<?if($_REQUEST['data']=='apples_per_message'){?>
<p class="wide_small"><span class=attention>Стоимость сообщения в чате не может быть менее 1 золото за сообщение</span></p>
<?}?>
<?if($_REQUEST['data']=='rub_usd'){?>
<p class="wide_small"><span class=attention>Стоимость одного доллара в рублях должна быть отличной от нуля (если конечно америке не пришел капец!)))</span></p>
<?}?>
<?if($_REQUEST['data']=='admin_mail'){?>
<p class="wide_small"><span class=attention>Почта администратора не может быть пустой</span></p>
<?}?>
<?if($_REQUEST['data']=='keywords'){?>
<p class="wide_small"><span class=attention>Ключевые слова должны быть заполнены</span></p>
<?}?>
<?if($_REQUEST['data']=='description'){?>
<p class="wide_small"><span class=attention>Описание сайта должно быть заполнено</span></p>
<?}?>
<?if($_REQUEST['data']=='combine_price'){?>
<p class="wide_small"><span class=attention>Стоимость помощника должна быть отличной от нуля</span></p>
<?}?>
<?if($_REQUEST['data']=='autoreferal_price'){?>
<p class="wide_small"><span class=attention>Стоимость автореферала должна быть отличной от нуля</span></p>
<?}?>
<?if($_REQUEST['data']=='link_per_day'){?>
<p class="wide_small"><span class=attention>Стоимость заказа ссылок должна быть отличной от нуля</span></p>
<?}?>
<?if($_REQUEST['data']=='mailer_price'){?>
<p class="wide_small"><span class=attention>Стоимость рассылки сообщений должна быть отличной от нуля</span></p>
<?}?>
<form action=settings_controller.php method=get>
<input type=hidden name=action value="edit_settings">
<div style="display: inline-table">
<table border=0px>
<tr height=20px>
    <td width=250px><p class=small>Срок производства шоколада, мин.</p></td>
    <td width=100px><input type=text name=harvest_time value="<?=$harvest_time?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Стоимость 1 золота в шоколаде</p></td>
    <td width=100px><input type=text name=apples_per_gold value="<?=$apples_per_gold?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Курс доллара к рублю<br> (укажите целое число)</p></td>
    <td width=100px><input type=text name=rub_usd value="<?=$rub_usd?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Максимум шоколадных фабрик у игрока</p></td>
    <td width=100px><input type=text name=client_max_trees value="<?=$client_max_trees?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Срок эксплуатации шоколадной фабрики, дней</p></td>
    <td width=100px><input type=text name=tree_lifetime value="<?=$tree_lifetime?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Стоимость сообщения в золоте</p></td>
    <td width=100px><input type=text name=apples_per_message value="<?=$apples_per_message?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Стоимость помощника, золото</p></td>
    <td width=100px><input type=text name=combine_price value="<?=$combine_price?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Стоимость автореферала, золото</p></td>
    <td width=100px><input type=text name=autoreferal_price value="<?=$autoreferal_price?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Стоимость показа баннера, рубли</p></td>
    <td width=100px><input type=text name=banner_per_day value="<?=$banner_per_day?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Стоимость показа ссылок, рубли</p></td>
    <td width=100px><input type=text name=link_per_day value="<?=$link_per_day?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Стоимость рассылки, рубли</p></td>
    <td width=100px><input type=text name=mailer_price value="<?=$mailer_price?>" style='width: 50px'></td>
</tr>
</table>
</div>
<div style="display: inline-table">
<table border=0px>
<tr height=20px>
    <td><p class=small>Накрутка к резерву</p></td>
    <td width=50px>
    <span class=success><b>+</b></span><input type=text name=reserv_change_up value="<? if($reserv_change<=0) echo -$reserv_change;?>" style='width: 50px'>
    <span class=attention><b>-</b></span><input type=text name=reserv_change_down value="<? if($reserv_change>0) echo $reserv_change;?>" style='width: 50px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Накрутка игроков</p></td>
    <td width=100px><input type=text name=user_count value="<?=$user_count?>" style='width: 50px;'></td>
</tr>
<tr height=20px>
    <td width=250px><p class=small>Часовой пояс</p></td>
    <td width=100px>
    <select name=timezone style="width:250px">
    <option value="1" <?if($timezone=="1") echo "selected"?>>USZ1	Калининградское время MSK–1 (UTC+3)</option>
    <option value="2" <?if($timezone=="2") echo "selected"?>>MSK Московское время MSK (UTC+4)</option>
    <option value="3" <?if($timezone=="3") echo "selected"?>>YEKT	Екатеринбургское время MSK+2 (UTC+6)</option>
    <option value="4" <?if($timezone=="4") echo "selected"?>>OMST	Омское время	MSK+3 (UTC+7)</option>
    <option value="5" <?if($timezone=="5") echo "selected"?>>KRAT	Красноярское время	MSK+4 (UTC+8)</option>
    <option value="6" <?if($timezone=="6") echo "selected"?>>IRKT	Иркутское время	MSK+5 (UTC+9)</option>
    <option value="7" <?if($timezone=="7") echo "selected"?>>YAKT	Якутское время	MSK+6 (UTC+10)</option>
    <option value="8" <?if($timezone=="8") echo "selected"?>>VLAT	Владивостокское время	MSK+7 (UTC+11)</option>
    <option value="9" <?if($timezone=="9") echo "selected"?>>MAGT	Магаданское время	MSK+8 (UTC+12)</option>
    </select>
    </td>
</tr>
<tr height=20px>
    <td><p class=small>Почта администратора</p></td>
    <td width=100px><input type=text name=admin_mail value="<?=$admin_mail?>" style='width: 250px'></td>
</tr>
<tr height=20px>
    <td><p class=small>Ключевые слова сайта (keywords)</p></td>
    <td width=100px><textarea type=text name=keywords style='width: 250px; height: 100px'><?=$keywords?></textarea></td>
</tr>
<tr height=20px>
    <td><p class=small>Описание сайта (description)</p></td>
    <td width=100px><textarea type=text name=description style='width: 250px; height: 50px'><?=$description?></textarea></td>
</tr>
</table>
</div>
<input type=submit class=input_button value="Сохранить">
</form>

<h1>Статистика</h1>
<?
$select_new_cliens_query_text="SELECT count(client_id) as client_counter FROM clients WHERE UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(add_date)<3600*24";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
 $new_cliens = $select_new_cliens_data['client_counter'];
                }
$select_new_cliens_query_text="SELECT sum(payment_summ) as total_payment_summ FROM payment_incoming WHERE UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(payment_datetime)<3600*24";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$total_payment_summ = $select_new_cliens_data['total_payment_summ'];
            }
$select_new_cliens_query_text="SELECT sum(payment_summ) as total_payment_summ2 FROM payment_outcoming WHERE UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(payment_datetime)<3600*24";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$total_payment_summ2 = $select_new_cliens_data['total_payment_summ2'];
            }
$select_new_cliens_query_text="SELECT count(banner_id) as total_banners FROM banners WHERE TO_DAYS(start_datetime) > TO_DAYS(NOW())
AND TO_DAYS(end_datetime)<TO_DAYS(NOW())";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$total_banners = $select_new_cliens_data['total_banners'];
            }
$select_new_cliens_query_text="SELECT count(link_id) as total_links FROM links WHERE TO_DAYS(start_datetime) > TO_DAYS(NOW())
AND TO_DAYS(end_datetime)<TO_DAYS(NOW())";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$total_links = $select_new_cliens_data['total_links'];
            }
$select_new_cliens_query_text="SELECT count(mailer_id) as total_mailer FROM mailer WHERE TO_DAYS(start_datetime) > TO_DAYS(NOW())";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$total_mail = $select_new_cliens_data['total_mail'];
            }
$select_new_cliens_query_text="SELECT count(message_id) as total_messages FROM chat WHERE UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(add_date) > 3600*24";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$total_messages = $select_new_cliens_data['total_messages'];
            }



$select_new_cliens_query_text="SELECT count(client_id) as client_counter FROM clients";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
 $alltime_new_cliens = $select_new_cliens_data['client_counter'];
                }
$select_new_cliens_query_text="SELECT sum(payment_summ) as total_payment_summ FROM payment_incoming";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$alltime_total_payment_summ = $select_new_cliens_data['total_payment_summ'];
            }
$select_new_cliens_query_text="SELECT sum(payment_summ) as total_payment_summ2 FROM payment_outcoming";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$alltime_total_payment_summ2 = $select_new_cliens_data['total_payment_summ2'];
            }
$select_new_cliens_query_text="SELECT count(banner_id) as total_banners FROM banners";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$alltime_total_banners = $select_new_cliens_data['total_banners'];
            }
$select_new_cliens_query_text="SELECT count(link_id) as total_links FROM links";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$alltime_total_links = $select_new_cliens_data['total_links'];
            }
$select_new_cliens_query_text="SELECT count(mailer_id) as total_mail FROM mailer";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$alltime_total_mail = $select_new_cliens_data['total_mail'];
            }
$select_new_cliens_query_text="SELECT count(message_id) as total_messages FROM chat";
$select_new_cliens_query = mysqli_query($connector, $select_new_cliens_query_text);
while($select_new_cliens_data=mysqli_fetch_assoc($select_new_cliens_query)){
$alltime_total_messages = $select_new_cliens_data['total_messages'];
            }

if(empty($new_cliens)) $new_cliens=0;
if(empty($total_payment_summ)) $total_payment_summ=0;
if(empty($total_payment_summ2)) $total_payment_summ2=0;
if(empty($total_banners)) $total_banners=0;
if(empty($total_links)) $total_links=0;
if(empty($total_mail)) $total_mail=0;
if(empty($total_messages)) $total_messages=0;
if(empty($alltime_new_cliens)) $alltime_new_cliens=0;
if(empty($alltime_total_payment_summ)) $alltime_total_payment_summ=0;
if(empty($alltime_total_payment_summ2)) $alltime_total_payment_summ2=0;
if(empty($alltime_total_banners)) $alltime_total_banners=0;
if(empty($alltime_total_links)) $alltime_total_links=0;
if(empty($alltime_total_mail)) $alltime_total_mail=0;
if(empty($alltime_total_messages)) $alltime_total_messages=0;



            ?>
<div style="display: inline-table">
<table width=760px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #888">
<tr style="vertical-align: top">
<td width=100px align=left>
    <p class=small>Период</p>
</td>
<td width=100px align=left>
    <p class=small>Новые игроки</p>
</td>
<td width=100px align=left>
    <p class=small>Внесено средств</p>
</td>
<td width=100px align=left>
    <p class=small>Выведено средств</p>
</td>
<td width=100px align=left>
    <p class=small>Заказано баннеров</p>
</td>
<td width=100px align=left>
    <p class=small>Заказано ссылок</p>
</td>
<td width=100px align=left>
    <p class=small>Заказано рассылок</p>
</td>
<td width=150px align=left>
    <p class=small>Новых сообщений в чате</p>
</td>
</tr>
<tr>
<td align=left>
    <p class=small>последние сутки</p>
</td>
<td align=left>
    <p class=small><?=$new_cliens?></p>
</td>
<td align=left>
    <p class=small><?=$total_payment_summ?></p>
</td>
<td align=left>
    <p class=small><?=$total_payment_summ2?></p>
</td>
<td align=left>
    <p class=small><?=$total_banners?></p>
</td>
<td align=left>
    <p class=small><?=$total_links?></p>
</td>
<td align=left>
    <p class=small><?=$total_mail?></p>
</td>
<td align=left>
    <p class=small><?=$total_messages?></p>
</td>
</tr>
<tr>
<td align=left>
    <p class=small>все время</p>
</td>
<td align=left>
    <p class=small><?=$alltime_new_cliens?></p>
</td>
<td align=left>
    <p class=small><?=$alltime_total_payment_summ?></p>
</td>
<td align=left>
    <p class=small><?=$alltime_total_payment_summ2?></p>
</td>
<td align=left>
    <p class=small><?=$alltime_total_banners?></p>
</td>
<td align=left>
    <p class=small><?=$alltime_total_links?></p>
</td>
<td align=left>
    <p class=small><?=$alltime_total_mail?></p>
</td>
<td align=left>
    <p class=small><?=$alltime_total_messages?></p>
</td>
</tr>
</table>
</div>
<div style="display: inline-table">
<table width=160px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #888">
<tr>
<td align=left>
    <p class=small>Уровень шоколадной фабрики</p>
</td>
<td align=left>
    <p class=small>Количество</p>
</td>
</tr>
<?$select_glade_stat_query_text="SELECT *, count(client_tree_id) as counter FROM trees GROUP BY (level) ORDER BY level DESC";
$select_glade_stat_query = mysqli_query($connector, $select_glade_stat_query_text);
while($select_glade_stat_data=mysqli_fetch_assoc($select_glade_stat_query)){
$counter = $select_glade_stat_data['counter'];
$level = $select_glade_stat_data['level'];
            ?>
<tr>
<td align=left>
    <p class=small><?=$level?></p>
</td>
<td align=left>
    <p class=small><?=$counter?></p>
</td>
</tr>
<?}?>
</table>
</div>