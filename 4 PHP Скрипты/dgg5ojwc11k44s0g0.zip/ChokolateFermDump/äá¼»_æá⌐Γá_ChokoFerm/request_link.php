<h1>Заказ рекламной ссылки</h1>
<?if($_REQUEST['result']=='wrong_description'){?><p class=wide_small><span class=attention>Ошибка!</span>
Текст ссылки не должен быть пустым</p>
<?}?>
<?if($_REQUEST['result']=='wrong_url'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана ссылка (url)</p>
<?}?>
<?if($_REQUEST['result']=='wrong_show_datetime'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указано количество показов ссылки</p>
<?}?>
<?if($_REQUEST['result']=='wrong_start_datetime'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана дата начала показа ссылки</p>
<?}?>
<?if($_REQUEST['result']=='wrong_mail'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана почта для контроля ссылки</p>
<?}?>
<?if($_REQUEST['result']=='wrong_pay_type'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана система оплаты за показ ссылки</p>
<?}?>
<?if($_REQUEST['result']=='success'){?><p class=wide_small><span class=success>Поздравляем!</span>
Вашей ссылке присвоен номер в системе <b><?=$_REQUEST['data']?></b>, она ожидает проверки со стороны администрации сайта.
Как только заказ будет оплачен, ссылки станут видны на сайте с указанной вами даты начала показа (с момента полуночи).
Информация о том, как автоматически оплатить заказ, смотреть статистику по ссылке и как контроллировать показ отправлена на указанный почтовый ящик.
Оплатить показ ссылки вы можете следующими способами:<br>
- <b>Qiwi</b> (номер <b><?=$qiwi_account?></b>)<br>
- <b>Яндекс-деньги </b> (номер <b><?=$yandex_account?></b>)<br>
При оплате обязательно указывается в комментарии "Оплата счета за показ ссылок #<?=$_REQUEST['data']?>"<br>
<?if($wm_attestat_status){?>
<a href="?mode=wm_payment&service_mode=L&link_id=<?=$_REQUEST['data']?>&count=<?=$_REQUEST['show_datetime']?>">Оплатить через webmoney в автоматическом режиме</a>
<?}?>
Благодарим за сотрудничество!
C уважением, администрация сайта <?=$sitename?></p>
<?}?>
<br>
<form name=user_register action="request_link_controller.php" method=post enctype="multipart/form-data">
<input type=hidden name=action value=link_request>
<table cellspacing="1px" align="center" border=0px>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Текст ссылки*(максимум 45 символов включая пробелы и знаки препинания, также запрещается
    использовать ВЕРХНИЙ регистр для всего текста ссылки)</p></td>
    <td width=260px align=center class=info_cell><input type=text name=description id=linktext style="width: 240px"></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>url ссылки*</p></td>
    <td width=260px align=center class=info_cell><input type=text name=url style="width: 240px"></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Срок показа, дни*</p></td>
    <td width=260px align=center class=info_cell>
<select name=show_datetime>
<?$x=0;
while($x<90){
  $x++;?>
<option value="<?=$x?>"><?=$x?></option>
<?}?>
</select>
    </td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Дата начала показа</p></td>
    <td width=260px align=center class=info_cell>
<div id="datepicker" style="width: 200px"></div>
<input type=hidden name=start_datetime value='<?=date("Y-m-d")?>'>
</td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Ваш email*</p></td>
    <td width=260px align=center class=info_cell>
    <input type=text name=mail class=search_from_element style="width: 240px">
    </td>
</tr>
<!--
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Докажи что не робот :)*</p></td>
    <td width=260px align=center class=info_cell>
    <span class=inwork>Работа не <input type=text name=captcha id="captcha" class=search_from_element style="width: 40px">, в лес не убежит</span></td>
</tr>
-->
<tr style="vertical-align: top">
    <td colspan=2 class=info_cell align=center>
    <button class=orange_from_element type=submit class=search_from_element style="width: 140px">
    <img src="images/design/money_small.png" style="vertical-align: middle"> Заказать</button></td>
    </tr>
</table>
</form>
<p class=small>Поля, отмеченные *, обязательны для заполнения!</p>
<br>
