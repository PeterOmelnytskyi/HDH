<h1>Таблица уровней</h1>
<form action="admin_levels_form.php" method=get>
<input type=hidden name=action value=update_levels>
<table border="0" width="480" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td rowspan="2">Шоколадная Фабрика</td>
        <td rowspan="2" width="60">Уровень</td>
        <td colspan="2">Производство шоколада (за 5 мин.)</td>
        <td rowspan="2">Цена</td>
    </tr>
    <tr align="center">
        <td width="100">Обычный</td>
        <td width="100">Бонус</td>

    </tr>
<?
$get_level_info_query=mysqli_query($connector, "SELECT * FROM levels");
while($get_level_info=mysqli_fetch_assoc($get_level_info_query)){
                $level = $get_level_info['level_id'];
                $cost = $get_level_info['cost'];
                $harvest = $get_level_info['harvest'];
                $bonus   = $get_level_info['bonus'];?>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/almaz.png" width="20"></td><td> - </td></tr></table></td>
        <td><?=$level?></td>
        <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/almaz.png" width="20"></td><td><input name=<?="harvest".$level?> value="<?=$harvest?>" style="width: 60px"></td></tr></table></td>
       <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/almaz.png" width="20"></td><td><input name=<?="bonus".$level?> value="<?=$bonus?>" style="width: 60px"></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/coins.png" width="20"></td><td><input name=<?="cost".$level?> value="<?=$cost?>" style="width: 60px"></td></tr></table></td>
    </tr>
<?}?>
</table>
<input type=submit class=input_button value="сохранить">
</form>