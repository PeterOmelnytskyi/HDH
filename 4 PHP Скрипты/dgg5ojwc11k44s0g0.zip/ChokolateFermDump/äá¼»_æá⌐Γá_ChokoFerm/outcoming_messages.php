<?
if((empty($_SESSION[$session_login])) OR (($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!")))){
exit;
}
?>
<h1>Исходящие сообщения:</h1>
<a href="?mode=outcoming_messages" class=minilink>Показать все исходящие</a>
<?if($_REQUEST['result']=='not_deleted'){?><p class=wide_small><span class=attention>Внимание!</span>
Сообщение не было удалено!<br><?=$_REQUEST['data']?></p><?}?>
<?if($_REQUEST['result']=='deleted'){?>
<p class=wide_small><span class=success>Сообщение успешно удалено</span>
 </p><?}?>
 <table border=0px style="border-top: 2px dotted #888; border-left: 0px; border-right: 0px;">
<tr height=2px>
    <td width=640px>
</td>
</tr>
</table>
<table width=650px border=0px cellpadding=2px cellspasing=0px>
<?if(!empty($_REQUEST['message_id'])){
    $current_message_id=$_REQUEST['message_id'];
    $outcoming_messages=mysqli_query($connector, "SELECT client_id, login, message_from, message_content, date_sent FROM messages,
            clients WHERE messages.message_from = $current_admin_id AND messages.message_to=clients.client_id
            AND messages.message_id=$current_message_id");
    while($outcoming_messages_data = mysqli_fetch_assoc($outcoming_messages)){?>
    <tr valign=top style="vertical-align: top">
    <td valign=top style="text-align: left; vertical-align: top" width=220px>
    <p class="small"><b><?=$outcoming_messages_data['login']?></b></p>
    <p class="small"><b><?=$outcoming_messages_data['date_sent']?></b></p></td>
    <td valign=top style="vertical-align: top"><p class=small>
    <?=$outcoming_messages_data['message_content']?></p></td>
    <td valign=top width=120px style="vertical-align: top"><a href="message_delete_form.php?action=delete_sended_message&message_id=<?=$current_message_id?>" class=minilink>удалить сообщение</a></td>
    </tr>
    <?}?>
<?}else{?>
    <?php $incoming_messages_query=mysqli_query($connector, "SELECT login, message_to, message_content,
    date_sent, message_id, message_from_stat FROM messages, clients WHERE messages.message_from = $current_admin_id
    AND messages.message_to=clients.client_id AND message_from_stat<>2 ORDER BY date_sent DESC");
    while($incoming_messages_data = mysqli_fetch_assoc($incoming_messages_query)) {
     $admin_fio = $incoming_messages_data['login'];
     $current_message = $incoming_messages_data['message_content'];
     $current_date_sent = $incoming_messages_data['date_sent'];
     $current_message_id = $incoming_messages_data['message_id'];
     $current_message_stat = $incoming_messages_data['message_stat'];
 ?>
    <tr message_id=<?=$current_message_id?> valign=top style="vertical-align: top; <?if($current_message_stat=='0') echo "background-color: #eee"?>">
    <td valign=top style="text-align: left; vertical-align: top" width=180px>
    <p class="small"><b><?=$admin_fio; ?></b></p>
    <p class="small"><b><?=$current_date_sent; ?></b></p></td>
    <td valign=top style="vertical-align: top"><a href="?mode=outcoming_messages&message_id=<?=$current_message_id?>" class=message_link>
    <? if(strlen($current_message)>400){
    echo substr($current_message,0, strrpos(substr($current_message,0,400), " "));
    }else echo $current_message;?></a></td>
    <td valign=top style="vertical-align: top" width=120px><a href="message_delete_form.php?action=delete_sended_message&message_id=<?=$current_message_id?>" class=minilink>удалить сообщение</a></td>
    </tr>
<?}}?>
</table>