<h1>Таблица уровней</h1>
<p class=wide_small>Увеличивать уровень Шоколадной Фабрики в игре очень выгодно! Вы сможете получать намного больше шоколада при меньших затратах, а также начиная с 3-его уровня
Вы начнете получать дополнительные бонусы.
Чем выше уровень Шоколадной Фабрики, тем больше фабрика приносит бонусов в виде шоколада! Бонусы также как начисляются 1 раз в 5 минут.<b>
</b></p>
<table border="0" width="480" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td rowspan="2">Шоколадная Фабрика</td>
        <td rowspan="2" width="60">Уровень</td>
        <td colspan="2">Уровень производства шоколада (за 5 мин.)</td>
        <td rowspan="2">Цена</td>
    </tr>
    <tr align="center">
        <td width="100">Обычный</td>
        <td width="100">Бонус</td>

    </tr>
<?
$get_level_info_query=mysqli_query($connector, "SELECT * FROM levels WHERE level_id<=6");
while($get_level_info=mysqli_fetch_assoc($get_level_info_query)){
                $level = $get_level_info['level_id'];
                $cost = $get_level_info['cost'];
                $harvest = $get_level_info['harvest'];
                $bonus   = $get_level_info['bonus'];?>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/rudnik.png" width="70"></td><td>Шоколадная Фабрика</td></tr></table></td>
        <td><?=$level?></td>
        <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/almaz.png" width="20"></td><td><?=$harvest?></td></tr></table></td>
       <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/almaz.png" width="20"></td><td><?=$bonus?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><img src="images/design/coins.png" width="20"></td><td><?=$cost?></td></tr></table></td>
    </tr>
<?}?>
</table>