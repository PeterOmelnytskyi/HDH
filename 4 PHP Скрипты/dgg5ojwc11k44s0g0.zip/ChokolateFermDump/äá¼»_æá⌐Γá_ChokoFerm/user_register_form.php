<?
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("config.php");
//mb_internal_encoding("UTF-8");
$action         =   $_REQUEST['action'];
$sex            =   htmlspecialchars($_REQUEST['sex']);
$user_skype     =   htmlspecialchars($_REQUEST['user_skype']);
$user_icq       =   htmlspecialchars($_REQUEST['user_icq']);
$user_mail      =   htmlspecialchars($_REQUEST['user_mail']);
$user_phone     =   htmlspecialchars($_REQUEST['user_phone']);
$user_pwd       =   htmlspecialchars($_REQUEST['user_pwd']);
$user_login     =   htmlspecialchars($_REQUEST['user_login']);
$user_data      =   htmlspecialchars($_REQUEST['user_data']);
$key            =   htmlspecialchars($_REQUEST['key']);

$sex            =   mysqli_real_escape_string($connector,$sex);
$user_skype     =   mysqli_real_escape_string($connector,$user_skype);
$user_icq       =   mysqli_real_escape_string($connector,$user_icq);
$user_mail      =   mysqli_real_escape_string($connector,$user_mail);
$user_phone     =  mysqli_real_escape_string($connector,$user_phone);
$user_pwd       =  mysqli_real_escape_string($connector,$user_pwd);
$user_login     =  mysqli_real_escape_string($connector,$user_login);
$user_data      =  mysqli_real_escape_string($connector,$user_data);
$key            =  mysqli_real_escape_string($connector,$key);


if($action=="register"){
//добавлени к сессии регистрации данных, чтобы не вводить их по нескольку раз
$_SESSION['user_login'] = $user_login;
$_SESSION['user_mail'] = $user_mail;
$_SESSION['user_skype'] = $user_skype;
$_SESSION['user_icq'] = $user_icq;
$_SESSION['sex'] = $sex;

      $error="";
      $login_counter = array();
      if((strlen($user_login)>16) or (strlen($user_login)<6)) $error.="&false_login=true";
      if((strlen($user_pwd)>16) or (strlen($user_pwd)<6)) $error.="&false_password=true";
      $check_login_query_text = "SELECT login FROM clients WHERE login='$user_login'";
      $check_login_query = mysqli_query($connector, $check_login_query_text);
      while($login_counter_data = mysqli_fetch_assoc($check_login_query))
      {
        $login_counter[] = $login_counter_data['login'];
      }
      if(count($login_counter)>0) $error.="&result=login_exists";
      if(!empty($error)) {
        header("Location: index.php?mode=register".$error);
        exit;}

      if(!preg_match("/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/",$user_mail))
         {
        $error.="&result=mail_failed";
        header("Location: index.php?mode=register".$error);
        exit;
        }

      $check_mail_query_text = "SELECT * FROM clients WHERE client_mail='$user_mail'";
      $check_mail_query = mysqli_query($connector, $check_mail_query_text);
      $check_mail_counter = mysqli_num_rows($check_mail_query);

      if($check_mail_counter>0) $error.="&result=mail_exists";
      if(!empty($error)) {
        header("Location: index.php?mode=register".$error);
        exit;
        }

      /*проверка на блокированные почтовые сервера*/
      /*
      if(substr($user_mail,-8)=="@mail.ru") $error.="&result=mail_blocked";
      if(!empty($error)) {
        header("Location: index.php?mode=register".$error);
        exit;
        }
        */


        $key=md5($user_login."251188".$user_login);
        $pwd=md5($user_pwd);
        if(!empty($_SESSION['register_referer'])){
            $ref_login = $_SESSION['register_referer'];
            $ref_id_query_text = "SELECT client_id FROM clients WHERE login='$ref_login'";
            $ref_id_query = mysqli_query($connector, $ref_id_query_text);
            while($ref_id_data = mysqli_fetch_assoc($ref_id_query))
            {
              $ref_id = $ref_id_data['client_id']+0;
            }
        }
        else $ref_id=0;
        $query="INSERT INTO clients (client_sex, login, password, client_skype, client_icq, client_mail, client_phone_number,
        client_stat, add_date, account_key, client_referal) VALUES ('$sex','$user_login', '$pwd',
        '$user_skype', '$user_icq', '$user_mail', '$user_phone', 1, NOW(), '$key', $ref_id)";
        if($create_user=mysqli_query($connector, $query))
      {
         if(empty($error)){
        $_SESSION['key'] = $key;
        $default_mail = mysqli_query($connector, "SELECT admin_mail FROM settings");
        while($mail=mysqli_fetch_assoc($default_mail)){$def_mail=$mail['admin_mail'];}
		  $reg_time=date("Y-m-d (H:i:s)",time());
                //заголовок для администратора
                //$headers  = "MIME-Version: 1.0\r\n";
                $headers .= "Content-Type: text/html  charset=utf-8\r\n";
                $headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
                $headers .= "From: \"Администрация сайта $sitename\r\n";
                //заголовок для сотрудника
                //$headers2  = "MIME-Version: 1.0\r\n";
                $headers2 .= "Content-Type: text/html  charset=utf-8\r\n";
                $headers2 .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
                $headers2 .= "From: \"Администрация сайта $sitename  <auto_messager@$sitename>\r\n";
                //$headerszakaz .= "X-Mailer: My Send E-mail\r\n";
                @mail("$def_mail","Регистрация нового игрока на сайте $sitename","Игрок был успешно зарегистрирован на сайте $sitename Логин: <b>$user_login</b>,
                электронная почта: <b>$user_mail</b>, контактный телефон: <b>$user_phone</b>, дата регистрации: <b>$reg_time</b>","$headers");//отправляем сообщение администратору
                @mail("$user_mail","Регистрация нового игрока на сайте $sitename","Уведомление!<br>
                Вы были зарегистрированы на сайте $sitename. Если это письмо пришло по ошибке, удалите его.
                Ваш логин на сайте: <b>$user_login</b>, пароль: <b>$user_pwd</b>\r\n После авторизации вы сможете сменить пароль на привычный или более запоминающийся.
                <a class=minilink href='http://$sitename/user_register_form.php?action=activate_account&key=$key'>ссылка активации.</a>
                <br>Добро пожаловать на сайт <a href='http://$sitename'>$sitename</a>","$headers2");//отправляем сообщение заказчику
			    header("Location: ".$_SERVER['HTTP_REFERER']."");
			}
              //если игрок начинает новую тысячу, создаем новый банк для него
        header("Location: index.php?mode=register_last_step");
        exit();
        }
      else echo $query."<br>".mysqli_error($connector);
      exit();
}
if($action=="activate_account"){
       $base_key_query=mysqli_query($connector, "SELECT account_key, client_referal, client_id FROM clients WHERE account_key='$key'");
       while($base_key=mysqli_fetch_assoc($base_key_query))
       {
          $base_key_data=$base_key['account_key'];
          $new_client_id=$base_key['client_id'];
          $client_referal=$base_key['client_referal'];
       }
       if($base_key_data==$key){
          $activate_user=mysqli_query($connector, "UPDATE clients SET client_stat=2 WHERE account_key='$key'");
if($client_referal=='0'){
/*если реферал отсутствует применить автореферал*/
$get_last_referer_query=mysqli_query($connector, "SELECT * FROM autoreferal WHERE end_time>NOW() ORDER BY last_uptime ASC LIMIT 1");
 while($get_last_referer=mysqli_fetch_assoc($get_last_referer_query))
           {
              $last_referer = $get_last_referer['client_id'];
           }
if(intval($last_referer)>0){
          $add_clien_to_referer=mysqli_query($connector, "UPDATE clients SET client_referal=$last_referer WHERE client_id=$new_client_id");
          $update_autoreferal=mysqli_query($connector, "UPDATE autoreferal SET client_counter=client_counter+1, last_uptime=NOW() WHERE client_id=$last_referer");
    }
}
          header("Location: index.php?mode=register_complete");
       }
       else echo "ошибка активации аккаунта";
}
if($action=="get_password"){
      $error="";
      $login_counter = array();
      $mail_counter = array();
      $key_counter  = array();
      $user_data = htmlspecialchars(substr($user_data, 0, 32));
      $check_login_query_text = "SELECT account_key, login, client_mail FROM clients WHERE login='$user_data' OR client_mail='$user_data' LIMIT 1";
      //echo $check_login_query_text;
      $check_login_query = mysqli_query($connector, $check_login_query_text);
      while($login_counter_data = mysqli_fetch_assoc($check_login_query))
      {
        $mail_counter[] = $login_counter_data['client_mail'];
        $login_counter[] = $login_counter_data['login'];
        $key_counter[] = $login_counter_data['account_key'];
      }
      if((count($login_counter)==0) and (count($mail_counter)==0))
      {
        $error.="&result=login_or_mail_not_exists";
        if(!empty($error)) header("Location: index.php?mode=get_password".$error);
      }
      else {
          $restore_login = $login_counter[0];
          $restore_mail  = $mail_counter[0];
          $restore_key =  $key_counter[0];
          //echo  $restore_login." ".$restore_mail." ".$restore_key;
		  $reg_time=date("Y-m-d (H:i:s)",time());
                $headers .= "Content-Type: text/html  charset=utf-8\r\n";
                $headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
                $headers .= "From: \"Администрация сайта $sitename\r\n";
                $headers2 .= "Content-Type: text/html  charset=utf-8\r\n";
                $headers2 .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
                $headers2 .= "From: \"Администрация сайта $sitename  <auto_messager@$sitename>\r\n";
                @mail("$restore_mail","Заявка на восстановление пароля игрока на сайте $sitename","Уведомление!<br>
                Для генерации нового пароля игрока $restore_login пройдите по следующей ссылке.
                <a class=minilink href='http://$sitename/user_register_form.php?action=activate_new_pass&key=$restore_key'>ссылка генерации пароля.</a>
                <br>Добро пожаловать на сайт <a href='http://$sitename'>$sitename</a>","$headers2");//отправляем сообщение заказчику
			    header("Location: index.php?mode=get_password&result=restore_send");
                exit();
			}

}
if($action=="activate_new_pass"){
       $base_key_query=mysqli_query($connector, "SELECT client_mail, password FROM clients WHERE account_key='$key'");
       while($base_key=mysqli_fetch_assoc($base_key_query))
       {
          $old_pass  =  $base_key['password'];
          $client_mail  =  $base_key['client_mail'];

       }
       if(!empty($old_pass)){
          $new_pwd_hash = md5($key);
          $new_pwd      = substr($new_pwd_hash, 24, 6);
          $new_pwd_base = md5($new_pwd);
          $activate_user=mysqli_query($connector, "UPDATE clients SET password = '$new_pwd_base' WHERE account_key='$key'");
          header("Location: index.php?mode=register_complete");
    	  $reg_time=date("Y-m-d (H:i:s)",time());
          $headers .= "Content-Type: text/html  charset=utf-8\r\n";
          $headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
          $headers .= "From: \"Администрация сайта $sitename\r\n";
          $headers2 .= "Content-Type: text/html  charset=utf-8\r\n";
          $headers2 .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
          $headers2 .= "From: \"Администрация сайта $sitename  <auto_messager@$sitename>\r\n";
          @mail("$client_mail","Был сброшен пароль игрока на сайте $sitename","Уведомление!<br>
          Ваш пароль на сайте: <b>$new_pwd</b>\r\n После авторизации вы сможете сменить пароль на привычный или более запоминающийся.
          <br>Добро пожаловать на сайт <a href='http://$sitename'>$sitename</a>","$headers2");//отправляем сообщение заказчику
          header("Location: index.php?mode=get_password&result=restore_success");
          exit;
       }
       header("Location: index.php?mode=get_password&result=restore_failed");
          exit;
}

if($action=="reactivate_account"){
       $base_key_query=mysqli_query($connector, "SELECT account_key FROM clients WHERE account_key='$key'");
       while($base_key=mysqli_fetch_assoc($base_key_query))
       {
          $base_key_data=$base_key['account_key'];
       }
       if($base_key_data==$key){
          $activate_user=mysqli_query($connector, "UPDATE clients SET client_stat=2 WHERE account_key='$key'");

          header("Location: index.php?mode=reactivate_complete");
       }
       else echo "ошибка активации аккаунта";
}


if($action=="reactivate_mail"){
require_once ("current_settings.php");
  if(!empty($current_client_mail)){
		  $reg_time=date("Y-m-d (H:i:s)",time());
                //заголовок для сотрудника
                //$headers2  = "MIME-Version: 1.0\r\n";
                $headers2 .= "Content-Type: text/html  charset=utf-8\r\n";
                $headers2 .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
                $headers2 .= "From: \"Администрация сайта $sitename  <auto_messager@$sitename>\r\n";
                mail("$current_client_mail","Реактивация аккаунта игрока на сайте $sitename","Уведомление!<br>
                Вы были зарегистрированы на сайте $sitename. Если это письмо пришло по ошибке, удалите его.
                Ваш логин на сайте: <b>$login</b>.
                <a class=minilink href='http://$sitename/user_register_form.php?action=reactivate_account&key=$current_account_key'>ссылка реактивации аккаунта.</a>
                <br>Добро пожаловать на сайт <a href='http://$sitename'>$sitename</a>","$headers2");//отправляем сообщение заказчику
			    header("Location: ".$_SERVER['HTTP_REFERER']."&result=restore_success&mail=".$current_client_mail);
			}
  else {
    header("Location: ".$_SERVER['HTTP_REFERER']."&result=restore_failed");

  }
}
?>