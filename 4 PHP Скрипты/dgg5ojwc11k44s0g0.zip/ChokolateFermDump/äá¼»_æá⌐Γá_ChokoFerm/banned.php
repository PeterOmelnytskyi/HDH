<h1>Бан!</h1>
<img src="images/design/stop_big.png" width=200px>
<p class="small attention"><b><span class=attention style="line-height: 16px">Вам был ограничен доступ к сайту администрацией сайта
начиная с <?=rus_calendar($ban_start)?> и до <?=rus_calendar($ban_end)?> серверного времени.</span></b></p>
<p class="small"><b>Причина ограничения: <span class=attention><?=$ban_couse?></span></b></p>