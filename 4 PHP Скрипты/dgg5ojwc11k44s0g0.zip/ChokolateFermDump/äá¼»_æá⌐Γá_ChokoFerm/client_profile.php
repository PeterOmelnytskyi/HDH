<?
$avatar_path      = "images/avatars/";
if(($client_id == $current_admin_id) or (empty($client_id))){
$your_profile=true;
$profile_admin_fio  =   $current_admin_fio;
$profile_admin_stat =    $current_admin_stat;
$profile_client_mail=    $current_client_mail;
$profile_client_skype=   $current_client_skype;
$profile_client_icq=     $current_client_icq;
$profile_client_phone=   $current_client_phone;
$profile_client_city=    $current_client_city;
$profile_client_avatar=  $current_client_avatar;
$profile_client_add_date=$current_client_add_date;
$profile_client_last_act=$current_client_last_act;
$profile_client_actmes  =$current_client_actmes;
$profile_client_referer =$current_client_referal;
}
else{
$client_id = intval($client_id);
$user_profile_query=mysqli_query($connector, "SELECT * FROM clients WHERE client_id = $client_id");
while($user_profile_data=mysqli_fetch_assoc($user_profile_query)){
$profile_admin_fio      =$user_profile_data['login'];
$profile_admin_stat     =$user_profile_data['client_stat'];
$profile_client_mail    =$user_profile_data['client_mail'];
$profile_client_skype   =$user_profile_data['client_skype'];
$profile_client_icq     =$user_profile_data['client_icq'];
$profile_client_phone   =$user_profile_data['client_phone'];
$profile_client_city    =$user_profile_data['client_city'];
$profile_client_avatar  =$user_profile_data['client_avatar'];
$profile_client_actmes  =$user_profile_data['active_message'];
$profile_client_add_date=$user_profile_data['add_date'];
$profile_client_last_act=$user_profile_data['last_activity'];
$profile_client_referer=$user_profile_data['client_referal'];
  }
}
?>
<h1>Профиль игрока</h1>
<?if($_REQUEST['result']=='error_filetype'){?><p class=wide_small><span class=attention>Внимание!</span>
Изображение аватары может иметь расширение только следующих типов: jpg, gif, png, jpeg.</p><?}?>
<table class="levelsTable">
<tr style="vertical-align: top">
    <td style="vertical-align: top" align=left class="" rowspan=9 width=220px>
    <?if(!$your_profile){?>
<img src="<?=$avatar_path.$profile_client_avatar?>" style="max-height: 180px; max-width: 150px; min-width: 120px; min-height: 150px; border: 1px solid #666; background: #343a4e" id=avatar>
<?$check_friend_query_text = mysqli_query($connector, "SELECT * FROM client_relationship WHERE
         (client1_id = $current_admin_id AND client2_id = $client_id AND stat1 = 2) OR (client2_id = $current_admin_id AND client1_id = $client_id AND stat2 = 2)");
         while($user_friends_data=mysqli_fetch_assoc($check_friend_query_text)){
        $friend_client1_stat = $user_friends_data['stat1'];
        $friend_client2_stat = $user_friends_data['stat2'];
        }
        if((empty($friend_client1_stat)) AND (empty($friend_client2_stat))){?>
       <div class=edit_button>
        <a href='user_profile.php?action=add_friend&client_id=<?=$client_id?>'><span class=success>Добавить в друзья</span></a>
       </div>
       <?}
       else{
         ?>
       <div class=edit_button>
       <a href='user_profile.php?action=delete_friend&client_id=<?=$client_id?>'><span class=attention>Удалить из друзей</span></a>
       </div>
       <?}?>
    <?if($profile_client_actmes==0){?>
    <div class=edit_button><a href="?mode=new_message&client_id=<?=$client_id?>">Написать игроку</a></div>
    <?}}else{?>

    <img src="<?=$avatar_path.$profile_client_avatar?>" style="max-height: 180px; max-width: 150px; min-width: 120px; min-height: 150px; border: 1px solid #666; background: #343a4e" id=avatar>
    <form name="avatar" action="user_profile.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="action" value="upload_avatar">
    <input type="file" name="avatar">
    <input type="submit" value="Загрузить" class=input_button>
    </form>
    <?}?>
    </td>
    <td class="" width=220px><p class=small>Имя игрока: </p></td>
    <td class="" width=220px><p class=small><b id=c_fio><?=$profile_admin_fio?></b><?if($your_profile) echo " (это вы)"?></p></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>Город: </p></td>
    <td class=""><p class=small id=c_city><?=$profile_client_city?></p></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>Зарегистрирован(а): </p></td>
    <td class=""><p class=small><?=$profile_client_add_date?></p></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>Последний раз посещал(а): </p></td>
    <td class=""><p class=small><?=$profile_client_last_act?></p></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>skype: </p></td>
    <td class=""><p class=small id=c_skype><?=$profile_client_skype?></p></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>icq номер: </p></td>
    <td class=""><p class=small id=c_icq><?=$profile_client_icq?></p></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>Номер телефона: </p></td>
    <td class=""><p class=small id=c_phone><? if($your_profile){echo $profile_client_phone;} else echo "скрыто";?></p></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>Кто пригласил: </p></td>
    <td class=""><? if($profile_client_referer>0){
    $user_profile_query=mysqli_query($connector, "SELECT login FROM clients WHERE client_id = $profile_client_referer");
while($user_profile_data=mysqli_fetch_assoc($user_profile_query)){
  $ref_login = $user_profile_data['login'];
  }?>
    <a class=minilink href="?mode=client_profile&client_id=<?=$profile_client_referer?>"><?=$ref_login?></a>
    <?}?></td>
</tr>
<tr style="vertical-align: top">
    <td class="" colspan=2 align=center>
    <?if($your_profile){?>
    <div class=edit_button><a href="#" id=edit_profile>редактировать профиль</a></div>
    <?}?>
    </td>
</tr>
</table>
<?if($your_profile){?>
<form name="avatar" action="user_profile.php" method="post">
<input type="hidden" name="action" value="active_message">
<table>
<tr style="vertical-align: top">
    <td align=center>
<p class=small><input type="checkbox" name="no_message" <?if($profile_client_actmes==1) echo "checked";?>>Не получать письма <input type="submit" value="Сохранить" style="margin: 0px"></p>
    </td>
</tr>
</table>
</form>
 <?}else{
if($profile_client_actmes==1){?>
<p class=small>Пользователь отключил возможность приема сообщений.</p>
<?}?>
 <?}?>
<div id=profile_editor>
<form name="avatar" action="user_profile.php" method="post">
<input type="hidden" name="action" value="edit_profile">
<table class="levelsTable" width=100%>
<tr style="vertical-align: top">
    <td class=""><p class=small>Город: </p></td>
    <td class=""><input type=text name='client_city' value='<?=$profile_client_city?>'></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>Мобильный телефон: </p></td>
    <td class=""><input type=text name='client_phone_number' value='<?=$profile_client_phone?>'></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>skype: </p></td>
    <td class=""><input type=text name='client_skype' value='<?=$profile_client_skype?>'></td>
</tr>
<tr style="vertical-align: top">
    <td class=""><p class=small>icq номер: </p></td>
    <td class=""><input type=text name='client_icq' value='<?=$profile_client_icq?>'></td>
</tr>
<tr style="vertical-align: top" align=center>
    <td class="" colspan=2><input type="submit" value="Сохранить" class=input_button style="margin: 0px"></td>
</tr>
</table>
</form>
</div>


<div id=friends>
<h1>Друзья</h1>
<table class="levelsTable" width=100%>
<tr style="vertical-align: top">
    <td><p class=small>Игрок</p></td>
    <td><p class=small>Статус</p></td>
    <td><p class=small>Последняя активность</p></td>
    <td width=200px><p class=small>Контроль</p></td>
</tr>
<?if(($client_id == $current_admin_id) or (empty($client_id))){ ?>
<?$user_friends_query=mysqli_query($connector, "SELECT * FROM client_relationship WHERE
 client_relationship.client1_id = $current_admin_id ORDER BY client_relationship.client_relationship_id");
 while($user_friends_data=mysqli_fetch_assoc($user_friends_query)){
$friend_client2_id   = $user_friends_data['client2_id'];
$friend_client1_stat = $user_friends_data['stat1'];
$friend_client2_stat = $user_friends_data['stat2'];
  /*
  stat:
  1 - запрос в друзья
  2 - добавлен в друзья
  */
$client_friends_query=mysqli_query($connector, "SELECT * FROM clients WHERE client_id = $friend_client2_id");
while($client_friends_data=mysqli_fetch_assoc($client_friends_query)){
$friend_admin_login     = $client_friends_data['login'];
$friend_admin_stat      = $client_friends_data['client_stat'];
$friend_client_mail     = $client_friends_data['client_mail'];
$friend_client_skype    = $client_friends_data['client_skype'];
$friend_client_icq      = $client_friends_data['client_icq'];
$friend_client_phone    = $client_friends_data['client_phone'];
$friend_client_city     = $client_friends_data['client_city'];
$friend_client_avatar   = $client_friends_data['client_avatar'];
$friend_client_actmes   = $client_friends_data['active_message'];
$friend_client_add_date = $client_friends_data['add_date'];
$friend_client_last_act = $client_friends_data['last_activity'];
$friend_client_referer  = $client_friends_data['client_referal'];?>
<tr style="vertical-align: top">
    <td width=100px align=center><a class=minilink href="?mode=client_profile&client_id=<?=$friend_client2_id?>"><?=$friend_admin_login?></a>
    <img src="<?=$avatar_path.$friend_client_avatar?>" style="max-height: 120px; max-width: 100px; min-width: 80px; min-height: 80px; border: 1px solid #666; background: #343a4e"></td>
    <td width=200px align=center><?
        if(($friend_client1_stat=='2') AND ($friend_client2_stat=='1')){echo "<p class=small><span class=inwork style='italic'>Вы отправили заявку, но пользователь пока не принял решение добавить вас</span></p>";}
    elseif(($friend_client1_stat=='1') AND ($friend_client2_stat=='2')){echo "<p class=small><span class=inwork style='italic'>Пользователь отправил вам заявку, но вы пока не приняли решение добавить его в друзья</span></p>
    <div class=edit_button><a href='user_profile.php?action=add_friend&client_id=".$friend_client2_id."'><span class=success>Принять</span></a></div>
    <div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client2_id."'><span style='color: red'>удалиться из друзей</span></a></div>";
    }
    elseif(($friend_client1_stat=='0') AND ($friend_client2_stat=='2')){
      echo "<p class=small><span class=inwork style='italic'>Пользователь удалил вас из друзей</span></p>";
      echo "<div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client2_id."'><span class=attention>Удалиться из его друзей</span></a></div>";
      }
    elseif(($friend_client1_stat=='2') AND ($friend_client2_stat=='0')){
      echo "<p class=small><span class=attention style='italic'>Вы удалили пользователя из друзей</span></p>";
      echo "<div class=edit_button><a href='user_profile.php?action=add_friend&client_id=".$friend_client2_id."'><span class=success>Добавить обратно</span></a></div>";
      }

    elseif(($friend_client1_stat=='1') AND ($friend_client2_stat=='0')){echo "<p class=small><span class=attention style='italic'>Вы отправили заявку, но пользователь отверг ее</span></p>";}
    elseif(($friend_client1_stat=='2') AND ($friend_client2_stat=='2')){echo "<p class=header><b class=success>Вы друзья</b></p>";
    echo "<div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client2_id."'><span style='color: red'>Удалиться из друзей</span></a></div>";}

    ?></td>
    <td><p class=small><?=rus_calendar($friend_client_last_act);?></p></td>
    <td><div class=edit_button><a href="?mode=new_message&client_id=<?=$friend_client2_id?>">Написать игроку</a></div></td>
</tr>
<?}?>
<?}?>



<?$user_friends_query=mysqli_query($connector, "SELECT * FROM client_relationship WHERE
 client_relationship.client2_id = $current_admin_id ORDER BY client_relationship.client_relationship_id");
 while($user_friends_data=mysqli_fetch_assoc($user_friends_query)){
$friend_client1_id   = $user_friends_data['client1_id'];
$friend_client1_stat = $user_friends_data['stat1'];
$friend_client2_stat = $user_friends_data['stat2'];
  /*
  stat:
  1 - запрос в друзья
  2 - добавлен в друзья
  */
$client_friends_query=mysqli_query($connector, "SELECT * FROM clients WHERE client_id = $friend_client1_id");
while($client_friends_data=mysqli_fetch_assoc($client_friends_query)){
$friend_admin_login     = $client_friends_data['login'];
$friend_admin_stat      = $client_friends_data['client_stat'];
$friend_client_mail     = $client_friends_data['client_mail'];
$friend_client_skype    = $client_friends_data['client_skype'];
$friend_client_icq      = $client_friends_data['client_icq'];
$friend_client_phone    = $client_friends_data['client_phone'];
$friend_client_city     = $client_friends_data['client_city'];
$friend_client_avatar   = $client_friends_data['client_avatar'];
$friend_client_actmes   = $client_friends_data['active_message'];
$friend_client_add_date = $client_friends_data['add_date'];
$friend_client_last_act = $client_friends_data['last_activity'];
$friend_client_referer  = $client_friends_data['client_referal'];?>
<tr style="vertical-align: top">
    <td width=100px align=center><a class=minilink href="?mode=client_profile&client_id=<?=$friend_client1_id?>"><?=$friend_admin_login?></a>
    <img src="<?=$avatar_path.$friend_client_avatar?>" style="max-height: 120px; max-width: 100px; min-width: 80px; min-height: 80px; border: 1px solid #666; background: #343a4e"></td>
    <td width=200px align=center><?
    if(($friend_client1_stat=='1') AND ($friend_client2_stat=='2')){echo "<p class=small><span class=inwork style='italic'>Вы отправили заявку, но пользователь пока не принял решение добавить вас</span></p>";}
    elseif(($friend_client1_stat=='2') AND ($friend_client2_stat=='1')){echo "<p class=small><span class=inwork style='italic'>Пользователь отправил вам заявку, но вы пока не приняли решение добавить его в друзья</span></p>
    <div class=edit_button><a href='user_profile.php?action=add_friend&client_id=".$friend_client1_id."'><span class=success>Принять</span></a></div>
    <div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client1_id."'><span class=attention>Отказаться</span></a></div>";
    }
    elseif(($friend_client1_stat=='0') AND ($friend_client2_stat=='2')){
      echo "<p class=small><span class=inwork style='italic'>Вы удалили пользователя из друзей</span></p>";
      echo "<div class=edit_button><a href='user_profile.php?action=add_friend&client_id=".$friend_client1_id."'><span style='color: red'>Добавить обратно</span></a></div>";
      }
    elseif(($friend_client1_stat=='2') AND ($friend_client2_stat=='0')){
      echo "<p class=small><span class=attention style='italic'>Пользователь удалил вас из друзей</span></p>";
      echo "<div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client2_id."'><span class=attention>Удалить из друзей</span></a></div>";
      }

    elseif(($friend_client1_stat=='1') AND ($friend_client2_stat=='0')){echo "<p class=small><span class=attention style='italic'>Вы отправили заявку, но пользователь отверг ее</span></p>";}
    elseif(($friend_client1_stat=='2') AND ($friend_client2_stat=='2')){echo "<p class=header><b class=success>Вы друзья</b></p>";
    echo "<div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client1_id."'><span class=attention>удалиться из друзей</span></a></div>";}

    ?></td>
    <td><p class=small><?=rus_calendar($friend_client_last_act);?></p></td>
    <td><div class=edit_button><a href="?mode=new_message&client_id=<?=$friend_client1_id?>">Написать игроку</a></div></td>
</tr>
<?}?>
<?}?>
<?}
else{?>
<?$user_friends_query=mysqli_query($connector, "SELECT * FROM client_relationship WHERE
 client_relationship.client1_id = $client_id AND stat2 = 2 AND stat1 = 2 ORDER BY client_relationship.client_relationship_id");
 while($user_friends_data=mysqli_fetch_assoc($user_friends_query)){
$friend_client2_id   = $user_friends_data['client2_id'];
$friend_client1_stat = $user_friends_data['stat1'];
$friend_client2_stat = $user_friends_data['stat2'];
  /*
  stat:
  1 - запрос в друзья
  2 - добавлен в друзья
  */
$client_friends_query=mysqli_query($connector, "SELECT * FROM clients WHERE client_id = $friend_client2_id");
while($client_friends_data=mysqli_fetch_assoc($client_friends_query)){
$friend_admin_login     = $client_friends_data['login'];
$friend_admin_stat      = $client_friends_data['client_stat'];
$friend_client_mail     = $client_friends_data['client_mail'];
$friend_client_skype    = $client_friends_data['client_skype'];
$friend_client_icq      = $client_friends_data['client_icq'];
$friend_client_phone    = $client_friends_data['client_phone'];
$friend_client_city     = $client_friends_data['client_city'];
$friend_client_avatar   = $client_friends_data['client_avatar'];
$friend_client_actmes   = $client_friends_data['active_message'];
$friend_client_add_date = $client_friends_data['add_date'];
$friend_client_last_act = $client_friends_data['last_activity'];
$friend_client_referer  = $client_friends_data['client_referal'];?>
<tr style="vertical-align: top">
    <td width=100px align=center><<a class=minilink href="?mode=client_profile&client_id=<?=$friend_client2_id?>"><?=$friend_admin_login?></a>
    <img src="<?=$avatar_path.$friend_client_avatar?>" style="max-height: 120px; max-width: 100px; min-width: 80px; min-height: 80px; border: 1px solid #666; background: #343a4e"></td>
    <td width=200px align=center><?
    if(($friend_client1_stat=='2') AND ($friend_client2_stat=='1')){echo "<p class=small><span class=inwork style='italic'>Вы отправили заявку, но пользователь пока не принял решение добавить вас</span></p>";}
    elseif(($friend_client1_stat=='1') AND ($friend_client2_stat=='2')){echo "<p class=small><span class=inwork style='italic'>Пользователь отправил вам заявку, но вы пока не приняли решение добавить его в друзья</span></p>
    <div class=edit_button><a href='user_profile.php?action=add_friend&client_id=".$friend_client2_id."'><span class=success>Принять</span></a></div>
    <div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client2_id."'><span class=attention>удалиться из друзей</span></a></div>";
    }
    elseif(($friend_client1_stat=='0') AND ($friend_client2_stat=='2')){
      echo "<p class=small><span class=inwork style='italic'>Вы удалили пользователя из друзей</span></p>";}

    elseif(($friend_client1_stat=='1') AND ($friend_client2_stat=='0')){echo "<p class=small><span class=attention style='italic'>Вы отправили заявку, но пользователь отверг ее</span></p>";}
    elseif(($friend_client1_stat=='2') AND ($friend_client2_stat=='2')){echo "<p class=header><b class=success>Вы друзья</b></p>";
    echo "<div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client2_id."'><span style='color: red'>удалиться из друзей</span></a></div>";}

    ?></td>
    <td><p class=small><?=rus_calendar($friend_client_last_act);?></p></td>
    <td><div class=edit_button><a href="?mode=new_message&client_id=<?=$friend_client2_id?>">Написать игроку</a></div></td>
</tr>
<?}?>
<?}?>



<?$user_friends_query=mysqli_query($connector, "SELECT * FROM client_relationship WHERE
 client_relationship.client2_id = $client_id AND stat2 = 2 AND stat1 = 2 ORDER BY client_relationship.client_relationship_id");
 while($user_friends_data=mysqli_fetch_assoc($user_friends_query)){
$friend_client1_id   = $user_friends_data['client1_id'];
$friend_client1_stat = $user_friends_data['stat1'];
$friend_client2_stat = $user_friends_data['stat2'];
  /*
  stat:
  1 - запрос в друзья
  2 - добавлен в друзья
  */
$client_friends_query=mysqli_query($connector, "SELECT * FROM clients WHERE client_id = $friend_client1_id");
while($client_friends_data=mysqli_fetch_assoc($client_friends_query)){
$friend_admin_login     = $client_friends_data['login'];
$friend_admin_stat      = $client_friends_data['client_stat'];
$friend_client_mail     = $client_friends_data['client_mail'];
$friend_client_skype    = $client_friends_data['client_skype'];
$friend_client_icq      = $client_friends_data['client_icq'];
$friend_client_phone    = $client_friends_data['client_phone'];
$friend_client_city     = $client_friends_data['client_city'];
$friend_client_avatar   = $client_friends_data['client_avatar'];
$friend_client_actmes   = $client_friends_data['active_message'];
$friend_client_add_date = $client_friends_data['add_date'];
$friend_client_last_act = $client_friends_data['last_activity'];
$friend_client_referer  = $client_friends_data['client_referal'];?>
<tr style="vertical-align: top">
    <td width=100px align=center><a class=minilink href="?mode=client_profile&client_id=<?=$friend_client1_id?>"><?=$friend_admin_login?></a>
    <img src="<?=$avatar_path.$friend_client_avatar?>" style="max-height: 120px; max-width: 100px; min-width: 80px; min-height: 80px; border: 1px solid #666; background: #343a4e"></td>
    <td width=200px align=center><?
    if($friend_client1_stat=='2'){echo "<p class=header><b class=success>У пользователя в друзьях</b></p>";}?>
    <?if($friend_client2_stat==$current_admin_id){?>
    <div class=edit_button><a href='user_profile.php?action=delete_friend&client_id=".$friend_client1_id."'><span style='color: red'>удалиться из друзей</span></a></div><?}?>
    </td>
    <td><p class=small><?=rus_calendar($friend_client_last_act);?></p></td>
    <td><div class=edit_button><a href="?mode=new_message&client_id=<?=$friend_client1_id?>">Написать игроку</a></div></td>
</tr>
<?}?>
<?}?>
<?}?>
</table>
</div>