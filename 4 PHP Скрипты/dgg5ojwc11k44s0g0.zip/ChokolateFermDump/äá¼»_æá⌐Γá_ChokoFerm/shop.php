<?
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
?>
<h1>Магазин</h1>
<p class=wide_small>Специализированный магазин позволяет приобрести Шоколадную фабрику 1-го уровня.
на шоколадной фабрике можно производить шоколад, который Вы сможете продать на рынке и получить доход.
<br>Курс игровой валюты: <b>100 золото = 1 рубль </b></p>
<br>
<?
//$tree_control_query_text = "SELECT client_id FROM trees WHERE tree_id = "
$current_apples_query_text="SELECT barrels FROM clients WHERE client_id = $current_admin_id";
$current_apples_query = mysqli_query($connector, $current_apples_query_text);
while($current_apples_data=mysqli_fetch_assoc($current_apples_query)){
                $current_apples = $current_apples_data['barrels'];
                $current_harvest= floor($current_apples/$apples_per_gold);
                $max_gold       = $current_harvest*$apples_per_gold;
                }
$get_level_up_price_query=mysqli_query($connector, "SELECT * FROM levels WHERE level_id=1");
       while($get_level_up_price_data=mysqli_fetch_assoc($get_level_up_price_query))
       {
          $upgrade_cost    = $get_level_up_price_data['cost'];
          $upgrade_harvest = $get_level_up_price_data['harvest'];
       }
?>

<table class="levelsTable" cellpadding=4px>
<form action="ferm_form.php" method=get>
<input type=hidden value="buy_tree" name=action>
<tr height=20px>
    <td width=40px align=center><img src="images/design/rudnik.png" style="vertical-align: bottom" width=120px></td>
    <td width=380px><p class=middle>Шоколадная Фабрика, 1 уровень</p>
    <p class=small>Шоколадная Фабрика приносит: <?=$upgrade_harvest*12?>   <img src="images/design/almaz.png" style="vertical-align: middle" width=20px> в час</p></td>
    <td width=100px><p class=middle><img src="images/design/coins.png" style="vertical-align: middle" width=30px> <?=$upgrade_cost?></p></td>
    <td width=160px><input type=submit value="Купить" class=input_button></td>
</tr>
</form>
<form name=buy_combine action="ferm_form.php" method=get>
<input type=hidden value="buy_combine" name=action>
<tr height=20px>
    <td width=40px><img src="images/design/telejka.png" style="vertical-align: bottom" width=110px></td>
    <td width=380px><p class=middle>Помощник</p>
    <p class=small>Приглашается на 1 месяц, позволяет в течение месяца производить сбор шоколада прозрачно и незаметно для игрока.</p></td>
    <td width=100px><p class=middle><img src="images/design/coins.png" style="vertical-align: middle" width=30px> <?=$combine_price?></p></td>
    <td width=160px><input type=submit value="Арендовать" class=input_button></td>
</tr>
</form>

<form action="ferm_form.php" method=get>
<input type=hidden value="buy_autoreferal" name=action>
<tr height=20px>
    <td width=40px><img src="images/design/autoreferal.png" style="vertical-align: bottom" width=100px></td>
    <td width=380px><p class=middle>Автореферал</p>
    <p class=small>Приобретается на две недели, позволяет стать реферером для игроков, которые регистрируются без реферера.</p></td>
    <td width=100px><p class=middle><img src="images/design/coins.png" style="vertical-align: middle" width=30px> <?=$autoreferal_price?></p></td>
    <td width=160px><input type=submit value="Купить" class=input_button></td>
</tr>
</form>
</table>

<?if($_REQUEST['error']=='not_enough_gold'){?><p class=wide_small><span class=attention>Внимание!</span>
 Золота недостаточно для покупки!</p><?}?>
<?if($_REQUEST['error']=='already_have'){?><p class=wide_small><span class=attention>Внимание!</span>
 У вас уже имеется приглашенный помощник!</p><?}?>
<?if($_REQUEST['success']=='buy_success'){?><p class=wide_small><span class=success>Поздравляем!</span>
Вы приобрели Шоколадную Фабрику первого уровня!
 </p><?}?>
 <?if($_REQUEST['success']=='buy_autoreferal_success'){?><p class=wide_small><span class=success>Поздравляем!</span>
Вы приобрели автореферал!
 </p>
 <?}?>
 <?if($_REQUEST['success']=='buy_combine_success'){?><p class=wide_small><span class=success>Поздравляем!</span>
Вы пригласили помощника для автоматического сбора шоколада!
 </p><?}?>