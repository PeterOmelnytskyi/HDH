<?
$session_login      = "mushroom_login";
$session_pass       = "mushroom_pass";
$wmr                = "R244741202890";
$wmr                = "R244741202890";
$sms_anon_key       = "YmhbcWv67vemzNmT6Dy0Wd4YK2ltVj5tMbLpx7kusFWhS02OCqNZJGxU9ZET9DLaP1OMa9";
$sitename           = "chokolat-fabrik.ru";
$mail_contact       = "chokolat-fabrik.ru@yandex.ru";
$skype_contact      = "chokolat-fabrik.ru";
$icq_contact        = "";
$qiwi_account       = "+79033849277";
$yandex_account     = "______________";
$LiqPAY_account     = "___________________________";
$PM_account         = "___________________________";
$interkassa_key     = "55A744AB-C5AE-2CB4-33DF-5FF7FCEE7B67";
$wm_attestat_status = false; /*or false*/

?>