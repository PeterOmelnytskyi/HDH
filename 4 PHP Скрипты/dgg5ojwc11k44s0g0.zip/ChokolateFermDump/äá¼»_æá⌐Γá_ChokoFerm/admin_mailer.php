<h1>Рассылки</h1>
<?
$mailers_query_text="SELECT * FROM mailer ORDER By mailer_id DESC";
$mailers_query=mysqli_query($connector, $mailers_query_text);?>
<table border="0" width="990" class="levelsTable"  cellspacing=0px>
<?
$system[1] = "Webmoney";
$system[2] = "Яндекс-деньги";
$system[3] = "Мобильный телефон";
$system[4] = "liqpay.com";
$system[5] = "Qiwi-кошелек";
$system[10] = "Perfect-money";
$banner_status[0] = "<p class=inwork>рассылка взята на проверку</p>";
$banner_status[1] = "<p class=attention>рассылка отвергнута</p>";
$banner_status[2] = "<p class=success>рассылка успешно произведена</p>";
while($banners_data=mysqli_fetch_assoc($mailers_query)){
   $start_datetime    = $banners_data['start_datetime'];
   $mail              = $banners_data['mail'];
   $description       = $banners_data['description'];
   $pay_type          = $banners_data['pay_type'];
   $mail_id           = $banners_data['mailer_id'];
   $stat              = $banners_data['stat'];
   $pay_stat          = $banners_data['pay_stat'];
   $client_mailers_query_text="SELECT count(*) AS counter FROM client_mailer WHERE mailer_id=$mail_id";
$client_mailers_query=mysqli_query($connector, $client_mailers_query_text);
while($mailers_client_data=mysqli_fetch_assoc($client_mailers_query)){
$counter = $mailers_client_data['counter'];
}
if($counter=="") $counter=0;
?>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><b>id рассылки</b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b>Время рассылки</b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b>Почта заказщика</b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b>Получивших</b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b>Удалить</b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b>Операции</b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b>Статус</b></td></tr></table></td>
    </tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><?=$mail_id?><br></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=rus_calendar($start_datetime)?><br></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$mail?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$counter?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>
        <a class="minilink" href="request_mailer_controller.php?action=delete_mailer&mail_id=<?=$mail_id?>"><span class=attention>Удалить</span></a>
        </td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>
         <?if($stat=='1'){?>
        <a class="minilink" href="request_mailer_controller.php?action=edit_stat&mail_id=<?=$mail_id?>&stat=0"><span class=success>Не разослан</span></a>
        <?}else {?>
        <a class="minilink" href="request_mailer_controller.php?action=edit_stat&mail_id=<?=$mail_id?>&stat=1"><span class=attention>Разослать</span></a>
        <?}?>
        <?if($pay_stat=='1'){?>
        <a class="minilink" href="request_mailer_controller.php?action=edit_pay_stat&mail_id=<?=$mail_id?>&pay_stat=0"><span class=success>Не оплачен</span></a>
        <?}else {?>
        <a class="minilink" href="request_mailer_controller.php?action=edit_pay_stat&mail_id=<?=$mail_id?>&pay_stat=1"><span class=attention>Оплачен</span></a>
        <?}?>
         </td></tr></table></td>
         <td><table class="levelsTableCell" border=0px><tr><td>
          <?if($pay_stat=='1'){?> <span class=success>Оплачен</span><?} else {?><span class=attention>Не оплачен</span><?}?>
         / <?if($stat=='1'){?> <span class=success>Разослано</span><?} else {?><span class=attention>Не разослано</span><?}?>
         </td></tr></table></td>
    </tr>
    <tr align="center">
    <td><table class="levelsTableCell" border=0px><tr><td></td></tr></table></td>
        <td colspan=4 align=left><table class="levelsTableCell" border=0px><tr><td align=left><b>Описание</b></td></tr></table></td>
        <td colspan=2 align=left><table class="levelsTableCell" border=0px><tr><td align=left><b>
        <form name=send_mailer method=post action="request_mailer_controller.php">
        <input type=hidden name=action value=send_mailer>
        <input type=hidden name=mail_id value="<?=$mail_id?>">
        <input type=text name=mailer_count value="" placeholder="число клиентов для рассылки" style="width: 220px">
        <input type=submit value="Разослать">
        </form>
        </b></td></tr></table></td>
    </tr>
    <tr align="center">
    <td><table class="levelsTableCell" border=0px><tr><td></td></tr></table></td>
        <td colspan=6 align=left><table class="levelsTableCell" border=0px><tr><td align=left>
        <form name=edit_mailer method=post action="request_mailer_controller.php">
        <input type=hidden name=mail_id value="<?=$mail_id?>">
        <input type=hidden name=action value=edit_mailer>
        <textarea name="description" cols=80 rows=4><?=$description?></textarea>
        <input type=submit value="Сохранить">
        </form>

        </td></tr></table></td>
    </tr>
<?}?>
</table>