<h1>Восстановление пароля</h1>
<?if($_REQUEST['result']=="restore_success"){?>
<p class=success>Новый пароль был отправлен на указанный email игрока!</p>
<?}elseif($_REQUEST['result']=="restore_failed"){?>
<p class=attention>Генерация нового пароля закончилась неудачно!</p>
<?}elseif($_REQUEST['result']=="restore_send"){?>
<p class=success>Данные для генерации нового пароля отправлены на указанный email игрока!</p>
<?}else{?>
<form name=user_register action="user_register_form.php" method=post>
<input type=hidden name=action value=get_password>
<table cellspacing="1px" align="left" border=0px>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Введите ваш логин или электронную почту</p></td>
    <td width=260px align=center class=info_cell><input type=text name=user_data style="width: 240px"></td>
</tr>
<?if($_REQUEST['result']=="login_or_mail_not_exists"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>Введенный логин или электронная почта не найдены!</p>
    </td>
</tr>
<?}?>
<tr style="vertical-align: top">
    <td colspan=2 class=info_cell align=center>
    <button type=submit class=search_from_element style="width: 240px">Сбросить пароль</button></td>
    </tr>
</table>
</form>
<?}?>