<?php
define('HOST', 'localhost');
define('DATABASE', 'choko');
define('MYSQL_USER', 'root');
define('MYSQL_PASS', '');

$connector=mysqli_connect(HOST, MYSQL_USER, MYSQL_PASS, DATABASE) or die('Нет соединения с MySQL сервером!');
if (!mysqli_set_charset($connector, 'utf8')) {
    die('Невозможно установить кодировку utf8: '.mysqli_error($connector));
}

//error_reporting(0);

/* ip контроль для начальной защиты от ddos */

$current_ip = $_SERVER['REMOTE_ADDR'];
$delete_IP_info_query = mysqli_query($connector, "DELETE FROM ip_control WHERE UNIX_TIMESTAMP(time)+60<UNIX_TIMESTAMP(NOW())");
$add_new_IP_info_query=mysqli_query($connector, "INSERT INTO ip_control (ip, time) VALUES('$current_ip', NOW())");
$get_IP_info_query=mysqli_query($connector, "SELECT *, UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(time) AS last_connect FROM ip_control WHERE ip = '$current_ip' ORDER BY time DESC");
$get_IP_info_counter = mysqli_num_rows($get_IP_info_query);
if($get_IP_info_counter>0){
$last_connect = array();
while($get_IP_info_data = mysqli_fetch_assoc($get_IP_info_query)){
  $last_connect[] = $get_IP_info_data['last_connect'];
  }
    if(count($last_connect)>200){
        require_once("ban.html");
        exit;
    }
}

$timezone_query=mysqli_query($connector, "SELECT timezone FROM settings");
while($timezone_data = mysqli_fetch_assoc($timezone_query)){
  $timezone = $timezone_data['timezone'];
}
if($timezone=="1") $timezone_mark = '+3:00';
if($timezone=="2") $timezone_mark = '+4:00';
if($timezone=="3") $timezone_mark = '+6:00';
if($timezone=="4") $timezone_mark = '+7:00';
if($timezone=="5") $timezone_mark = '+8:00';
if($timezone=="6") $timezone_mark = '+9:00';
if($timezone=="7") $timezone_mark = '+10:00';
if($timezone=="8") $timezone_mark = '+11:00';
if($timezone=="9") $timezone_mark = '+12:00';
mysqli_query($connector, "SET TIME_ZONE='$timezone_mark'");

?>
