<h1>Контактная информация</h1>
<?require_once('config.php');?>
<p class="small">
Ваши вопросы, отзывы и пожелания принимаются в скайпе <b>skype: <?=$skype_contact?></b>
Предложения по рекламе принимаются по электронной почте <b><?=$mail_contact?></b></p>
<br>
<?if($_REQUEST['result']=='success'){?><p class=wide_small><span class=success>Внимание!</span>
Ваше сообщение успешно отправлено администратору.</p><?}?>
<p class=middle>Оставить сообщение</p>
<form name="payment" action="feedback_form.php" method="get">
<input type="hidden" name="action" value="feedback">
<input type="text" name="username" value="" placeholder="ваше имя"><br>
<input type="text" name="email" value="" placeholder="ваш e-mail"><br>
<textarea name="message_text" placeholder="введите ваше сообщение" style="width: 360px; height: 120px"></textarea>
<input type="submit" value="Отправить" class=input_button style="width: 150px">
</form>
