<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
$action     = $_REQUEST['action'];
$user_id            = $_REQUEST['user_id'];
$payment_amount     =   $_REQUEST['payment_amount'];
$payment_system_id  =   $_REQUEST['payment_system_id'];
$payment_system     =   $_REQUEST['payment_system'];
$gold_increase = floor($payment_amount*100);

if ((empty($_SESSION["admin_log"])) OR (empty($_SESSION["admin_pass"])))
	{
		die("<script>window.location='admin_init.php';</script>");
	}
if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
if ($mode=="logout")
	{
		$_SESSION["admin_log"] = "";
		$_SESSION["admin_pass"] = "";
        $_SESSION["admin_mode"] =  "";
		unset($_SESSION["admin_log"]);
		unset($_SESSION["admin_pass"]);
      	unset($_SESSION["admin_mode"]);
        session_destroy();
		die("<script>window.location='admin_init.php';</script>");
	}


	if($action=="money_incoming")
	{ $error="";
         $insert_incoming_payment_query_text = "INSERT INTO payment_incoming (payment_datetime, payment_client_id, payment_summ, payment_type,
         payment_trans_id, stat) VALUES (NOW(), $user_id, '$payment_amount', $payment_system, '', 1)";
         $insert_incoming_payment_query = mysqli_query($connector, $insert_incoming_payment_query_text);
         $error.=mysqli_error($connector);
         $update_client_gold_query_text = "UPDATE clients SET gold_market = gold_market+$gold_increase WHERE client_id = $user_id";
         $update_client_gold_query = mysqli_query($connector, $update_client_gold_query_text);
         $error.=mysqli_error($connector);
         if(empty($error)){
			header("Location: adminka.php?mode=users&user_id=".$user_id."&result=payment_success");
			}
		 else echo "Произошли следующие ошибки: ".$error;
	}

    if($action=="increase_gold")
	{ $error="";
         $update_client_gold_query_text = "UPDATE clients SET gold = gold+$gold_increase WHERE client_id = $user_id";
         $update_client_gold_query = mysqli_query($connector, $update_client_gold_query_text);
         $error.=mysqli_error($connector);
         if(empty($error)){
			header("Location: adminka.php?mode=users&user_id=".$user_id."&result=payment_success");
			}
		 else echo "Произошли следующие ошибки: ".$error;
	}
        if($action=="decrease_gold_market")
	{ $error="";
         $update_client_gold_query_text = "UPDATE clients SET gold_market = gold_market-$gold_increase WHERE client_id = $user_id";
         $update_client_gold_query = mysqli_query($connector, $update_client_gold_query_text);
         $error.=mysqli_error($connector);
         if(empty($error)){
			header("Location: adminka.php?mode=users&user_id=".$user_id."&result=payment_success");
			}
		 else echo "Произошли следующие ошибки: ".$error;
	}
            if($action=="decrease_gold")
	{ $error="";
         $update_client_gold_query_text = "UPDATE clients SET gold = gold-$gold_increase WHERE client_id = $user_id";
         $update_client_gold_query = mysqli_query($connector, $update_client_gold_query_text);
         $error.=mysqli_error($connector);
         if(empty($error)){
			header("Location: adminka.php?mode=users&user_id=".$user_id."&result=payment_success");
			}
		 else echo "Произошли следующие ошибки: ".$error;
	}
?>