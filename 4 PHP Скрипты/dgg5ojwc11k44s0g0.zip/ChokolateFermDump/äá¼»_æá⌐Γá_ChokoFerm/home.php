<table>
<tr>
<td><a href="?mode=register"><img src="images/design/shap.png" border=0px style="align: left" width=250px height=250px></a><br></td>
<td style="vertical-align: top">
<h1>Шоколадная Фабрика – увлекательная игра с превосходным заработком и выводом реальных денег!</h1>
<p class="wide_small" style="text-align: justify">
Экономическая онлайн игра Шоколадная Фабрика "chokolat-fabrik.ru" - стабильный надежный доход!
Покупайте фабрики и производите шоколад, продавайте его на рынке за реальные деньги. Будьте уверены в завтрашнем дне!
Мы делаем всё для развития и постоянного улучшения проекта.
</p>
</td>
</tr>
<br>
<br>
<tr>
<td colspan=2 style="vertical-align: top">
<h1>Рекламодателям:</h1>
<p class="wide_small" style="text-align: justify">
Вы создали свой сайт - интересный проект, и естественно хотите, чтобы он был узнаваем.
Хотите вывести его на первые позиции в рейтингах и поисковых запросах.
У нас Вы сможете заказать любую рекламную кампанию и выгодно раскрутить свой сайт,
поднять в рейтингах и привлечь своих потенциальных клиентов и покупателей.
Мы делаем все для вашего удобства и ценим каждого клиента.</p>
</td>
</tr>
</table>


_____________________________________________________________________________
<p class="wide_small"><b>Текущая стоимость показа ссылки - <?=$link_per_day?> в сутки,
стоимость рассылки сообщений - <?=$mailer_price?></b></p>

<div class=button style="text-align: center; display: inline-table"><a href="?mode=request_link">Заказать показ ссылок</a></div>
<div class=button style="text-align: center; display: inline-table"><a href="?mode=request_mailer">Заказать рассылку</a></div>