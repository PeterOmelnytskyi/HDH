<?
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("current_settings.php");
require_once ("config.php");
$pay_stat       = intval($_REQUEST['pay_stat']);
$stat           = intval($_REQUEST['stat']);
$link_id        = intval($_REQUEST['link_id']);
$action         = htmlspecialchars($_REQUEST['action']);
$pay_type       = intval($_REQUEST['pay_type']);
$show_datetime  = intval($_REQUEST['show_datetime']);
$mail           = htmlspecialchars($_REQUEST['mail']);
$start_datetime = htmlspecialchars($_REQUEST['start_datetime']);
$error          = "";
$captcha        = htmlspecialchars($_REQUEST['captcha']);
$description    = $_REQUEST['description'];
$url            = $_REQUEST['url'];
$banner_path    = "images/banners/";

$link_id        =  mysqli_real_escape_string($connector,$link_id);
$pay_type       =  mysqli_real_escape_string($connector,$pay_type);
$show_datetime  =  mysqli_real_escape_string($connector,$show_datetime);
$mail           =  mysqli_real_escape_string($connector,$mail);
$start_datetime =  mysqli_real_escape_string($connector,$start_datetime);
$description    =  mysqli_real_escape_string($connector,$description);
$url            =  mysqli_real_escape_string($connector,$url);

//проверки
//заполнены ли все поля
//является ли баннер подходящим по пропорциям
//форма оплаты
//возвращать после добавления баннера на проверку id баннера
if($action=="link_request"){
  /*
      if($captcha!="волк")
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_captha");
        exit;
      }
      */
      if(empty($description))
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_description");
        exit;
      }
      if(empty($url)) {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_url");
        exit;
        }
      if(!(intval($show_datetime)>0))
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_show_datetime");
        exit;
      }
      if(!preg_match("/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/",$start_datetime))
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_start_datetime");
        exit;
      }
      if(!preg_match("/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/",$mail))
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_mail");
        exit;
      }
            $insert_banner_query_text="INSERT INTO links (url, description, mail, start_datetime, show_datetime, end_datetime, stat, counter)
            VALUES ('$url', '$description', '$mail', '$start_datetime', '$show_datetime', '$start_datetime', 0, 0)";
            $insert_banner_query=mysqli_query($connector, $insert_banner_query_text);
            $last_link_id = mysqli_insert_id($connector);
            $update_new_banner_query_text="UPDATE links SET end_datetime=CAST(DATE_ADD(start_datetime, INTERVAL $show_datetime DAY) AS DATETIME) WHERE link_id=$last_link_id";
            $update_new_banner_query = mysqli_query($connector, $update_new_banner_query_text);
            $settings_query_text="SELECT link_per_day FROM settings";
            $settings_query=mysqli_query($connector, $settings_query_text);
            while($settings=mysqli_fetch_assoc($settings_query)){
            $link_per_day = $settings['link_per_day'];
            }
            $link_price = floor($link_per_day*$show_datetime);
            $reg_time=date("Y-m-d (H:i:s)",time());
            $headers2 .= "Content-Type: text/html  charset=utf-8\r\n";
            $headers2 .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
            $headers2 .= "From: \"Администрация сайта $sitename\r\n";
            @mail("$mail","Вы заказали показ рекламных ссылок на сайте $sitename","Уведомление!<br>
            Вы заказали показ рекламных ссылок на сайте $sitename. Если это письмо пришло по ошибке, удалите его.
            Стоимость пакета показа ссылок составляет $link_price рублей (из расчета $link_per_day за сутки показа).
            При оплате пакета показа рекламных ссылок укажите в комментарии к счету номер заказа ссылок.
            Как только показ рекламных ссылок будет оплачен и проверен, ссылка появится на сайте.
            Оплатить заказ, а также наблюдать текущее количество показов, статус заказа и прочее на сайте вы сможете по следующей ссылке:
            <a class=minilink href='http://$sitename/?mode=check_link&link_id=$last_link_id'>ссылка контроля пакета показов ссылки.</a>
            <br>Добро пожаловать на сайт <a href='http://$sitename'>$sitename</a>","$headers2");
          	$error.=mysqli_error($connector);
          	if(empty($error)){
          		    header("Location: ".$_SERVER['HTTP_REFERER']."&result=success&data=".$last_link_id."&pay_type=".$pay_type."&show_datetime=".$show_datetime);
                      }
          		else {
                      die("Ошибка: ".$error);
                      }
}
if($action=="edit_stat"){
  if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
           $update_banner_query_text="UPDATE links SET stat=$stat WHERE link_id=$link_id";
           $update_new_banner_query = mysqli_query($connector, $update_banner_query_text);
           header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
}
if($action=="edit_pay_stat"){
  if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
           $update_banner_query_text="UPDATE links SET pay_stat=$pay_stat WHERE link_id=$link_id";
           $update_new_banner_query = mysqli_query($connector, $update_banner_query_text);
           header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
}
if($action=="delete_link"){
  if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
  if(($link_id>0) and ($link_id<9999)){
           $update_banner_query_text="DELETE FROM links WHERE link_id=$link_id";
           $update_new_banner_query = mysqli_query($connector, $update_banner_query_text);
           header("Location: ".$_SERVER['HTTP_REFERER']);
  }
}
?>