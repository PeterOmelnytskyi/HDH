<h1>Рынок</h1>
<p class=wide_small>Внутренний рынок позволяет Вам продавать собранный шоколад за игровое золото.<br>
Резерв золота проекта: <b>[золото] <?=($total_money_balance-$reserv_change)*100?></b></p>
<?
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
echo "<p class='small'><span class=attention>Данная страница доступна только для авторизованных пользователей.</span></p>";
exit;
}
?>
<?
$current_apples_query_text="SELECT barrels FROM clients WHERE client_id = $current_admin_id";
$current_apples_query = mysqli_query($connector, $current_apples_query_text);
while($current_apples_data=mysqli_fetch_assoc($current_apples_query)){
                $current_apples = $current_apples_data['barrels'];
                $current_harvest= floor($current_apples/$apples_per_gold);
                $max_gold       = $current_harvest*$apples_per_gold;
                }
?>
<form action="ferm_form.php" method=get>
<input type=hidden value="sold_product" name=action>
<table>
<tr height=20px>
    <td width=40px><img src="images/design/almaz.png" style="vertical-align: bottom" width=50px></td>
    <td width=380px><p class=middle>Вы можете продать <b><?=$current_apples?></b> шоколада</p>
    <p class=small>Стоимость: <?=$apples_per_gold?>   шт. = 1 золото</p></td>
    <td width=100px><input type=text id=gold_value name=product value="<?=$max_gold?>"></td>
    <td width=160px><input type=submit value="Обработать" class=input_button></td>
</tr>
</table>
</form>