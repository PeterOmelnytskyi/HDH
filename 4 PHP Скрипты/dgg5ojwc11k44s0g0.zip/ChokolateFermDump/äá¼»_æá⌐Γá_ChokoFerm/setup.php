<?php
date_default_timezone_set("Asia/Novosibirsk");

?>