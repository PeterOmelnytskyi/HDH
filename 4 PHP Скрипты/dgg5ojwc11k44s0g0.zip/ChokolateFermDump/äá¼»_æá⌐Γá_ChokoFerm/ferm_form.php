<?
require_once ("config.php");
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("config.php");
require_once ("current_settings.php");
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
$_SESSION[$session_login]= '';
$_SESSION[$session_pass] = '';
$_SESSION["user_checker"]= '';
unset($_SESSION);
header("Location: index.php");
exit;
}
//mb_internal_encoding("UTF-8");
$client_id  =   htmlspecialchars($_REQUEST['client_id']);
$tree_id    =   htmlspecialchars($_REQUEST['product_id']);
$action     =   htmlspecialchars($_REQUEST['action']);
$product    =   intval($_REQUEST['product']);
$count      =   intval($_REQUEST['count']);

$client_id   =   mysqli_real_escape_string($connector,$client_id);
$tree_id     =   mysqli_real_escape_string($connector,$tree_id);
$product     =   mysqli_real_escape_string($connector,$product);
$count       =   mysqli_real_escape_string($connector,$count);
/*
операции баланса
1. Продажа ягод
2. Сбор урожая
3. Сбор урожая со всех деревьев
4. Перевод серебра на счет для покупок
5. Покупка дерева
6. Повышение уровня дерева
7. Пополнение баланса с реквизитов
8. доход от реферала при апгрейде дерева
9. доход от реферала при покупке дерева
10. приобретение комбайна
11. приобретение автореверала
*/


if($action=="get_harvest"){
//  if(intval($tree_id)>0){

$tree_control_query_text="SELECT *, UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(last_free_time) AS harvest_time, NOW() AS ntime FROM trees
INNER JOIN levels WHERE trees.client_tree_id = $tree_id AND levels.level_id = trees.level AND client_id = $current_admin_id";
$tree_control_query = mysqli_query($connector, $tree_control_query_text);
while($tree_control_data=mysqli_fetch_assoc($tree_control_query)){
                $start_time     = $tree_control_data['start_time'];
                $last_free_time = $tree_control_data['last_free_time'];
                $level          = $tree_control_data['level'];
                $harvest        = $tree_control_data['harvest'];
                $bonus          = $tree_control_data['bonus'];
                $current_htime  = $tree_control_data['harvest_time'];
                $ntime          = $tree_control_data['ntime'];
                $current_harvest= floor($current_htime/(60*5))*($harvest+$bonus);
                }
      if($current_harvest==0){
       header("Location: ".$_SERVER['HTTP_REFERER']."&error=empty_harvest&current_harvest=".$current_harvest);
          exit();
      }
      else {

          $update_apples_query_text = "UPDATE clients SET barrels = barrels+$current_harvest WHERE client_id='$current_admin_id'";
          if($update_apples_query = mysqli_query($connector, $update_apples_query_text)){
                $update_last_free_time_query_text = "UPDATE trees SET last_free_time = NOW() WHERE client_tree_id='$tree_id'";
                $update_last_free_time_query = mysqli_query($connector, $update_last_free_time_query_text);
                //добавление записей в историю операций
                $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
                barrels, gold, gold_market, add_date) VALUES($current_admin_id, 2, $current_harvest, 0, 0, NOW())";
                $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
                header("Location: ".$_SERVER['HTTP_REFERER']."&success=success_harvest");

          }
      }
//}
}
/*сбор всего урожая*/

if($action=="get_all_harvest"){

    //получаем все деревья игрока
if(intval($current_admin_id)>0){
    $check_apples_query=mysqli_query($connector, "SELECT client_tree_id FROM trees WHERE client_id='$current_admin_id'");
           while($check_apples_data=mysqli_fetch_assoc($check_apples_query))
           {
    $current_tree_id=$check_apples_data['client_tree_id'];
    $tree_control_query_text="SELECT *, UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(last_free_time) AS harvest_time, NOW() AS ntime FROM trees
    INNER JOIN levels WHERE trees.client_tree_id = $current_tree_id AND levels.level_id = trees.level";
    $tree_control_query = mysqli_query($connector, $tree_control_query_text);
    while($tree_control_data=mysqli_fetch_assoc($tree_control_query)){
                    $start_time     = $tree_control_data['start_time'];
                    $last_free_time = $tree_control_data['last_free_time'];
                    $level          = $tree_control_data['level'];
                    $bonus          = $tree_control_data['bonus'];
                    $harvest        = $tree_control_data['harvest'];
                    $current_htime  = $tree_control_data['harvest_time'];
                    $ntime          = $tree_control_data['ntime'];
                    $current_harvest= floor($current_htime/(60*5))*($harvest+$bonus);
                    }
          if($current_harvest>0){

              /*бонус при наличии активного петуха*/
              $check_cock_query=mysqli_query($connector, "SELECT * FROM cocks WHERE client_id='$current_admin_id' AND end_time>NOW()");
              $check_cock = mysqli_num_rows($check_cock_query);

              if($check_cock>0) {
                $current_harvest = $current_harvest*1.3;
              }

              $update_apples_query_text = "UPDATE clients SET barrels = barrels+$current_harvest WHERE client_id='$current_admin_id'";
              if($update_apples_query = mysqli_query($connector, $update_apples_query_text)){
                    $update_last_free_time_query_text = "UPDATE trees SET last_free_time = NOW() WHERE client_tree_id='$current_tree_id'";
                    $update_last_free_time_query = mysqli_query($connector, $update_last_free_time_query_text);
                   $harvest_counter += $current_harvest;
              }
          }
    }
    if($harvest_counter>0){
    $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
    barrels, gold, gold_market, add_date) VALUES($current_admin_id, 3, $harvest_counter, 0, 0, NOW())";
    $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
    }
    //когда все плоды собраны производим переадресацию
    header("Location: ".$_SERVER['HTTP_REFERER']."&success=success_harvest&harvest_counter=".$harvest_counter);
}
}
//продажа плодов - обмен на золото
if($action=="sold_product"){
$settings_query="SELECT * FROM settings";
$settings_query=mysqli_query($connector, $settings_query);
while($settings=mysqli_fetch_assoc($settings_query)){
$apples_per_gold = $settings['apples_per_gold'];
}      $check_apples_query=mysqli_query($connector, "SELECT barrels FROM clients WHERE client_id='$current_admin_id'");
       while($check_apples_data=mysqli_fetch_assoc($check_apples_query))
       {
          $real_apples=$check_apples_data['barrels'];
       }
       if($real_apples>=$product){
         //проверка на деление без остатка
         $gold_increase = $product/$apples_per_gold;
         if(($gold_increase=floor($gold_increase)) AND ($product>0)){
            $update_sold=mysqli_query($connector, "UPDATE clients SET gold=gold+$gold_increase WHERE client_id='$current_admin_id'");
            $update_sold=mysqli_query($connector, "UPDATE clients SET barrels=barrels-$product WHERE client_id='$current_admin_id'");
                $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
                barrels, gold, gold_market, add_date) VALUES($current_admin_id, 1, -$product, $gold_increase, 0, NOW())";
                $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
                header("Location: ".$_SERVER['HTTP_REFERER']."&success=sold_apples_success");
          }
          else header("Location: ".$_SERVER['HTTP_REFERER']."&error=out_of_mushrooms");
          exit();
       }
       else header("Location: ".$_SERVER['HTTP_REFERER']."&error=out_of_mushrooms");
       exit();
}

//апгрейд дерева
if($action=="level_up"){
    if(intval($tree_id)>=1){
        $settings_query="SELECT * FROM settings";
        $settings_query=mysqli_query($connector, $settings_query);
        while($settings=mysqli_fetch_assoc($settings_query)){
        $apples_per_gold = $settings['apples_per_gold'];
        }
        $check_harvest_query=mysqli_query($connector, "SELECT *, UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(last_free_time) AS harvest_time FROM trees
            INNER JOIN levels WHERE trees.client_tree_id = $tree_id AND levels.level_id = trees.level");
        while($check_harvest_data=mysqli_fetch_assoc($check_harvest_query)){
                        $start_time     = $check_harvest_data['start_time'];
                        $last_free_time = $check_harvest_data['last_free_time'];
                        $level          = $check_harvest_data['level'];
                        $harvest        = $check_harvest_data['harvest'];
                        $current_htime  = $check_harvest_data['harvest_time'];
                        $current_harvest= floor($current_htime/(60*5))*$harvest;
                        }
        //если имеется урожай на дереве, сообщаем об ошибке
                  if($current_harvest>0){
        header("Location: ".$_SERVER['HTTP_REFERER']."&error=have_harvest");
        exit();
                  }
        //получаем стоимость перехода на новый уровень
        $get_level_query=mysqli_query($connector, "SELECT level FROM trees WHERE client_tree_id=$tree_id AND client_id = $current_admin_id");
                   while($get_level_data=mysqli_fetch_assoc($get_level_query))
                   {
            $current_level=$get_level_data['level'];
            }

        $get_level_up_price_query=mysqli_query($connector, "SELECT cost FROM levels WHERE level_id=$current_level+1");
               while($get_level_up_price_data=mysqli_fetch_assoc($get_level_up_price_query))
               {
                  $upgrade_cost=$get_level_up_price_data['cost'];
               }
        //если золота недостаточно для продаж


        if($current_client_gold_market<$upgrade_cost)
        {
            header("Location: ".$_SERVER['HTTP_REFERER']."&error=not_enough_gold");
            exit();
        }
//проверка наличия пригласившего
//если есть присгласивший
    if($current_client_referal>0){
      //увеличиваем его счет
      $update_gold_refer_master=mysqli_query($connector, "UPDATE clients SET gold=gold+$upgrade_cost*0.1 WHERE client_id='$current_client_referal'");
      $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
                    barrels, gold, gold_market, add_date, ref_id) VALUES($current_client_referal, 8, 0, $upgrade_cost*0.1, 0, NOW(), $current_admin_id)";
                    $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
                    /*
    //проверка наличия реферала второго уровня
        $client_referal_query_text="SELECT client_referal FROM clients WHERE client_id = $current_client_referal";
        $client_referal_query=mysqli_query($connector, $client_referal_query_text);
        while($client_referal_data=mysqli_fetch_assoc($client_referal_query))
       {
          $client_referal=$client_referal_data['client_referal'];
       }
       if($client_referal!=0){
            $update_gold_refer_master=mysqli_query($connector, "UPDATE clients SET gold=gold+$upgrade_cost*0.05 WHERE client_id='$client_referal'");
            $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
            barrels, gold, gold_market, add_date, ref_id) VALUES($client_referal, 12, 0, $upgrade_cost*0.05, 0, NOW(), $current_admin_id)";
            $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
       }
       */
   }

  $update_tree_level=mysqli_query($connector, "UPDATE trees SET level=$current_level+1, tree_lifetime = CAST(DATE_ADD(NOW(), INTERVAL 365 DAY) AS DATETIME)
  WHERE client_tree_id=$tree_id AND client_id = $current_admin_id");
  $update_gold_market=mysqli_query($connector, "UPDATE clients SET gold_market=gold_market-$upgrade_cost WHERE client_id='$current_admin_id'");
  $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
  barrels, gold, gold_market, add_date) VALUES($current_admin_id, 6, 0, 0, -$upgrade_cost, NOW())";
  $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
  header("Location: ".$_SERVER['HTTP_REFERER']."&success=level_up");
  }
}

//покупка дерева
if($action=="buy_tree"){
  $settings_query="SELECT * FROM settings";
$settings_query=mysqli_query($connector, $settings_query);
while($settings=mysqli_fetch_assoc($settings_query)){
$tree_lifetime   = $settings['tree_lifetime'];
$client_max_trees = $settings['client_max_trees'];
}
$check_tree_max_count_query=mysqli_query($connector, "SELECT count(*) AS count FROM trees WHERE client_id=$current_admin_id");
       while($check_tree_max_count_data=mysqli_fetch_assoc($check_tree_max_count_query))
       {
          $tree_count=$check_tree_max_count_data['count'];
       }
if($tree_count>=$client_max_trees)
{
    header("Location: ".$_SERVER['HTTP_REFERER']."&error=max_tree");
    exit();
}
$get_level_up_price_query=mysqli_query($connector, "SELECT cost FROM levels WHERE level_id=1");
       while($get_level_up_price_data=mysqli_fetch_assoc($get_level_up_price_query))
       {
          $upgrade_cost=$get_level_up_price_data['cost'];
       }
//если золота недостаточно для продаж
if($current_client_gold_market<$upgrade_cost)
{
    header("Location: ".$_SERVER['HTTP_REFERER']."&error=not_enough_gold");
    exit();
}

$insert_new_tree=mysqli_query($connector, "INSERT INTO trees (level, client_id, start_time, last_free_time, tree_lifetime)
VALUES(1,$current_admin_id, NOW(), NOW(), CAST(DATE_ADD(NOW(), INTERVAL $tree_lifetime DAY) AS DATETIME))");
$update_gold_market=mysqli_query($connector, "UPDATE clients SET gold_market=gold_market-$upgrade_cost WHERE client_id='$current_admin_id'");
$balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
barrels, gold, gold_market, add_date, ref_id) VALUES($current_admin_id, 5, 0, 0, -$upgrade_cost, NOW(), 0)";
$balance_actions_query = mysqli_query($connector, $balance_actions_query_text);

//проверка наличия пригласившего
//если есть присгласивший
    if($current_client_referal>0){
      //увеличиваем его счет
      $update_gold_refer_master=mysqli_query($connector, "UPDATE clients SET gold=gold+$upgrade_cost*0.1 WHERE client_id='$current_client_referal'");
      $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
                    barrels, gold, gold_market, add_date, ref_id) VALUES($current_client_referal, 9, 0, $upgrade_cost*0.1, 0, NOW(), $current_admin_id)";
                    $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
    /*
    //проверка наличия реферала второго уровня
        $client_referal_query_text="SELECT client_referal FROM clients WHERE client_id = $current_client_referal";
        $client_referal_query=mysqli_query($connector, $client_referal_query_text);
        while($client_referal_data=mysqli_fetch_assoc($client_referal_query))
       {
          $client_referal=$client_referal_data['client_referal'];
       }
       if($client_referal!=0){
            $update_gold_refer_master=mysqli_query($connector, "UPDATE clients SET gold=gold+$upgrade_cost*0.05 WHERE client_id='$client_referal'");
            $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
            barrels, gold, gold_market, add_date, ref_id) VALUES($client_referal, 13, 0, $upgrade_cost*0.05, 0, NOW(), $current_admin_id)";
            $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
       }
       */
   }
header("Location: ".$_SERVER['HTTP_REFERER']."&success=buy_success");
}

//перевод средств для вывода в средства для покупки
if($action=="convert_gold"){



if(strlen($count)>=8)
{
    header("Location: ".$_SERVER['HTTP_REFERER']."&error=too_mutch_symbols");
    exit();
}
if($count<=0)
{
    header("Location: ".$_SERVER['HTTP_REFERER']."&error=not_positive_count");
    exit();
}
if(intval($current_client_gold)<0)
{
    header("Location: ".$_SERVER['HTTP_REFERER']."&error=not_enough_gold");
    exit();
}
//если золота недостаточно для продаж
if($count>intval($current_client_gold))
{
    header("Location: ".$_SERVER['HTTP_REFERER']."&error=not_enough_gold");
    exit();
}
/*
$insert_new_tree=mysqli_query($connector, "INSERT INTO trees (level, client_id, start_time, last_free_time)
VALUES(1,$current_admin_id, NOW(), NOW())");
*/
$update_gold_market=mysqli_query($connector, "UPDATE clients SET gold_market=gold_market+$count WHERE client_id='$current_admin_id'");
$update_gold_market=mysqli_query($connector, "UPDATE clients SET gold=gold-$count WHERE client_id='$current_admin_id'");
$balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
barrels, gold, gold_market, add_date) VALUES($current_admin_id, 4, 0, -$count, $count, NOW())";
$balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
header("Location: ".$_SERVER['HTTP_REFERER']."&success=convert_gold");
}
//продажа комбайна
if($action=="buy_combine"){
//проверка есть ли уже действующий комбайн
$check_combine_query=mysqli_query($connector, "SELECT * FROM client_combines WHERE client_id='$current_admin_id' AND stat=1");
$check_combine = mysqli_num_rows($check_combine_query);
if($check_combine==0){
      $settings_query="SELECT combine_price FROM settings";
    $settings_query=mysqli_query($connector, $settings_query);
    while($settings=mysqli_fetch_assoc($settings_query)){
    $combine_price = $settings['combine_price'];
    }
    //если золота недостаточно для продаж
    if($current_client_gold_market<$combine_price)
    {
        header("Location: ".$_SERVER['HTTP_REFERER']."&error=not_enough_gold");
        exit();
    }

    $insert_new_tree=mysqli_query($connector, "INSERT INTO client_combines (client_id, start_time, end_time, stat)
    VALUES($current_admin_id, NOW(), CAST(DATE_ADD(NOW(), INTERVAL 1 MONTH) AS DATETIME), 1)");
    echo mysqli_error($connector);
    $update_gold_market=mysqli_query($connector, "UPDATE clients SET gold_market=gold_market-$combine_price WHERE client_id=$current_admin_id");
    echo mysqli_error($connector);
    $balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
    barrels, gold, gold_market, add_date, ref_id) VALUES($current_admin_id, 10, 0, 0, -$combine_price, NOW(), 0)";
    $balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
    echo mysqli_error($connector);
    header("Location: ".$_SERVER['HTTP_REFERER']."&success=buy_combine_success");
}
else {header("Location: ".$_SERVER['HTTP_REFERER']."&error=already_have");}
}
//продажа комбайна

if($action=="buy_autoreferal"){
    $settings_query="SELECT autoreferal_price FROM settings";
    $settings_query=mysqli_query($connector, $settings_query);
    while($settings=mysqli_fetch_assoc($settings_query)){
    $autoreferal_price = $settings['autoreferal_price'];
    }
//если золота недостаточно для продаж
if($current_client_gold_market<$autoreferal_price)
{
    header("Location: ".$_SERVER['HTTP_REFERER']."&error=not_enough_gold");
    exit();
}
$insert_new_tree=mysqli_query($connector, "INSERT INTO autoreferal (client_id, start_time, end_time, last_uptime, client_counter)
VALUES($current_admin_id, NOW(), CAST(DATE_ADD(NOW(), INTERVAL 14 DAY) AS DATETIME), NOW(), 0)");
$update_gold_market=mysqli_query($connector, "UPDATE clients SET gold_market=gold_market-$autoreferal_price WHERE client_id='$current_admin_id'");
$balance_actions_query_text = "INSERT INTO balance_actions (client_id, action_type,
barrels, gold, gold_market, add_date, ref_id) VALUES($current_admin_id, 11, 0, 0, -$autoreferal_price, NOW(), 0)";
$balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
header("Location: ".$_SERVER['HTTP_REFERER']."&success=buy_autoreferal_success");
}
?>