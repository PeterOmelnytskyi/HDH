<?
require_once ("dbconnect.php");
require_once ("functions.php");
$link_id = intval($_REQUEST['link_id']);
/*показ ссылки*/
if((intval($link_id)>0)and(intval($link_id)<=999999)){
$link_query=mysqli_query($connector, "SELECT * FROM links WHERE start_datetime<NOW() AND end_datetime>NOW()
AND stat=1 AND link_id=$link_id");
 while($link_data=mysqli_fetch_assoc($link_query))
     {
        $link_url = $link_data['url'];
    }
    if (!preg_match('/^(http|https|ftp)/',$link_url)){
      $link_url="http://".$link_url;
    }
    header("Location: ".$link_url);
    exit();
}
?>