<?
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
?>
<h1>Ваша Шоколадная Фабрика</h1>
<?
if(intval($glade_id)<=0){exit;}
$glade_id = mysqli_real_escape_string($connector,$glade_id);
$tree_control_query_text="SELECT *, UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(last_free_time) AS harvest_time,
NOW() AS ntime FROM trees INNER JOIN levels WHERE trees.client_tree_id = $glade_id AND levels.level_id = trees.level";
$tree_control_query = mysqli_query($connector, $tree_control_query_text);
while($tree_control_data=mysqli_fetch_assoc($tree_control_query)){
                $client_id      = $tree_control_data['client_id'];
                $start_time     = $tree_control_data['start_time'];
                $last_free_time = $tree_control_data['last_free_time'];
                $level          = $tree_control_data['level'];
                $harvest        = $tree_control_data['harvest'];
                $bonus          = $tree_control_data['bonus'];
                $current_htime  = $tree_control_data['harvest_time'];
                $ntime          = $tree_control_data['ntime'];
                $current_harvest= floor($current_htime/(60*5))*($harvest+$bonus);
                }
$next_level =  $level+1;
$tree_control_query_text="SELECT * FROM levels WHERE level_id = $next_level";
$tree_control_query = mysqli_query($connector, $tree_control_query_text);
while($tree_control_data=mysqli_fetch_assoc($tree_control_query)){
                $next_level_price = $tree_control_data['cost'];
                }
if($current_admin_id!=$client_id){?>
<p class=wide_small><span class=attention>Внимание!</span> Данная Шоколадная Фабрика не принадлежит вам!</p>
<?=$current_admin_id." ".$client_id?>
<?} else {?>
 <table border=0px width=100%>
<tr style="vertical-align: top">
<td width=250px>
<p class=middle>Уровень: <?=$level?></p>

<p class=middle>Производство шоколада: <?=12*($harvest+$bonus);?> штук в час</p>

<p class=middle>Текущее количество шоколада: <?=$current_harvest?> штук.</p>

<div class=button><a href="ferm_form.php?action=get_harvest&product_id=<?=$glade_id?>">Собрать шоколад</a></div>
<?if($_REQUEST['error']=='empty_harvest'){?><p class=wide_small><span class=attention>Внимание!</span>
 Шоколада нет! Подождите несколько минут.</p><?}?>
 <?if($_REQUEST['success']=='success_harvest'){?><p class=wide_small><span class=success>Поздравляем!</span>
 Шоколад успешно собран!</p><?}?>
  <?if($_REQUEST['success']=='level_up'){?><p class=wide_small><span class=success>Поздравляем!</span>
Уровень Шоколадной Фабрики был успешно повышен!
 </p><?}?>
 <?if($_REQUEST['error']=='not_enough_gold'){?><p class=wide_small><span class=attention>Внимание!</span>
 Золота недостаточно для повышения уровня Шоколадной Фабрики!</p><?}?>
  <?if($_REQUEST['error']=='have_harvest'){?><p class=wide_small><span class=attention>Внимание!</span>
 Для повышения уровня Шоколадной Фабрики необходимо собрать имеющийся шоколад!</p><?}?>
<br>
<?//запрет перехода выше 12-го уровня
if($level!='9'){?>
<p class=small>Стоимость перехода на следующий уровень: <b>[золото] <?=$next_level_price?></b></p>
<div class=button><a href="ferm_form.php?action=level_up&product_id=<?=$glade_id?>">Поднять уровень</a></div>
<?}?>
</td>
<td><img src="images/design/rudnik.png" width=150px></td>
</tr>
</table>
<?}?>