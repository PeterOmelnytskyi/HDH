$(document).ready(function(){


$('#client_search').keyup(function(){
if($('#client_search').val().length >= 3){
  alert(1);
//var client_search=encodeURI($('#client_search').val());
//windows.location.href="?mode=users&search_user="+client_search;
}
});

$('#linktext').keyup(function(){
var num=$(this).val();
if(num.length>=45)
{
	$(this).val(num.substr(0,45));
	return false;
}
});

var docwidth = $(document).width();
var docheight = $(document).height();
var windowwidth = $(window).width();
var windowheight = $(window).height();
$('#top').css('left', windowwidth*0.5-1000*0.5);
$('#banner').css('left', windowwidth*0.5-1000*0.5);
$('#bottom').css('width', windowwidth);
$('#center').css('width', windowwidth);
$('#bottom img').css('width', windowwidth);
$('#center img').css('width', windowwidth);
$('#bottom').fadeTo(1,0.1);

var rightbar_height = $('#rightbar').height();
var leftbar_height = $('#leftbar').height();
if(rightbar_height>=leftbar_height){

 $('#leftbar').css('height',rightbar_height+'px');
}
else {
 $('#rightbar').css('height',leftbar_height+'px');
}


$('#edit_avatar_block').click(function(){
  $('#avatar_block').show(400);
});
$('#close_avatar_block').live("click", function(){
  $('#avatar_block').hide(400);
});
$('#edit_profile').click(function(){
  $('#profile_editor').show(400);
});
$('#close_profile_editor').live("click", function(){
  $('#profile_editor').hide(400);
});

$.datepicker.setDefaults(
$.extend($.datepicker.regional["ru"])
);
$("#datepicker").datepicker({
onSelect: function(date) {
//$("#datepicker").datepicker( "option", "dateFormat", 'yy-mm-dd' );
var ready_date = date.replace('.', '-');
var ready_date_2 = ready_date.replace('.', '-');
var ready_date_3 = ready_date_2.split("-");
var ready_date_4 = ready_date_3[2]+"-"+ready_date_3[1]+"-"+ready_date_3[0];
$("input[name=start_datetime]").val(ready_date_4);
 }});
$('.smile').click(function(){
var smile = $(this).attr('alt');
var current_message = $('#chat_messager').val();
$('#chat_messager').val(current_message+''+smile);

});


});