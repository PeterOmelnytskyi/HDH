$(document).ready(function(){
var docwidth = $(document).width();
/***************** Авторизация в административную панель  ****************/
var mng_login;
var mng_pwd;
var pass;
$('#manager_login').click(function(){
mng_login   = $("#mng_login").val();
mng_pwd     = $("#mng_pwd").val();
var auth_login="authorize=1&mng_login="+mng_login+"&mng_pwd="+mng_pwd;
        $.ajax({
        url: "admin_login.php",
       	type: "post",
       	dataType: 'json',
       	data: auth_login,
       	beforeSend: function (){
       	},
       	success: function(data){
       	  if(data.auth_result=="success"){
       	{$('#auth_result').html("<b>Вы успешно авторизовались! Сейчас вы будете перенаправлены в панель администрирования</b>");}
setTimeout(function(){window.location.href="adminka.php";}, 3000);
          }
          else if(data.auth_result=="false_key")
          {$('#auth_result').html("вы вводите неверный пароль или логин!");}
        },
       	complete: function(){
       	}
       });
});
});