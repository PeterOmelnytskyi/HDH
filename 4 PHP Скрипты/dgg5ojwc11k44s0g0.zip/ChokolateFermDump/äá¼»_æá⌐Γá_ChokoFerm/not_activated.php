<h1>Реактивация электронной почты</h1>
<?if($_REQUEST['result']=="restore_success"){?>
<p class=success>Данные для реактивации электронной почты аккаунта были отправлены на указанный email игрока!</p>
<?}elseif($_REQUEST['result']=="restore_failed"){?>
<p class=attention>Реактивация нового пароля закончилась неудачно!</p>
<?}elseif($_REQUEST['result']=="restore_send"){?>
<p class=success>Данные для генерации нового пароля отправлены на указанный email игрока!</p>
<?}else{?>
<p class=small>В связи с повышением уровня безопасности сайта просим игроков реактивировать электронную почту вашего аккаунта.<br>
С уважением, Администрация сайта Грибная поляна.</p>
<form name=user_register action="user_register_form.php" method=post>
<input type=hidden name=action value=reactivate_mail>
<table cellspacing="1px" align="center" border=0px>
<?if($_REQUEST['result']=="login_or_mail_not_exists"){?>
<tr style="vertical-align: top">
    <td width=260px class=info_cell colspan=2><p class=attention>Введенный логин или электронная почта не найдены!</p>
    </td>
</tr>
<?}?>
<tr style="vertical-align: top">
    <td colspan=2 class=info_cell align=center>
    <button class=orange_from_element type=submit class=search_from_element style="width: 240px">
    <img src="images/design/register.png" style="vertical-align: middle" width=50px> Отправить на указанную почту ссылку для реактивации почты.</button></td>
    </tr>
</table>
</form>
<?}?>