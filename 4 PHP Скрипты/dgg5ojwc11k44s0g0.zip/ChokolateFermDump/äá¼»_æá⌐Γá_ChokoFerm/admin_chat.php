<?
$avatar_path       = "images/avatars/";
$message_page = intval($_REQUEST['message_page']);
$ref_counter=0;
$select_refs_count=mysqli_query($connector, "SELECT count(*) AS counter FROM chat INNER JOIN clients WHERE clients.client_id = chat.client_id AND
clients.client_stat>=1 AND chat.message_stat>0");
while($ref_data=mysqli_fetch_assoc($select_refs_count)){
  $ref_counter  = $ref_data['counter'];
  }
if(empty($message_page)) $message_page=1;
if(empty($show_ref_count)) $show_ref_count=100;
$page_count=floor($ref_counter/$show_ref_count);
$limit_start=($message_page-1)*$show_ref_count;
$limit_count=$show_ref_count;
?>
<div style="display: inline-table; vertical-align: top">
<h1>Форум</h1>
<table width=450px>
<?
$chat_query=mysqli_query($connector, "SELECT *, chat.add_date AS message_add_date FROM chat INNER JOIN clients WHERE clients.client_id = chat.client_id AND
clients.client_stat>=1 AND chat.message_stat>0 ORDER BY chat.add_date DESC LIMIT $limit_start, $limit_count");
while($chat_data=mysqli_fetch_assoc($chat_query)){
                $chat_client_id = $chat_data['client_id'];
                $chat_login = $chat_data['login'];
                $chat_message_text=$chat_data['message_text'];
                $chat_message_id=$chat_data['message_id'];
                $chat_add_date=$chat_data['message_add_date'];
                $chat_avatar=$chat_data['client_avatar'];?>
<tr height=20px>
    <td width=120px class=chat_cell><a class=minilink href="?mode=users&user_id=<?=$chat_client_id?>" <?if($chat_client_id==1){echo "style='color: red'";}?>><?=$chat_login?></a></td>
    <td width=880px class=chat_cell><p class=small><?=$chat_add_date?> <a href="admin_chat_form.php?action=delete_message&message_id=<?=$chat_message_id?>" class=minilink><span class=attention>удалить сообщение</span></a></p></td>
</tr>
<tr height=30px style="vertical-align: top">
    <td class=chat_cell><?if(!empty($chat_avatar)){?>
<img src="<?=$avatar_path.$chat_avatar?>" style="max-height: 30px; max-width: 50px;">
<?}?></td>
    <td class=chat_cell><p class=small><?
    $message = substr(htmlspecialchars($chat_message_text),0, 1500);
    $current_message_text=preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a class=minilink href="\\0">\\0</a>',$message);
    echo $current_message_text;
    ?>
    </p></td>
</tr>
<? } ?>
</table>
<div style="margin: 0px auto; width: 320px;"><span class=small>Страницы:</span>
<?if($message_page!=1){?>
<a class="minilink" href="?mode=chat&message_page=1"><<</a>
<?}?>
<?while ($u<=$page_count+1){?>
<a class="minilink" href="?mode=chat&message_page=<?=$u?>" <?if($message_page==$u) {?> style="text-decoration: underline" <?}?>><?=$u?></a>
<? $u++;}?>
<?if($message_page!=$page_count+1){?>
<a class="minilink" href="?mode=chat&message_page=<?=$page_count+1?>">>></a>
<?}?>
</div>
<br>
<form action=admin_chat_form.php method=get>
<input type=hidden name=action value="add_message">
<p class=small><b>Введите сообщение</b></p>
<table>
<tr>
    <td><textarea name=message_text cols=40 rows=8 id=chat_messager></textarea></td>
</tr>
</table>
<input type=submit value="Отправить">
</form>
</div>


<div style="display: inline-table; vertical-align: top">
<h1>Обратная связь (для гостей сайта)</h1>
<table width=520px>
<?
$feedback_query=mysqli_query($connector, "SELECT * FROM feedback ORDER BY add_date DESC");
while($feedback_data=mysqli_fetch_assoc($feedback_query)){
                $email          =   $feedback_data['email'];
                $username       =   $feedback_data['username'];
                $message_text   =   $feedback_data['message_text'];
                $message_id     =   $feedback_data['feedback_id'];
                $add_date       =   $feedback_data['add_date'];
                $ip             =   $feedback_data['ip'];
?>
<tr height=20px>
    <td width=15px class=chat_cell><p class=small><?=$message_id?></p></td>
    <td width=70px class=chat_cell><p class=small><?=$username?></p></td>
    <td width=100px class=chat_cell><p class=small><?=$email?></p></td>
    <td width=100px class=chat_cell><p class=small><?=$add_date?></p></td>
    <td width=130px class=chat_cell><p class=small><?="IP отправителя: ".$ip?></p></td>
    <td width=100px class=chat_cell><a href="admin_chat_form.php?action=delete_feedback&message_id=<?=$message_id?>" class=minilink><span class=attention>удалить сообщение</span></a></td>

</tr>
<tr height=30px style="vertical-align: top">
    <td colspan=6 class=chat_cell><p class=small><?
    $message = substr(htmlspecialchars($message_text),0, 1500);
    $current_message_text=preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a class=minilink href="\\0">\\0</a>',$message);
    echo $current_message_text;?></p>
    </td>
</tr>
<? } ?>
</table>
</div>