<?
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
?>
<h1>Написать новое сообщение:</h1>
<a href="?mode=incoming_messages>" class=minilink>Показать все входящие</a>
<div class=message_block style="display: inline-table; width: 650px; height:400px;">
<form name="new_message_form" method="get" action="message_sending_form.php">
<input type=hidden name="action" value="send">
<table width=650px border=0px cellpadding=2px cellspasing=0px style="border: 1px solid #ccc; margin: 4px;">
<tr height=300px valign=top style="vertical-align: top"><td>
<p class="small">Ваше сообщение:</p>
<textarea name=message_content style="width: 400px; height: 300px"></textarea>
</td>
<td><p class="small">Адресаты:</p>
<select name=message_to size=16 style="width: 200px; max-height: 300px">
<? $users=mysqli_query($connector, "SELECT login, client_id, active_message FROM clients ORDER BY login ASC");
while($usl=mysqli_fetch_assoc($users)){
 $active_message = $usl['active_message'];
  if($usl['client_id']==$current_admin_id) continue;?>
<option value="<?=$usl['client_id']?>" <?if($client_id==$usl['client_id']) echo "selected";?> <?if($active_message==1) echo "disabled";?>><?=$usl['login']?></option>
<?}?>
</select>
</td>
</tr>
</table>
<input type=submit value="Отправить">
</form>
</div>