<?
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("config.php");
require_once ("current_settings.php");

if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
$current_password = htmlspecialchars($_REQUEST['old_pass']);
$new_password     = htmlspecialchars($_REQUEST['new_pass']);
$new_password2    = htmlspecialchars($_REQUEST['new_pass_2']);
$action           = htmlspecialchars($_REQUEST['action']);
$old_mail         = htmlspecialchars($_REQUEST['old_mail']);
$new_mail         = htmlspecialchars($_REQUEST['new_mail']);
$new_mail_2       = htmlspecialchars($_REQUEST['new_mail_2']);
$mail_key         = htmlspecialchars($_REQUEST['key']);
$client_city      = htmlspecialchars($_REQUEST['client_city']);
$client_skype     = htmlspecialchars($_REQUEST['client_skype']);
$client_icq       = htmlspecialchars($_REQUEST['client_icq']);
$no_message       = htmlspecialchars($_REQUEST['no_message']);
$client_id        = intval($_REQUEST['client_id']);

$new_mail = mysqli_real_escape_string($connector,$new_mail);
$client_skype = mysqli_real_escape_string($connector,$client_skype);
$client_city = mysqli_real_escape_string($connector,$client_city);
$client_icq = mysqli_real_escape_string($connector,$client_icq);
$client_phone_number=mysqli_real_escape_string($connector, $_REQUEST['client_phone_number']);

$avatar_path      = "images/avatars/";
function getExtension($filename) {
    return end(explode(".", $filename));
  }

if($action=="upload_avatar"){
               if($_FILES["avatar"]["size"] > 0){
	   if($_FILES["avatar"]["size"] > 1024*1024*0.2)
	   {
            header("Location: ".$_SERVER['HTTP_REFERER']."&result=too_large_file");
            exit;
	   }
                                if(!getimagesize($_FILES["avatar"]["tmp_name"]))
      {
           header("Location: ".$_SERVER['HTTP_REFERER']."&result=error_filetype");
           exit;
      }
			if(copy($_FILES["avatar"]["tmp_name"],"upload/".$_FILES["avatar"]["name"]))
        {
            copy("upload/".$_FILES["avatar"]["name"],$avatar_path.$_FILES["avatar"]["name"]) or die("Не удается скопировать!");
            unlink("upload/".$_FILES["avatar"]["name"]);
            $startname = $_FILES['avatar']['name'];
            $ava_ext = getExtension($startname);
            $final_name = md5($startname.md5(time())).".".$ava_ext;
            rename($avatar_path.$startname, $avatar_path.$final_name);
            $update_ava_query_text="UPDATE clients SET client_avatar = '$final_name' WHERE client_id = $current_admin_id";
            $update_ava_query=mysqli_query($connector, $update_ava_query_text);
                 header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
                exit;

       }
        else {
            header("Location: ".$_SERVER['HTTP_REFERER']."&result=upload_file_error");
            exit;
	   }
    }
    else {
            header("Location: ".$_SERVER['HTTP_REFERER']."&result=empty_file");
            exit;
	   }
}

if($action=='add_friend'){
    //проверка на непустое значение $client_id
    if(!empty($client_id)){
        //новая заявка
        $check_friend_query_text = mysqli_query($connector, "SELECT * FROM client_relationship WHERE
         (client1_id = $current_admin_id AND client2_id = $client_id) OR (client2_id = $current_admin_id AND client1_id = $client_id)");
         while($user_friends_data=mysqli_fetch_assoc($check_friend_query_text)){
        $friend_client1_stat = $user_friends_data['stat1'];
        $friend_client2_stat = $user_friends_data['stat2'];
        }
        if((empty($friend_client1_stat)) AND (empty($friend_client2_stat))){
        $insert_friend_query_text = mysqli_query($connector, "INSERT INTO client_relationship
        (client1_id, client2_id, stat1, stat2) VALUES ($current_admin_id, $client_id, 2, 1)");
        header("Location: index.php?mode=client_profile&result=invite_send_success");
        exit;
        }
    //не новая заявка
        elseif((!empty($friend_client1_stat)) OR (!empty($friend_client2_stat)))
        {
          $check_friend_query1 = mysqli_query($connector, "SELECT * FROM client_relationship WHERE
          client1_id = $current_admin_id AND client2_id = $client_id");
          if(mysqli_num_rows($check_friend_query1)>0){
              while($user_friends_data=mysqli_fetch_assoc($check_friend_query1)){
                $client1_stat = $user_friends_data['stat1'];
                $client2_stat = $user_friends_data['stat2'];
              }
              if(($client1_stat=='0') AND ($client2_stat=='2')){
                header("Location: index.php?mode=client_profile&result=invite_was_already_sended");
                exit;
              }
              elseif(($client1_stat=='1') AND ($client2_stat=='0')){
                header("Location: index.php?mode=client_profile&result=invite_was_rejected");
                exit;
              }
              //вернуть обратно в друзья
              elseif(($client1_stat=='2') AND ($client2_stat=='0')){
                $delete_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat1 = 2, stat2 = 2 WHERE client1_id = $current_admin_id AND client2_id = $client_id");
                header("Location: index.php?mode=client_profile&result=friend_was_deleted");
                exit;
              }
              elseif(($client1_stat=='1') AND ($client2_stat=='2')){
                //текущий пользователь добавляет в друзья
                $add_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat1 = 2 WHERE client1_id = $current_admin_id AND client2_id = $client_id");
                header("Location: index.php?mode=client_profile&result=invite_was_accepted");
                exit;
              }
          }

          $check_friend_query2 = mysqli_query($connector, "SELECT * FROM client_relationship WHERE
          client2_id = $current_admin_id AND client1_id = $client_id");
          if(mysqli_num_rows($check_friend_query2)>0){
              while($user_friends_data=mysqli_fetch_assoc($check_friend_query2)){
                $client1_stat = $user_friends_data['stat1'];
                $client2_stat = $user_friends_data['stat2'];
              }
              //вернуть обратно в друзья
              if(($client1_stat=='0') AND ($client2_stat=='2')){
                $delete_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat1 = 2, stat2 = 2 WHERE client2_id = $current_admin_id AND client1_id = $client_id");
                header("Location: index.php?mode=client_profile&result=invite_was_already_sended");
                exit;
              }
              elseif(($client1_stat=='0') AND ($client2_stat=='1')){
                header("Location: index.php?mode=client_profile&result=invite_was_rejected");
                exit;
              }
              elseif(($client1_stat=='2') AND ($client2_stat=='0')){
                header("Location: index.php?mode=client_profile&result=friend_was_deleted");
                exit;
              }
              elseif(($client1_stat=='2') AND ($client2_stat=='1')){
                //текущий пользователь добавляет в друзья
                $add_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat2 = 2 WHERE client2_id = $current_admin_id AND client1_id = $client_id");
                header("Location: index.php?mode=client_profile&result=invite_was_accepted");
                exit;
              }
          }
        }
    }
}

if($action=='delete_friend'){
    //проверка на непустое значение $client_id
    if(!empty($client_id)){
        //новая заявка
        $check_friend_query_text = mysqli_query($connector, "SELECT * FROM client_relationship WHERE
         (client1_id = $current_admin_id AND client2_id = $client_id) OR (client2_id = $current_admin_id AND client1_id = $client_id)");
         while($user_friends_data=mysqli_fetch_assoc($check_friend_query_text)){
        $friend_client1_stat = $user_friends_data['stat1'];
        $friend_client2_stat = $user_friends_data['stat2'];
        }
        if((empty($friend_client1_stat)) AND (empty($friend_client2_stat))){
        header("Location: index.php?mode=client_profile&result=error_delete_friend");
        exit;
        }
        elseif((!empty($friend_client1_stat)) OR (!empty($friend_client2_stat)))
        {
          $check_friend_query = mysqli_query($connector, "SELECT * FROM client_relationship WHERE
          client1_id = $current_admin_id AND client2_id = $client_id");
          if(mysqli_num_rows($check_friend_query)>0){
              while($user_friends_data=mysqli_fetch_assoc($check_friend_query)){
                $friend_client1_stat = $user_friends_data['stat1'];
                $friend_client2_stat = $user_friends_data['stat2'];
              }
              //текущий пользователь отказывается от добавления в друзья
              if(($friend_client1_stat=='2') AND ($friend_client2_stat=='1')){
                $delete_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat2 = 0 WHERE client1_id = $current_admin_id AND client2_id = $client_id");
                header("Location: index.php?mode=client_profile&result=invite_was_rejected");
                exit;
               }
               //текущий пользователь удаляет из друзей после того как его удалили из друзей
              if(($friend_client1_stat=='0') AND ($friend_client2_stat=='2')){
                $delete_friend_query_text = mysqli_query($connector,
                "DELETE FROM client_relationship WHERE client1_id = $current_admin_id AND client2_id = $client_id");
                header("Location: index.php?mode=client_profile&result=friend_was_deleted_also");
                exit;
              }
              if(($friend_client1_stat=='2') AND ($friend_client2_stat=='2')){
                //текущий пользователь удаляет из друзей
                $delete_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat1 = 2, stat2 = 0 WHERE client1_id = $current_admin_id AND client2_id = $client_id");
                header("Location: index.php?mode=client_profile&result=friend_was_deleted");
                exit;
              }
          }
          $check_friend_query2 = mysqli_query($connector, "SELECT * FROM client_relationship WHERE
          client2_id = $current_admin_id AND client1_id = $client_id");
          if(mysqli_num_rows($check_friend_query2)>0){
              while($user_friends_data=mysqli_fetch_assoc($check_friend_query2)){
                $friend_client1_stat = $user_friends_data['stat1'];
                $friend_client2_stat = $user_friends_data['stat2'];
              }
              if(($friend_client1_stat=='1') AND ($friend_client2_stat=='2')){
                $delete_friend_query_text = mysqli_query($connector, "DELETE FROM client_relationship
                 WHERE client2_id = $current_admin_id AND client1_id = $client_id");
                header("Location: index.php?mode=client_profile&result=invite_sending_was_canceled");
                exit;
               }
              if(($friend_client1_stat=='2') AND ($friend_client2_stat=='1')){
                $delete_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat1 = 0 WHERE client2_id = $current_admin_id AND client1_id = $client_id");
                header("Location: index.php?mode=client_profile&result=invite_was_rejected");
                exit;
              }
              if(($friend_client1_stat=='2') AND ($friend_client2_stat=='2')){
                //текущий пользователь удаляет из друзей
                $delete_friend_query_text = mysqli_query($connector, "UPDATE client_relationship
                SET stat1 = 0, stat2 = 2 WHERE client2_id = $current_admin_id AND client1_id = $client_id");
                header("Location: index.php?mode=client_profile&result=friend_was_deleted");
                exit;
              }
          }
        }
    }
}




if($action=='edit_profile'){

          $edit_profile_query_text="UPDATE clients SET client_skype='$client_skype', client_icq = '$client_icq', client_phone_number = '$client_phone_number',
          client_city = '$client_city' WHERE client_id='$current_admin_id'";
          mysqli_query($connector, $edit_profile_query_text);
          echo mysqli_error($connector);
          header("Location: index.php?mode=client_profile&result=success");
}

if($action=='active_message'){
      if(!empty($no_message)) $message_flag = 1;
      else $message_flag = 0;
          $edit_profile_query_text="UPDATE clients SET active_message=$message_flag WHERE client_id='$current_admin_id'";
          mysqli_query($connector, $edit_profile_query_text);
          echo mysqli_error($connector);
          header("Location: index.php?mode=client_profile&result=success");
}


if($action=="change_password"){
 // echo md5($current_password)." / ".$_SESSION["pass"];
  //exit();
      $change_error="";
      if($new_password!=$new_password2){$change_error.="Поля нового пароля содержат различные значения!"; }
      if(md5($current_password)!=$_SESSION[$session_pass]) {$change_error.="Введенный текущий пароль не совпадает с текущим паролем в базе<br>";}
      if(strlen($new_password)<5) $change_error.="Пароль не может быть короче 5 символов";
      if(strlen($new_password)>20) $change_error.="Пароль не может быть длиннее 20 символов";
      if($change_error!=""){
        header("Location: ".$_SERVER['HTTP_REFERER']."&error=wrong_password&data=".$change_error);
        exit();
      }
      else {
      $new_pass=md5($new_password);
      $curr_login=$_SESSION[$session_login];
      $update_pass="UPDATE clients SET password='$new_pass' WHERE login='$curr_login'";
      mysqli_query($connector, $update_pass);
        $_SESSION[$session_pass] = $new_pass;
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
        exit();
      }
}
if($action=='change_mail'){
      $check_key_query_text="SELECT account_key, new_client_mail FROM clients WHERE client_id = $current_admin_id";
      $check_mail_query = mysqli_query($connector, $check_key_query_text);
                while ($check_mail_data = mysqli_fetch_assoc($check_mail_query)){
                  $new_client_mail = $check_mail_data['new_client_mail'];
                  $account_key = $check_mail_data['account_key'];
                  }
      if($mail_key==$account_key){
      $update_new_mail="UPDATE clients SET client_mail=new_client_mail WHERE client_id='$current_admin_id'";
      mysqli_query($connector, $update_new_mail);
      echo mysqli_error($connector);
      header("Location: index.php?mode=change_mail&result=change_mail_success");
      }

}


if($action=="change_mail_request"){
 // echo md5($current_password)." / ".$_SESSION["pass"];
  //exit();
      $change_error="";
      if($new_mail!=$new_mail_2){$change_error.="Названия нового Email в двух полях различаются!"; }
      $check_mail_query_text="SELECT client_mail FROM clients WHERE client_id = $current_admin_id";
      $check_mail_query = mysqli_query($connector, $check_mail_query_text);
                while ($check_mail_data = mysqli_fetch_assoc($check_mail_query)){
                  $current_mail = $check_mail_data['client_mail'];
                  }
      if($old_mail!=$current_mail) {$change_error.="Введенный текущий email не совпадает с текущим Email в базе<br>";}
      if(strlen($new_mail)<5) $change_error.="Email не может быть короче 5 символов";
      if(strlen($new_mail)>32) $change_error.="Email не может быть длиннее 32 символов";
      if($change_error!=""){
        header("Location: ".$_SERVER['HTTP_REFERER']."&error=wrong_mail&data=".$change_error);
        exit();
      }
      else {
      $key = md5($new_mail."221188".$new_mail);
      $update_new_mail="UPDATE clients SET new_client_mail='$new_mail', account_key='$key' WHERE client_id='$current_admin_id'";
      mysqli_query($connector, $update_new_mail);
                $reg_time=date("Y-m-d (H:i:s)",time());
                $headers2 .= "Content-Type: text/html  charset=utf-8\r\n";
                $headers2 .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
                $headers2 .= "From: \"Администрация сайта $sitename <auto_messager@$sitename>\r\n";

                @mail("$current_mail","Запрос на смену email игрока на сайте $sitename","Уведомление!<br>
                Ваш email был запрошен в качестве действующего для игрока на сайте $sitename. Если это письмо пришло по ошибке, удалите его.
                <a class=minilink href='http://$sitename/user_profile.php?action=change_mail&key=$key'>ссылка активации.</a>
                <br>Добро пожаловать на сайт <a href='http://$sitename'>$sitename</a>","$headers2");//отправляем сообщение заказчику
                header("Location: ".$_SERVER['HTTP_REFERER']."&result=change_mail_request_success");
                exit();
      }
}
?>