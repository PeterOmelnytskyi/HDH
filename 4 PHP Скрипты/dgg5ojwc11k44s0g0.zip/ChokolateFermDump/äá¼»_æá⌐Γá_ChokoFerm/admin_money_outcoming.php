<h1>Вывод средств</h1>
<?
$money_outcoming_query_text="SELECT * FROM payment_outcoming INNER JOIN clients WHERE
clients.client_id = payment_outcoming.payment_client_id ORDER By $clients_select_sort $clients_select_direction LIMIT $clients_select_count";
$money_outcoming_query=mysqli_query($connector, $money_outcoming_query_text);
$money_outcoming_count=mysqli_num_rows($money_outcoming_query);
?>
<div>
<form name="clients_sort" action="adminka.php" method="get">
<input type=hidden name="action" value="sort_clients">
<input type=hidden name="sort_type" value="money_outcoming">
<table cellpadding=2px width=700px cellspacing=0px style="text-align: center;">
<tr>
    <td width=100px>
<p class="small">Сортировать по</p></td>
<td width=150px>
<div class="transparent">
<select name=select_sort_clients onchange="if(this.options[this.selectedIndex].value != -1){ document.clients_sort.submit() }">
<option value=payment_client_id <? if($clients_select_sort=="payment_client_id") echo "selected";?>>Клиенту</option>
<option value=payment_datetime <? if($clients_select_sort=="payment_datetime") echo "selected";?>>Дате запроса</option>
<option value=payment_summ <? if($clients_select_sort=="payment_summ") echo "selected";?>>Сумме запроса</option>
<option value=payment_type <? if($clients_select_sort=="payment_type") echo "selected";?>>Системе выведения</option>
<option value=payment_stat <? if($clients_select_sort=="payment_stat") echo "selected";?>>Статусу запроса</option>
</select>

</div>
</td><td width=80px>
<p class="small"> Отображать </p>
</td><td width=40px>
<div class="transparent">
<select name=select_count_clients onchange="if(this.options[this.selectedIndex].value != -1){ document.clients_sort.submit() }">
<option value=10 <? if($clients_select_count=="10") echo "selected";?>>10</option>
<option value=20 <? if($clients_select_count=="20") echo "selected";?>>20</option>
<option value=40 <? if($clients_select_count=="40") echo "selected";?>>40</option>
<option value=99999999 <? if($clients_select_count=="99999999") echo "selected";?>>Все</option>
</select>

</div>
</td><td width=170px>
<p class="small"> клиентов. Упорядочить по
</p>
</td>
<td width=120px>
<div class="transparent">
<select name=select_direction_clients onchange="if(this.options[this.selectedIndex].value != -1){ document.clients_sort.submit() }">
<option value=asc <? if($clients_select_direction=="asc") echo "selected";?>>Увеличению</option>
<option value=desc <? if($clients_select_direction=="desc") echo "selected";?>>Уменьшению</option>
</select>
</div>
</td>
</tr>
</table>
</form>
</div>
<table border="0" width="990" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td>Дата запроса / игрок</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Сумма</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Система вывода</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Счет / кошелек</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Текущий статус запроса</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Операции</td></tr></table></td>
    </tr>
<?
$system[1] = "Webmoney";
$system[2] = "Яндекс-деньги";
$system[3] = "Мобильный телефон";
$system[4] = "liqpay.com";
$system[5] = "Qiwi-кошелек";
$system[5] = "Perfect-Money";
$payment_status[0] = "<p class=inwork>запрос вывода принят в обработку</p>";
$payment_status[1] = "<p class=attention>запрос вывода отвергнут</p>";
$payment_status[2] = "<p class=success>вывод средств успешно проведен</p>";
while($payment_outcoming_data=mysqli_fetch_assoc($money_outcoming_query)){
   $payment_datetime    = $payment_outcoming_data['payment_datetime'];
   $payment_stat        = $payment_outcoming_data['payment_stat'];
   $payment_system_id   = $payment_outcoming_data['payment_system_id'];
   $payment_summ        = $payment_outcoming_data['payment_summ'];
   $payment_type        = $payment_outcoming_data['payment_type'];
   $payment_client_id   = $payment_outcoming_data['payment_client_id'];
   $payment_id          = $payment_outcoming_data['payment_id'];
   $payment_client_fio  = $payment_outcoming_data['login'];
//payment_client_id
?>

    <tr align="center">
        <td width=140px><table class="levelsTableCell" border=0px><tr><td><b><?=$payment_datetime?><br><br><a class=minilink href="adminka.php?mode=users&user_id=<?=$payment_client_id?>"><?=$payment_client_fio?></a></b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b><?=$payment_summ?></b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><span class=small><?=$system[$payment_type]?></span></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$payment_system_id?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$payment_status[$payment_stat]?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>
        <a class="minilink" href="adminka.php?action=edit_outcoming_payment&payment_id=<?=$payment_id?>&new_stat=2"><span class=success>Провести</span></a>
        / <a class="minilink" href="adminka.php?action=edit_outcoming_payment&payment_id=<?=$payment_id?>&new_stat=0"><span class=inwork>Подвесить</span></a>
         / <a class="minilink" href="adminka.php?action=edit_outcoming_payment&payment_id=<?=$payment_id?>&new_stat=1"><span class=attention>Отказать</span></a>
         </td></tr></table></td>
    </tr>
<?}?>
</table>
