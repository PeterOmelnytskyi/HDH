<h1>Управление новостями проекта</h1>
<?
$news_id = $_REQUEST['news_id'];
if(empty($news_id)){
$news_query=mysqli_query($connector, "SELECT * FROM newsline ORDER BY add_date DESC");?>
<table border=0px width=990px>
<?while($news_data=mysqli_fetch_assoc($news_query)){
                $news_id    = $news_data['news_id'];
                $news_text  = $news_data['news_text'];
                $add_date   = $news_data['add_date'];
                $news_name  = $news_data['news_name'];?>
<tr>
    <td><a href="adminka.php?mode=admin_newsline&news_id=<?=$news_id?>" class=minilink><b><?=$news_name?></b></a></td>
    <td width=350px><p class=small>новость опубликована: <b><?=rus_calendar($add_date)?></b></p>
    <a href="admin_newsline_form.php?action=delete_news&news_id=<?=$news_id?>" class="minilink"><span class=attention>удалить новость</span></a></td>
</tr>
<tr height=20px>
    <td colspan=2><p class=small><?=$news_text?></p></td>
</tr>
<? }
?>
</table>
<h1>Добавить новость</h1>
<form action=admin_newsline_form.php method=post>
<input type=hidden name=action value="add_news">
<p class=small><b>Введите название новости</b></p>
<input type=text name=news_name value="" style="width:430px">
<p class=small><b>Введите текст новости</b></p>
<textarea name=news_text cols=50 rows=4></textarea><br>
<input type=submit value="Отправить">
</form>
<?}else{
$news_query=mysqli_query($connector, "SELECT * FROM newsline WHERE news_id = $news_id");?>
<table border=0px width=990px>
<?while($news_data=mysqli_fetch_assoc($news_query)){
                $news_id    = $news_data['news_id'];
                $news_text  = $news_data['news_text'];
                $add_date   = $news_data['add_date'];
                $news_name  = $news_data['news_name'];?>
<tr>
    <td><p class=small><b><?=$news_name?></b></p></td>
    <td width=350px><p class=small>новость опубликована: <b><?=rus_calendar($add_date)?></b></p></td>
</tr>
<tr height=20px>
    <td colspan=2><p class=small><?=$news_text?></p></td>
</tr>
<? }
?>
</table>
<h1>Редактировать новость</h1>
<form action=admin_newsline_form.php method=post>
<input type=hidden name=action value="add_news">
<input type=hidden name=news_id value="<?=$news_id?>">
<p class=small><b>Введите название новости</b></p>
<input type=text name=news_name value="<?=htmlspecialchars($news_name)?>" style="width: 430px">
<p class=small><b>Введите текст новости</b></p>
<textarea name=news_text cols=50 rows=4><?=$news_text?></textarea><br>
<input type=submit value="Отправить"> <a href="admin_newsline_form.php?action=delete_news&news_id=<?=$news_id?>" class="minilink"><span class=attention>удалить новость</span></a>
</form>

<?}?>