<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("config.php");
require_once ("current_settings.php");
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
$action     =   htmlspecialchars($_REQUEST['action']);
$message_id =   htmlspecialchars($_REQUEST['message_id']);
$message_id = mysqli_real_escape_string($connector,$message_id);
$error      =   "";
	if($action=="delete_received_message")
	{
        $message_sending = mysqli_query($connector, "UPDATE messages SET message_to_stat = 2 WHERE message_id=$message_id AND message_to=$current_admin_id");
		$error.=mysqli_error($connector);
        $af=mysqli_affected_rows($connector);
 		if((empty($error))&&(!empty($af))){
          header("Location: index.php?mode=incoming_messages&result=deleted");
			}
		else {
            header("Location: index.php?mode=incoming_messages&result=not_deleted");
          };
     }
    if($action=="delete_sended_message")
	{
        $message_sending = mysqli_query($connector, "UPDATE messages SET message_from_stat = 2 WHERE message_id=$message_id AND message_from=$current_admin_id");
		$error.=mysqli_error($connector);
        $af=mysqli_affected_rows($connector);
 		if((empty($error))&&(!empty($af))){
          header("Location: index.php?mode=outcoming_messages&result=deleted");
			}
		else {
            header("Location: index.php?mode=outcoming_messages&result=not_deleted");
          };
     }
?>