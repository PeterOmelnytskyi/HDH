<?
session_start();
if((empty($_SESSION["admin_log"])) OR ($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode"))){
exit;
}
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
$timezone             = $_REQUEST['timezone'];
$admin_mail           = $_REQUEST['admin_mail'];
$description          = $_REQUEST['description'];
$keywords             = $_REQUEST['keywords'];
$apples_per_message   = $_REQUEST['apples_per_message'];
$client_max_trees     = $_REQUEST['client_max_trees'];
$rub_usd              = $_REQUEST['rub_usd'];
$harvest_time         = $_REQUEST['harvest_time'];
$tree_lifetime        = $_REQUEST['tree_lifetime'];
$apples_per_gold      = $_REQUEST['apples_per_gold'];
$combine_price        = $_REQUEST['combine_price'];
$autoreferal_price    = $_REQUEST['autoreferal_price'];
$banner_per_day       = $_REQUEST['banner_per_day'];
$link_per_day         = $_REQUEST['link_per_day'];
$mailer_price         = $_REQUEST['mailer_price'];
$user_count           = $_REQUEST['user_count'];
$action               = $_REQUEST['action'];
$current_password = $_REQUEST['old_pass'];
$new_password     = $_REQUEST['new_pass'];
$new_password2    = $_REQUEST['new_pass_2'];
$reserv_change_up = $_REQUEST['reserv_change_up'];
$reserv_change_down = $_REQUEST['reserv_change_down'];
if(!empty($reserv_change_up)) {$reserv_change=-$reserv_change_up;}
elseif(!empty($reserv_change_down)) {$reserv_change=$reserv_change_down;}
else $reserv_change=0;
	if (!isset($_SESSION["admin_log"]) || !isset($_SESSION["admin_pass"])) //unauthorized
	{
		header("Location: admin_init.php");
		die("<script>window.location='admin_init.php';</script>");
	}
if($action=="edit_settings"){
if(empty($admin_mail)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=timezone");
  exit();
}
if(empty($keywords)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=keywords");
  exit();
}
if(empty($description)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=description");
  exit();
}
if((strlen(intval($apples_per_message))<=0)OR($apples_per_message<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=apples_per_message");
  exit();
}
if((strlen(intval($client_max_trees))<=0) OR ($client_max_trees<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=client_max_trees");
  exit();
}
if((strlen(intval($rub_usd))<=0) OR (($rub_usd<=0))) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=rub_usd");
  exit();
}
if((strlen(intval($harvest_time))<=0) OR ($harvest_time<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=harvest_time");
  exit();
}
if((strlen(intval($tree_lifetime))<=0) OR ($tree_lifetime<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=tree_lifetime");
  exit();
}
if((strlen(intval($apples_per_gold))<=0) OR ($apples_per_gold<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=apples_per_gold");
  exit();
}
if((strlen(intval($combine_price))<=0) OR ($combine_price<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=combine_price");
  exit();
}
if((strlen(intval($autoreferal_price))<=0) OR ($autoreferal_price<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=autoreferal_price");
  exit();
}
if((strlen(intval($banner_per_day))<=0) OR ($banner_per_day<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=banner_per_day");
  exit();
}
if((strlen(intval($link_per_day))<=0) OR ($link_per_day<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=link_per_day");
  exit();
}
if((strlen(intval($mailer_price))<=0) OR ($mailer_price<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=mailer_price");
  exit();
}
if((strlen(intval($user_count))<=0) OR ($user_count<=0)) {
  header("Location: adminka.php?mode=admin_settings&result=error&data=user_count");
  exit();
}


$update_settings_query_text="UPDATE settings SET
timezone                  = '$timezone',
admin_mail                = '$admin_mail',
description               = '$description',
keywords                  = '$keywords',
apples_per_message        = $apples_per_message,
client_max_trees          = $client_max_trees,
rub_usd                   = '$rub_usd',
harvest_time              = $harvest_time,
tree_lifetime             = $tree_lifetime,
reserv_change             = $reserv_change,
apples_per_gold           = $apples_per_gold,
combine_price             = $combine_price,
banner_per_day            = $banner_per_day,
link_per_day             = $link_per_day,
mailer_price             = $mailer_price,
user_count               = $user_count,
autoreferal_price        = $autoreferal_price";
//echo $update_settings_query_text;
if($update_settings_query=mysqli_query($connector, $update_settings_query_text)){
  header("Location: adminka.php?mode=admin_settings&result=success");
}
else {
  header("Location: adminka.php?mode=admin_settings&result=error");
}
}
if($action=="change_password"){
 // echo md5($current_password)." / ".$_SESSION["pass"];
  //exit();
      $change_error="";
      if($new_password!=$new_password2){$change_error.="Поля нового пароля содержат различные значения!"; }
      if(md5($current_password)!=$_SESSION["admin_pass"]) {$change_error.="Введенный текущий пароль не совпадает с текущим паролем в базе<br>";}
      if(strlen($new_password)<5) $change_error.="Пароль не может быть короче 5 символов";
      if(strlen($new_password)>20) $change_error.="Пароль не может быть длиннее 20 символов";
      if($change_error!=""){
        header("Location: ".$_SERVER['HTTP_REFERER']."&error=wrong_password&data=".$change_error);
        exit();
      }
      else {
      $new_pass=md5($new_password);
      $curr_login=$_SESSION["admin_log"];
      $update_pass="UPDATE admin SET password='$new_pass' WHERE login='$curr_login'";
      mysqli_query($connector, $update_pass);
        $_SESSION["admin_pass"] = $new_pass;
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
        exit();
      }
 }
?>