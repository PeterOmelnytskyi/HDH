<?
session_start();
require_once("dbconnect.php");
require_once("functions.php");
require_once("config.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title><?=$sitename?> - вход в администраторскую панель</title>

<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="js/jquery-ui-1.8.14.custom.css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<script type="text/javascript" src="js/jquery.js"></script>
<script>
$(document).ready(function(){

var docwidth = $(document).width();
var docheight = $(document).height();
var windowwidth = $(window).width();
var windowheight = $(window).height();
var main_window_bottom = $("#main_window").height();
$('#top').css('left', windowwidth*0.5-1000*0.5);

});
</script>

<script type="text/javascript" src="js/access-style-edit.js"></script>
</head>
<body>
<div id=admin_main_window>
<table>
<tr style="vertical-align: top">
<td>
  <div id="login_form" style="width: 990px">
  <table border=0px align=center>
    <tr>
    <td>
      <h1><img src="images/design/keys.gif" width=20px style="vertical-align: middle"> Вход</h1>
      </td>
    <td>
      <span class=header>ЛОГИН:</span>
      </td>
      <td>
      <input type=text class=input id="mng_login" name="login"><br>
      </td>
    <td>
      <span class=header>ПАРОЛЬ:</span>
    </td>
    <td>
      <input class=input name=password id=mng_pwd type=password>
    </td>
    <td colspan=2>
     <input id="manager_login" value="войти" type=button>
      </td>
    </tr>
  </table>
    <div id="login_info">
    </div>
    <div id="auth_result">
    </div>
  </div>
</td>
</tr>
</table>
</div>
</body>
</html>