<h1>Профиль → изменить Email</h1>
<form name="password" action="user_profile.php" method="post">
<input type="hidden" name="action" value="change_mail_request">
<table>
<tr height=20px>
    <td width=140px><p class=small>Старый Email</p></td>
    <td width=100px><input type=text name=old_mail value=""></td>
</tr>
<tr height=20px>
    <td width=140px><p class=small>Новый Email</p></td>
    <td width=100px><input type=text name=new_mail value=""></td>
</tr>
<tr height=20px>
    <td width=140px><p class=small>Новый Email (повтор)</p></td>
    <td width=100px><input type=text name=new_mail_2 value=""></td>
</tr>
</table>
<input type=submit value="Изменить" class=input_button>
</form>

<?if($_REQUEST['error']=='wrong_mail'){?><p class=wide_small><span class=attention>Внимание!</span>
Вы вводите неверное название ящика электронной почты!<br><?=$_REQUEST['data']?></p><?}?>
<?if($_REQUEST['result']=='change_mail_request_success'){?>
<p class=wide_small><span class=success>Запрос на смену Email был успешно отправлен на новый ящик электронной почты</span>
 </p><?}?>
 <?if($_REQUEST['result']=='change_mail_success'){?>
<p class=wide_small><span class=success>Email был успешно изменен</span>
 </p><?}?>