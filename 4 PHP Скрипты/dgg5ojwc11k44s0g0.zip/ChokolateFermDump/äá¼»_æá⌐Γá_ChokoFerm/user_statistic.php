<h1><img src="images/design/online.png" alt="игроки он-лайн" title="игроки он-лайн"> Кто сейчас в системе:</h1>
<p class="small">список составлен по активности пользователей за последние 15 минут.</p>
<table cellpadding=3px cellspasing=0px>
<tr><td width=650px align=left>
<b class=attention>Администратор</b>
<? $online_session_admins_query="SELECT * FROM clients WHERE TIME_TO_SEC(TIMEDIFF(NOW(),last_activity))<60*15";
$online_session_admins_query=mysqli_query($connector, $online_session_admins_query);
while ($online_session_admins_data=mysqli_fetch_assoc($online_session_admins_query)){
echo " | ";
?>
<a href="?mode=client_profile&client_id=<?=$online_session_admins_data['client_id'];?>" class=minilink><b><?=$online_session_admins_data['login'];?></b></a>
<?}?>
</td>
</tr>
</table>

<h1>Статистика</h1>
<p class=wide_small>Статистика количества шоколадных фабрик на проекте.</p>
<table width="650" border=0px cellpadding=2px cellspasing=0px class="levelsTable">
<tr>
<td align=left>
    <p class=small>Уровень Шоколадной Фабрики</p>
</td>
<td align=left>
    <p class=small>Количество</p>
</td>
</tr>
<?$select_glade_stat_query_text="SELECT *, count(client_tree_id) as counter FROM trees GROUP BY (level) ORDER BY level ASC";
$select_glade_stat_query = mysqli_query($connector, $select_glade_stat_query_text);
while($select_glade_stat_data=mysqli_fetch_assoc($select_glade_stat_query)){
$counter = $select_glade_stat_data['counter'];
$level = $select_glade_stat_data['level'];
            ?>
<tr>
<td align=left>
    <p class=small><?=$level?> уровень</p>
</td>
<td align=left>
    <p class=small><?=$counter?></p>
</td>
</tr>
<?}?>
</table>

<h1>TOP 30 → самые активные игроки</h1>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Игрок</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Всего вывел(а) из системы</td></tr></table></td>
    </tr>
<?
$top_user_page = intval($_REQUEST['top_user_page']);

if(empty($top_user_page)) $top_user_page=1;
if(empty($show_ref_count)) $show_ref_count=10;
$page_count=10;
$limit_start=($top_user_page-1)*$show_ref_count;
$limit_count=$show_ref_count;

$top_user_query_text="SELECT *, sum(payment_summ) AS p_total FROM payment_outcoming INNER JOIN clients WHERE
clients.client_id = payment_outcoming.payment_client_id AND clients.client_id !=1 GROUP BY (payment_client_id) ORDER By p_total DESC LIMIT $limit_start, $limit_count";
$top_user_query = mysqli_query($connector, $top_user_query_text);
while($top_user=mysqli_fetch_assoc($top_user_query)){
                $client_id    = $top_user['client_id'];
                $client_login = $top_user['login'];
                $p_total      = $top_user['p_total'];
?>

    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><a class=minilink href="?mode=client_profile&client_id=<?=$client_id?>"><b><?=$client_login?></b></a></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b><span class="small inwork"><?=$p_total?></span></b></td></tr></table></td>
    </tr>
<?}?>
</table>
<div style="margin: 0px auto; width: 320px;"><span class=small>Страницы:</span>
<?if($top_user_page!=1){?>
<a class="microlink" href="?mode=top&top_user_page=1"><<</a>
<?}?>
<?while ($u<=$page_count){?>
<a class="microlink" href="?mode=top&top_user_page=<?=$u?>" <?if($top_user_page==$u) {?> style="text-decoration: underline" <?}?>><?=$u?></a>
<? $u++;}?>
<?if($top_user_page!=$page_count+1){?>
<a class="microlink" href="?mode=top&top_user_page=<?=$page_count+1?>">>></a>
<?}?>
</div>


<h1>TOP 50 → ТОП по рефералам</h1>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Игрок</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Количество рефералов</td></tr></table></td>
    </tr>
<?
$top_ref_user_page = intval($_REQUEST['top_ref_user_page']);

if(empty($top_ref_user_page)) $top_ref_user_page=1;
if(empty($show_referal_count)) $show_referal_count=10;
$ref_page_count=10;
$limit_start=($top_ref_user_page-1)*$show_referal_count;
$limit_count=$show_referal_count;

$top_referals_query_text="SELECT *, count(client_referal) AS ref_counter FROM clients WHERE client_referal!=0 GROUP BY client_referal HAVING client_referal!=0
ORDER By count(client_referal) DESC LIMIT $limit_start, $limit_count";
$top_referals_query = mysqli_query($connector, $top_referals_query_text);
while($top_referals=mysqli_fetch_assoc($top_referals_query)){
                $client_id    = $top_referals['client_referal'];

                $ref_counter  = $top_referals['ref_counter'];
$login_referals_query_text="SELECT login FROM clients WHERE client_id = $client_id";
$login_referals_query = mysqli_query($connector, $login_referals_query_text);
while($login_referals=mysqli_fetch_assoc($login_referals_query)){
$client_login = $login_referals['login'];
  }
?>

    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><a class=minilink href="?mode=client_profile&client_id=<?=$client_id?>"><b><?=$client_login?></b></a></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b><span class="small inwork"><?=$ref_counter?></span></b></td></tr></table></td>
    </tr>
<?}?>
</table>
<div style="margin: 0px auto; width: 320px;"><span class=small>Страницы:</span>
<?if($top_ref_user_page!=1){?>
<a class="microlink" href="?mode=top&top_ref_user_page=1"><<</a>
<?}?>
<?while ($y<=$ref_page_count){?>
<a class="microlink" href="?mode=top&top_ref_user_page=<?=$y?>" <?if($top_ref_user_page==$y) {?> style="text-decoration: underline" <?}?>><?=$y?></a>
<? $y++;}?>
<?if($top_ref_user_page!=$ref_page_count+1){?>
<a class="microlink" href="?mode=top&top_ref_user_page=<?=$ref_page_count+1?>">>></a>
<?}?>
</div>