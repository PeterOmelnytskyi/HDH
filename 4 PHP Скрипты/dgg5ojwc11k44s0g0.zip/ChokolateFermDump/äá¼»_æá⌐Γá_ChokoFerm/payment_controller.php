<?
//session_start();
$write_key = fopen("ip_inter.txt","w");
$ip = $_SERVER['REMOTE_ADDR'];
fwrite($write_key, $ip);
require_once ("dbconnect.php");
//require_once ("functions.php");
$ik_payment_amount   = htmlspecialchars($_REQUEST['ik_payment_amount']);
$ik_payment_id       = intval($_REQUEST['ik_payment_id']);
$ik_payment_timestamp= intval($_REQUEST['ik_payment_timestamp']);
$ik_payment_desc     = htmlspecialchars($_REQUEST['ik_payment_desc']);
$ik_baggage_fields   = intval($_REQUEST['ik_baggage_fields']);
$ik_payment_state    = htmlspecialchars($_REQUEST['ik_payment_state']);
$ik_currency_exch    = intval($_REQUEST['ik_currency_exch']);
$ik_trans_id         = htmlspecialchars($_REQUEST['ik_trans_id']);
$client_id         = intval($_REQUEST['client_id']);
           $settings_query="SELECT * FROM settings";
           $settings_query=mysqli_query($connector, $settings_query);
           while($settings=mysqli_fetch_assoc($settings_query)){
              $rub_usd = $settings['rub_usd'];
          }
$payment_amount = $rub_usd*$ik_payment_amount;
if(count($_REQUEST)>0){
  //проверка нет ли подобной записи по ошибочно дублированной ссылке
      $check_incoming_payment_query_text = "SELECT * FROM payment_incoming WHERE payment_trans_id = '$ik_trans_id'";
     $check_incoming_payment_query = mysqli_query($connector, $check_incoming_payment_query_text);
     $check_incoming_payment_counter = mysqli_num_rows($check_incoming_payment_query);
     if($check_incoming_payment_counter==0){
        $insert_incoming_payment_query_text = "INSERT INTO payment_incoming (payment_datetime, payment_client_id, payment_summ, payment_type,
         payment_trans_id, stat) VALUES (NOW(), $ik_payment_id, '$payment_amount', 1, '$ik_trans_id', 0)";
         $insert_incoming_payment_query = mysqli_query($connector, $insert_incoming_payment_query_text);
        //уведомление об успешном платеже
        if($ik_payment_state=='success'){
          //if($ip!="46.211.123.219"){exit;}
           $edit_incoming_payment_query_text = "UPDATE payment_incoming SET stat = 1 WHERE payment_trans_id = '$ik_trans_id'";
           $edit_incoming_payment_query = mysqli_query($connector, $edit_incoming_payment_query_text);
           $get_payment_amount_query_text = "SELECT payment_summ FROM payment_incoming WHERE payment_trans_id = '$ik_trans_id'";
           $get_payment_amount_query = mysqli_query($connector, $get_payment_amount_query_text);
            while($get_payment_amount_data=mysqli_fetch_assoc($get_payment_amount_query)){
              $payment_summ = $get_payment_amount_data['payment_summ'];
          }
          $gold_increase = floor($payment_summ*100);
           $update_client_gold_query_text = "UPDATE clients SET gold_market = gold_market+$gold_increase WHERE client_id = $ik_payment_id";
           $update_client_gold_query = mysqli_query($connector, $update_client_gold_query_text);
           header("Location: index.php?mode=payment_success");
           exit();
        }

        //уведомление о неуспешном платеже
        elseif($ik_payment_state=='fail'){
           $delete_incoming_payment_query_text = "DELETE FROM payment_incoming WHERE payment_trans_id = '$ik_trans_id'";
           $delete_incoming_payment_query = mysqli_query($connector, $delete_incoming_payment_query_text);
           header("Location: index.php?mode=payment_failed");
           exit();
        }
    }
    elseif(($check_incoming_payment_counter>0) AND ($ik_payment_state=='success')){
           header("Location: index.php?mode=payment_success");
           exit();
    }
    elseif(($check_incoming_payment_counter>0) AND ($ik_payment_state=='fail')){
           header("Location: index.php?mode=payment_failed");
           exit();
    }
}
?>
