<?
$message_page = intval($_REQUEST['message_page']);
$ref_counter=0;
$select_refs_count=mysqli_query($connector, "SELECT count(*) AS counter FROM public_feedback INNER JOIN clients WHERE clients.client_id = public_feedback.client_id AND
clients.client_stat>=1 AND public_feedback.message_stat>0");
while($ref_data=mysqli_fetch_assoc($select_refs_count)){
  $ref_counter  = $ref_data['counter'];
  }
if(empty($message_page)) $message_page=1;
if(empty($show_ref_count)) $show_ref_count=10;
$page_count=floor($ref_counter/$show_ref_count);
$limit_start=($message_page-1)*$show_ref_count;
$limit_count=$show_ref_count;
?>
<h1>Отзывы о сайте</h1>
<?
$chat_query=mysqli_query($connector, "SELECT *, public_feedback.add_date AS message_add_date FROM public_feedback INNER JOIN clients
WHERE clients.client_id = public_feedback.client_id AND
clients.client_stat>=1 AND public_feedback.message_stat>0 ORDER BY public_feedback.add_date DESC LIMIT $limit_start, $limit_count");
while($chat_data=mysqli_fetch_assoc($chat_query)){
                $chat_client_id = $chat_data['client_id'];
                $chat_login = $chat_data['login'];
                $chat_message_text=$chat_data['message'];
                $chat_add_date=$chat_data['message_add_date'];
                $chat_avatar=$chat_data['client_avatar'];?>
<div class=feedback_messages>
<p class=small><span style="font-size: 11px; color: white">Отзыв от игрока <b><?=$chat_login?></b>, оставлен <b><?=rus_calendar($chat_add_date)?></b></span></p>
<p class=small><span style="font-size: 11px; color: white; line-height: 12px; margin: 1px"><?=$chat_message_text?></span></p>
<hr style="border-top: 1px dashed #fff; border-bottom: none; height: 1px; width:90%; ">
</div>
<br>
<br>
<?}?>
<div style="margin: 0px auto; width: 320px;"><span class=small>Страницы:</span>
<?if($message_page!=1){?>
<a class="microlink" href="?mode=feedback&message_page=1"><<</a>
<?}?>
<?while ($u<=$page_count+1){?>
<a class="microlink" href="?mode=feedback&message_page=<?=$u?>" <?if($message_page==$u) {?> style="text-decoration: underline" <?}?>><?=$u?></a>
<? $u++;}?>
<?if($message_page!=$page_count+1){?>
<a class="microlink" href="?mode=feedback&message_page=<?=$page_count+1?>">>></a>
<?}?>
</div>
<?//гость
if($current_client_barrels>=$apples_per_message){?>
<p class=middle>Оставить отзыв</p>
<p class="small">Ваш отзыв будет добавлен на сайт после проверки администратором.</p>
<?if($_REQUEST['result']=='success'){?>
<p class=wide_small><span class=success>Внимание!</span>
Ваш отзыв успешно отправлен.</p><?}?>
<br>
<form name="payment" action="feedback_form.php" method="get">
<input type="hidden" name="action" value="public_feedback">
<textarea name="message_text" placeholder="введите ваше сообщение" style="width: 360px; height: 120px"></textarea>
<input type="submit" value="Отправить" class=input_button style="width: 150px">
</form>
<?}
elseif($current_client_barrels<$apples_per_message){
?>
<p class=wide_small>
У вас не хватает шоколада для отправки отзыва! Стоимость сообщения - <?=$apples_per_message?> <img src="images/design/almaz.png" width=18px style="vertical-align: bottom">
</p>
<?}?>
