<h1>Выплаты</h1>
<p class="middle inwork">Последние 50 выплат</p>
<?
$money_outcoming_query_text="SELECT * FROM payment_outcoming INNER JOIN clients WHERE
clients.client_id = payment_outcoming.payment_client_id AND clients.client_id!=1 AND payment_outcoming.payment_stat=2 ORDER By payment_datetime DESC LIMIT 50";
$money_outcoming_query=mysqli_query($connector, $money_outcoming_query_text);
$money_outcoming_count=mysqli_num_rows($money_outcoming_query);
?>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Игрок</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Дата запроса</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Сумма, руб</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Система вывода</td></tr></table></td>
    </tr>
<?
$system[1] = "Webmoney";
$system[2] = "Яндекс-деньги";
$system[3] = "Мобильный телефон";
$system[4] = "LiqPAY";
$system[5] = "Qiwi-кошелек";
$system[10] = "Perfect Money";
while($payment_outcoming_data=mysqli_fetch_assoc($money_outcoming_query)){
   $client_id   = $payment_outcoming_data['payment_client_id'];
   $payment_datetime    = $payment_outcoming_data['payment_datetime'];
   $payment_system   = $payment_outcoming_data['payment_type'];
   $payment_summ        = $payment_outcoming_data['payment_summ'];
   $payment_client_fio  = $payment_outcoming_data['login'];
//payment_client_id
?>

    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td><a class=minilink href="?mode=client_profile&client_id=<?=$client_id?>"><b><?=$payment_client_fio?></b></a></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b><?=rus_calendar($payment_datetime)?></b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b><span class="small success"><?=$payment_summ?></span></b></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><b><span class="small inwork"><?=$system[$payment_system]?></span></b></td></tr></table></td>
    </tr>
<?}?>
</table>
