<?php
  //-- Разрешенные диапазоны
   //$Allow_Ip_Range = array('212.158.173.0/24','212.118.48.0/24','82.111.127.1/8');
   //-------------------------------------------------------------------
   //-- Функция проверки ip
   //-------------------------------------------------------------------
   function Check_Ip ($Ip_For_Search, $Allow_Ip_Range)
   {
     $ip_count = array(32=>0, 31=>1, 30=>3, 29=>7, 28=>15, 27=>31, 26=>63, 25=>127, 24=>255, 23=>511, 22=>1023, 21=>2047, 20=>4095,
                       19=>8191, 18=>16383, 17=>32767, 16=>65535, 15=>131071, 14=>262143, 13=>524287, 12=>1048575, 11=>2097151,
                       10=>4194303, 9=>8388607, 8=>16777215, 7=>33554431, 6=>67108863, 5=>134217727, 4=>268435455, 3=>536870911,
                       2=>1073741823);

     $Ip_For_Search_Converted = ip2long($Ip_For_Search);
     //$Result = FALSE;
     foreach ( $Allow_Ip_Range as $Value )
     {
       list($ip, $prefix) = preg_split('/\//',$Value);
       $Range_Start = ip2long($ip);
       $Range_End   = $Range_Start + $ip_count["$prefix"];
       //echo $Value;
       if ( $Ip_For_Search_Converted >= $Range_Start && $Ip_For_Search_Converted <= $Range_End )
       {
         return TRUE;
       }
     }
     return FALSE;
   }
   function translit($str)
	{
		$tr = array(
			"А"=>"A","Б"=>"B","В"=>"V","Г"=>"G",
			"Д"=>"D","Е"=>"E","Ж"=>"J","З"=>"Z","И"=>"I",
			"Й"=>"Y","К"=>"K","Л"=>"L","М"=>"M","Н"=>"N",
			"О"=>"O","П"=>"P","Р"=>"R","С"=>"S","Т"=>"T",
			"У"=>"U","Ф"=>"F","Х"=>"H","Ц"=>"TS","Ч"=>"CH",
			"Ш"=>"SH","Щ"=>"SCH","Ъ"=>"","Ы"=>"YI","Ь"=>"",
			"Э"=>"E","Ю"=>"YU","Я"=>"YA","а"=>"a","б"=>"b",
			"в"=>"v","г"=>"g","д"=>"d","е"=>"e","ж"=>"j",
			"з"=>"z","и"=>"i","й"=>"y","к"=>"k","л"=>"l",
			"м"=>"m","н"=>"n","о"=>"o","п"=>"p","р"=>"r",
			"с"=>"s","т"=>"t","у"=>"u","ф"=>"f","х"=>"h",
			"ц"=>"ts","ч"=>"ch","ш"=>"sh","щ"=>"sch","ъ"=>"y",
			"ы"=>"yi","ь"=>"","э"=>"e","ю"=>"yu","я"=>"ya"
		);
		return strtr($str,$tr);
	}
    define ("YY_PART_YEAR", 70);
    define ("YY_MAGIC_BELOW", 200);
    function to_days($year, $month, $day)
     {
         if ($year == 0 && $month == 0 && $day == 0)
         {
           return ;
         }
         if ($year < YY_MAGIC_BELOW)
         {
             if (($year = $year+1900) < 1900+YY_PART_YEAR)
             {
                 $year+=100;
             }
         }
         $delsum = 365*$year+31*($month-1)+$day;
         if ($month <= 2)
         {
             $year--;
         }
         else
         {
             $delsum -= floor(($month*4+23)/10);
         }
         $temp = floor((floor($year/100)+1)*3/4);
         return floor($delsum+$year/4-$temp);
     }

     function extend_mail($mail, $name, $send_data, $from){

$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html;  charset=UTF-8\r\n";
$headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
//$headers .= "From: \".$from.\r\n";
$headers .= "X-Mailer: My Send E-mail\r\n";
$pwd_ip=$_SERVER['REMOTE_ADDR'];

@mail($mail, $name,"
Попытка входа в систему администрирования по адресу $pwd_ip.
Ключ авторизации: $send_data","$headers");//отправляем сообщение нам
}

     function notify_mail($mail, $name, $send_data, $from){

$headers  = "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html;  charset=UTF-8\r\n";
$headers .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
$headers .= "From: \".$from.\r\n";
$headers .= "X-Mailer: My Send E-mail\r\n";
mail($mail, $name,"Уведомление: $send_data","$headers");//отправляем сообщение нам
}

function rus_calendar($date){

  $month  = substr($date,5,2);
  $year   = substr($date,0,4);
  $day    = substr($date,8,2);
      if($month=="01") $rus_month = "января";
  elseif($month=="02") $rus_month = "февраля";
  elseif($month=="03") $rus_month = "марта";
  elseif($month=="04") $rus_month = "апреля";
  elseif($month=="05") $rus_month = "мая";
  elseif($month=="06") $rus_month = "июня";
  elseif($month=="07") $rus_month = "июля";
  elseif($month=="08") $rus_month = "августа";
  elseif($month=="09") $rus_month = "сентября";
  elseif($month=="10") $rus_month = "октября";
  elseif($month=="11") $rus_month = "ноября";
  elseif($month=="12") $rus_month = "декабря";
    if(strlen($date)==19){
  $hour   = substr($date,11,2);
  $minute = substr($date,14,2);
    return $day." ".$rus_month." ".$year." г. ".$hour."ч ".$minute." м.";
  }
  else {
    return $day." ".$rus_month." ".$year." г. ".$hour;
  }
}

function rus_calendar_date($date){

  $month  = substr($date,5,2);
  $year   = substr($date,0,4);
  $day    = substr($date,8,2);
      if($month=="01") $rus_month = "января";
  elseif($month=="02") $rus_month = "февраля";
  elseif($month=="03") $rus_month = "марта";
  elseif($month=="04") $rus_month = "апреля";
  elseif($month=="05") $rus_month = "мая";
  elseif($month=="06") $rus_month = "июня";
  elseif($month=="07") $rus_month = "июля";
  elseif($month=="08") $rus_month = "августа";
  elseif($month=="09") $rus_month = "сентября";
  elseif($month=="10") $rus_month = "октября";
  elseif($month=="11") $rus_month = "ноября";
  elseif($month=="12") $rus_month = "декабря";
  return $day." ".$rus_month." ".$year." г.";
}

function date_hour($date){
$hour   = substr($date,11,2);
  return $hour;
}

function is_mobile() {
  $user_agent=strtolower(getenv('HTTP_USER_AGENT'));
  $accept=strtolower(getenv('HTTP_ACCEPT'));

  if ((strpos($accept,'text/vnd.wap.wml')!==false) ||
      (strpos($accept,'application/vnd.wap.xhtml+xml')!==false)) {
    return 1; // Мобильный браузер обнаружен по HTTP-заголовкам
  }

  if (isset($_SERVER['HTTP_X_WAP_PROFILE']) ||
      isset($_SERVER['HTTP_PROFILE'])) {
    return 2; // Мобильный браузер обнаружен по установкам сервера
  }

  if (preg_match('/(mini 9.5|vx1000|lge |m800|e860|u940|ux840|compal|'.
    'wireless| mobi|ahong|lg380|lgku|lgu900|lg210|lg47|lg920|lg840|'.
    'lg370|sam-r|mg50|s55|g83|t66|vx400|mk99|d615|d763|el370|sl900|'.
    'mp500|samu3|samu4|vx10|xda_|samu5|samu6|samu7|samu9|a615|b832|'.
    'm881|s920|n210|s700|c-810|_h797|mob-x|sk16d|848b|mowser|s580|'.
    'r800|471x|v120|rim8|c500foma:|160x|x160|480x|x640|t503|w839|'.
    'i250|sprint|w398samr810|m5252|c7100|mt126|x225|s5330|s820|'.
    'htil-g1|fly v71|s302|-x113|novarra|k610i|-three|8325rc|8352rc|'.
    'sanyo|vx54|c888|nx250|n120|mtk |c5588|s710|t880|c5005|i;458x|'.
    'p404i|s210|c5100|teleca|s940|c500|s590|foma|samsu|vx8|vx9|a1000|'.
    '_mms|myx|a700|gu1100|bc831|e300|ems100|me701|me702m-three|sd588|'.
    's800|8325rc|ac831|mw200|brew |d88|htc\/|htc_touch|355x|m50|km100|'.
    'd736|p-9521|telco|sl74|ktouch|m4u\/|me702|8325rc|kddi|phone|lg |'.
    'sonyericsson|samsung|240x|x320vx10|nokia|sony cmd|motorola|'.
    'up.browser|up.link|mmp|symbian|smartphone|midp|wap|vodafone|o2|'.
    'pocket|kindle|mobile|psp|treo)/', $user_agent)) {
    return 3; // Мобильный браузер обнаружен по сигнатуре User Agent
  }

  if (in_array(substr($user_agent,0,4),
    Array("1207", "3gso", "4thp", "501i", "502i", "503i", "504i", "505i", "506i",
          "6310", "6590", "770s", "802s", "a wa", "abac", "acer", "acoo", "acs-",
          "aiko", "airn", "alav", "alca", "alco", "amoi", "anex", "anny", "anyw",
          "aptu", "arch", "argo", "aste", "asus", "attw", "au-m", "audi", "aur ",
          "aus ", "avan", "beck", "bell", "benq", "bilb", "bird", "blac", "blaz",
          "brew", "brvw", "bumb", "bw-n", "bw-u", "c55/", "capi", "ccwa", "cdm-",
          "cell", "chtm", "cldc", "cmd-", "cond", "craw", "dait", "dall", "dang",
          "dbte", "dc-s", "devi", "dica", "dmob", "doco", "dopo", "ds-d", "ds12",
          "el49", "elai", "eml2", "emul", "eric", "erk0", "esl8", "ez40", "ez60",
          "ez70", "ezos", "ezwa", "ezze", "fake", "fetc", "fly-", "fly_", "g-mo",
          "g1 u", "g560", "gene", "gf-5", "go.w", "good", "grad", "grun", "haie",
          "hcit", "hd-m", "hd-p", "hd-t", "hei-", "hiba", "hipt", "hita", "hp i",
          "hpip", "hs-c", "htc ", "htc-", "htc_", "htca", "htcg", "htcp", "htcs",
          "htct", "http", "huaw", "hutc", "i-20", "i-go", "i-ma", "i230", "iac",
          "iac-", "iac/", "ibro", "idea", "ig01", "ikom", "im1k", "inno", "ipaq",
          "iris", "jata", "java", "jbro", "jemu", "jigs", "kddi", "keji", "kgt",
          "kgt/", "klon", "kpt ", "kwc-", "kyoc", "kyok", "leno", "lexi", "lg g",
          "lg-a", "lg-b", "lg-c", "lg-d", "lg-f", "lg-g", "lg-k", "lg-l", "lg-m",
          "lg-o", "lg-p", "lg-s", "lg-t", "lg-u", "lg-w", "lg/k", "lg/l", "lg/u",
          "lg50", "lg54", "lge-", "lge/", "libw", "lynx", "m-cr", "m1-w", "m3ga",
          "m50/", "mate", "maui", "maxo", "mc01", "mc21", "mcca", "medi", "merc",
          "meri", "midp", "mio8", "mioa", "mits", "mmef", "mo01", "mo02", "mobi",
          "mode", "modo", "mot ", "mot-", "moto", "motv", "mozz", "mt50", "mtp1",
          "mtv ", "mwbp", "mywa", "n100", "n101", "n102", "n202", "n203", "n300",
          "n302", "n500", "n502", "n505", "n700", "n701", "n710", "nec-", "nem-",
          "neon", "netf", "newg", "newt", "nok6", "noki", "nzph", "o2 x", "o2-x",
          "o2im", "opti", "opwv", "oran", "owg1", "p800", "palm", "pana", "pand",
          "pant", "pdxg", "pg-1", "pg-2", "pg-3", "pg-6", "pg-8", "pg-c", "pg13",
          "phil", "pire", "play", "pluc", "pn-2", "pock", "port", "pose", "prox",
          "psio", "pt-g", "qa-a", "qc-2", "qc-3", "qc-5", "qc-7", "qc07", "qc12",
          "qc21", "qc32", "qc60", "qci-", "qtek", "qwap", "r380", "r600", "raks",
          "rim9", "rove", "rozo", "s55/", "sage", "sama", "samm", "sams", "sany",
          "sava", "sc01", "sch-", "scoo", "scp-", "sdk/", "se47", "sec-", "sec0",
          "sec1", "semc", "send", "seri", "sgh-", "shar", "sie-", "siem", "sk-0",
          "sl45", "slid", "smal", "smar", "smb3", "smit", "smt5", "soft", "sony",
          "sp01", "sph-", "spv ", "spv-", "sy01", "symb", "t-mo", "t218", "t250",
          "t600", "t610", "t618", "tagt", "talk", "tcl-", "tdg-", "teli", "telm",
          "tim-", "topl", "tosh", "treo", "ts70", "tsm-", "tsm3", "tsm5", "tx-9",
          "up.b", "upg1", "upsi", "utst", "v400", "v750", "veri", "virg", "vite",
          "vk-v", "vk40", "vk50", "vk52", "vk53", "vm40", "voda", "vulc", "vx52",
          "vx53", "vx60", "vx61", "vx70", "vx80", "vx81", "vx83", "vx85", "vx98",
          "w3c ", "w3c-", "wap-", "wapa", "wapi", "wapj", "wapm", "wapp", "wapr",
          "waps", "wapt", "wapu", "wapv", "wapy", "webc", "whit", "wig ", "winc",
          "winw", "wmlb", "wonu", "x700", "xda-", "xda2", "xdag", "yas-", "your",
          "zeto", "zte-"))) {
    return 4; // Мобильный браузер обнаружен по сигнатуре User Agent
  }

  return 0; // Мобильный браузер не обнаружен
}
function user_check_browser(){
  if ( stristr($_SERVER['HTTP_USER_AGENT'], 'Firefox') ) return 'mozilla';
elseif ( stristr($_SERVER['HTTP_USER_AGENT'], 'Chrome') ) return 'chrome';
elseif ( stristr($_SERVER['HTTP_USER_AGENT'], 'Safari') ) return 'safari';
elseif ( stristr($_SERVER['HTTP_USER_AGENT'], 'Opera') ) return 'opera';
elseif ( stristr($_SERVER['HTTP_USER_AGENT'], 'MSIE') ) return 'ie';
elseif ( stristr($_SERVER['HTTP_USER_AGENT'], 'maxton') ) return 'maxton';
elseif ( stristr($_SERVER['HTTP_USER_AGENT'], 'konqueror') ) return 'konqueror';
else return 'unknown';
}

function filter_mobile_number($phone_number)
	{
      return $valid_phone_number;
    }

?>