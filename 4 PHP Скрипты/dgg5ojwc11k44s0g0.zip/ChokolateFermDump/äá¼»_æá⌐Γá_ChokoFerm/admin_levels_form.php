<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
$action     = $_REQUEST['action'];
$cost1  =   $_REQUEST['cost1'];
$cost2  =   $_REQUEST['cost2'];
$cost3  =   $_REQUEST['cost3'];
$cost4  =   $_REQUEST['cost4'];
$cost5  =   $_REQUEST['cost5'];
$cost6  =   $_REQUEST['cost6'];
$cost7  =   $_REQUEST['cost7'];
$cost8  =   $_REQUEST['cost8'];
$cost9  =   $_REQUEST['cost9'];
$harvest1  =   $_REQUEST['harvest1'];
$harvest2  =   $_REQUEST['harvest2'];
$harvest3  =   $_REQUEST['harvest3'];
$harvest4  =   $_REQUEST['harvest4'];
$harvest5  =   $_REQUEST['harvest5'];
$harvest6  =   $_REQUEST['harvest6'];
$harvest7  =   $_REQUEST['harvest7'];
$harvest8  =   $_REQUEST['harvest8'];
$harvest9  =   $_REQUEST['harvest9'];
$bonus1  =   $_REQUEST['bonus1'];
$bonus2  =   $_REQUEST['bonus2'];
$bonus3  =   $_REQUEST['bonus3'];
$bonus4  =   $_REQUEST['bonus4'];
$bonus5  =   $_REQUEST['bonus5'];
$bonus6  =   $_REQUEST['bonus6'];
$bonus7  =   $_REQUEST['bonus7'];
$bonus8  =   $_REQUEST['bonus8'];
$bonus9  =   $_REQUEST['bonus9'];

if ((empty($_SESSION["admin_log"])) OR (empty($_SESSION["admin_pass"])))
	{
		die("<script>window.location='admin_init.php';</script>");
	}
if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}    
if ($mode=="logout")
	{
		$_SESSION["admin_log"] = "";
		$_SESSION["admin_pass"] = "";
		unset($_SESSION["admin_log"]);
		unset($_SESSION["admin_pass"]);
        session_destroy();
		die("<script>window.location='admin_init.php';</script>");
	}


	if($action=="update_levels")
	{

            $update_levels_query_text="UPDATE levels SET cost=$cost1, harvest=$harvest1, bonus=$bonus1 WHERE level_id=1";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost2, harvest=$harvest2, bonus=$bonus2 WHERE level_id=2";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost3, harvest=$harvest3, bonus=$bonus3 WHERE level_id=3";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost4, harvest=$harvest4, bonus=$bonus4 WHERE level_id=4";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost5, harvest=$harvest5, bonus=$bonus5 WHERE level_id=5";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost6, harvest=$harvest6, bonus=$bonus6 WHERE level_id=6";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost7, harvest=$harvest7, bonus=$bonus7 WHERE level_id=7";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost8, harvest=$harvest8, bonus=$bonus8 WHERE level_id=8";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);
            $update_levels_query_text="UPDATE levels SET cost=$cost9, harvest=$harvest9, bonus=$bonus9 WHERE level_id=9";
            $update_levels_query = mysqli_query($connector, $update_levels_query_text);
 		    $error.=mysqli_error($connector);


		if(empty($error)){
			header("Location: adminka.php?mode=levels");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
?>