<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
$action     = $_REQUEST['action'];
$action_id    = $_REQUEST['action_id'];
$action_text  =   $_REQUEST['action_text'];
$action_name  =   $_REQUEST['action_name'];
if ((empty($_SESSION["admin_log"])) OR (empty($_SESSION["admin_pass"])))
	{
		die("<script>window.location='admin_init.php';</script>");
	}
if ($mode=="logout")
	{
		$_SESSION["admin_log"] = "";
		$_SESSION["admin_pass"] = "";
		unset($_SESSION["admin_log"]);
		unset($_SESSION["admin_pass"]);
        session_destroy();
		die("<script>window.location='admin_init.php';</script>");
	}
	if($action=="add_action")
	{
        if((empty($action_text))&&(empty($action_name))) $error.="Название и текст акции должны быть непусты<br>";

		if(!empty($error))
		{
			echo "Произошли следующие ошибки: ".$error."<br><a href='adminka.php?mode=admin_action'>вернуться обратно</a>";
			die();
		}
        if(!empty($actions_id)){
            $update_actions_query_text="UPDATE actions SET action_text='$action_text', action_name='$actions_name' WHERE action_id = $actions_id";
            $update_actions_query = mysqli_query($connector, $update_actions_query_text);
        }
        else
        {
    		$add_actions_query_text="INSERT INTO actions (action_text, action_name, add_date) VALUES ('$action_text', '$action_name', NOW())";
            $add_actions_query = mysqli_query($connector, $add_actions_query_text);
        }
		$error.=mysqli_error($connector);

		if(empty($error)){
			header("Location: adminka.php?mode=admin_actions");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
    	if($action=="delete_action")
	{
        if(!empty($action_id)){
            $delete_actions_query_text="DELETE FROM actions WHERE action_id = $action_id";
            $delete_actions_query = mysqli_query($connector, $delete_actions_query_text);
        }
		$error.=mysqli_error($connector);
		if(empty($error)){
			header("Location: adminka.php?mode=admin_actions");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
?>