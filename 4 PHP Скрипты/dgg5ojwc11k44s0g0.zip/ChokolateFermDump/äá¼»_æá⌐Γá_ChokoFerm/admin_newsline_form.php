<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
$action     = $_REQUEST['action'];
$news_id    = $_REQUEST['news_id'];
$news_text  =   $_REQUEST['news_text'];
$news_name  =   $_REQUEST['news_name'];
if ((empty($_SESSION["admin_log"])) OR (empty($_SESSION["admin_pass"])))
	{
		die("<script>window.location='admin_init.php';</script>");
	}
if ($mode=="logout")
	{
		$_SESSION["admin_log"] = "";
		$_SESSION["admin_pass"] = "";
		unset($_SESSION["admin_log"]);
		unset($_SESSION["admin_pass"]);
        session_destroy();
		die("<script>window.location='admin_init.php';</script>");
	}
	if($action=="add_news")
	{
        if((empty($news_text))&&(empty($news_name))) $error.="Название и текст новости должны быть непусты<br>";

		if(!empty($error))
		{
			echo "Произошли следующие ошибки: ".$error."<br><a href='adminka.php?mode=admin_newsline'>вернуться обратно</a>";
			die();
		}
        if(!empty($news_id)){
            $update_news_query_text="UPDATE newsline SET news_text='$news_text', news_name='$news_name' WHERE news_id = $news_id";
            $update_news_query = mysqli_query($connector, $update_news_query_text);
        }
        else
        {
    		$add_news_query_text="INSERT INTO newsline (news_text, news_name, add_date) VALUES ('$news_text', '$news_name', NOW())";
            $add_news_query = mysqli_query($connector, $add_news_query_text);
        }
		$error.=mysqli_error($connector);

		if(empty($error)){
			header("Location: adminka.php?mode=admin_newsline");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
    	if($action=="delete_news")
	{
        if(!empty($news_id)){
            $delete_news_query_text="DELETE FROM newsline WHERE news_id = $news_id";
            $delete_news_query = mysqli_query($connector, $delete_news_query_text);
        }
		$error.=mysqli_error($connector);
		if(empty($error)){
			header("Location: adminka.php?mode=admin_newsline");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
?>