<h1>Операции с балансом</h1>
<p class=wide_small><b>Обмен золота для вывода на золото для покупок </b>
Для осуществления перевода средств введите сумму в золоте и нажмите кнопку "Обменять". Средства будут мгновенно переведены на счет для покупок.</p>
<form action="ferm_form.php" method=get>
<input type=hidden value="convert_gold" name=action>
<table>
<tr height=20px>
    <td width=100px><p class=middle>Сумма:</p></td>
    <td width=100px><input type=text id=gold_value name=count value="<?=$max_gold?>"></td>
    <td width=460px align=left><input type=submit value="Обменять" class=input_button></td>
</tr>
</table>
</form>
<?if($_REQUEST['error']=='not_positive_count'){?><p class=wide_small><span class=attention>Внимание!</span>
Сумма конвертации должна быть положительной!</p><?}?>
<?if($_REQUEST['error']=='not_enough_gold'){?><p class=wide_small><span class=attention>Внимание!</span>
На кошельке для вывода недостаточно средств для проведения данной операции!</p><?}?>
<?if($_REQUEST['success']=='convert_gold'){?><p class=wide_small><span class=success>Денежные средства успешно переведены!</span>
 </p><?}?>
<h1>История операций</h1>
<?if($_REQUEST['limit']=='no'){?>
<a class=minilink style="float: right" href="?mode=balance_actions">показать последние 20 операций</a>
<?}else {?>
<a class=minilink style="float: right" href="?mode=balance_actions&limit=no">показать все операции</a>
<?}?>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td>Дата</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Сумма</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Операция</td></tr></table></td>
    </tr>
<?
if($_REQUEST['limit']=='no'){
$balance_actions_query_text="SELECT * FROM balance_actions WHERE client_id = $current_admin_id ORDER BY add_date DESC";
}
else {
$balance_actions_query_text="SELECT * FROM balance_actions WHERE client_id = $current_admin_id ORDER BY add_date DESC LIMIT 20";
}
$balance_actions_query = mysqli_query($connector, $balance_actions_query_text);
while($balance_actions_data=mysqli_fetch_assoc($balance_actions_query)){
   $add_date    = $balance_actions_data['add_date'];
   $action_type = $balance_actions_data['action_type'];
   $apples      = $balance_actions_data['barrels'];
   $gold        = $balance_actions_data['gold'];
   $gold_market = $balance_actions_data['gold_market'];
$action[1] = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> Продажа шоколада";
$action[2] = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> Сбор шоколада";
$action[3] = "<img src='images/design/almaz.png' width=16px style='vertical-align: bottom'> Сбор шоколада со всех фабрик";
$action[4] = "Перевод золота на счет для покупок";
$action[5] = "Покупка Шоколадной Фабрики";
$action[6] = "Повышение уровня Шоколадной Фабрики";
$action[7] = "Пополнение баланса с реквизитов";
$action[8] = "Доход от реферала (апгрейд Шоколадной Фабрики)";
$action[9] = "Доход от реферала (покупка Шоколадной Фабрики)";
$action[10] = "Аренда автосборщика шоколада";
$action[11] = "Приобретение автореферала";
$action[20] = "Вывод средств";
$sum[1]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'>+".$gold;
$sum[2]    = "<img src='images/design/almaz.png' width=20px style='vertical-align: bottom'>+".$apples;
$sum[3]    = "<img src='images/design/almaz.png' width=20px style='vertical-align: bottom'>+".$apples;
$sum[4]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[5]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[6]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[7]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold_market;
$sum[8]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[9]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[10]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[20]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> -".$gold;
$sum[11]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> ".$gold_market;
$sum[12]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[13]    = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> +".$gold;
$sum[14]    = "<img src='images/design/almaz.png' width=20px style='vertical-align: bottom'> ".$apples;
$sum[15]    = "<img src='images/design/almaz.png' width=20px style='vertical-align: bottom'> ".$apples;
$sum[21] = "<img src='images/design/coins.png' width=16px style='vertical-align: bottom'> 0";
?>

    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td><?=$add_date?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$sum[$action_type]?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$action[$action_type]?></td></tr></table></td>
    </tr>
<?}?>
</table>
<?//гость
if(empty($_SESSION[$session_login])){?>
<p class=wide_small><b>Вы не авторизованны! Вам необходимо повторно авторизоваться на проекте!</b></p>
<?}?>