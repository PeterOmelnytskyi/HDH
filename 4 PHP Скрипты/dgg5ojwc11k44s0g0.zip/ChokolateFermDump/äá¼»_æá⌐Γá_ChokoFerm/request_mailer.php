<h1>Заказ рекламной рассылки</h1>
<?if($_REQUEST['result']=='wrong_description'){?><p class=wide_small><span class=attention>Ошибка!</span>
Описание баннера не должно быть пустым</p>
<?}?>
<?if($_REQUEST['result']=='wrong_url'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана ссылка (url)</p>
<?}?>
<?if($_REQUEST['result']=='wrong_show_datetime'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указано количество показов баннера</p>
<?}?>
<?if($_REQUEST['result']=='wrong_start_datetime'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана дата начала показов баннера</p>
<?}?>
<?if($_REQUEST['result']=='wrong_mail'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана почта для контроля баннера</p>
<?}?>
<?if($_REQUEST['result']=='wrong_pay_type'){?><p class=wide_small><span class=attention>Ошибка!</span>
Неверно указана система оплаты за показ баннера</p>
<?}?>
<?if($_REQUEST['result']=='too_large_file'){?><p class=wide_small><span class=attention>Ошибка!</span>
Файл очень велик. Разрешена загрузка баннеров не более чем в 300 килобайт.</p>
<?}?>
<?if($_REQUEST['result']=='upload_file_error'){?><p class=wide_small><span class=attention>Ошибка!</span>
Ошибка загрузки файла.</p>
<?}?>
<?if($_REQUEST['result']=='empty_file'){?><p class=wide_small><span class=attention>Ошибка!</span>
Отсутствует файл для загрузки.</p>
<?}?>
<?if($_REQUEST['result']=='error_filetype'){?><p class=wide_small><span class=attention>Внимание!</span>
Изображение аватары может иметь расширение только следующих типов: jpg, gif, png, jpeg.</p>
<?}?>
<?if($_REQUEST['result']=='success'){?><p class=wide_small><span class=success>Поздравляем!</span>
Рассылка была успешно добавлена в очередь, ей присвоен номер в системе <b><?=$_REQUEST['data']?></b>, она ожидает проверки со стороны администрации сайта.
Как только она будет оплачен, будет произведена рассылка текста активным пользователям сайта (кроме тех, кто отказался от приема личных сообщений).
Информация о рекламной рассылке также отправлена на указанный почтовый ящик.
Оплатить рассылку вы можете следующими способами:<br>
- <b>Qiwi</b> (номер <b><?=$qiwi_account?></b>)<br>
- <b>Яндекс-деньги </b> (номер <b><?=$yandex_account?></b>)<br>
При оплате обязательно указывается в комментарии "Оплата счета за рассылку #<?=$_REQUEST['data']?>"<br>
<?if($wm_attestat_status){?>
<a href="?mode=wm_payment&service_mode=M&banner_id=<?=$_REQUEST['data']?>">Оплатить через webmoney в автоматическом режиме</a>
<?}?>
Благодарим за сотрудничество!
C уважением, администрация сайта <?=$sitename?></p>
<?}?>
<p class=wide_small>
Игроки, отказавшиеся от приема личных сообщений, рассылку получать не будут (система предусматрительно не будет отправлять им сообщения).</p>
<br>
<form name=user_register action="request_mailer_controller.php" method=post>
<input type=hidden name=action value=mailer_request>
<table cellspacing="1px" align="center" border=0px>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Текст рассылки (не более 1000 символов)*</p></td>
    <td width=260px align=center class=info_cell><textarea name=description style="width: 240px; height: 200px"></textarea></td>
</tr>
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Ваш email*</p></td>
    <td width=260px align=center class=info_cell>
    <input type=text name=mail class=search_from_element style="width: 240px">
    </td>
</tr>
<!--
<tr style="vertical-align: top">
    <td width=260px class=info_cell><p class=small>Докажи что не робот :)*</p></td>
    <td width=260px align=center class=info_cell>
    <span class=inwork>Семь раз отмерь -  <input type=text name=captcha id="captcha" class=search_from_element style="width: 40px"> отрежь</span></td>
</tr>
-->
<tr style="vertical-align: top">
    <td colspan=2 class=info_cell align=center>
    <button type=submit class=search_from_element style="width: 140px">
    <img src="images/design/money_small.png" style="vertical-align: middle"> Заказать</button></td>
    </tr>
</table>
</form>
<p class=small>Поля, отмеченные *, обязательны для заполнения!</p>
<br>
