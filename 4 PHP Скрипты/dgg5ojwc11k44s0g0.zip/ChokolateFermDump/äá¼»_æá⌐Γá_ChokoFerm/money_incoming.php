<?//гость
if((empty($_SESSION[$session_login])) OR ($_SESSION["user_checker"]!=md5($_SERVER["REMOTE_ADDR"]."fuck you, stupid hacker!"))){
exit;
}
require_once('config.php');?>
<?if(empty($_REQUEST['pay_type'])){?><h1>Пополнить баланс</h1>
<p class=wide_small>Курс игровой валюты: 1 рубль (RUB) = 100 золота.
Сервис ИнтерКасса позволяет автоматически приобрести игровое золото с помощью различных платежных систем в интернете, банковских карт,
SMS, терминалов, денежных переводов и т.д. </p>
<p class=wide_small><b>Автоматическое пополнение</b></p>
<a href="?mode=money_incoming&pay_type=interkassa"><img src="images/design/interkassa.png" border=0px></a>
<?if($wm_attestat_status){?>
<a href="http://www.oplata.info/asp/pay_unit.asp?id_d=1428732"><img src="images/design/webmoney.gif" border=0px></a>
<?}?>
<!--wm_payment&service_mode=G-->
<br>
<p class=wide_small><b>Ручное пополнение (экономия на комиссии):</b></p>
<p class=wide_small>

- <b>Qiwi</b> (номер <b><?=$qiwi_account?></b>)<br>
- <b>Webmoney</b> (номер <b><?=$wmr?></b>)<br>
Ожидание зачисления средств максимум 12 часов.
При оплате в ручном режиме <b>ОБЯЗАТЕЛЬНО</b> указывайте в комментарии ваш логин и цель платежа!
<!--Ru-кошелек для оплаты <b><?=$wmr?></b>--></p>
<?}elseif($_REQUEST['pay_type']=='interkassa'){?>
<h1>Пополнение через Интеркассу</h1>
<p class=wide_small>
Число которое вы вводите считается в долларах. 1 доллар = <?=floor($rub_usd*100)?> золота. ВНИМАНИЕ! При автоматической оплате для корректного зачисления средств необходимо после оплаты
вернуться на сайт игры!</p>
<form name="payment" action="http://www.interkassa.com/lib/payment.php" method="post" target="_top">
<input type="hidden" name="ik_shop_id" value="<?=$interkassa_key?>">
<input type="text"   name="ik_payment_amount" value="">
<input type="hidden" name="ik_payment_id" value="<?=$current_admin_id?>">
<input type="hidden" name="ik_payment_desc" value=" Пополнение баланса золота для покупок">
<input type="hidden" name="ik_paysystem_alias" value="">
<input type="hidden" name="ik_success_method" value="GET">
<input type="hidden" name="ik_success_url" value="http://<?=$sitename?>/payment_controller.php">
<input type="hidden" name="ik_fail_method" value="GET">
<input type="hidden" name="ik_fail_url" value="http://<?=$sitename?>/payment_controller.php">
<input type="hidden" name="ik_status_method" value="GET">
<input type="hidden" name="ik_status_url" value="http://<?=$sitename?>/payment_controller.php">
<input type="hidden" name="ik_baggage_fields" value="игрок <?=$login?>">
<input type="submit" name="process" value="Оплатить">
</form>
<?}?>
<table border="0" width="650" class="levelsTable"  cellspacing=0px>
    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td>Дата</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Сумма, руб</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>Система</td></tr></table></td>
    </tr>
<?
$system[1] = "Интеркасса";
$system[2] = "Яндекс-деньги";
$system[3] = "Мобильный телефон";
$system[4] = "liqpay.com";
$system[5] = "Qiwi-кошелек";
$system[6] = "Webmoney";
$payment_status[0] = "<p class=inwork>запрос вывода принят в обработку</p>";
$payment_status[1] = "<p class=attention>запрос вывода отвергнут</p>";
$payment_status[2] = "<p class=success>вывод средств успешно проведен</p>";

if($_REQUEST['limit']=='no'){
$payment_outcoming_query_text="SELECT * FROM payment_incoming WHERE payment_client_id = $current_admin_id ORDER BY payment_datetime DESC";
}
else {
$payment_outcoming_query_text="SELECT * FROM payment_incoming WHERE payment_client_id = $current_admin_id ORDER BY payment_datetime DESC LIMIT 20";
}
$payment_outcoming_query = mysqli_query($connector, $payment_outcoming_query_text);
while($payment_outcoming_data=mysqli_fetch_assoc($payment_outcoming_query)){
   $payment_datetime    = $payment_outcoming_data['payment_datetime'];
   $payment_stat        = $payment_outcoming_data['payment_stat'];
   $payment_system_id   = $payment_outcoming_data['payment_system_id'];
   $payment_summ        = $payment_outcoming_data['payment_summ'];
   $payment_type        = $payment_outcoming_data['payment_type'];
?>

    <tr align="center">
        <td width=130px><table class="levelsTableCell" border=0px><tr><td><?=$payment_datetime?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$payment_summ?></td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><span class=small><?=$system[$payment_type]?></span></td></tr></table></td>
    </tr>
<?}?>
</table>
