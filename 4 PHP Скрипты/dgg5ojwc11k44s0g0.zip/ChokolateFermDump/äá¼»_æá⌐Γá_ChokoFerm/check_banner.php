<h1>Баннеры</h1>
<?
if(intval($banner_id)>0){?>

<?}
$banners_query_text="SELECT * FROM banners WHERE banner_id = $banner_id";
$banners_query=mysqli_query($connector, $banners_query_text);
$banners_count=mysqli_num_rows($banners_query);
if($banners_count==0){?>
<span class=attention>Баннер с данным номером не найден!</span>
<?}
else{
?>
<?
$system[1] = "Webmoney";
$system[2] = "Яндекс-деньги";
$system[3] = "Мобильный телефон";
$system[4] = "liqpay.com";
$system[5] = "Qiwi-кошелек";
$banner_status[0] = "<p class=inwork>баннер взят на проверку</p>";
$banner_status[1] = "<p class=attention>баннер отвергнут</p>";
$banner_status[2] = "<p class=success>баннер успешно принят к показу</p>";
while($banners_data=mysqli_fetch_assoc($banners_query)){
   $start_datetime    = $banners_data['start_datetime'];
   $end_datetime      = $banners_data['end_datetime'];
   $show_datetime     = $banners_data['show_datetime'];
   $mail              = $banners_data['mail'];
   $url               = $banners_data['url'];
   $file              = $banners_data['file'];
   $description       = $banners_data['description'];
   $pay_type          = $banners_data['pay_type'];
   $counter           = $banners_data['counter'];
   $banner_id         = $banners_data['banner_id'];
   $stat              = $banners_data['stat'];
   $pay_stat          = $banners_data['pay_stat'];
//payment_client_id
?>
<img src='<?="images/banners/".$file?>'>
<br>
<a href="?mode=wm_payment&banner_id=<?=$banner_id?>&service_mode=B" class="minilink">Оплатить баннер</a>
<table border="0" class="levelsTable"  cellspacing=0px>

    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Начала показа</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=rus_calendar($start_datetime)?><br></td></tr></table></td>
</tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Окончания показа</td></tr></table></td>
         <td><table class="levelsTableCell" border=0px><tr><td><?=rus_calendar($end_datetime)?></td></tr></table></td>
</tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Период показа, дней</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$show_datetime?></td></tr></table></td>
</tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Статус</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td>
          <?if($pay_stat=='1'){?> <span class=success>Оплачен</span><?} else {?><span class=attention>Не оплачен</span><?}?>
         / <?if($stat=='1'){?> <span class=success>Показывается</span><?} else {?><span class=attention>Не показывается</span><?}?>
         </td></tr></table></td>
    </tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Показов</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$counter?></td></tr></table></td>
</tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>URl</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$url?></td></tr></table></td>

    </tr>
    <tr align="center">
        <td><table class="levelsTableCell" border=0px><tr><td>Описание</td></tr></table></td>
        <td><table class="levelsTableCell" border=0px><tr><td><?=$description?></td></tr></table></td>
    </tr>
</table>
<?}?>

<?}?>