<?
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("current_settings.php");
require_once ("config.php");
$mailer_count   = intval($_REQUEST['mailer_count']);
$pay_stat       = intval($_REQUEST['pay_stat']);
$stat           = intval($_REQUEST['stat']);
$mail_id        = intval($_REQUEST['mail_id']);
$action         = htmlspecialchars($_REQUEST['action']);
$pay_type       = intval($_REQUEST['pay_type']);
$mail           = htmlspecialchars($_REQUEST['mail']);
$error          = "";
$captcha        = htmlspecialchars($_REQUEST['captcha']);
$description    = htmlspecialchars($_REQUEST['description']);
$mail_id        =  mysqli_real_escape_string($connector,$mail_id);
$pay_type       =  mysqli_real_escape_string($connector,$pay_type);
$mail           =  mysqli_real_escape_string($connector,$mail);
$description    =  mysqli_real_escape_string($connector,$description);

//проверки
//заполнены ли все поля
//является ли баннер подходящим по пропорциям
//форма оплаты
//возвращать после добавления баннера на проверку id баннера

if($action=="mailer_request"){
  /*
      if($captcha!="один")
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_captha");
        exit;
      }
      */
      if(empty($description))
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_description");
        exit;
      }

      if(!preg_match("/^([a-z0-9_\.-]+)@([a-z0-9_\.-]+)\.([a-z\.]{2,6})$/",$mail))
      {
        header("Location: ".$_SERVER['HTTP_REFERER']."&result=wrong_mail");
        exit;
      }
            $insert_mailer_query_text="INSERT INTO mailer (description, mail, stat, start_datetime,	pay_stat, pay_type)
            VALUES ('$description', '$mail', 0, NOW(), 0, $pay_type)";
            $insert_mailer_query=mysqli_query($connector, $insert_mailer_query_text);
            $last_mail_id = mysqli_insert_id($connector);
            $settings_query_text="SELECT mailer_price FROM settings";
            $settings_query=mysqli_query($connector, $settings_query_text);
            while($settings=mysqli_fetch_assoc($settings_query)){
            $mailer_price = $settings['mailer_price'];
            }
            $reg_time=date("Y-m-d (H:i:s)",time());
            $headers2 .= "Content-Type: text/html  charset=utf-8\r\n";
            $headers2 .= "Date: ".date("Y-m-d (H:i:s)",time())."\r\n";
            $headers2 .= "From: \"Администрация сайта $sitename\r\n";
            @mail("$mail","Вы заказали рекламную рассылку на сайте $sitename","Уведомление!<br>
            Вы заказали рекламную рассылку на сайте $sitename. Если это письмо пришло по ошибке, удалите его.
            Стоимость рассылки составляет $mailer_price рублей.
            При оплате рассылки вручную укажите в комментарии к счету
            Как только рассылка будет оплачена, она будет произведена в течение 3 часов.
            <br>Добро пожаловать на сайт <a href='http://$sitename'>$sitename</a>","$headers2");
          	$error.=mysqli_error($connector);
          	if(empty($error)){
          		    header("Location: ".$_SERVER['HTTP_REFERER']."&result=success&data=".$last_mail_id."&pay_type=".$pay_type);
                      }
          		else {
                      die("Ошибка: ".$error);
                      }
}
//message_id 	message_from 	message_to 	message_to_stat 	message_from_stat 	date_sent 	date_received 	message_content
if($action=="send_mailer"){
if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
  if(($mail_id>0) AND ($mailer_count>0) AND ($mailer_count<=10000)){
      $get_mailer_data_query_text = "SELECT description FROM mailer WHERE mailer_id=$mail_id";
      $get_mailer_data_query = mysqli_query($connector, $get_mailer_data_query_text);
        while($get_mailer_data=mysqli_fetch_assoc($get_mailer_data_query)){
      $description = $get_mailer_data['description'];
      }
      $description = "<b style='color: red; font-size: 18px'>Реклама</b><br>".$description;
      $description = mysqli_real_escape_string($connector, $description);
      $select_valid_clients_query_text = "SELECT client_id FROM clients WHERE active_message = 0 ORDER BY rand() LIMIT $mailer_count";
      $select_valid_clients_query = mysqli_query($connector, $select_valid_clients_query_text);
      while($select_valid_clients_data=mysqli_fetch_assoc($select_valid_clients_query)){
      $select_valid_clients[]  = $select_valid_clients_data['client_id'];
      }
      $select_sended_clients_query_text = "SELECT client_id FROM client_mailer WHERE mailer_id = $mail_id";
      $select_sended_clients_query = mysqli_query($connector, $select_sended_clients_query_text);
      while($select_sended_clients_data=mysqli_fetch_assoc($select_sended_clients_query)){
      $select_sended_clients[]  = $select_sended_clients_data['client_id'];
      }
      if(count($select_sended_clients)>0){
      $result_clients = array_diff($select_valid_clients, $select_sended_clients);
      }
      else $result_clients = $select_valid_clients;
     $x=0;
      while($x<count($result_clients)){
        $current_mailer_client = $result_clients[$x];
               $send_mailer_query_text="INSERT INTO messages (message_from, message_to, message_to_stat,
               message_from_stat, date_sent, message_content)
               VALUES(0, $current_mailer_client, 0, 0, NOW(), '$description')";
               $send_mailer_query = mysqli_query($connector, $send_mailer_query_text);
               $insert_client_mailer_query_text="INSERT INTO client_mailer (client_id, mailer_id) VALUES($current_mailer_client, $mail_id)";
               $insert_client_mailer_query = mysqli_query($connector, $insert_client_mailer_query_text);
    $x++;
      }
               header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
    }
}
if($action=="edit_mailer"){
  if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
  if(($mail_id>0) AND (!empty($description))){

      $edit_mailer_query_text = "UPDATE mailer SET description='$description' WHERE mailer_id = $mail_id";
      $edit_mailer_query = mysqli_query($connector, $edit_mailer_query_text);
      header("Location: ".$_SERVER['HTTP_REFERER']);
      exit;
  }
}
if($action=="edit_pay_stat"){
if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
           $update_banner_query_text="UPDATE mailer SET pay_stat=$pay_stat WHERE mailer_id=$mail_id";
           $update_new_banner_query = mysqli_query($connector, $update_banner_query_text);
           header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
}
if($action=="edit_stat"){
if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
           $update_banner_query_text="UPDATE mailer SET stat=$stat WHERE mailer_id=$mail_id";
           $update_new_banner_query = mysqli_query($connector, $update_banner_query_text);
           header("Location: ".$_SERVER['HTTP_REFERER']."&result=success");
}
if($action=="delete_mailer"){
if($_SESSION["admin_mode"]!=md5($_SERVER["REMOTE_ADDR"]."admin_mode")){
die("<script>window.location='admin_init.php';</script>");
}
  if(($mail_id>0) and ($mail_id<9999)){
           $update_banner_query_text="DELETE FROM mailer WHERE mailer_id=$mail_id";
           $update_new_banner_query = mysqli_query($connector, $update_banner_query_text);
           header("Location: ".$_SERVER['HTTP_REFERER']);
  }
}
?>