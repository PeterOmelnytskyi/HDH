<h1>Управление акциями проекта</h1>
<?
$action_id = $_REQUEST['action_id'];
if(empty($action_id)){
$news_query=mysqli_query($connector, "SELECT * FROM actions ORDER BY add_date DESC");?>
<table border=0px width=990px>
<?while($news_data=mysqli_fetch_assoc($news_query)){
                $action_id    = $news_data['action_id'];
                $action_text  = $news_data['action_text'];
                $add_date     = $news_data['add_date'];
                $action_name  = $news_data['action_name'];?>
<tr>
    <td><a href="adminka.php?mode=admin_action&action_id=<?=$action_id?>" class=minilink><b><?=$action_name?></b></a></td>
    <td width=350px><p class=small>акция опубликована: <b><?=rus_calendar($add_date)?></b></p>
    <a href="admin_action_form.php?action=delete_action&action_id=<?=$action_id?>" class="minilink"><span class=attention>удалить акцию</span></a></td>
</tr>
<tr height=20px>
    <td colspan=2><p class=small><?=$action_text?></p></td>
</tr>
<? }
?>
</table>
<h1>Добавить акцию</h1>
<form action=admin_action_form.php method=post>
<input type=hidden name=action value="add_action">
<p class=small><b>Введите название акции</b></p>
<input type=text name=action_name value="" style="width:430px">
<p class=small><b>Введите текст акции</b></p>
<textarea name=action_text cols=50 rows=4></textarea><br>
<input type=submit value="Отправить">
</form>
<?}else{
$news_query=mysqli_query($connector, "SELECT * FROM actions WHERE action_id = $action_id");?>
<table border=0px width=990px>
<?while($news_data=mysqli_fetch_assoc($news_query)){
                $action_id    = $news_data['action_id'];
                $action_text  = $news_data['action_text'];
                $add_date     = $news_data['add_date'];
                $action_name  = $news_data['action_name'];?>
<tr>
    <td><p class=small><b><?=$action_name?></b></p></td>
    <td width=350px><p class=small>акция опубликована: <b><?=rus_calendar($add_date)?></b></p></td>
</tr>
<tr height=20px>
    <td colspan=2><p class=small><?=$action_text?></p></td>
</tr>
<? }
?>
</table>
<h1>Редактировать акцию</h1>
<form action=admin_action_form.php method=post>
<input type=hidden name=action value="add_action">
<input type=hidden name=action_id value="<?=$action_id?>">
<p class=small><b>Введите название акции</b></p>
<input type=text name=action_name value="<?=htmlspecialchars($action_name)?>" style="width: 430px">
<p class=small><b>Введите текст акции</b></p>
<textarea name=action_text cols=50 rows=4><?=$action_text?></textarea><br>
<input type=submit value="Отправить"> <a href="admin_action_form.php?action=delete_action&action_id=<?=$action_id?>" class="minilink">
<span class=attention>удалить акцию</span></a>
</form>

<?}?>