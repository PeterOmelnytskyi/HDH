<?
$message_page = intval($_REQUEST['message_page']);
$ref_counter=0;
$select_refs_count=mysqli_query($connector, "SELECT count(*) AS counter FROM chat INNER JOIN clients WHERE clients.client_id = chat.client_id AND
clients.client_stat>=1 AND chat.message_stat>0");
while($ref_data=@mysqli_fetch_assoc($select_refs_count)){
  $ref_counter  = $ref_data['counter'];
  }
if(empty($message_page)) $message_page=1;
if(empty($show_ref_count)) $show_ref_count=10;
$page_count=floor($ref_counter/$show_ref_count);
$limit_start=($message_page-1)*$show_ref_count;
$limit_count=$show_ref_count;
?>
<h1>Форум</h1>
<p class=wide_small>В чате игроки могут общаться, их сообщения могут увидеть все участники проекта и даже не зарегистрированные пользователи.
<b><br>Стоимость одного сообщения - <?=$apples_per_message?> золота для вывода
<img src="images/design/coins.png" width=25px style="vertical-align: bottom">.</b>
Интервал отправки сообщений в чате - <b>1 минута</b>
</p>
<?if($_REQUEST['chat_error']=='not_enough_gold'){?><p class=wide_small><span class=attention>Внимание!</span>
У вас недостаточно золота для вывода для отправки сообщений в чате!</p><?}?>
<table>
<?
$chat_query=mysqli_query($connector, "SELECT *, chat.add_date AS message_add_date FROM chat INNER JOIN clients WHERE clients.client_id = chat.client_id AND
clients.client_stat>=1 AND chat.message_stat>0 ORDER BY chat.add_date DESC LIMIT $limit_start, $limit_count");
while($chat_data=@mysqli_fetch_assoc($chat_query)){
                $chat_client_id = $chat_data['client_id'];
                $chat_login = $chat_data['login'];
                $chat_message_text=$chat_data['message_text'];
                $chat_add_date=$chat_data['message_add_date'];
                $chat_avatar=$chat_data['client_avatar'];?>
<tr height=20px class=chat_row>
    <td class=chat_cell width=120px><a class=minilink href="?mode=client_profile&client_id=<?=$chat_client_id?>" <?if($chat_client_id==1){echo "style='color: red'";}?>><?=$chat_login?></a></td>
    <td class=chat_cell width=520px><p class=small><?=$chat_add_date?></p></td>
</tr>
<tr height=80px style="vertical-align: top" class=chat_row>
    <td class=chat_cell><?if(!empty($chat_avatar)){?>
<img src="<?=$avatar_path.$chat_avatar?>" style="max-height: 100px; max-width: 120px; min-height: 50px;">
<?}?></td>
    <td class=chat_cell><p class=small><?
    $message = substr(htmlspecialchars($chat_message_text),0, 1500);
    $current_message_text=preg_replace("#(https?|ftp)://\S+[^\s.,>)\];'\"!?]#",'<a class=minilink href="\\0">\\0</a>',$message);
    echo $current_message_text;
    ?>
    </p></td>
</tr>
<? } ?>
</table>
<div style="margin: 0px auto; width: 320px;"><span class=small>Страницы:</span>
<?if($message_page!=1){?>
<a class="microlink" href="?mode=chat&message_page=1"><<</a>
<?}?>
<?while ($u<=$page_count+1){?>
<a class="microlink" href="?mode=chat&message_page=<?=$u?>" <?if($message_page==$u) {?> style="text-decoration: underline" <?}?>><?=$u?></a>
<? $u++;}?>
<?if($message_page!=$page_count+1){?>
<a class="microlink" href="?mode=chat&message_page=<?=$page_count+1?>">>></a>
<?}?>
</div>
<?//гость
if($current_client_gold>=$apples_per_message){?>
<p class=wide_small>
<span class=attention>Важно!</span> В чате запрещены: реклама и публикация ссылок, СПАМ, мат, расизм, оскорбления, агитация против проекта, клевета и т.п.
Штраф: БАН аккаунта навсегда!
</p>
<br>
<form action=chat_form.php method=get>
<input type=hidden name=action value="add_message">
<p class=small><b>Введите сообщение</b></p>
<table>
<tr>
    <td><textarea name=message_text cols=58 rows=8 id=chat_messager></textarea></td>
</tr>
</table>
<input type=submit value="Отправить">
</form>
<?}
elseif($current_client_gold<$apples_per_message){
?>
<p class=wide_small>
У вас не хватает золота для отправки сообщений в чате! Стоимость сообщения - <?=$apples_per_message?> <img src="images/design/coins.png" width=25px style="vertical-align: bottom">
</p>
<?}?>