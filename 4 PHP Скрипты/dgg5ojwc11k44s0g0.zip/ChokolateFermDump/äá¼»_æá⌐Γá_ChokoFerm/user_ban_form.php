<?php
session_start();
require_once ("dbconnect.php");
require_once ("functions.php");
require_once ("setup.php");
$action     = $_REQUEST['action'];
$user_id    = $_REQUEST['user_id'];
$years      =   $_REQUEST['years'];
$days       =   $_REQUEST['days'];
$hours      =   $_REQUEST['hours'];
$minutes    =   $_REQUEST['minutes'];
$ban_couse  =   $_REQUEST['ban_couse'];

if ((empty($_SESSION["admin_log"])) OR (empty($_SESSION["admin_pass"])))
	{
		die("<script>window.location='admin_init.php';</script>");
	}
if ($mode=="logout")
	{
		$_SESSION["admin_log"] = "";
		$_SESSION["admin_pass"] = "";
		unset($_SESSION["admin_log"]);
		unset($_SESSION["admin_pass"]);
        session_destroy();
		die("<script>window.location='access_admin.php';</script>");
	}


	if($action=="user_ban")
	{
        if(($years==0)&&($days==0)&&($hours==0)&&($minutes==0)) $error.="Время бана игрока не может быть менее одной минуты<br>";

		if(!empty($error))
		{
			echo "Произошли следующие ошибки: ".$error."<br><a href='adminka.php?mode=users'>вернуться обратно</a>";
			die();
		}
        if(($days==0)&&($hours==0)&&($minutes==0)){
              $user_ban_query_text="INSERT INTO user_ban_list (ban_start, ban_end, user_id, ban_couse)
              VALUES (NOW(), CAST(DATE_ADD(NOW(), INTERVAL $years year) AS DATETIME), $user_id, '$ban_couse')";
              $user_ban_query = mysqli_query($connector, $user_ban_query_text);
        }
        else
        {
    		$user_ban_query_text="INSERT INTO user_ban_list (ban_start, ban_end, user_id, ban_couse)
            VALUES (NOW(), CAST(DATE_ADD(NOW(), INTERVAL \"$days' '$hours':'$minutes':00'\" DAY_SECOND) AS DATETIME), $user_id, '$ban_couse')";
            $user_ban_query = mysqli_query($connector, $user_ban_query_text);
            if($years>0){
              $get_las_ubid=mysqli_insert_id($connector);
            $user_ban2_query_text="UPDATE user_ban_list SET ban_end = CAST(DATE_ADD(ban_end, INTERVAL $years year) AS DATETIME)
            WHERE user_ban_id = $get_las_ubid";
            $user_ban2_query = mysqli_query($connector, $user_ban2_query_text);
        }
        }
		$error.=mysqli_error($connector);

		if(empty($error)){
			header("Location: adminka.php?mode=users&user_id=".$user_id."&result=user_banned");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
	if($action=="delete_ban")
	{
       	$delete_ban_query_text="DELETE FROM user_ban_list WHERE user_id=$user_id";
        $delete_ban_query = mysqli_query($connector, $delete_ban_query_text);
		$error.=mysqli_error($connector);

		if(empty($error)){
			header("Location: adminka.php?mode=users&user_id=".$user_id."&result=user_banned");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
    	if($action=="full_delete")
	{
	    if($user_id>0){
       	$delete_autoreferal_query_text="DELETE FROM autoreferal WHERE client_id=$user_id";
        $delete_autoreferal_query = mysqli_query($connector, $delete_autoreferal_query_text);
		$error.=mysqli_error($connector);
        $delete_balance_actions_query_text="DELETE FROM balance_actions WHERE client_id=$user_id";
        $delete_balance_actions_query = mysqli_query($connector, $delete_balance_actions_query_text);
		$error.=mysqli_error($connector);
        $delete_chat_query_text="DELETE FROM chat WHERE client_id=$user_id";
        $delete_chat_query = mysqli_query($connector, $delete_chat_query_text);
		$error.=mysqli_error($connector);
        $delete_client_combines_query_text="DELETE FROM client_combines WHERE client_id=$user_id";
        $delete_client_combines_query = mysqli_query($connector, $delete_client_combines_query_text);
		$error.=mysqli_error($connector);
        $delete_payment_outcoming_query_text="DELETE FROM payment_outcoming WHERE payment_client_id=$user_id";
        $delete_payment_outcoming_query = mysqli_query($connector, $delete_payment_outcoming_query_text);
		$error.=mysqli_error($connector);
        $delete_payment_incoming_query_text="DELETE FROM payment_incoming WHERE payment_client_id=$user_id";
        $delete_payment_incoming_query = mysqli_query($connector, $delete_payment_incoming_query_text);
		$error.=mysqli_error($connector);
        $delete_trees_query_text="DELETE FROM trees WHERE client_id=$user_id";
        $delete_trees_query = mysqli_query($connector, $delete_trees_query_text);
		$error.=mysqli_error($connector);
        $delete_ip_list_query_text="DELETE FROM ip_list WHERE admin_id=$user_id";
        $delete_ip_list_query = mysqli_query($connector, $delete_ip_list_query_text);
		$error.=mysqli_error($connector);
        $delete_clients_query_text="DELETE FROM clients WHERE client_id=$user_id";
        $delete_clients_query = mysqli_query($connector, $delete_clients_query_text);
		$error.=mysqli_error($connector);
        }
		if(empty($error)){
			header("Location: adminka.php?mode=users");
			}
		else echo "Произошли следующие ошибки: ".$error;
	}
?>