<?php
	$dbhost = 'localhost';
	$dbuser = 'dbuser';
	$dbpass = 'dbpass';
	$dbname = 'dbname';
?>