<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

define("IN_SITE", 1);
require_once 'brain.php';

/* [ Seguran�a ] */
checkUserLoggedOff();

/* [ Defini��es ] */
define("IN_TAB", "widget-tab", true);
define("WIDGET_SIZE", $Session_Engine->getUserWidget(USER_USERNAME, "SIZE"), true);
define("WIDGET_BACKGROUND_COLOR", $Session_Engine->getUserWidget(USER_USERNAME, "BACKGROUND"), true);
define("WIDGET_FOREGROUND_COLOR", $Session_Engine->getUserWidget(USER_USERNAME, "FOREGROUND"), true);
define("WIDGET_HEIGHT", $Session_Engine->getUserWidget(USER_USERNAME, "HEIGHT"), true);
define("WIDGET_WIDTH", $Session_Engine->getUserWidget(USER_USERNAME, "WIDTH"), true);

$up_widget['size'] = $_POST["size"];
$up_widget['bgcolor'] = $_POST["bgcolor"];
$up_widget['fgcolor'] = $_POST["fgcolor"];

/* Livre para Edi��o */
$iframe['border'] = 0; 
$iframe['scroller'] = "no";
$iframe['border_style'] = "none";

/* [ A��es ] */
if($_SERVER['REQUEST_METHOD'] == "POST"){ $Session_Engine->updateUserWidget($up_widget['size'], $up_widget['bgcolor'], $up_widget['fgcolor']); }else{}

/* [ Par�metros ] */
$Session_Template->setParameter("serializeTabs", $Session_Engine->serialize_SeetingsTabs(''.IN_TAB.''), true);
$Session_Template->setParameter("widgetCode", '&lt;iframe src=&quot;http://'.SITE_DOMAIN.'/widget/'.USER_USERNAME.'?size='.WIDGET_SIZE.'&amp;bgcolor='.WIDGET_BACKGROUND_COLOR.'&amp;fgcolor='.WIDGET_FOREGROUND_COLOR.'&quot; frameborder=&quot;'.$iframe['border'].'&quot; scrolling=&quot;'.$iframe['scroller'].'&quot; width=&quot;'.WIDGET_WIDTH.'&quot; height=&quot;'.WIDGET_HEIGHT.'&quot; style=&quot;border:'.$iframe['border_style'].';&quot;&gt;&lt;a href=&quot;http://'.SITE_DOMAIN.'/'.USER_USERNAME.'&quot;&gt;http://'.SITE_DOMAIN.'/'.USER_USERNAME.'&lt;/a&gt;&lt;/iframe&gt;', false);

/* [ P�gina HTML -> Sa�da ] */
$Session_Template->loadHeaderHtml();
$Session_Template->writeLine("<head>"); 
$Session_Template->setTitle($Session_Template->getLang(103));
$Session_Template->setBase(); 
$Session_Template->loadHeaderMetas();
$Session_Template->loadIcon();
$Session_Template->loadHeaderCSS("settings-widget");
$Session_Template->loadHeaderJS();
$Session_Template->loadHeaderJS("color-picker"); // Mostra Palheta de Cores
$Session_Template->writeLine("</head>"); 
$Session_Template->writeLine("<body>");
$Session_Template->loadLogo();
$Session_Template->loadMenu();
$Session_Template->writeLine('<div class="clear"></div></div>');
$Session_Template->loadTpl("acc_widget");
$Session_Template->loadTpl("footer");
$Session_Template->loadOutput();
?>