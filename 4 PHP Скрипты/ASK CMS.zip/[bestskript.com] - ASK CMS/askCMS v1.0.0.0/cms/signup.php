<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

define("IN_SITE", 1);
require_once 'brain.php';

/* [ Seguran�a ] */
checkUserLoggedIn();

/* [ Defini��es ] */
$signUp["username"] = filterText(ucfirst(strtolower($_POST["username"])));
$signUp["password"] = filterText(strtolower($_POST["password"]));
$signUp["name"] = filterText(ucfirst(strtolower($_POST["name"])));
$signUp["surname"] = filterText(ucfirst(strtolower($_POST["surname"])));
$signUp["email"] = filterText(strtolower($_POST["email"]));

/* [ A��es ] */
if($_SERVER['REQUEST_METHOD'] == "POST"){ $Session_Engine->createUserAccount($signUp["username"], $signUp["password"], $signUp["name"], $signUp["surname"], $signUp["email"]); }
	
/* [ P�gina HTML -> Sa�da ] */
$Session_Template->loadHeaderHtml();
$Session_Template->writeLine("<head>"); 
$Session_Template->setTitle($Session_Template->getLang(114));
$Session_Template->setBase(); 
$Session_Template->loadHeaderMetas();
$Session_Template->loadIcon();
$Session_Template->loadHeaderCSS("signup");
$Session_Template->loadHeaderJS();
$Session_Template->writeLine("</head>"); 
$Session_Template->writeLine("<body>");
$Session_Template->loadLogo();
$Session_Template->loadMenu();
$Session_Template->writeLine('<div class="clear"></div></div>');
$Session_Template->loadTpl("signup");
$Session_Template->loadTpl("footer");
$Session_Template->loadOutput();
?>
