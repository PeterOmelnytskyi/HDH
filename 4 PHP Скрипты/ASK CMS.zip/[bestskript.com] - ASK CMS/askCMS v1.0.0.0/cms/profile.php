<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

define("IN_SITE", 1);
require_once 'brain.php';

/* [ Seguran�a ] - Seguran�a n�o � necess�ria aqui. */

/* [ Defini��es ] */
$get["data"] = "STATUS";

define("PROFILE_USER", filterText(ucfirst(strtolower($_GET["user_profile"]))), true);
define("PROFILE_WHAT_ASK", $Session_Engine->getUserData(PROFILE_USER, "WHAT_ASK"), true);
define("PROFILE_PHOTO", $Session_Engine->getUserData(PROFILE_USER, "PHOTO"), true);
define("PROFILE_REAL_NAME", $Session_Engine->getUserData(PROFILE_USER, "REAL_NAME"), true);
define("PROFILE_REAL_SURNAME", $Session_Engine->getUserData(PROFILE_USER, "REAL_SURNAME"), true);
define("PROFILE_LOCAL", $Session_Engine->getUserData(PROFILE_USER, "LOCALIZATION"), true);
define("PROFILE_WEB", $Session_Engine->getUserData(PROFILE_USER, "WEBSITE"), true);
define("PROFILE_BIO", $Session_Engine->getUserData(PROFILE_USER, "BIO"), true);
define("PROFILE_ANONYMOUS", $Session_Engine->getUserData(PROFILE_USER, "A_VIEW"), true);
define("PROFILE_ANSWERED_QUESTIONS", $Session_Engine->inboxQuestions(''.PROFILE_USER.'', 1), true);

/* [ Par�metros ] */
if($Session_Engine->profileUserExists(''.PROFILE_USER.'') != 0) { $result["userExists"] = true; } else { $result["userExists"] = false; }
if($Session_Engine->getUserData(''.PROFILE_USER.'', $get["data"]) != 0) { $result["userStatus"] = true; } else { $result["userStatus"] = false; }
if($Session_Engine->getUserData(''.PROFILE_USER.'', "A_VIEW") == 0 && SESSION_STATUS == false) { $result["userView"] = true; } else { $result["userView"] = false; }
$Session_Template->setParameter("serializeProfileQA", $Session_Engine->serializeProfileQA(''.PROFILE_USER.''), true);

/* [ P�gina HTML -> Sa�da ] */
// Checar se usu�rio Existe
if($result["userExists"] != false)
{
	// Proibindo Acesso �s Pastas
	if(PROFILE_USER == "Css" || PROFILE_USER == "Images" || PROFILE_USER == "Js" || PROFILE_USER == "Housemanager" || PROFILE_USER == "Core")
	{
		// Redirecionando para P�gina de Erro
		header('Location: http://'.SITE_DOMAIN.'/site/error');
	}
	// Checa Status do Usu�rio <Desativado ou Ativado>
	else if($result["userStatus"] != false)
	{
		$Session_Template->loadHeaderHtml();
		$Session_Template->writeLine("<head>");
		$Session_Template->setTitle(''.PROFILE_USER.' - ('.PROFILE_REAL_NAME.' '.PROFILE_REAL_SURNAME.')');
		$Session_Template->setBase();
		$Session_Template->loadHeaderMetas();
		$Session_Template->loadIcon();
		$Session_Template->loadHeaderCSS("profile");
		$Session_Template->loadHeaderJS();
		$Session_Template->writeLine("</head>");
		$Session_Template->writeLine("<body>");
		$Session_Template->loadLogo();
		$Session_Template->loadMenu();
		$Session_Template->writeLine('<div class="clear"></div></div>');
		
		// Checar se Usu�rio Aceita An�nimos visitando seu Perfil
		if($result["userView"] != false)
		{
			// Carrega P�gina para Conex�o
			$Session_Template->writeLine('<center>');
			$Session_Template->loadTpl("security");
			$Session_Template->writeLine('</center>');
		}
		else
		{
			// Carrega Perfil do Usu�rio
			$Session_Template->loadTpl("profile");
		}
		
		$Session_Template->loadTpl("footer");
		$Session_Template->loadOutput();
	}
	else
	{
		// O usu�rio encontra-se desativado, redirecionando para P�gina
		header('Location: http://'.SITE_DOMAIN.'/site/disabled');
	}
}
// Usu�rio infelizmente n�o existe.
else
{
	// Redirecionando para P�gina de Erro
	header('Location: http://'.SITE_DOMAIN.'/site/error');
}
?>