Event.observe(window, "load", function () {
    setQuestionObservers();
    setCommentObservers();
});


function removeResponse(id) {
    $("question" + id).addClassName("highlightRed");
    if (!confirm("Are you sure you want to remove your response?  The question will go back into your Inbox.")) {
        $("question" + id).removeClassName("highlightRed");
        return;
    }
    $("removeResponse" + id + "Indicator").show();
    new(Ajax.Request)(baseHREF() + "ajax/removeResponse", {
        parameters: {
            ajax: 1,
            id: id
        }, onSuccess: function (_b) {
            var _14 = jsonParse(_b);
            if (!_14) {
                return;
            }
            var _15 = _14.get("error");
            var _16 = _14.get("deleted");
            if (_15) {
                ajaxFailure(_15);
                $("removeResponse" + id + "Indicator").hide();
            } else {
                Effect.Fade("question" + _16, {
                    afterFinish: function (e) {
                        Element.remove(e.element);
                        var _d = parseInt($("inboxCount").innerHTML);
                        $("inboxCount").innerHTML = _d + 1;
                    }
                });
            }
        }, onFailure: function (_e) {
            ajaxFailure(_e);
            $("removeResponse" + id + "Indicator").hide();
        }
    });
}


function removeComment(id) {
    $("comment" + id).addClassName("highlightRed");
    if (!confirm("Are you sure you want to remove this comment? It will be deleted permanently.")) {
        $("comment" + id).removeClassName("highlightRed");
        return;
    }
    $("removeComment" + id + "Indicator").show();
    new(Ajax.Request)(baseHREF() + "ajax/removeComment", {
        parameters: {
            ajax: 1,
            id: id
        }, onSuccess: function (_b) {
            var _14 = jsonParse(_b);
            if (!_14) {
                return;
            }
            var _15 = _14.get("error");
            var _16 = _14.get("deleted");
            if (_15) {
                ajaxFailure(_15);
                $("removeComment" + id + "Indicator").hide();
            } else {
                Effect.Fade("comment" + _16);
                var _c = parseInt($("commentCount").innerHTML);
                $("commentCount").innerHTML = _c - 1;
            }
        }, onFailure: function (_e) {
            ajaxFailure(_e);
            $("removeComment" + id + "Indicator").hide();
        }
    });
}


function setQuestionObservers() {
    $$(".question").each(function (_f) {
        Event.observe(_f, "mouseover", function (e) {
            _f.select(".removeResponseLink").invoke("show");
        });
        Event.observe(_f, "mouseout", function (e) {
            _f.select(".removeResponseLink").invoke("hide");
        });
    });
}

function setCommentObservers() {
    $$(".commentbox").each(function (_f) {
        Event.observe(_f, "mouseover", function (e) {
            _f.select(".removeCommentLink").invoke("show");
        });
        Event.observe(_f, "mouseout", function (e) {
            _f.select(".removeCommentLink").invoke("hide");
        });
    });
}

function ajaxFailure(_6) {
    alert("There was an error processing the request: " + _6);
}


function jsonParse(_7) {
    var _8 = _7.responseText.evalJSON(true);
    if (!_8) {
        ajaxFailure(_7);
        return false;
    }
    _8 = $H(_8);
    return _8;
}