Event.observe(window, "load", function () {
    Event.observe("query", "keypress", function (e) {
        if (e.keyCode == Event.KEY_RETURN) {
            search();
        }
    });
});

function search() {
    var _2 = $F("query").replace(/^\s*/, "").replace(/\s*$/, "");
    if (!_2.match(/\w/) || _2.length < 3) {
        $("query").addClassName("highlightRed");
        return;
    }
    $("query").removeClassName("highlightRed");
    getResults($F("query"), 1, $F("searchtype"));
};

function getResults(_3, _4, _5) {
    $("searchIndicator").show();
    $("query").scrollTo();
    new Ajax.Request(baseHREF() + "ajax/getSearchResults", {
        parameters: {
            ajax: 1,
            searchtype: _5,
            query: _3,
            page: _4
        },
        onSuccess: function (_6) {
            $("searchResults").innerHTML = _6.responseText;
            $("searchResults").show();
            $("searchIndicator").hide();
        },
        onFailure: function (_7) {
            ajaxFailure(_7);
            $("searchIndicator").hide();
        }
    });
};