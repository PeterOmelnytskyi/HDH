function respondQuestion(id) {
    $$(".question").each(

    function (_2) {
        if (_2.id != "question" + id) {
            _2.hide();
        }
    });
    $$(".questionTools").invoke("hide");
    $("question" + id).select(".questionRespond").invoke("show");
    $("question" + id).select(".questionRespondTools").invoke("show");
    $("response" + id).focus();
}


function sendResponse(id) {
    var _14 = $H({
        ajax: 1,
        'id': id,
        'fb_post': $F("fb_post_" + id)
    });
    
    var _17 = $F("response" + id);
    if (_17.match(/\S/)) {
        _14.set("response", _17);
        $("response" + id).removeClassName("highlightRed");
    } else {
        $("response" + id).addClassName("highlightRed");
        return;
    }
    $("sendResponse" + id + "Button").disabled = true;
    $("sendResponse" + id + "Indicator").show();
    new(Ajax.Request)(baseHREF() + "ajax/respond", {
        parameters: _14,
        onSuccess: function (_19) {
            var res = jsonParse(_19);
            if (!res) {
                return;
            }
            var _63 = res.get("error");
            if (_63) {
                alert("There was an error processing the request: " + _63);
                $("sendResponse" + id + "Button").disabled = false;
                $("sendResponse" + id + "Indicator").hide();
                return;
            }
            var _62 = res.get("deleted");
            if (!_62) {
                return;
            }
            $A(_62).each(function (id) {
                $("question" + id).remove();
            });
            var _68 = parseInt($("inboxCount").innerHTML);
            var _69 = _68 - _62.length;
            if (_69 > -1) {
                $("inboxCount").innerHTML = _69;
            }
            if (_69 == 0) {
                $("questions").hide();
                $("inboxEmptyMessage").show();
            }
            respondCancel();
        },
        onFailure: function (_1c) {
            ajaxFailure(_1c);
            $("sendResponse" + id + "Button").disabled = false;
            $("sendResponse" + id + "Indicator").hide();
        }
    });
}


function respondCancel() {
    $$(".questionRespond").invoke("hide");
    $$(".questionRespondTools").invoke("hide");
    $$(".question").invoke("show");
    var _1d = $$(".question").size();
    $$(".questionTools").invoke("show");
}


function deleteQuestion(id) {
    var _4a = $("question" + id);
    _4a.addClassName("warning");
    if (!confirm("Are you sure you want to delete this question? It cannot be undone.")) {
        _4a.removeClassName("warning");
        return;
    }
    $("question" + id + "Indicator").show();
    new(Ajax.Request)(baseHREF() + "ajax/delete", {
        parameters: {
            ajax: 1,
            'id': id,
        },
        onSuccess: function (_6e) {
            var res = jsonParse(_6e);
            if (!res) {
                return;
            }
            var _63 = res.get("error");
            if (_63) {
                alert("There was an error processing the request: " + _63);
                _4a.removeClassName("warning");
                $("question" + id + "Indicator").hide();
                return;
            }
            var _62 = res.get("deleted");
            if (!_62) {
                return;
            }
            $A(_62).each(function (id) {
                $("question" + id).remove();
            });
            var _68 = parseInt($("inboxCount").innerHTML);
            var _69 = _68 - _62.length;
            if (_69 > -1) {
                $("inboxCount").innerHTML = _69;
            }
            if (_69 == 0) {
                $("questions").hide();
                $("inboxEmptyMessage").show();
            }
        },
        onFailure: function (_6f) {
            ajaxFailure(_6f);
        }
    });
}