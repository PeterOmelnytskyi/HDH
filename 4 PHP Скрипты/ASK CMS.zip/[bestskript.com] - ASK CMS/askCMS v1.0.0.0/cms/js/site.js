Event.observe(window, "load", function () {
    if ($("question") && $("question").type.toLowerCase() == "textarea") {
        Event.observe("question", "keyup", function () {
            var _4 = $F("question");
            if (_4.length > 255) {
                $("question").value = _4.substring(0, 255);
            }
        });
    }
});

function noCacheParam() {
    var _5 = new Date;
    return "&r=" + _5.getTime();
}


function ajaxFailure(_6) {
    alert("There was an error processing the request: " + _6.responseText);
}


function jsonParse(_7) {
    var _8 = _7.responseText.evalJSON(true);
    if (!_8) {
        ajaxFailure(_7);
        return false;
    }
    _8 = $H(_8);
    return _8;
}


function baseHREF() {
    var _9 = $$("base");
    return _9.length ? _9[0].href : "";
}


function redirectToLogout() {
    window.location = baseHREF() + "account/logout";
}


function redirectToAccountSetup() {
    window.location = baseHREF() + "account/setup";
}


function validationError(el, _b) {
    var _c = $(el + "Status");
    if (!_c) {
        return;
    }
    _c.innerHTML = _b;
    _c.removeClassName("validationOK");
    _c.addClassName("validationError");
    return false;
}


function validationOK(el) {
    var _e = $(el + "Status");
    if (!_e) {
        return;
    }
    _e.innerHTML = "";
    _e.removeClassName("validationError");
    _e.addClassName("validationOK");
    return true;
}


function ask(_f) {
    if (!$F("question").match(/\S/)) {
        $("question").addClassName("highlightRed").focus();
        return;
    }
    $("question").removeClassName("highlightRed");
    $("sendButton").disabled = true;
    $("sendIndicator").show();
    var _12 = $H(Form.serialize("askForm", true));
    _12.set("username", _f);
    _12.set("ajax", 1);
    new(Ajax.Request)(baseHREF() + "ajax/ask", {
        parameters: _12,
        onSuccess: function (_13) {
            var _14 = jsonParse(_13);
            if (!_14) {
                return;
            }
            var _15 = _14.get("error");
            if (_15) {
                ajaxFailure(_15);
                $("sendButton").disabled = false;
                $("sendIndicator").hide();
            } else {
                $("askForm").hide();
                $("success").show();
                $("sendButton").disabled = false;
                $("sendIndicator").hide();
            }
        }, onFailure: function (_16) {
            ajaxFailure(_16);
            $("sendButton").disabled = false;
            $("sendIndicator").hide();
        }
    });
}


function askAgain() {
    $("question").value = "";
    $("success").hide();
    $("askForm").show();
    $("question").focus();
}


function addComment(_f) {
    if (!$F("comment").match(/\S/)) {
        $("comment").addClassName("highlightRed").focus();
        return;
    }
    $("comment").removeClassName("highlightRed");
    $("sendButton").disabled = true;
    $("sendIndicator").show();
    var _12 = $H(Form.serialize("commentForm", true));
    _12.set("id", _f);
    _12.set("ajax", 1);
    new(Ajax.Request)(baseHREF() + "ajax/comment", {
        parameters: _12,
        onSuccess: function (_13) {
            var _14 = jsonParse(_13);
            if (!_14) {
                return;
            }
            var _15 = _14.get("error");
            var _16 = _14.get("html");

            if (_15) {
                ajaxFailure(_15);
                $("sendButton").disabled = false;
                $("sendIndicator").hide();
            } else {
                $("commentslist").innerHTML = $("commentslist").innerHTML + _16;
                Effect.Appear("commentslist", {
                    afterFinish: function (e) {
                        Effect.ScrollTo("addcomment");
                        var _g = parseInt($("commentCount").innerHTML);
                        $("commentCount").innerHTML = _g + 1;
                    }
                });

                $("commentForm").hide();
                $("commentSuccess").show();
                $("sendButton").disabled = false;
                $("sendIndicator").hide();
            }
        }, onFailure: function (_17) {
            ajaxFailure(_17);
            $("sendButton").disabled = false;
            $("sendIndicator").hide();
        }
    });
}


function commentAgain() {
    $("comment").value = "";
    $("commentSuccess").hide();
    $("commentForm").show();
    $("comment").focus();
}


function checkLoginForm() {
    var ok = true;
    if (!$F("username").match(/\w/)) {
        $("username").addClassName("highlightRed");
        ok = false;
    }
    if (!$F("password").match(/\w/)) {
        $("password").addClassName("highlightRed");
        ok = false;
    }
    return ok;
}