Event.observe(window, "load", function () {
    if ($("username")) {
        Event.observe("username", "keyup", checkUsername);
    }
    if ($("bio")) {
        Event.observe("bio", "keyup", function () {
            var _1 = $F("bio");
            if (_1.length > 255) {
                $("bio").value = _1.substring(0, 255);
            }
        });
    }
});

function checkUsername() {
    var _2 = $F("username");
    new(Ajax.Request)(baseHREF() + "ajax/checkusername", {
        parameters: {
            ajax: 1,
            username: _2
        },
        onSuccess: function (_3) {
            var _4 = jsonParse(_3);
            if (!_4) {
                return;
            }
            var _5 = _4.get("error");
            if (_5) {
                validationError("username", _5);
            } else {
                validationOK("username");
            }
        },
        onFailure: ajaxFailure
    });
}


function setupComplete() {
    var _6 = 0;
    _6 += checkProfileSettings();
    if (!$("terms").checked) {
        $("terms").addClassName("highlightRed");
        $("termsLabel").addClassName("highlightRed");
        _6++;
    } else {
        $("terms").removeClassName("highlightRed");
        $("termsLabel").removeClassName("highlightRed");
    }
    if (!_6) {
        return;
    } else {
        return false;
    }
}


function checkWebsite() {
    if ($F("website")) {
        $("website").value = $F("website").replace(/\s*/g, "");
        if (!$F("website").match(/^https?:\/\//)) {
            $("website").value = "http://" + $F("website");
        }
    }
    $("saveProfileButton").disabled = true;
    $("saveProfileIndicator").show();
    $("profileForm").submit();
}


function saveSettings() {
    var _8 = checkAccountSettings();
    if (_8) {
        return true;
    }
    $("saveSettingsButton").disabled = true;
    $("saveSettingsIndicator").show();
    $("settingsForm").submit();
}


function checkProfileSettings() {
    var _9 = 0;
    var _a = $A(["username", "name", "email"]);
    _a.each(function (_b) {
        $(_b).removeClassName("highlightRed");
        if (!$F(_b).match(/\w/)) {
            $(_b).addClassName("highlightRed");
            _9++;
        }
    });
    if ($("usernameStatus").hasClassName("validationError")) {
        $("username").addClassName("highlightRed");
        _9++;
    }
    if ($("password") && $("password").visible()) {
        if ($F("password") == "" || $F("password2") == "") {
            $("password").addClassName("highlightRed");
            $("password2").addClassName("highlightRed");
            _9++;
        } else {
            if ($F("password") != $F("password2")) {
                $("password").addClassName("highlightRed");
                validationError("password", "The passwords do not match");
                _9++;
            } else {
                validationOK("password");
                $("password").removeClassName("highlightRed");
                validationOK("password2");
                $("password2").removeClassName("highlightRed");
            }
        }
    }
    if ($F("email")) {
        if (!$F("email").match(/^\s*[^\,\s]+\@[\w\-\.]+\.\w+\s*$/)) {
            $("email").addClassName("highlightRed");
            validationError("email", "The email address does not appear to be valid");
            _9++;
        } else {
            validationOK("email");
        }
    }
    return _9;
}


function checkAccountSettings() {
    var _9 = 0;
    var _a = $A(["name", "email"]);
    _a.each(function (_b) {
        $(_b).removeClassName("highlightRed");
        if (!$F(_b).match(/\w/)) {
            $(_b).addClassName("highlightRed");
            _9++;
        }
    });
    if ($("password") && $("password").visible()) {
        if ($F("password") == "" || $F("password2") == "") {
            $("password").addClassName("highlightRed");
            $("password2").addClassName("highlightRed");
            _9++;
        } else {
            if ($F("password") != $F("password2")) {
                $("password").addClassName("highlightRed");
                validationError("password", "The passwords do not match");
                _9++;
            } else {
                validationOK("password");
                $("password").removeClassName("highlightRed");
                validationOK("password2");
                $("password2").removeClassName("highlightRed");
            }
        }
    }
    if ($F("email")) {
        if (!$F("email").match(/^\s*[^\,\s]+\@[\w\-\.]+\.\w+\s*$/)) {
            $("email").addClassName("highlightRed");
            validationError("email", "The email address does not appear to be valid");
            _9++;
        } else {
            validationOK("email");
        }
    }
    return _9;
}


function changePassword() {
    $("changePasswordLink").hide();
    $("changePassword").show();
    $("password").show();
}


function deletePhoto() {
    $("photoPreview").hide();
    $("photoUpload").show();
    $("deletephoto").value = 1;
}


function selectTheme(_d) {
    $$(".selectedTheme").each(function (_e) {
        _e.removeClassName("selectedTheme");
    });
    $$("link").each(function (_f) {
        if (_f.rel && _f.title && _f.title.match(/^theme_/)) {
            _f.disabled = !("theme_" + _d == _f.title);
        }
    });
    $("theme_" + _d).addClassName("selectedTheme");
    $("theme").value = _d;
}


function deleteBackground() {
    $("backgroundPreview").hide();
    $("backgroundUpload").show();
    $("deletebackground").value = 1;
}


function updateWidget() {
    $("updateWidgetIndicator").show();
    new(Ajax.Request)(baseHREF() + "ajax/widgetcode", {
        parameters: {
            ajax: 1,
            size: $F("size"),
            bgcolor: $F("bgcolor"),
            fgcolor: $F("fgcolor")
        },
        onSuccess: function (_16) {
            $("widgetCode").value = _16.responseText;
            $("widgetPreview").innerHTML = _16.responseText;
            $("updateWidgetIndicator").hide();
        },
        onFailure: ajaxFailure
    });
}