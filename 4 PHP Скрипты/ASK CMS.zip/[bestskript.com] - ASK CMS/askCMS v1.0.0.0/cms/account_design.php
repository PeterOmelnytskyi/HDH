<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

define("IN_SITE", 1);
require_once 'brain.php';

/* [ Seguran�a ] */
checkUserLoggedOff();

/* [ Defini��es ] */
define("IN_TAB", "theme-tab", true);
define("USER_THEME", $Session_Engine->getUserData(USER_USERNAME, "THEME"), true);
$getChoosedTheme = $_POST["theme"];

/* [ A��es ] */
if($_SERVER['REQUEST_METHOD'] == "POST"){ $Session_Engine->updateUserTheme(''.USER_USERNAME.'', $getChoosedTheme); }else{}

/* [ Par�metros ] */
$Session_Template->setParameter("serializeTabs", $Session_Engine->serialize_SeetingsTabs(''.IN_TAB.''), true);
$Session_Template->setParameter("serializeThemes", $Session_Engine->serializeThemes(''.USER_THEME.''), true);

/* [ P�gina HTML -> Sa�da ] */
$Session_Template->loadHeaderHtml();
$Session_Template->writeLine("<head>"); 
$Session_Template->setTitle($Session_Template->getLang(99));
$Session_Template->setBase(); 
$Session_Template->loadHeaderMetas();
$Session_Template->loadIcon();
$Session_Template->loadHeaderCSS("settings-theme");
$Session_Template->loadHeaderJS();
$Session_Template->loadHeaderJS("color-picker"); // Mostra Palheta de Cores
$Session_Template->writeLine("</head>"); 
$Session_Template->writeLine("<body>");
$Session_Template->loadLogo();
$Session_Template->loadMenu();
$Session_Template->writeLine('<div class="clear"></div></div>');
$Session_Template->loadTpl("acc_themes");
$Session_Template->loadTpl("footer");
$Session_Template->loadOutput();

?>