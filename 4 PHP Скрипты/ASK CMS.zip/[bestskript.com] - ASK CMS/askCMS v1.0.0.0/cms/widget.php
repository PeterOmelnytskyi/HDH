<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

define("IN_SITE", 1);
require_once 'brain.php';

/* [ Seguran�a ] - Seguran�a n�o � necess�ria aqui. */

// Do Widget
define("WIDGET_USER", filterText(ucfirst(strtolower($_GET["user_widget"]))), true);
define("WIDGET_SIZE", $Session_Engine->getUserWidget(''.WIDGET_USER.'', "SIZE"), true);
define("WIDGET_BGCOLOR", $Session_Engine->getUserWidget(''.WIDGET_USER.'', "BACKGROUND"), true);
define("WIDGET_FGCOLOR", $Session_Engine->getUserWidget(''.WIDGET_USER.'', "FOREGROUND"), true);
define("WIDGET_WIDTH", $Session_Engine->getUserWidget(''.WIDGET_USER.'', "WIDTH"), true);
define("WIDGET_HEIGHT", $Session_Engine->getUserWidget(''.WIDGET_USER.'', "HEIGHT"), true);

// Do usu�rio
define("WIDGET_WHAT_ASK", $Session_Engine->getUserData(WIDGET_USER, "WHAT_ASK"), true);
define("WIDGET_ANONYMOUS", $Session_Engine->getUserData(WIDGET_USER, "A_VIEW"), true);

/* Verificando se Usu�rio Existe */
if($Session_Engine->profileUserExists(''.WIDGET_USER.'') != 1 || $Session_Engine->getUserData(''.WIDGET_USER.'', "STATUS") != 1)
{
	/* Verifaicando se Widget est� ativado */
	if($Session_Engine->getUserWidget(''.WIDGET_USER.'', "STATUS") == false)
	{
		// Ops ! Erro.
		echo('<h3>'.$Session_Template->getLang(117).'</h3>');
	}
}
/* Checa se Usu�rio aceita An�nimos visitando seu Perfil e fazendo Perguntas */
else if($Session_Engine->getUserData(''.WIDGET_USER.'', "A_VIEW") != 1 && SESSION_STATUS != true)
{
	echo('<h3>'.$Session_Template->getLang(118).'</h3>');
}
/* Exbi��o do Widget */
else
{
	/* [ A��es ] - Sem A��es */
	
	/* [ Par�metros ] */
	$Session_Template->setParameter("serializeUserWidgetCSS", $Session_Engine->serializeWidgetCSS(''.WIDGET_BGCOLOR.'', ''.WIDGET_FGCOLOR.''), true);
	
	/* [ P�gina HTML -> Sa�da ] */
	$Session_Template->loadHeaderHtml();
	$Session_Template->writeLine("<head>"); 
	$Session_Template->setTitle(''.$Session_Template->getLang(116).' - '.WIDGET_USER);
	$Session_Template->setBase(); 
	$Session_Template->loadHeaderMetas();
	$Session_Template->loadHeaderCSS("widget");
	readParameter(serializeUserWidgetCSS);
	$Session_Template->loadHeaderJS();
	$Session_Template->writeLine("</head>");
	$Session_Template->writeLine("<body>");
	$Session_Template->writeLine('<div class="widget'.WIDGET_SIZE.'">');
	$Session_Template->loadTpl("widget");
	$Session_Template->loadOutput();
}

?>
