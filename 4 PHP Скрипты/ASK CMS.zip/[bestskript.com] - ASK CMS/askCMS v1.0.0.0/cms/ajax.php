<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

define("IN_SITE", 1);
require_once 'brain.php';

/* [ Seguran�a ] - N�o necess�ria aqui. */

/* [ Defini��es ] */
$get["cmd"] = $_GET["cmd"];

/* In�cio [ Vari�veis ] */
$ask["question"] = ucfirst(filterText($_POST["question"]));
$ask["to_user"] = filterText($_POST["username"]);
$ask["anonymous"] = $_POST["anonymous"];
$delete["id"] = $_GET["del_id"];
$answer["answer"] = ucfirst(filterText($_POST["response"]));
$answer["id"] = $_POST["qa_id"];
$check["username"] = filterText(ucfirst(strtolower($_POST["username"])));
/* Fim [ Vari�veis ] */

/* [ A��es ] */
if(isset($get["cmd"]))
{
	switch($get["cmd"])
	{
		/* Perguntar */
		case "ask":
		   $Session_Engine->ask($ask["question"], $ask["to_user"] ,$ask["anonymous"]);
		   break;
		   
		/* Deletar Pergunta */
		case "delete_qa":
		   $Session_Engine->delete($delete["id"]);
		   break;
		   
		/* Responder Pergunta */
		case "answer_qa":
		   $Session_Engine->answer($answer["answer"], $answer["id"]);
		   break;
		   
		/* Checar Nome de Usu�rio */
		case "check_name":
		   $Session_Engine->checkAjaxName($check["username"]);
		   break;
		   
		/* Redireciona*/
		default:
		   $Session_Engine->headerIn();
		   break;
	}
}
else
{
	// Redirecionar para In�cio
	$Session_Engine->headerIn();
}
?>
