<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

define("IN_SITE", 0);
require_once '../brain.php';

/* [ Seguran�a ] */
checkUserLoggedOff();

/* [ Defini��es ] */
define("IN_TAB", "tab-[4]", true);
$get["id"] = filterText($_GET["id"]);
$setUsername["ByID"] = $Session_Engine->getUsernameByID($get["id"]);
define("UA_USERNAME", $setUsername["ByID"], true);

define("UA_USER_WEBSITE", $Session_Engine->getUserData(UA_USERNAME, "WEBSITE"), true);
define("UA_USER_LOCALIZATION", $Session_Engine->getUserData(UA_USERNAME, "LOCALIZATION"), true);
define("UA_USER_BIO", $Session_Engine->getUserData(UA_USERNAME, "BIO"), true);
define("UA_USER_WA", $Session_Engine->getUserData(UA_USERNAME, "WHAT_ASK"), true);
$update_ua["website"] = $_POST["website"];
$update_ua["location"] = filterText(ucfirst($_POST["location"]));
$update_ua["bio"] = filterText(ucfirst($_POST["bio"]));
$update_ua["ask"] = filterText(ucfirst($_POST["ask"]));

/* [ A��es ] */
if($_SERVER['REQUEST_METHOD'] == "POST"){ $Session_Engine->updateHmUP($get["id"], $update_ua["website"], $update_ua["location"], $update_ua["bio"], $update_ua["ask"]); }else{}
if($Session_Engine->userHasRights("ADM") || $Session_Engine->userHasRights("MOD") && $Session_Engine->userHasRights("FREE_HM_ACCESS"))
{
	/* [ Par�metros ] */
	$Session_Template->setParameter("serializeHmTabs", $Session_Engine->serializeHmTabs(''.IN_TAB.''), true);
	$Session_Template->setParameter("UID", $get["id"], true);
	
	/* [ P�gina HTML -> Sa�da ] */
	$Session_Template->loadHeaderHtml();
	$Session_Template->writeLine("<head>"); 
	$Session_Template->setTitle($Session_Template->getLang(337));
	$Session_Template->setBase();
	$Session_Template->loadHeaderMetas();
	$Session_Template->loadIcon();
	$Session_Template->loadHeaderCSS("dashboard");
	$Session_Template->loadHeaderJS();
	$Session_Template->writeLine("</head>"); 
	$Session_Template->writeLine("<body>");
	$Session_Template->loadLogo();
	$Session_Template->loadMenu();
	$Session_Template->writeLine('<div class="clear"></div></div>');
	
	if($Session_Engine->userHasRights("EDIT_USER_PROFILE"))
	{
		// Usu�rio Existe ???
		if($Session_Engine->profileUserExists(''.UA_USERNAME.'') != 0)
		{
			// Carrega a p�gina de Editar Perfil de Usu�rio
			$Session_Template->loadTpl("hm_eup");
		}
		// Usu�rio n�o Existe
		else
		{
			// Exibe HTML de "Erro"
			$Session_Template->writeLine("<div id=\"content\">");
			readParameter(serializeHmTabs);
			$Session_Template->writeLine("<div class=\"clear\"></div>");
			$Session_Template->writeLine('<h2>'.$Session_Template->getLang(396).'</h2>');
			$Session_Template->writeLine('<p>'.$Session_Template->getLang(397).'');
			$Session_Template->writeLine('</div>');
		}
	}
	else
	{
		// Carrega a p�gina de Privil�gios Insuficientes
		$Session_Template->loadTpl("hm_permission");
	}
	$Session_Template->writeLine("</div>");
	$Session_Template->writeLine("</div>"); 
	$Session_Template->loadTpl("footer");
	$Session_Template->loadOutput();
}
else
{
	$Session_Engine->headerIn();
}
?>