<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

#########################################################################################
## � praticamente o c�rebro da CMS. Daqui, executa e recebe todos os comandos do site. ##
#########################################################################################

/* PHP Stuff */
error_reporting(0);
ini_set('display_errors', 0);

// Fun��o para "Salvar C�digo"
function usingConfig($file) { require_once 'core/'.$file.'.config.php'; } // Configs

// Iniciando Sess�o
session_start();

// Requer Classes <classes>
require_once('core/mysql.class.php'); // MySQL
require_once('core/template.class.php'); // Design
require_once('core/engine.class.php'); // Processamento

usingConfig("mysql"); // Configura��es do Banco de Dados

// Declarando Classes
$Session_Database = new Mysql(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
$Session_Database->Connect();
$Session_Template = new Templates();
$Session_Engine = new Engine();

/* [ Inicializando Componentes Secund�rios ] */
usingConfig("website"); // Configura��es do Site

/* [ Verifica��o de Arquivos da CMS ] 
 * [ 1 = Verifica��o dos Arquivos da CMS ativada / 0 = Verifica��o Desativada ] */
define("SECURITY_CHECK", 1);
define("IMG_PATH", "images/users/");

// Definindo Componentes de Usu�rio Principais
define("USER_ID", $_SESSION['id']);
define("USER_USERNAME", $_SESSION['account_username']);
define("USER_RIGHTS", $_SESSION['__rights']);
define("SESSION_STATUS", $_SESSION['login']);
define("SESSION_MESSAGE", $_SESSION['msg']);

// Vers�o do Script
define("SCRIPT_VERSION", "1.0.0.0");

/* [ Inicializando Componentes Prim�rios e Verifica��es / Seguran�a ] */
$Session_Engine->initEnvironment();

// Fun��o para limpar uma vari�vel (Detectando Scripts Maliciosos e C�digos HTML Indevidos)
function filterText($text)
{
	/* AntiSQL Injection */
	$text = preg_replace(sql_regcase("/(from|select|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"),"",$text);
	
	/* AntiScript Injection */
	$text = preg_replace("/(\<script)(.*?)(script>)/si", "! ScriptDetected !", $text);
	
	/* Filtro HTML Adicional */
	$text = strip_tags($text); 
	$text = str_replace("<!--", "&lt;!--", $text); 
	$text = preg_replace("/(\<)(.*?)(--\>)/mi", "".nl2br("\\2")."", $text); 
	$text = stripslashes(htmlspecialchars($text));
	
	// Retornar Valor
	return $text;
}

/* Fun��o para Exibir todos os arquivos da pasta Lang / Arquivos de Linguagem. */
function scanLang()
{
	$RemoveChars = array('.', 'php');
	$DirectoryLangFolder = "../core/lang";
	
	// Diret�rio de Linguagens para Escanear Arquivos
	$directoryScan = scandir($DirectoryLangFolder);
	
	// N�mero de Arquivos na Array
	$countArrayFiles = sizeof($directoryScan);
	
	$Message = "<select name=\"language\">";
	
	// Verificar Quantidade da Array - Para ser v�lido deve ser Maior que 0
	if(is_numeric($countArrayFiles) > 0)
	{
		// Excluindo os 2 Primeiros Elementos da Array que s�o inutiliz�veis
		unset($directoryScan[0]);
		unset($directoryScan[1]);
			
		// Atribuindo Valores
		foreach($directoryScan as $languageFiles)
		{
			// Limpando Nome dos Arquivos de Linguagem
			$file = str_replace($RemoveChars, '', $languageFiles);
			
			// HTML do Idioma Escolhido
			$Message .= '<option value="'.$file.'">&nbsp;&nbsp;&nbsp;'.$file.'&nbsp;&nbsp;&nbsp;</option>';
		}
	}
	
	// HTML do Idioma Escolhido
	$Message .= "</select>";
	
	// Exibir Mensagem
	echo $Message;
}

/* [ C�digos Adicionais ] */
function readParameter($value) { echo (''.$value.''); }

/* Retorna Texto do ID do Idioma */
function getLanguage($id, $return = 0)
{
	global $Session_Template;
	$res = is_numeric($id) ? true : false; // � um n�mero ou N�o ???
	
	// � um n�mero ?
	if($res && $return == 0)
	{
		// Exibe Valor de Texto da Linguagem
		echo $Session_Template->getLang($id);
	}
	// Sen�o ???
	elseif($res && $return != 0)
	{
		// Retorna Valor do Texto da Linguagem
		return $Session_Template->getLang($id);
	}
}

/* Fun��o Para Converter Valores de [ Bool ] para [ Int ] */
function fakeBoolToEnum($bool)
{
	// Convertendo Valores
	if($bool == "true")
	{
		return 1;
	}
	
	// Se n�o retorna 0
	return 0;
}

/* Checa se Usu�rio n�o est� Logado */
function checkUserLoggedOff() {	if(SESSION_STATUS != true) { header('Location: http://'.SITE_DOMAIN.'/account/login');} }

/* Checa se Usu�rio est� Logado */
function checkUserLoggedIn() {	if(SESSION_STATUS != false) { header('Location: http://'.SITE_DOMAIN.'/account/inbox');} }

?>