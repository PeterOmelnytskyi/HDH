<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

###############################################################################
## Arquivo de Configura��o do Site. Edite-o de acordo com suas prefer�ncias. ##
###############################################################################

/* [ Requer Classe <engine> ] */
require_once "engine.class.php";

/* [ Declarando Classe ] */
$getEngine = new Engine();

###################################
# Configura��es Globais do Site   #
# ------------------------------- #
# Obs: N�o editar nada.           #
###################################

// Nome do Site
define("SITE_NAME", $getEngine->getSettingsVal("website_name", 0), true);

// URL do Site <Obs: N�o use http:// e / no final>
define("SITE_DOMAIN", $getEngine->getSettingsVal("website_domain", 0), true);

// Descri��o do Site
define("SITE_DESCRIPTION", $getEngine->getSettingsVal("website_description", 0), true);

// Palavras Chave do Site
define("SITE_KEYWORDS", $getEngine->getSettingsVal("website_keywords", 0), true);

// Idioma do Site
define("SITE_LANGUAGE", $getEngine->getSettingsVal("website_language", 0) , true);

// Manuten��o do Site
define("SITE_MAINTENANCE", $getEngine->getSettingsVal("website_maintenance", 0) , true);

// Ip do Usu�rio
define("USER_IP", getenv("REMOTE_ADDR"), true);

// Como an�nimo se Chama ?
define("ANONYMOUS", $getEngine->langVar(82), true);


###################################
# Configura��es de Upload de Foto #
# ------------------------------- #
# Obs: Livre para Edi��o.         #
###################################

// Tamanho M�ximo de Upload Foto
define("PHOTO_MAX_SIZE", 106883, true); // 1MB

// Largura M�xima de Upload Foto
define("PHOTO_MAX_WIDTH", 450, true); // 350 Pixels

// Altura M�xima de Upload Foto
define("PHOTO_MAX_HEIGHT", 280, true); // 180 Pixels

?>