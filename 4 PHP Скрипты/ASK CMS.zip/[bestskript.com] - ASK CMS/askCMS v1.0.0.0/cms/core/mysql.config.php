<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo 'At0m' Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo 'At0m' Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

###########################################################
## Dados de acesso ao BANCO DE DADOS vem aqui. N�o erre. ##
###########################################################

	/* Nome do Host */
	define('DB_SERVER', '');

	/* Nome de Usu�rio */
	define('DB_USERNAME', '');
	
	/* Senha */
	define('DB_PASSWORD', '');
	
	 /* Nome da Database */
	define('DB_NAME', '');
	
?>