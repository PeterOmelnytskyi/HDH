<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

require_once "engine.class.php";

###########################################################
## Classe para tratar do visual(estilo, design) do site. ##
###########################################################

class Templates extends Engine
{
	// Carregar Html Inicial
	public function loadHeaderHtml()
	{
		$this->writeLine('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">');
		$this->writeLine('<html xmlns="http://www.w3.org/1999/xhtml">');
	}
	
	// Carregar Header / JS <javascript>
	public function loadHeaderMetas($charset = 'UTF-8')
	{
		// Charset
		$this->writeLine('<meta http-equiv="Content-Type" content="text/html; charset='.$charset.'" />');
		// Descri��o
		$this->writeLine('<meta name="description" content="'.SITE_DESCRIPTION.'" />');
		// Palavras Chave
		$this->writeLine('<meta name="keywords" content="'.SITE_KEYWORDS.'" />');
	}
	
	// Carregar Header / CSS <css>
	public function loadHeaderCSS($page_type)
	{
		// Vari�veis
		$THEME = Engine::getUserData(USER_USERNAME, "THEME");
		$PROFILE_THEME = Engine::getUserData(PROFILE_USER, "THEME");
		
		// Tipos CSS
		switch($page_type)
		{
			case "index":
			$this->writeLine('<link type="text/css" href="css/site.css" rel="stylesheet" />');
			$this->writeLine('<link type="text/css" href="css/home.css" rel="stylesheet" media="all" />');
			break;
			
			case "maintenance":
			case "error":			
			case "privacy":
			case "terms":
			case "disabled":
			case "logout":
			$this->writeLine('<link type="text/css" href="css/site.css" rel="stylesheet" />');
			if(SESSION_STATUS != false)
			{
				$this->writeLine("<link type=\"text/css\" href=\"css/themes/$THEME.css\" rel=\"stylesheet\" />");
			}
			break;
			
			case "dashboard":
			case "forgotpassword":
			case "login":
			case "signup":
			$this->writeLine('<link type="text/css" href="css/site.css" rel="stylesheet" />');
			$this->writeLine('<link type="text/css" href="css/account.css" rel="stylesheet" media="all" />');
			break;
			
			case "profile":
			$this->writeLine("<link type=\"text/css\" href=\"css/site.css\" rel=\"stylesheet\" />");
			$this->writeLine("<link type=\"text/css\" href=\"css/profile.css\" rel=\"stylesheet\" media=\"all\" />");
$this->writeLine("<link type=\"text/css\" href=\"css/themes/$PROFILE_THEME.css\" rel=\"stylesheet\" />");
break;
			
			case "settings-disable":
			case "settings-widget":
			case "settings-theme":
			case "settings-photo":
			case "settings-profile":
			case "settings-account":
			case "inbox":		
			$this->writeLine("<link type=\"text/css\" href=\"css/site.css\" rel=\"stylesheet\" />");
			$this->writeLine("<link type=\"text/css\" href=\"css/account.css\" rel=\"stylesheet\" />");
			$this->writeLine("<link type=\"text/css\" href=\"css/themes/$THEME.css\" rel=\"stylesheet\" />");
			break;
			
			case "search":
			$this->writeLine('<link type="text/css" href="css/site.css" rel="stylesheet" />');
			$this->writeLine('<link type="text/css" href="css/search.css" rel="stylesheet" media="all" />');
			if(SESSION_STATUS != false)
			{
				$this->writeLine("<link type=\"text/css\" href=\"css/themes/$THEME.css\" rel=\"stylesheet\" />");
			}
			break;
			
			case "widget":
			$this->writeLine('<link type="text/css" href="css/widget.css" rel="stylesheet" />');
			break;
		}
	}
	
	// Carrega os c�digos finais do Html
	public function loadOutput()
	{
		$this->writeLine('</body>');
		$this->writeLine('</html>');
	}
	
		// Carregar Header / JS <javascript>
	public function loadHeaderJS($type)
	{
		switch($type)
		{
			/* [ColorPicker] - Funciona basicamente como um auxiliador dos c�digos HTML de cores.
			 *  Usado para gerar o c�digo HTML da cor ao clicar, especialmente para o Widget.     */
			case "color-picker":
			$this->writeLine('<script type="text/javascript" src="js/color_picker.js"></script>');
			break;
			
			default:	
			$this->writeLine('<script type="text/javascript" src="js/prototype.js"></script>');
			$this->writeLine('<script type="text/javascript" src="js/scriptaculous.js"></script>');
			$this->writeLine('<script type="text/javascript" src="js/site.js"></script>');
			$this->writeLine('<script type="text/javascript" src="js/search.js"></script>');
			$this->writeLine('<script type="text/javascript" src="js/settings.js"></script>');
			$this->writeLine('<script type="text/javascript" src="js/inbox.js"></script>');
			$this->writeLine('<script type="text/javascript" src="js/profile.js"></script>');
			break;
        }
	}
	
	// Carregar o �cone do Site
	public function loadIcon()
	{
		$this->writeLine('<link type="image/x-icon" href="ico.png" rel="icon" />');
		$this->writeLine('<link type="image/x-icon" href="ico.png" rel="shortcut icon" />');
	}
	// Carregar o Menu do Site
	public function loadMenu()
	{
		// Quantas quest�es minha Caixa de Perguntas Possui ?
		$inboxQuestions = Engine::inboxQuestions(''.USER_USERNAME.'', 0);
		
		// Formatando HTML para Exibi��o do N�mero de Perguntas
		if($inboxQuestions == 0) { $inboxQuestions = $inboxQuestions; } 
		else if($inboxQuestions > 0) { $inboxQuestions = '<font color="#FF0000">'.$inboxQuestions.'</font>'; }
		
		$this->writeLine('<ul id="headernav">');
		
		if(SESSION_STATUS != true)
		{
			if(SITE_MAINTENANCE == 0)
			{
				$this->writeLine('<li><a href="search/profiles">'.Templates::getLang(12).'</a></li>');
				$this->writeLine('<li><a href="account/signup">'.Templates::getLang(13).'</a></li>');
				$this->writeLine('<li><a href="account/login">'.Templates::getLang(14).'</a></li>');
				$this->writeLine('<li><a href="http://'.SITE_DOMAIN.'/">'.Templates::getLang(15).'</a></li>');
			}
		}
		else if(SESSION_STATUS != false)
		{
			if(SITE_MAINTENANCE == 0)
			{
				$this->writeLine('<li><a href="account/logout">'.Templates::getLang(16).'</a></li>');
				$this->writeLine('<li><a href="search/profiles">'.Templates::getLang(17).'</a></li>');
				$this->writeLine('<li><a href="account/settings">'.Templates::getLang(18).'</a></li>');
				$this->writeLine('<li><a href="account/inbox">'.Templates::getLang(19).' (<span id="inboxCount">'.$inboxQuestions.'</span>)</a></li>');
				$this->writeLine('<li><a href="'.USER_USERNAME.'">'.Templates::getLang(20).'</a></li>');
			}
			
			if(Engine::userHasRights("ADM") != false || Engine::userHasRights("MOD") != false)
			{
				if(Engine::userHasRights("FREE_HM_ACCESS") != false)
				{
					if(SITE_MAINTENANCE == 0)
					{
						$this->writeLine('<br/><br/>');
					}
					
					$this->writeLine('<li><a href="housemanager/index.php">[ '.Templates::getLang(21).' ]</a></li>');
					
					// Suporte � Acess�vel apenas para Administradores
					if(Engine::userHasRights("SUPPORT_REQUEST") == true)
					{
						$this->writeLine('<li><a href="http://at0m.com.nu" target="_blank">[ At0m ]</a></li>');
					}
				}
			}
		}
		
    $this->writeLine('</ul>');
	
	}
		
	// Carrega o Logotipo do SITE
	public function loadLogo()
	{
		$this->writeLine('<div id="wrapper">');
		$this->writeLine('<div id="header">');
		$this->writeLine('<div id="logo">');
		$this->writeLine('<a href="http://'.SITE_DOMAIN.'/"><img src="images/logo.png" alt="'.SITE_NAME.'" /></a>');
		$this->writeLine('</div>');
	}
	
	// Define o T�tulo da P�gina
	public function setTitle($page_title)
	{
		if($page_title == "" || strlen($page_title) <= 0) 
		{ $page_title = ''.Templates::getLang(22).''; }
		else
		{ $page_title = $page_title; }
		
		$this->writeLine('<title>'.$page_title.' | '.SITE_NAME.'</title>');
	}
	
	// Define a Base do WebSite
	public function setBase()
	{
		// Seguran�a
		if(SITE_DOMAIN != "" && strlen(SITE_DOMAIN) > 0)
		{
			// Base do Site � a URL
			$this->writeLine('<base href="http://'.SITE_DOMAIN.'/" />');
		}
		
	}
	
	/* Mostrar Erro */
	public function showError($error_title, $error_message)
	{
		die('<center><h1>'.$error_title.'</h1><p>'.$error_message.' </div><div id="footer"><ul id="footernav"><li><a href="./site/privacy">'.Templates::getLang(23).'</a></li><li><a href="./site/terms">'.Templates::getLang(24).'</a></li></ul>askCMS - The Formspring Clone Project<br /><!-- askCMS - At0m (C) 2011 - http://at0m.com.nu --><a href="http://at0m.com.nu/">At0m &copy; 2011</a><div class="clear"></div></div></body></html>');
		
	}
	
	// Carregar Template da pasta Templates
	public function loadTpl($template, $folder = "tpl", $file_type = "tpl")
	{
	
		$filename = 'core/'.$folder.'/'.$template.'.'.$file_type.'';
		$filename_ = '../core/'.$folder.'/'.$template.'.'.$file_type.'';
		
		/* Verifica se a p�gina existe */
		if(file_exists($filename) != FALSE)
		{
			if(pathinfo($filename, PATHINFO_EXTENSION) == "tpl")
			{
				Engine::requireFile(''.$folder.'/'.$template.'.'.$file_type.'');
			}
		}
		/* Especialmente para carregar as "Tpl�s" do Painel de Administra��o */
		else if(file_exists($filename_) != FALSE)
		{
			if(pathinfo($filename_, PATHINFO_EXTENSION) == "tpl")
			{
				Engine::requireFile($filename_);
			}
		}
		else
		{
			$this->showError(''.Templates::getLang(26).'', ''.Templates::getLang(27).' <b>'.$template.'.tpl</b> '.Templates::getLang(28).'<br>'.Templates::getLang(29).' <br>');
		}
	}
	
	/* Escreve algo na P�gina */
	public function writeLine($text)
	{
		echo(''.$text.'
		');
	}
	
	/* Define algum par�metro para exibir no arquivo TPL */
	public function setParameter($var, $value, $boolean)
	{
		$parameter = define("$var", "$value", $boolean);
		return $parameter;
	}
	
	/* Retorna Vari�vel da Array do arquivo de Linguagem */
	public function getLang($request_id, $folder = "lang")
	{
		/* Checa se diret�rio Existe */
		if(file_exists("core/lang"))
		{
			/* Requer arquivo de Texto */
			@include(''.$folder.'/'.SITE_LANGUAGE.'.php');
			/* Retornando o valor da Linguagem */
			return $arr[''.$request_id.''];
		}
		else if(file_exists("../core/lang"))
		{
			/* Requer arquivo de Texto */
			@include('../core/'.$folder.'/'.SITE_LANGUAGE.'.php');
			/* Retornando o valor da Linguagem */
			return $arr[''.$request_id.''];
		}
	}
	
}
?>