<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

###########################################################
## Classe MySQL - Armazenamento de Dados dos Usu�rios.   ##
###########################################################

class Mysql
{
	private $mysql_query_;
	private $sql_is_connected = 0;
	private $database_is_connected = 0;
	private $sql_server;
	private $sql_username;
	private $sql_password;
	private $sql_database;
	private $dataErrors = Array();
	
	/* Conex�o Database MYSQL */
	function __construct($db_s, $db_u, $db_p, $db_d) 
	{
		// Atribuindo Valores
		$this->sql_server =   $db_s;
		$this->sql_username = $db_u;
		$this->sql_password = $db_p;
		$this->sql_database = $db_d;
	}
	
	/* Execu��o de Dados + MySQL */
	public function executeQuery($query)
	{
		// Defini��es
		$this->mysql_query_ = $query;
		
		// Executar Pedido MYSQL
		$final = @mysql_query("$this->mysql_query_");
		
		// Retornar o Resultado do Pedido
		if($final)
		{
			// Completo
			return 1;
		}
		else
		{
			// Erro
			return 0;
		}
	}
	
	/* Fun��o para Contar N�mero de Elementos na em uma Tabela */
	public function numOfRows($table)
	{
		// Checar Vari�vel
		if(isset($table))
		{
			// Checando N�mero de Elementos na Tabela
			$query = mysql_query("SELECT * FROM $table");
			$query = mysql_num_rows($query);
			
			// Retorna Valor
			if($query > 0) { return $query;	}
			// Retorna Valor
			else { return 0; }
		}
	}
	
	/* Fun��o para criar "ponte" entre o website e o Banco de dados. */
	public function Connect()
	{
		// Verificando Dados do Arquivo de Configura��o
		if(Mysql::CheckConfigFile() == "AllRight")
		{		
			// Conectando com Database
			Mysql::DatabaseConnect(Mysql::MysqlConnect());
			
			if(sizeof($this->dataErrors) > 0)
			{
				if($this->sql_is_connected == false)
				{
					die("Verifique os Dados de Entrada ao MySQL");
				}
				elseif($this->database_is_connected != true)
				{
					die("Verifique o Banco de Dados.");
				}
			}
		}
		else
		{
			// Redireciona para Instalador
			header("Location: setup/index.php");
		}
	}
	
	/* Fun��o para mostrar Erro MySQL */
	public function Error()
	{
		// Retorna Erro
		return ' Error: -> ' . mysql_error();
	}
	
	/* Fun��o para Checar o Arquivo de Configura��o MySQL */
	public function CheckConfigFile($successMessage = "AllRight", $errorMessage = "Problem")
	{
		// Verificando Campos de Dados
		if(!empty($this->sql_server) || !empty($this->sql_username) || !empty($this->sql_password) || !empty($this->sql_database))
		{
			// Retorna Sucesso, pois tudo est� preenchido como devia
			$message[id] = $successMessage;
		}
		else
		{
			// Retorna erro, que pena...
			$message[id] = $errorMessage;
		}
		
		// Retorna Valor dos resultados acima.
		return $message[id];
	}
	
	public function MysqlConnect()
	{
		// Conectando com MySQL...
		$mysql_connection = mysql_connect($this->sql_server, $this->sql_username, $this->sql_password);
		
		// Checando a Conex�o
		if($mysql_connection)
		{
			// Est� conectado
			$this->sql_is_connected = 1;
			
			// Retorna Conex�o Feita
			return $mysql_connection;
		}
		else
		{
			// N�o est� Conectado
			$this->sql_is_connected = 0;
			
			// Exibe Erro MySQL
			$this->dataErrors[] = 1;
		}
	}
	
	public function DatabaseConnect($mysql_connection)
	{
		// Conectando com Banco de Dados
		if($this->sql_is_connected == true)
		{
			// Conectando com Banco de Dados...
			$dbCon = mysql_select_db($this->sql_database, $mysql_connection);
			
			// Checando a Conex�o
			if($dbCon)
			{
				// Est� conectado
				$this->database_is_connected = 1;
			}
			else
			{
				// Exibe Erro MySQL
				$this->dataErrors[] = 2;		
			}
		}
	}
}
?>