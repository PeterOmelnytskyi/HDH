<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

###########################################################
## Classe para tratar do processamento de a��es do site. ##
###########################################################

class Engine extends Mysql
{

	/* In�cio Dados Usu�rio */
	private $id;
	private $username;
	private $photo;
	private $email;
	private $name;
	private $surname;
	private $password;
	private $protection;
	private $website;
	private $rank;
	private $status;
	private $location;
	private $ip;
	private $about_me;
	private $what_ask;
	private $reg_date;
	private $theme;
	private $user_rights;
	private $pass_code;
	/* Fim Dados Usu�rio */
	
	/* Inicio Perguntas */
	private $QA_id;
	private $QA_question;
	private $QA_answer;
	private $QA_anonymous;
	private $QA_to_user;
	private $QA_from_user;
	private $QA_status;
	private $QA_date;
	private $QA_ip;
	private $QA_time;
	/* Fim Perguntas */
	
	/* Inicio Outros */
	private $Message;
	/* Fim Outros */
	
	/* In�cio Widgets */
	private $widget_data;
	private $widget_size;
	private $widget_background_color;
	private $widget_foreground_color;
	private $widget_height;
	private $widget_width;
	private $widget_status;
	/* Fim Widgets */
	
	/* Inicializa��o do Sistema,*/
	public function initEnvironment()
	{
		/* Modo Manuten��o */
		if(IN_SITE == 1 && SITE_MAINTENANCE == 1)
		{
			// Checar Sess�o
			if(SESSION_STATUS != false)
			{
				// Destr�i Sess�o para Manuten��o
				$this->clearCookies();
			}
			
			// Redireciona para Manuten��o do Site
			$this->headerIn("site/maintenance");
			exit;
		}
		// Se o site n�o estiver mais em manuten��o e o usu�rio estiver na p�gina de manunte��o
		else if(IN_MAINT == 1 && SITE_MAINTENANCE == 0)
		{
			// Ele � redirecionado
			$this->headerIn();
			exit;
		}
		
	}
	
	/* Fun�o para contar n�mero de perguntas na "Inbox" */
	public function inboxQuestions($user, $mode)
	{
		/* [ Modos de Retorno de Valor ]
		 * Caso 0 -> Retorna quantas perguntas n�o foram respondidas 
		 * Caso 1 -> Retorna quantas perguntas foram respondidas */
		switch($mode)
		{
			case 0:
			$query = mysql_query("SELECT * FROM questions WHERE to_user = '$user' AND status='0'");
			$questions = mysql_num_rows($query);
			
			// Retornando Valores
			if($questions == 0) { return "0"; } else if($questions > 0)	{ return $questions; }
			break;
			
			case 1:
			$query = mysql_query("SELECT * FROM questions WHERE to_user = '$user' AND status='1'");
			$questions = mysql_num_rows($query);
			
			// Retornando Valores
			if($questions == 0) { return 0; } else if($questions > 0)	{ return $questions; }
			break;			
		}
	}
	
	/* Fun��o para requerer um arquivo */
	public function requireFile($_file) { require_once(''.$_file.''); }
	
	/* Menus das Configura��es de Usu�rio */
	public function serialize_SeetingsTabs($in_tab)
	{
		$this->Message = '<ul id="topTabs">';
		
		if($in_tab == "settings-tab")
		{ $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
		$this->Message .= '<a href="account/settings">'.Engine::langVar(30).'</a></li>';

		if($in_tab == "profile-tab")
		{ $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
		$this->Message .= '<a href="account/profile">'.Engine::langVar(31).'</a></li>';

		if($in_tab == "photo-tab")
		{ $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
		$this->Message .= '<a href="account/photo">'.Engine::langVar(32).'</a></li>';

		if($in_tab == "theme-tab")
		{ $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
		$this->Message .= '<a href="account/design">'.Engine::langVar(33).'</a></li>';

		if($in_tab == "widget-tab")
		{ $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
		$this->Message .= '<a href="account/widgets">'.Engine::langVar(34).'</a></li>';

		if($in_tab == "disable-tab")
		{ $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
		$this->Message .= '<a href="account/disable">'.Engine::langVar(35).'</a></li>';	

		$this->Message .= "</ul>";

		return $this->Message;
	}
	
	public function getSettingsVal($table_val, $mode, $echo = 1, $return = 0)
	{
		// Fazendo a busca no Banco de Dados
		$configsql = @mysql_query("SELECT * FROM site_config LIMIT 1") or die(mysql_error());
		$config = mysql_fetch_assoc($configsql);
		
		/* [ Modo Valor ]
		 * 0 -> < Retornar o Valor >
		 * 1 -> < Mostrar(Echo) o Valor > */
		
		// Retorna Valor 
		if($mode == $return && $mode != $echo)
		{ return $site_val = $config[''.$table_val.'']; }
		
		// Exibe Valor
		elseif($mode == $echo && $mode != $return)
		{ echo $site_val = $config[''.$table_val.'']; }
		
		// Retorna 0
		else
		{ return; }
	}
		
	/* Faz login do usu�rio, com dados inseridos, avaliando se verdadeiros e criando sess�es. */
	public function checkCookies($username, $password, $rankADM = 2, $rankMOD = 1, $rankNORMAL = 0)
	{
		/* Observa��es 
		 * Como o JS j� faz a verifica��o do tamanho dos Dados Inseridos n�o h� necessidade de fazer-mos o mesmo aqui.
		*/
		if(!preg_match('/^[a-za-zA-Z\d_]{1,32}$/i', $username)) 
		{
			// Cria Mensagem de Erro
			$_SESSION['error'] = 3;
			// Envia para P�gina de Login
			$this->headerIn("account/login");
			exit;	
		}
		
		// Criptografando Senha
		$pass = Engine::varCrypt(Engine::varCrypt(Engine::varCrypt($password, "MD5", 0), 2, 0), "SHA1", 0);
		
		/* Logando */
		$result = @mysql_query("SELECT id, username, password, status, rank FROM users WHERE username = '$username' AND password = '$pass'");
		$user_data = @mysql_fetch_array($result);
		
		if (@mysql_num_rows($result) != 0)
		{
			/* Verifica Status: < 1 = Ativo > | < 0 = Desativo >
			 * Verificar Rank: Se Rank for Diferente de 1 e de Zero -> Erro
			 * Se status diferente de zero ou rank diferente de 1 e 0 -> Erro */			 
			if($user_data['status'] != 1 || $user_data['rank'] != 1 && $user_data['rank'] != 0 && $user_data['rank'] != 2)
			{
				// Cria Mensagem de Erro
				$_SESSION['error'] = 1;
				// Envia para P�gina de Login
				$this->headerIn("account/login");;
				exit;
			}
			else
			{
				//Cria Sess�es
				$_SESSION['login'] = true; // Session is True
				$_SESSION['id'] = $user_data['id']; // Get the ID of User Account
				$_SESSION['account_username'] = $user_data['username']; // Get the Name of the User
				
				// Checa Direitos do Usu�rio (Administra��o/Modera��o ou N�o ?) 
				if($user_data['rank'] == $rankADM)
				{
					// Administrador
					for ($i = 1; $i <= 15; $i++)
					{
						$this->user_rights .= Engine::setUserRights($i);
					}
				}
				else if($user_data['rank'] == $rankMOD)
				{
					// Moderador
					for ($i = 16; $i <= 19; $i++)
					{
						$this->user_rights .= Engine::setUserRights($i);
					}
				}
				else if($user_data['rank'] == $rankNORMAL)
				{
					// Usu�rio Normal
					$this->user_rights = 'NORMAL';
				}
				
				// Cria Sess�o de Direitos
				$_SESSION['__rights'] = $this->user_rights;
				
				// Redireciona para Caixa de Mensagens
				$this->headerIn("account/inbox");
				exit;
				}
			}
		else
		{
			// Dados Inv�lidos ou Usu�rio N�o Encontrado
			// Mensagem de Erro
			$_SESSION['error'] = 2;
			
			// Redireciona para P�gina de Login
			$this->headerIn("account/login");
			exit;
		}
	}
	
	
	// Gera um Valor Aleart�rio
	public function _randomVar($length, $numbers, $upper)
	{
		if (1 > $length) $length = 8;
		$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$numChars = 62;
		
		if (!$numbers)
		{
			$numChars = 52;
			$chars = substr($chars, 10, $numChars);
		}
			
			if (!$upper)
			{
				$numChars -= 26;
				$chars = substr($chars, 0, $numChars);
			}
				
				$string = '';
				for ($i = 0; $i < $length; $i++)
				{
					$string .= $chars[mt_rand(0, $numChars - 1)];
				}
					
			return $string;
					
		}
		
	/* Fun��o para Resgatar Senha / Gerar Senha Nova */
	public function recoverPassword($code, $pass_length = 15)
	{
		// Defini��es
		$this->pass_code = $code;
		$real_pass = Engine::_randomVar($pass_length, true, false); // Senha Gerada Verdadeira
		$this->password = Engine::varCrypt(Engine::varCrypt(Engine::varCrypt($real_pass, "MD5", 0), 2, 0), "SHA1", 0); // Senha Gerada Encriptada
		$this->Message = '';
		
		// Vari�vel Existe ?
		if(isset($this->pass_code))
		{
			// Checar Sess�o - Deve estar Desativada
			if(SESSION_STATUS != true)
			{
				// Verifica Campos
				if($this->pass_code != "" && strlen($this->pass_code) > 0)
				{
					// Checar se � encotrado algum c�digo 
					// Verifica se Existe a Pergunta e se o Usu�rio Logado � o Dono
					$sql = "SELECT * FROM users WHERE password_key = '$this->pass_code' LIMIT 1";
					$query = mysql_query($sql);
					
					// Checa se foi encontrado algo
					if(@mysql_num_rows($query) != 0)
					{
						// Gerar Nova Senha E Atualizar na Database
						if(MySQL::executeQuery("UPDATE users SET password = '$this->password' WHERE password_key = '$this->pass_code'") != 0)
						{
							// Retorna Mensagem de Sucesso
							$this->Message .= '<p style="border: solid 10px #005588; background: #ffaa00; padding: 15px; -moz-border-radius: 15px; -khtml-border-radius: 15px; -webkit-border-radius: 15px; border-radius: 15px; margin: 0; text-align: center; line-height: 23px; color: white; font-size: 18px">'.Engine::langVar(36).'<br>'.$real_pass.'</p></p><a href="http://'.SITE_DOMAIN.'/account/login">'.Engine::langVar(37).'</a> '.Engine::langVar(38).'';
						}
						else { die('<center>'.Engine::langVar(39).'</center>'); }
					}
					else
					{
						// Mensagem de Erro
						$this->Message .= '<p class="error"><b>'.Engine::langVar(40).' </b>'.Engine::langVar(41).'</p>';
					}
				}
				else
				{
					// Mensagem de Erro
					$this->Message .= '<p class="error"><b>'.Engine::langVar(40).' </b>'.Engine::langVar(42).'</p>';
				}
			}
		}
		// Retornar Mensagem
		return $this->Message;
	}
	
	
	/* Direitos que os usu�rios possuem (ADM/NORMAL) */
	public function setUserRights($code, $min = 0, $max = 20)
	{
		// Checar Vari�vel
		if(!isset($code))
		{
			return '';
		}
		
		////////////////////////////////////
		$mRights .= 'VIEW_USERS';
		$mRights .= 'EDIT_USER_ACCOUNT';
		$mRights .= 'EDIT_USER_PROFILE';
		////////////////////////////////////
		
		// Checar C�digo
		if($code > $min && $code < $max)
		{
			switch($code)
			{
				/* SUPREME_COMMANDS -> Faz tudo o que um Moderador pode fazer e o que n�o pode. 
				 * Por exemplo: A �rea de configurar o site, apenas o Administrador pode.      */
				 
				/* In�cio - Direitos do Administrador */
				case 1: 
				    return "ADM";
					break;
				
				case 2: 
				    return "FREE_HM_ACCESS";
					break;
					
				case 3:
				    return "SUPREME_COMMANDS";
					break;
				
				case 4: 
				    return "VIEW_QA";
					break;
					
				case 5: 
				    return "DELETE_QA";
					break;
					
				case 6:
				    return "EDIT_SITE_SETTINGS";
					break;
					
				case 7:
				    return "VIEW_USERS";
					break;
					
				case 8:
				    return "VIEW_SITE_SETTINGS"; 
					break;
					
				case 9: 
				    return "EDIT_USER_ACCOUNT"; 
					break;
					
				case 10: 
				    return "EDIT_USER_PROFILE"; 
					break;
					
				case 11: 
				    return "DELETE_USER";
					break;
					
				case 12:
				    return "SUPPORT_REQUEST";
					break;
					
				case 13:
				    return "VIEW_RANKS"; 
					break;
					
				case 14: 
				    return "GIVE_RANK"; 
					break;
					
				case 15: 
				    return "TAKE_RANK";
					break;
				/* Fim - Direitos do Administrador */
				
				/* Direitos do Moderador */
				case 16: 
				    return "MOD"; 
					break;
					
				case 17: 
				    return "FREE_HM_ACCESS"; 
					break;
					
				case 18: 
				    return $mRights; 
					break;
				
				case 19: 
				    return "VIEW_QADELETE_QA"; 
					break;
					
					default:
					    return NULL;
						break;
			}
		}
	}
	
	
	/* Consulta de Dados de Widget do Usu�rio */
	public function getUserWidget($username, $widget_data)
	{
		// Defini��es Iniciais
		$this->username = $username;
		$this->widget_data = $widget_data;
		
		// Nome deve ter mais de 0 caracteres para ser V�lido
		if(strlen($this->username) > 0)
		{
				// Faz Pesquisa
				$sql = @mysql_query("SELECT * FROM widgets WHERE username = '$this->username'") or die(mysql_error());
				$readData = @mysql_fetch_assoc($sql);
				
				// Defini��es
				$this->widget_size = $readData['size'];
				$this->widget_status = $readData['status'];
				$this->widget_background_color = $readData['background_color'];
				$this->widget_foreground_color = $readData['foreground_color'];
				$this->widget_height = $readData['height'];
				$this->widget_width = $readData['width'];
				
				// Status do Widget tem que ser 1
				if($this->widget_status != false)
				{
					// Qual a Data ?
					switch($this->widget_data)
					{
						case "SIZE": // Tamanho
						     return $this->widget_size; break;
						case "BACKGROUND": // Plano de Fundo
						     return $this->widget_background_color; break;
						case "FOREGROUND": // Letra
						     return $this->widget_foreground_color; break;
						case "STATUS": // Status
						     return $this->widget_status; break;
					    case "HEIGHT": // Altura
						     return $this->widget_height; break;
						case "WIDTH": // Largura
						     return $this->widget_width; break;
					}
				}
				else
				return;
			}
			else
			return;
	}
	
	/* Fun��o para EstiloCSS do Widget do Usu�rio */
	public function serializeWidgetCSS($bgcolor, $fgcolor)
	{
		// Defini��es
		$this->widget_background_color = substr($bgcolor, -6, 6);
		$this->widget_foreground_color = substr($fgcolor, -6, 6);
		
		/* In�cio do EstiloCSS */
		$this->Message = '<style type="text/css">';
		$this->Message .= 'body {';
		$this->Message .= 'background-color: #'.$this->widget_background_color.';';
		$this->Message .= 'color: #'.$this->widget_foreground_color.';';
		$this->Message .= '}';
		$this->Message .= '.header {';
		$this->Message .= 'border-bottom: solid 1px #'.$this->widget_foreground_color.';';
		$this->Message .= '}';
		$this->Message .= 'a, a:visited {';
		$this->Message .= 'color: #'.$this->widget_foreground_color.';';
		$this->Message .= '}';
		$this->Message .= '</style>';
		/* Fim do EstiloCSS */
		
		// Retorna a Mensagem
		return $this->Message;
	}
	
	/* Fun��o para Atualizar Dados de Conta do Usu�rio */
	public function updateUserSettings($name, $password, $email, $protection, $surname)
	{
		//Defini��es
		$this->username = ''.USER_USERNAME.'';
		$this->name = $name;
		$this->surname = $surname;
		$this->password = $password;
		$this->email = $email;
		$this->protection = $protection;			
			
		//Checar Sess�o
		if(SESSION_STATUS != false)
		{
			if($this->email != Engine::getUserData($this->username, "EMAIL"))
			{
				// Checando se Email j� est� registrado
				if(Engine::email_Already_Exists($this->email) == "Email Exists")
				{
					// Exibe Mensagem de Erro
					$_SESSION['msg'] = 3;
					
					// Redireciona
					$this->headerIn("account/settings");
					exit;
				}
			 }
			 
			 // Checar Campos
			if($this->name == "" || $this->surname == "" || $this->email == "")
			{
				$_SESSION['msg'] = 2;
				// Envia para P�gina de Conta
				header('Location: http://'.SITE_DOMAIN.'/account/settings');
				exit;
			}
			
			// Senha - Atualizar ou N�o
			if(strlen($this->password) > 1){ $modify_pass = 1; } elseif($this->password == "") { $modify_pass = 0; }
			
			// Codificando a Senha
			$pass = Engine::varCrypt(Engine::varCrypt(Engine::varCrypt($this->password, "MD5", 0), 2, 0), "SHA1", 0);
			
			/* In�cio Mensagem MySQL */
			$MySQL_Message = "UPDATE users SET ";
			$MySQL_Message .= "real_name = '$this->name', ";
			$MySQL_Message .= "real_surname = '$this->surname', ";
			$MySQL_Message .= "email = '$this->email', ";
			if($modify_pass != 0) {	$MySQL_Message .= "password = '$pass', ";	}
			$MySQL_Message .= "anonymous_view = '$this->protection' ";
			$MySQL_Message .= "WHERE username = '$this->username'";
			/* T�rmino Mensagem MySQL */
			
			// Atualizando
			if(MySQL::executeQuery($MySQL_Message) != 0)
			{
				// Cria Mensagem de Sucesso
				$_SESSION['msg'] = 1;
				// Envia para P�gina de Conta
				header('Location: http://'.SITE_DOMAIN.'/account/settings');
				exit;
			} else { die('<center>'.Engine::langVar(39).'</center>'); }
		}
	}
	
	/* Fun��o para solicitar algum tempo dependendo do Modo */
	public function getCurrentTime($mode)
	{
		switch($mode)
		{
			// Retorna a Data em </ Dia - M�s - Ano />
			case "date":
			return date("d-m-Y");
			break;
			
			// Retorna o Tempo em </ Horas - Minutos - Segundos />
			case "time":
			return date("H:i:s");
			break;
			
			// Retorna o Dia da Semana
			case "day_of_week":
			switch(date("w"))
			{
				case 0: return ''.Engine::langVar(43).''; break;
				case 1: return ''.Engine::langVar(44).''; break;
				case 2: return ''.Engine::langVar(45).''; break;
				case 3: return ''.Engine::langVar(46).''; break;
				case 4: return ''.Engine::langVar(47).''; break;
				case 5: return ''.Engine::langVar(48).''; break;
				case 6: return ''.Engine::langVar(49).''; break;
				
				// Exibe mensagem de Erro
				default:
				return "Error";
				break;
			}
			break;
		}
	}
	
	/* Consulta de Dados do Usu�rio */
	public function getUserData($username, $data)
	{
		$this->username = $username;
		
		// Nome deve ter mais de 0 caracteres para ser V�lido
		if(strlen($this->username) > 0)
		{
				// Faz Pesquisa
				$sql = @mysql_query("SELECT * FROM users WHERE username = '$this->username'") or die(mysql_error());
				$readData = @mysql_fetch_assoc($sql);
				
				// Qual a Data ?
				switch($data)
				{
					case "ID": return $readData['id']; break; // Id do Usu�rio
					case "USERNAME": return $readData['username']; break; // Nome de Usu�rio
					case "PASSWORD": return $readData['password']; break; // Senha do Usu�rio
					case "REAL_NAME": return $readData['real_name']; break; // Nome Verdadeiro do Usu�rio
					case "REAL_SURNAME": return $readData['real_surname']; break; // Sobrenome Verdadeiro do Usu�rio
					case "RANK": return $readData['rank']; break; // Rank do Usu�rio
					case "EMAIL": return $readData['email']; break; // Email do Usu�rio
					case "WEBSITE": return $readData['website']; break; // Website do Usu�rio
					case "LOCALIZATION": return $readData['localization']; break; // Localiza��o do Usu�rio
					case "BIO": return $readData['bio']; break; // Sobre o Usu�rio
					case "WHAT_ASK": return $readData['what_ask']; break; // O que perguntar ?
					case "THEME": return $readData['theme']; break; // Tema do Usu�rio
					case "PHOTO": return $readData['photo']; break; // Foto do Usu�rio
					case "STATUS": return $readData['status']; break; // Status do Usu�rio
					case "IP_ADDRESS": return $readData['ip']; break; // Endere�o de IP do Usu�rio
					case "PASS_KEY": return $readData['password_key']; break; // Chave de Seguran�a do Usu�rio
					case "A_VIEW": return $readData['anonymous_view']; break; // Permiss�o de An�nimos
					case "REG_DATE": return $readData['reg_date']; break; // Data de Registro
			}
		}
	}
	
	/* Desloga o Usu�rio Conectado */
	public function clearCookies()
	{
		// Retirando/Removendo Valores da Sess�o
		unset($_SESSION['id']);
		unset($_SESSION['account_username']);
		unset($_SESSION['__rights']);
		unset($_SESSION['login']);
		
		// Destru�ndo Sess�o por Completo
		session_destroy();
		
		// Inicia Sess�o para Exibi��o da P�gina Logout-Complete
		session_start();
		$_SESSION["log_verify"] = true;
		
		//Redireciona para P�gina de Sucesso
		$this->headerIn("site/complete");
                exit;
	}
	
		/* Fun��o de Seguran�a da Senha */
	public function varCrypt($encrypt_val, $mode, $brute_pass)
	{
		// Checa tamanho da *Senha/Valor
		if(strlen($encrypt_val) < 0)
		{
			return;
		}
		
		// Retornar a *Senha/Valor j� na forma "Bruta"
		if($brute_pass != 0 && strlen($encrypt_val) > 0 || strlen($encrypt_val) < 800)
		{
			/* [Convers�o de Valores por Vez ] */
			switch($mode)
			{
				// Converter *Senha/Valor para <MD5>
				case 1:
				case "MD5":
				   return md5($encrypt_val);
				break;
				
				// Converter *Senha/Valor para <BASE64>
				case 2:
				case "BASE_64":
				   return base64_encode($encrypt_val);
				break;
				
				// Converter *Senha/Valor para <SHA1>
				case 3:
				case "SHA1":
				   return sha1($encrypt_val);
				break;
				
				// Padr�o ***
				default:
				return 0;
				break;
			}
		}
		else if($brute_pass != 1)
		{
			/* [Criptografaia Tripla <md5> + <base64> = <sha1> ] 
			*  -> Retornando *Seha/Valor em formato "Bruto"   */
			return sha1(base64_encode(md5($encrypt_val)));
		}
	}
	
	/* Fun��o que checa se o usu�rio tem ou n�o determinado Direito */
	public function userHasRights($received_right)
	{
		// Checar Vari�vel
		if(isset($received_right))
		{
			// Checar Sess�o
			if(SESSION_STATUS != false)
			{
				// Usu�rio possui o direito ?
				if(strpos(USER_RIGHTS, $received_right) === false)
				{
					// Direito N�o Existe
					$returnVar = 0;
				}
				else
				{
					// Direito Existe
					$returnVar = 1;
				}
				
				// Retorna Valor
				return $returnVar;
			}
		}
	}
	
	/* Fun��o que verifica se usu�rio existe ou n�o */
	public function profileUserExists($UserEntered)
	{
		// Defini��es
		$this->username = $UserEntered;
		
		// Seguran�a
		if(strlen($this->username) > 0)
		{
			// Pesquisa
			$result = @mysql_query("SELECT * FROM users WHERE username = '$this->username'");
			
			if(@mysql_num_rows($result) > 0)
			{
				// Exite
				return 1;
			}
			else
			{
				// N�o Existe
				return 0;
			}
		}
		else 
		return 0;
	}
	
	/* Fun��o de Listagem e Escolha de Temas */
	public function serializeThemes($myTheme)
	{
		/* Listagem dos Temas
		 * Na vers�o Original s�o apenas 12 Temas */
		 $arr = array();
		 $arr[] = "default";
		 $arr[] = "birch";
		 $arr[] = "bluedots";
		 $arr[] = "charcoal";
		 $arr[] = "chocolate";
		 $arr[] = "cranberry";
		 $arr[] = "django";
		 $arr[] = "forest";
		 $arr[] = "indigo";
		 $arr[] = "morocco";
		 $arr[] = "pinkdots";
		 $arr[] = "tartan";
		 /* Listagem Conclu�da
		  * Exibi��o */
		  
		  // Checa se Tema Est� na Array
		 if(in_array($myTheme, $arr) != true)
		 return;
		  
		/* Start - Default Theme */
		$this->Message = '<div id="theme_'.$arr[0].'" class="';
		if($myTheme != ''.$arr[0].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[0].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[0]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Default Theme */
		
		/* Start - Birch Theme */
		$this->Message .= '<div id="theme_'.$arr[1].'" class="';
		if($myTheme != ''.$arr[1].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[1].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[1]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>'; 
		/* End - Birch Theme */
		
		/* Start - BlueDots Theme */
		$this->Message .= '<div id="theme_'.$arr[2].'" class="';
		if($myTheme != ''.$arr[2].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[2].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[2]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - BlueDots Theme */

		/* Start - Charcoal Theme */
		$this->Message .= '<div id="theme_'.$arr[3].'" class="';
		if($myTheme != ''.$arr[3].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[3].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[3]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Charcoal Theme */
		
		/* Start - Chocolate Theme */
		$this->Message .= '<div id="theme_'.$arr[4].'" class="';
		if($myTheme != ''.$arr[4].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[4].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[4]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Chocolate Theme */
		
		/* Start - Cranberry Theme */
		$this->Message .= '<div id="theme_'.$arr[5].'" class="';
		if($myTheme != ''.$arr[5].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[5].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[5]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Cranberry Theme */
		
		/* Start - Django Theme */
		$this->Message .= '<div id="theme_'.$arr[6].'" class="';
		if($myTheme != ''.$arr[6].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[6].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[6]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Django Theme */
		
		/* Start - Forest Theme */
		$this->Message .= '<div id="theme_'.$arr[7].'" class="';
		if($myTheme != ''.$arr[7].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[7].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[7]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Forest Theme */
		
		/* Start - Indigo Theme */
		$this->Message .= '<div id="theme_'.$arr[8].'" class="';
		if($myTheme != ''.$arr[8].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[8].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[8]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Indigo Theme */

		/* Start - Morocco Theme */
		$this->Message .= '<div id="theme_'.$arr[9].'" class="';
		if($myTheme != ''.$arr[9].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[9].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[9]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Morocco Theme */
		
		/* Start - PinkDots Theme */
		$this->Message .= '<div id="theme_'.$arr[10].'" class="';
		if($myTheme != ''.$arr[10].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[10].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[10]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - PinkDots Theme */
		
		/* Start - Tartan Theme */
		$this->Message .= '<div id="theme_'.$arr[11].'" class="';
		if($myTheme != ''.$arr[11].'') { $this->Message .= 'theme'; } else { $this->Message .= 'theme selectedTheme'; }
		$this->Message .= '" style="background-image:url(images/themes/'.$arr[11].'.png)">';
        $this->Message .= "<a href=\"#\" onclick=\"selectTheme('$arr[11]'); return false;\">&nbsp;</a>";
		$this->Message .= '</div>';
		/* End - Tartan Theme */
		
		// Retorna Mensagens
		return $this->Message;
	}
	
	/* Fun��o para Atualizar o Tema do Usu�rio */
	public function updateUserTheme($username, $theme)
	{
		// Defini��es
		$this->username = $username;
		$this->theme = $theme;
		
		// Verificando a Sess�o
		if(SESSION_STATUS != false)
			{
				/* Verifica��o do Tema Inserido
				* Por quest�es de seguran�a. */
				if(in_array($this->theme, array('default', 'birch', 'bluedots', 'charcoal', 'chocolate', 'cranberry', 'django', 'forest', 'indigo', 'morocco', 'pinkdots', 'tartan')))
				{
					// Verificar se Tema � o mesmo que possuo
					if(Engine::getUserData(USER_USERNAME, "THEME") == $this->theme)
					{
						// Cria Mensagem de Erro
						$_SESSION['msg'] = 1;
						// Envia para P�gina de Temas
						$this->headerIn("account/design");
						exit;
					}
					// Agora atualizando o Tema do Usu�rio
					else if(MySQL::executeQuery("UPDATE users SET theme = '$this->theme' WHERE username = '$this->username'") != 0)
					{
						// Cria Mensagem de Sucesso
						$_SESSION['msg'] = 2;
						// Envia para P�gina de Temas
						$this->headerIn("account/design");
						exit;
						
					}   else { die('<center>'.Engine::langVar(39).'</center>'); }
				}
				else
				{
					// Cria Mensagem de Erro
					$_SESSION['msg'] = 3;
					// Envia para P�gina de Temas
					$this->headerIn("account/design");
					exit;
				} 
			}
	}
	
	/* Fun��o para Atualizar o Widget do Usu�rio */
	public function updateUserWidget($size, $bg_color, $fg_color)
	{		
		// Defini��es
		$this->username = ''.USER_USERNAME.'';
		$this->widget_size = $size;
		$this->widget_background_color = $bg_color;
		$this->widget_foreground_color = $fg_color;
		
		$array_val = in_array($this->widget_size, array('Small', 'Medium', 'Large'));
		
		// Checar Sess�o
		if(SESSION_STATUS != false)
		{
			/* Verificar campos - Tamanho da Caixa */
			if(strlen($this->widget_size) > 0 && $array_val === true)
			{
				/* Verifica��o das Cores */
				if(strlen($this->widget_background_color) == 7 && strlen($this->widget_foreground_color) == 7)
				{
						/* Definindo as Dimens�es da Caixa Widget <Altura x Largura>
						 * Altura -> (Width).px
						 * Largura -> (Height).px */
						 
						/* Tamanho Pequeno */
						if($this->widget_size == "Small")
						{
							$this->widget_width = 120;
							$this->widget_height = 275;
						}
						
						/* Tamanho M�dio */
						else if($this->widget_size == "Medium")
						{
							$this->widget_width = 180;
							$this->widget_height = 275;
						}
						
						/* Tamanho Grande */
						else if($this->widget_size == "Large")
						{
							$this->widget_width = 400;
							$this->widget_height = 275;
						}
							
							/* In�cio Mensagem MySQL */
							$MySQL_Message = "UPDATE widgets SET ";
							$MySQL_Message .= "size = '$this->widget_size', ";
							$MySQL_Message .= "background_color = '$this->widget_background_color', ";
							$MySQL_Message .= "foreground_color = '$this->widget_foreground_color', ";
							$MySQL_Message .= "height = '$this->widget_height', ";
							$MySQL_Message .= "width = '$this->widget_width' ";
							$MySQL_Message .= "WHERE username = '$this->username'";
							/* T�rmino Mensagem MySQL */
							
							// Atualizando
								if(MySQL::executeQuery($MySQL_Message) != 0)
								{
									// Cria Mensagem de Sucesso
									$_SESSION['msg'] = 1;
									// Envia para P�gina de Widgets
									$this->headerIn("account/widgets");
									exit;
								}
								else
								{
									die('<center>'.Engine::langVar(39).'</center>'); 
								}	
				}
				else
				{
					// Dados Inv�lidos - Mostrar Erro
					$_SESSION['msg'] = 2;
					$this->headerIn("account/widgets");
					exit;
				}
				
			}
			else
			// Isso n�o vai acontecer em hip�tese alguma, mas por quest�es de seguran�a foi adicionado.
			die(''.Engine::langVar(50).'');
		}
		else
		return;
	}
	
	/* Fun��o para exibir os Usu�rios do Site */
	public function serializeHmUsers()
	{
		// Defini��es
		$this->Message = '';
		
		// Verificar Sess�o
		if(SESSION_STATUS != false)
		{
			// Verificar Direitos
			if(Engine::userHasRights("VIEW_USERS") != false)
			{
				// Pesquisa no Banco de Daddos
				$sql = "SELECT * FROM users WHERE status = '1' ORDER BY id DESC";
				$query = mysql_query($sql);
				
				// N�mero de Usu�rios AtivOs
				if(@mysql_num_rows($query) != 0)
				{
					// Mensagem HTML de In�cio
					$this->Message .= '<table width="100%" border="0">';
					$this->Message .= '<tr>';
					$this->Message .= '<td width="10%" align="center"><b>'.Engine::langVar(51).'</b></td>';
					$this->Message .= '<td width="20%" align="center"><b>'.Engine::langVar(52).'</b></td>';
					$this->Message .= '<td width="25%" align="center"><b>'.Engine::langVar(53).'</b></td>';
					$this->Message .= '<td width="20%" align="center"><b>'.Engine::langVar(54).'</b></td>';
					$this->Message .= '<td width="25%" align="center"><b>'.Engine::langVar(55).'</b></td>';
					$this->Message .= '</tr>';
					
					// Exibindo Resultados/Usu�rios
					while($ii = mysql_fetch_assoc($query))
					{						
						$this->Message .= '<tr>';
						$this->Message .= '<td width="10%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$ii["id"].'</td>';
						$this->Message .= '<td width="20%" valign="top" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;"><a href="'.ucfirst($ii["username"]).'" target="_blank" title="Ver Perfil">'.ucfirst($ii["username"]).'</a></td>';
						$this->Message .= '<td width="25%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$ii["email"].'</td>';
						$this->Message .= '<td width="20%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$ii["reg_date"].'</td>';
						$this->Message .= '<td width="25%" align="center" style="border-top: 1px dashed grey;">';
						$this->Message .= '<table>';
						$this->Message .= '<tr>';
						$this->Message .= '<a href="housemanager/edit_user_account.php?id='.$ii["id"].'">'.Engine::langVar(56).'</a> | ';
						$this->Message .= '<a href="housemanager/edit_user_profile.php?id='.$ii["id"].'">'.Engine::langVar(57).'</a><br />';
						$this->Message .= '<a href="housemanager/delete_user.php?id='.$ii["id"].'">'.Engine::langVar(58).'</a>';
						$this->Message .= '</tr>';
						$this->Message .= '</table>';
						$this->Message .= '</td>';
						$this->Message .= '</tr>';					
					}
					
					//Mensagem HTML do Final
					$this->Message .= '</table>';
				}
				// N�o existe Pergunta
				else
				{
					// Mensagem de Erro
					$this->Message = '<font color="red"><p><center>'.Engine::langVar(59).'</center><p></font>';
				}
			}
		}
		
		// Retorna a Mensagem
		return $this->Message;
	}
		
	/* Fun��o para atualizar a Foto do Usu�rio */
	public function updateUserPhoto($photo_file)
	{
		//Defini��es
		$this->username = ''.USER_USERNAME.'';
		$this->photo = $photo_file = $_FILES["photo"];
		$error = array();
		$file = isset($this->photo) ? $this->photo : FALSE;
		
		// Seguran�a / Verifica��o do Arquivo Inserido
		if ($file)
		{
			// Verifica a Extens�o do Arquivo
			if (!eregi("^image\/(pjpeg|jpeg|png|gif|bmp)$", $file["type"]))
			{
				$error[] = 1;
				// Erro
				$_SESSION['msg'] = 1;
				header('Location: http://'.SITE_DOMAIN.'/account/photo');
				exit;
			}
			else
			{
				// Verifica Tamanho da Foto
				if ($file["size"] > PHOTO_MAX_SIZE)
				{
					$error[] = 2;
					// Erro
					$_SESSION['msg'] = 2;
					header('Location: http://'.SITE_DOMAIN.'/account/photo');
					exit;
				}
				
				// Verifica as Dimens�es da Foto
				$photo_dimensions = getimagesize($file["tmp_name"]);
				
				// Verifica a Largura da Foto
				if ($photo_dimensions[0] > PHOTO_MAX_WIDTH)
				{
					$error[] = 3;
					// Erro
					$_SESSION['msg'] = 3;
					header('Location: http://'.SITE_DOMAIN.'/account/photo');
					exit;
				}
				
				// Verifica a Altura da Foto
				if ($photo_dimensions[1] > PHOTO_MAX_HEIGHT)
				{
					$error[] = 4;
					// Erro
					$_SESSION['msg'] = 4;
					header('Location: http://'.SITE_DOMAIN.'/account/photo');
					exit;
				}
		}
		// Checa os Erros
		/* N�o h� muita preocupa��o com esta parte do c�digo, quanto aos erros, mas recomendo n�o alterar. */
		if (sizeof($error))
		{
			// Mas, infelizmente algo deu errado.
			$_SESSION['msg'] = 5;
			header('Location: http://'.SITE_DOMAIN.'/account/photo');
			exit;
		}
		
		// Agora, iniciando o Processo de Remaneja��o da Foto
		else
		{
			// Adquirir Extens�o da Foto
			preg_match("/\.(gif|bmp|png|jpg|jpeg){1}$/i", $file["name"], $ext);
			
			// Gerar Nome Codificado para Imagem
			$photo_crypt_name = Engine::varCrypt(''.USER_USERNAME.''.time().'', 1, 0) . "." . $ext[1];
			
			// Caminho de onde a imagem ficar�
			$directory = ''.IMG_PATH.'' . $photo_crypt_name;
			
			// Faz o upload da imagem
			move_uploaded_file($file["tmp_name"], $directory);
			
			// Checar Sess�o
			if(SESSION_STATUS != false)
			{
				// Atualizando Foto na Database
				if(MySQL::executeQuery("UPDATE users SET photo = '$photo_crypt_name' WHERE username = '$this->username'") != 0)
				{
					// Redirecionando
					$_SESSION['msg'] = 6;
					header('Location: http://'.SITE_DOMAIN.'/account/photo');
					exit;
					} else { die('<center>'.Engine::langVar(39).'</center>'); }
				}
		  }
	  }
  }
  
  /* Fun��o para Atualizar as Configura��es de Perfil do Usu�rio */
  public function updateUserProfile($website, $location, $about, $what)
  {
	  // Defini��es
	  $this->username = ''.USER_USERNAME.'';
	  $this->website = $website;
	  $this->location = $location;
	  $this->about_me = $about;
	  $this->what_ask = $what;
	  
	  /* Como os dados s�o muito pessoais, e alguns usu�rios n�o gostam de colocar suas informa��es, ent�o,
	   * eu (At0m) fiquei em d�vida se colocaria ou n�o a verifica��o dos campos, mas pensando melhor coloquei. */
	   
	   // Verificar se campos est�o em branco
	   if($this->website == "" || $this->location == "" || $this->about_me == "" || $this->what_ask == "")
	   {
		   // Exibir Mensagem de Erro
		   $_SESSION['msg'] = 2;
		   header('Location: http://'.SITE_DOMAIN.'/account/profile');
		   exit;
	   }
	   // Checar Sess�o
	   elseif(SESSION_STATUS != false)
			{
				// Atualizando Dados na Database
				if(MySQL::executeQuery("UPDATE users SET website='$this->website', localization='$this->location', bio='$this->about_me', what_ask='$this->what_ask' WHERE username = '$this->username'") != 0)
				{
					// Redirecionando
					$_SESSION['msg'] = 1;
					header('Location: http://'.SITE_DOMAIN.'/account/profile');
					exit;  
				} else { die("<center>MySQL Error Detected ! Something goes Wrong.</center>"); }
			}
			else
			return;
	}
	
	/* Fun��o para Desativar a conta do Usu�rio */
	public function disableMyAccount($GraphiX = 0)
	{
		// Defini��es
		$this->username = ''.USER_USERNAME.'';
		$error_msg = '<center>'.Engine::langVar(39).'</center>';
		
		// Checar Sess�o
		if(SESSION_STATUS != false)
		{
			// Verificar se o usu�rio est� com seu STATUS Ativado
			if(is_numeric(Engine::getUserData($this->username, "STATUS")) == true)
			{
				/* Atualizando Dados na Database
				 * Desativando o Usu�rio do Site */
				if(MySQL::executeQuery("UPDATE users SET status = '$GraphiX' WHERE username = '$this->username'") != 0)
				{
					/* Desativando o Widget do Usu�rio */
					if(MySQL::executeQuery("UPDATE widgets SET status = '$GraphiX' WHERE username = '$this->username'") != false)
					{
						/* Caso ocorra tudo bem ele ser� deslogado do site */
						$this->clearCookies();
						exit;
					}
					else { die($error_msg); }
				} 
				else { die($error_msg); }
			}
			else return;
		}
		else return;
	}
	
	/* Fun��o para Fazer busca de um usu�rio no Site */
	public function serializeSearch($typed)
	{
		/* N�o � preciso checar Sess�o
		 * Sendo que qualquer pessoa pode fazer uma Pesquisa */
		
		// Defini��es
		$workingString = mysql_real_escape_string($typed);
		$this->Message = '';
		
		/* Checando Campo de Pequisa
		 * Se n�mero de caracteres menor que 0, ou vazia, volta mensagem como Erro */
		if(!isset($workingString) || strlen($workingString) < 0 || empty($workingString))
		{
			// Mensagem de Erro
			$this->Message .= '<center><p class="error"><b>'.Engine::langVar(40).'</b> '.Engine::langVar(60).'</p></center>';
		}
		
		/* Comandos Especiais de Exibi��o de Usu�rio
		 * Dispon�vel para 3 idiomas <EN-PT-ES> */
		else if($workingString == "@show_users" || $workingString == "@mostrar_registrados" || $workingString == "@ver_usuarios")
		{
			// Exibe todos os usu�rios cadastrados no Site
			
			/* Fazendo Pesquisa na Database */
			$mysql = "SELECT * FROM users ORDER BY id DESC";
			$mysqlquery = mysql_query($mysql);
			
			if(@mysql_num_rows($mysqlquery) != 0)
			{
				// Exibindo Valores
				while($iii = mysql_fetch_assoc($mysqlquery))
				{
					// Sub-Defini��es
					$Username = $iii['username'];
					$Name = $iii['real_name'];
					$Surname = $iii['real_surname'];
					$Location = $iii['localization'];
					$Image = $iii['photo'];
					
					// Exibindo os Usu�rios
					$this->Message .= "<div class=\"result resultLeft\">";
					$this->Message .= "<div class=\"profilePic\">";
					$this->Message .= '<a href="http://'.SITE_DOMAIN.'/'.$Username.'"><img src="http://'.SITE_DOMAIN.'/images/users/'.$Image.'" alt="'.$Username.'" width="75" /></a>';
					$this->Message .= "</div>";
					$this->Message .= "<div class=\"profile\">";
					$this->Message .= "<ul>";
					$this->Message .= '<li class="username"><a href="http://'.SITE_DOMAIN.'/'.$Username.'"><strong>'.$Username.'</strong></a></li>';
					$this->Message .= '<li class="name">'.$Name.' '.$Surname.'</li>';
					$this->Message .= '<li class="location">'.$Location.'</li>';
					$this->Message .= "<ul>";
					$this->Message .= "</div>";
					$this->Message .= "<div class=\"clear\"></div>";
					$this->Message .= "</div>";
					// Fim de Exibi��o
				}
			}
		}
		else
		{
			/* Fazendo Pesquisa na Database */
			$sql = "SELECT * FROM users WHERE username LIKE '$workingString' OR email LIKE '$workingString' OR real_name LIKE '$workingString' OR  real_surname LIKE '$workingString' AND status = '1' ORDER BY id DESC";
			$query = mysql_query($sql);
			
			// Checa se foi encontrado algo
			if(@mysql_num_rows($query) != 0)
			{
				// Exibindo Valores
				while($ii = mysql_fetch_assoc($query))
				{
					// Sub-Defini��es
					$Username = $ii['username'];
					$Name = $ii['real_name'];
					$Surname = $ii['real_surname'];
					$Location = $ii['localization'];
					$Image = $ii['photo'];
					
					// Exibindo os Usu�rios
					$this->Message .= "<div class=\"result resultLeft\">";
					$this->Message .= "<div class=\"profilePic\">";
					$this->Message .= '<a href="http://'.SITE_DOMAIN.'/'.$Username.'"><img src="http://'.SITE_DOMAIN.'/images/users/'.$Image.'" alt="'.$Username.'" width="75" /></a>';
					$this->Message .= "</div>";
					$this->Message .= "<div class=\"profile\">";
					$this->Message .= "<ul>";
					$this->Message .= '<li class="username"><a href="http://'.SITE_DOMAIN.'/'.$Username.'"><strong>'.$Username.'</strong></a></li>';
					$this->Message .= '<li class="name">'.$Name.' '.$Surname.'</li>';
					$this->Message .= '<li class="location">'.$Location.'</li>';
					$this->Message .= "<ul>";
					$this->Message .= "</div>";
					$this->Message .= "<div class=\"clear\"></div>";
					$this->Message .= "</div>";
					// Fim de Exibi��o
				}
			}
			else
			{
				// Mensagem de Erro
				$this->Message .= '<center><p class="error"><b>'.Engine::langVar(40).'</b> '.Engine::langVar(61).'</p></center>';
			}
		}
		// Retorna a Mensagem
		return $this->Message;
	}
		
	/* Fun��o para codificar ou decodificar toda uma String em rela��o ao HTML */
	public function htmlEncodeDecode($text, $mode, $format = "UTF-8")
	{
		/* [ Modos ]
		 * 0 => Codifica String
		 * 1 => Decodifica String */
		 
		switch($mode)
		{
			// Codificando Caracteres HTML
			case 0:	return htmlentities($text, ENT_QUOTES, $format); break;
			
			// Decodificando Caracteres HTML
			case 1:	return strtr($text, array_flip(get_html_translation_table(HTML_SPECIALCHARS)));	break;
			
		}
		
	}
	
	/* Fun��o para criar uma pergunta que ser� enviada a um usu�rio */
	public function ask($question, $to_user, $anonymous, $jsonENCODE = "SUCCESS", $sqlTable = "questions")
	{
		// Defini��es
		$this->QA_question = Engine::htmlEncodeDecode($question, 0); // Pergunta
		$this->QA_to_user = $to_user; // Para o usu�rio
		$this->QA_anonymous = $anonymous; // Modo An�nimo <0 = N�o / 1 = Sim>
		$this->QA_date = Engine::getCurrentTime("date"); // Tempo <Dia/M�s/Ano>
		$this->QA_status = 0; // Status da Pergunta 0 -> N�o respondida
		$this->QA_ip = ''.USER_IP.''; // Ip do Usu�rio que fez a Pergunta
		$this->QA_time = Engine::getCurrentTime("time"); // Tempo <Horas/Minutos/Segundos>
		
		
		// Verifica Campo de Pergunta
		if(isset($this->QA_question))
		{
			// Verifica Modo de Pergunta
			if($this->QA_anonymous == 0)
			{
				// Checar Sess�o
				if(SESSION_STATUS != false)
				{
					// Usu�rio N�o-An�nimo
					$this->QA_from_user = ''.USER_USERNAME.'';
					$this->QA_anonymous == 0;
				}
			}
			
			else if($this->QA_anonymous == 1)
			{
				// Usu�rio An�nimo
				$this->QA_from_user = "";
				$this->QA_anonymous == 1;
			}
			
			// Checa se O usu�rio da pergunta Existe
			if(Engine::profileUserExists($this->QA_to_user) != 0)
			{
				// Checa se O usu�rio da pergunta est� Ativo
				if(Engine::getUserData($this->QA_to_user, "STATUS") == 1)
				{
					/* In�cio Mensagem MySQL */
					$MySQL_Message =  "INSERT INTO $sqlTable ";
					$MySQL_Message .= "(to_user, question, from_user, answer, status, anonymous, date, ip, time) ";
					$MySQL_Message .= "VALUES ";
					$MySQL_Message .= "('$this->QA_to_user', '$this->QA_question', '$this->QA_from_user', '', '0', '$this->QA_anonymous', '$this->QA_date', '$this->QA_ip', '$this->QA_time')";
					/* T�rmino Mensagem MySQL */
					
					// Inserindo Pergunta na Database
					if(MySQL::executeQuery($MySQL_Message) != 0)
					{
						// JSON Encode - Para retorno de Valor
						header('Content-type: application/json'); 
						echo json_encode($jsonENCODE);
					}
					else { die(''.Engine::langVar(39).''); }
				}
			}			
		}
	}
	
	/* Fun��o para Exibi��o das Perguntas j� respondidas pelo Usu�rio. */
	public function serializeProfileQA($username, $status = 1)
	{
		// Defini��es
		$this->username = $username;
		$this->Message = '';
		
		// Checar Vari�vel
		if(isset($this->username))
		{
			// Checa se O usu�rio Existe
			if(Engine::profileUserExists($this->username) != 0)
			{
				// Checa se O est� Ativo
				if(Engine::getUserData($this->username, "STATUS") == 1)
				{
					// Checando quantas perguntas ele possui na Inbox
					if(Engine::inboxQuestions($this->username, 1) == 0)
					{
						$this->Message .= '<p><center>'.Engine::langVar(62).' '.$this->username.' '.Engine::langVar(63).'</center></p><br>';
					}
					elseif(Engine::inboxQuestions($this->username, 1) > 0)
					{
						/* Fazendo Pesquisa na Database */
						$sql = "SELECT * FROM questions WHERE to_user = '$this->username' AND status = '1' ORDER BY id DESC";
						$query = mysql_query($sql);
						
						// Checa se foi encontrado algo
						if(@mysql_num_rows($query) != 0)
						{
							// Exibindo Valores
							while($ii = mysql_fetch_assoc($query))
							{
								//Sub-Defini��es
								$this->QA_id = $ii['id']; // Id da Pergunta
								$this->QA_to_user = $ii['to_user']; // Para o Usu�rio
								$this->QA_question = $ii['question']; // Pergunta
								$this->QA_from_user = $ii['from_user']; // Do Usu�rio
								$this->QA_answer = $ii['answer']; // Resposta
								$this->QA_status = $ii['status']; // Status da Pergunta
								$this->QA_anonymous = $ii['anonymous']; // Modo An�nimo <0 = N / 1 = S>
								$this->QA_date = $ii['date']; // Data em que foi feita a pergunta
								$this->QA_ip = $ii['ip']; // Ip do Usu�rio que fez a Pergunta
								$this->QA_time = $ii['time']; // Tempo em que foi feita a Pergunta
								
								// Exibindo as Perguntas Respondidas
								$this->Message .= "<div class=\"question\" id=\"question\">";
								$this->Message .= '<h4>'.Engine::htmlEncodeDecode($this->QA_question, 1).'</h4>'; // Tratamento HTML <Pergunta>
								$this->Message .= '<p>'.Engine::htmlEncodeDecode($this->QA_answer, 1).'</p>'; // Tratamento HTML <Resposta>
								$this->Message .= '<p>';
								$this->Message .= "<span id=\"questionInfo\">";
								$this->Message .= ''.Engine::langVar(64).' '.$this->QA_date.' '.Engine::langVar(65).' '.$this->QA_time.'';
								
								// Modo de Pergunta < An�nimo ou N�o >
								switch($this->QA_anonymous)
								{
									// Usu�rio N�o An�nimo
									case 0:
									$this->Message .= ' '.Engine::langVar(66).' <a href="http://'.SITE_DOMAIN.'/'.$this->QA_from_user.'" target="_blank">'.$this->QA_from_user.'</a>  ';
									break;
									
									// Usu�rio An�nimo
									case 1:
									$this->Message .= ' '.Engine::langVar(67).' '.ANONYMOUS.'  ';
									break;
								}
								
								$this->Message .= '</span>';
								
								//Verifica se � o dono do perfil com a sess�o para exibir
								if($this->username == USER_USERNAME && SESSION_STATUS != false)
								{
									// Deletar Pergunta ????
									$this->Message .= '<a href="delete/'.Engine::varCrypt($this->QA_id, 2, 0).'" class="removeResponseLink" style="display:none">('.Engine::langVar(68).')</a>';
								}
								
								$this->Message .= '</p>';
								$this->Message .= '</div>';
								}
							}
						}
					}
				}
			}
			// Retorna Mensagem
			return $this->Message;
	}
	
	/* Fun��o que faz retornar valor de idioma para exibi��o */
	public function langVar($varID)
	{
		// Vari�vel de Classe Global
		global $Session_Template;
		
		// Checar Vari�vel
		if(isset($varID))
		{
			// Checar se � um N�mero
			if(is_int($varID))
			{
				// Retorna Texto do ID inserido
				return $Session_Template->getLang($varID);
			}
		}
	}
	
	/* Fun��o para Deletar uma Pergunta/Resposta */
	public function delete($id)
	{
		// Defini��es
		$this->username = ''.USER_USERNAME.'';
		$this->QA_id = base64_decode($id);
		
		// Checa Vari�vel
		if(isset($this->QA_id))
		{
			// Checar Sess�o
			if(SESSION_STATUS != false)
			{
				// Checar se � um N�mero
				if((is_numeric($this->QA_id)) ? true : false)
				{
					// Verifica se � maior que 0
					if($this->QA_id > 0)
					{
						// Verifica se o ID da Pergunta consta como sendo do Usu�rio Logado
						$sql = "SELECT * FROM questions WHERE id = '$this->QA_id' AND to_user = '$this->username'";
						$query = mysql_query($sql);
						
						// Checa se foi encontrado algo
						if(@mysql_num_rows($query) != 0)
						{
							//Deletando da Database a Pergunta/Resposta
							if(MySQL::executeQuery("DELETE FROM questions WHERE id = '$this->QA_id' AND to_user = '$this->username'") != 0)
							{
								// Redirecionando
								$_SESSION['msg'] = 1;
								header('Location: http://'.SITE_DOMAIN.'/account/inbox');
								exit;
							}
							else { die(''.Engine::langVar(39).''); }
						}
						else
						{
							// Redireciona para Caixa de Perguntas
							$_SESSION['msg'] = 2;
							header('Location: http://'.SITE_DOMAIN.'/account/inbox');
							exit;
						}
					}
					else
					$this->headerIn();
				}
				else
				$this->headerIn();
			}
			else
			$this->headerIn();
		}
		else
		$this->headerIn();
	}
	
	/* Fun��o para Redirecionar para Index */
	public function headerIn($Add)
	{
		// Redirecionando para p�gina
		header('Location: http://'.SITE_DOMAIN.'/'.$Add.'');
	}
	
	/* Fun��o para Responder uma Pergunta */
	public function answer($response, $qa_id, $status = 0)
	{
		// Defini��es
		$this->username = ''.USER_USERNAME.'';
		$this->QA_id = $qa_id;
		$this->QA_answer = Engine::htmlEncodeDecode($response, 1); // Codificando Mensagem
		
		// Checar Sess�o
		if(SESSION_STATUS != false)
		{
			// Checar se Usu�rio Existe
			if(Engine::profileUserExists($this->username) != 0)
			{
				// Checar se Usu�rio est� Ativo
				if(Engine::getUserData($this->username, "STATUS") == 1)
				{
					// Checar se ID � um N�mero
					if((is_numeric($this->QA_id)) ? true : false)
					{
						// Checa se ID � maior que 0
						if($this->QA_id > 0)
						{
							// Checar Campos est�o em Branco
							if($this->QA_answer != "" && strlen($this->QA_answer) > 0)
							{
								// Verifica se Existe a Pergunta e se o Usu�rio Logado � o Dono
								$sql = "SELECT * FROM questions WHERE id = '$this->QA_id' AND to_user = '$this->username' AND status = '$status'";
								$query = mysql_query($sql);
								
								// Checa se foi encontrado algo
								if(@mysql_num_rows($query) != 0)
								{
									//Deletando da Database a Pergunta/Resposta
									if(MySQL::executeQuery("UPDATE questions SET answer = '$this->QA_answer', status = '1' WHERE id = '$this->QA_id'") != 0)
									{
										// Mensagem de Sucesso
										$_SESSION['msg'] = 3;
										// Redireciona
										$this->headerIn("account/inbox");
										exit;
									}
									else { die(''.Engine::langVar(39).''); }
								}
								else
								$this->headerIn("account/inbox");
							}
							else
							{
								// Mensagem de Erro
								$_SESSION['msg'] = 4;
								// Redireciona
								$this->headerIn("account/inbox");
								exit;
							}
						}
						else
						$this->headerIn("account/inbox");
					}
					else
					$this->headerIn("account/inbox");
				}
				else
				$this->headerIn();
			}
			else
			$this->headerIn();
		}
		else
		$this->headerIn();
	}
	
	/* Fun��o para Checar Nome de Usu�rio */
	public function checkAjaxName($intro)
	{
		// Defini��es
		$this->username = $intro; // Nome de Usu�rio Inserido
		$max_lenght = 20; // Tamanho M�ximo de Nome de Usu�rio
		$min_lenght = 3; // Tamanho M�nimo de Nome de Usu�rio
		
		// Checar Tamanhos da String
		if(strlen($this->username) < $min_lenght)
		{
			// Se Nome de Usu�rio for menor que 3 exibe erro.
			$json['error'] = ''.Engine::langVar(69).'';
		}
		else if(strlen($this->username) > $max_lenght)
		{
			// Se Nome de Usu�rio for maior que 20 exibe erro.
			$json['error'] = ''.Engine::langVar(70).'';
		}
		// Nomes Proibidos
		else if($this->username == "At0m" || $this->username == "Leoat0m" || $this->username == "UDontknow" || $this->username == "Askcms" || $this->username == "Leoxgr" || $this->username == "Core" || $this->username == "Images" || $this->username == "Css" || $this->username == "Js" || $this->username == "Housemanager")
		{
			// Exibe proibi��o
			$json['error'] = ''.Engine::langVar(71).'';
		}
		// Checar se Usu�rio j� existe
		else if(Engine::profileUserExists($this->username) != 0)
		{
			// Exibe Erro
			$json['error'] = ''.Engine::langVar(72).'';
		}
		// Checar se caracteres inseridas s�o v�lidas
		else if(strstr($this->username, ' ')!= false || strstr($this->username, ',')!= false || strstr($this->username, '.')!= false || strstr($this->username, '@')!= false)
		{
			$json['error'] = ''.Engine::langVar(73).'';
		}
		// Nome Verificado
		else
		{
			// Exibe Mensagem de Sucesso
			$json['success'] = NULL;
		}
		
		// Retorna Mensagem JSON Codificada
		$encoded = json_encode($json);
		die($encoded);
	}
	
	/* Fun��o para Exibi��o das Perguntas n�o respondidas pelo Usu�rio. */
	public function serializeInboxQA($username, $status = 0)
	{
		// Defini��es
		$this->username = $username;
		$this->Message = '';
		
		// Checar Sess�o -> Pois s�o as quest�es da Inbox
		if(SESSION_STATUS != false)
		{
			// Checa se O usu�rio Existe
			if(Engine::profileUserExists($this->username) != 0)
			{
				// Checa se O est� Ativo
				if(Engine::getUserData($this->username, "STATUS") == 1)
				{
					// Checando quantas perguntas ele possui na Inbox
					if(Engine::inboxQuestions($this->username, 0) == 0)
					{
						$this->Message .= '<br><center><img src="images/empty.png"><br><p>'.Engine::langVar(74).'<br></center>';
					}
					// Se n�mero de perguntas for maior que 0, mostra as mesmas
					else if(Engine::inboxQuestions($this->username, 0) > 0)
					{
						// Cuidado ao mostrar quest�es An�nimas ou N�o
						
						/* Fazendo Pesquisa na Database */
						$sql = "SELECT * FROM questions WHERE to_user LIKE '$this->username' AND status = '$status' ORDER BY id DESC";
						$query = mysql_query($sql);
						
						// Checa se foi encontrado algo
						if(@mysql_num_rows($query) != 0)
						{
							// Exibindo Valores
							while($ii = mysql_fetch_assoc($query))
							{
								// Sub-Defini��es
								$this->QA_id = $ii['id']; // Id da Pergunta
								$this->QA_to_user = $ii['to_user']; // Para o Usu�rio
								$this->QA_question = $ii['question']; // Pergunta
								$this->QA_from_user = $ii['from_user']; // Do Usu�rio
								$this->QA_status = $ii['status']; // Status da Pergunta
								$this->QA_anonymous = $ii['anonymous']; // Modo An�nimo <0 = N / 1 = S>
								$this->QA_date = $ii['date']; // Data em que foi feita a pergunta
								$this->QA_ip = $ii['ip']; // Ip do Usu�rio que fez a Pergunta	
								$this->QA_time = $ii['time']; // Tempo em que foi feita a Pergunta
								
								// Exibindo as Perguntas N�o Respondidas
								// Cuidado -> quest�es anonimas / formatar a pergunta com fun��o HTML
								$this->Message .= "<form method=\"post\" action=\"ajax/answer\">";
								$this->Message .= '<div class="question" id="question'.$this->QA_id.'">';
								$this->Message .= '<div class="questionTools">';
								$this->Message .= '<ul>';
								$this->Message .= '<li class="links delete">';
								$this->Message .= '<a href="delete/'.Engine::varCrypt($this->QA_id, 2, 0).'" class="iconDelete links">'.Engine::langVar(75).'</a>';
								$this->Message .= '</li>';
								$this->Message .= '<li class="links respond">';
								$this->Message .= '<a href="#" onclick="respondQuestion('.$this->QA_id.'); return false;" class="iconRespond links">'.Engine::langVar(76).'</a>';
								$this->Message .= '</li>';
								$this->Message .= '</ul>';
								$this->Message .= '</div>';
								$this->Message .= '<div class="questionText">';
								$this->Message .= '<h4>'.Engine::htmlEncodeDecode($this->QA_question, 1).'</h4>'; // Tratamento do Texto HTML, eu acho que merece prioridade.
								$this->Message .= '<span class="meta">';
								$this->Message .= ''.Engine::langVar(64).' <i>'.$this->QA_date.' '.Engine::langVar(65).' '.$this->QA_time.'</i>';
								// Modo de Pergunta < An�nimo ou N�o >
								switch($this->QA_anonymous)
								{
									// Usu�rio N�o An�nimo
									case 0:
									$this->Message .= ' '.Engine::langVar(66).' <a href="http://'.SITE_DOMAIN.'/'.$this->QA_from_user.'" target="_blank">'.$this->QA_from_user.'</a>';
									break;
									
									// Usu�rio An�nimo
									case 1:
									$this->Message .= ' '.Engine::langVar(67).' '.ANONYMOUS.'';
									break;
								}
								$this->Message .= '</span>';
								$this->Message .= '<img id="question'.$this->QA_id.'Indicator" src="images/indicator.gif" alt="." class="indicator" style="display:none" />';
								$this->Message .= '</div>';
								$this->Message .= '<div class="clear"></div>';
								$this->Message .= '<div class="questionRespond" style="display:none">';
								
								// Cuidado Aqui
								$this->Message .= '<input type="hidden" name="qa_id" id="qa_id" value="'.$this->QA_id.'">';
								$this->Message .= '<textarea rows="4" cols="50" name="response" id="response'.$this->QA_id.'"></textarea>';
								// Cuidado Aqui
								
								$this->Message .= '<div class="questionRespondTools" style="display:none">';
								$this->Message .= '<input type="submit" id="sendResponse'.$this->QA_id.'Button" value="'.Engine::langVar(76).'"  class="questionRespondButton" />';
								$this->Message .= '<img id="sendResponse'.$this->QA_id.'Indicator" src="images/indicator.gif" alt="." class="indicator" style="display:none" />';
								$this->Message .= '<a href="#" onclick="respondCancel(); return false;" class="questionRespondCancel">'.Engine::langVar(77).'</a>';
								$this->Message .= '</div>';
								$this->Message .= '</div>';
								$this->Message .= '</div>';
								$this->Message .= '</form>';
								// Fim de Exibi��o
							}
						}
					}
				}
			}
			// Retorna Mensagem
			return $this->Message;
		}
	}
	
	/* Fun��o para Criar conta de Usu�rio */
	public function createUserAccount($username, $password, $name, $surname, $email)
	{
		/* Como o Ajax j� faz todas as medidas de seguran�a necess�rias n�o � preciso repeti-las aqui, mas devia :/
		 * Apenas insere os dados normalmente e depois loga o usu�rio automaticamente */
		 
		 // Deifini��es Iniciais de Conta
		 $this->username = $username; // Nome de Usu�rio
		 $this->password = Engine::varCrypt(Engine::varCrypt(Engine::varCrypt($password, "MD5", 0), 2, 0), "SHA1", 0); // Senha do Usu�rio
		 $this->name = $name; // Nome Verdadeiro
		 $this->surname = $surname; // Sobrenome Verdadeiro
		 $this->rank = 0; // Rank do Usu�rio
		 $this->email = $email; // Email do Usu�rio
		 $this->website = 'http://'.SITE_DOMAIN.'/'.$this->username.''; // Website do Usu�rio
		 $this->location = ''.Engine::langVar(78).''; // Localiza��o do Usu�rio
		 $this->about_me = ''.Engine::langVar(79).''; // Sobre mim
		 $this->what_ask = ''.Engine::langVar(80).''; // O que perguntar ?
		 $this->theme = "default"; // Tema Inicial
		 $this->photo = "photo_default.png"; // Foto Inicial Padr�o
		 $this->status = 1; // Status do Usu�rio
		 $this->ip = ''.USER_IP.''; // Endere�o de IP do Usu�rio <Quest�es de Seguran�a>
		 $this->pass_code = Engine::_randomVar(15, true, true); // C�digo para Gera��o de Nova Senha em caso de Perda
		 $this->protection = 1; // Modo An�nimo -> Permitir ? Sim
		 $this->reg_date = Engine::getCurrentTime("date"); // Data de Registro
		 
		 // Checando tamanho do Email
		 if(!empty($this->email) && strlen($this->email) > 0)
		 {
			 // Checando se Email j� est� registrado
			 if(Engine::email_Already_Exists($this->email) == "Email Exists")
			 {
				 // Exibe Mensagem de Erro
				 $_SESSION['msg'] = 1;
				 
				 // Redireciona
				 $this->headerIn("account/signup");
				 exit;
			 }
		 }
		 
		 // Defini��es Inicias de Widget
		 $this->widget_size = "Large"; // Tamanho do Widget
		 $this->widget_background_color = "#FFFFFF"; // Cor do Fundo
		 $this->widget_foreground_color = "#000000"; // Cor da Letra
		 $this->widget_height = 275; // Altura
		 $this->widget_width = 400; // Largura
		 $this->widget_status = 1; // Ativado ou N�o ?
		 
		 /* Mensagem MySQL - Usu�rio */
		 $MySQL_Message["user"] = "INSERT INTO users ";
		 $MySQL_Message["user"] .= "(username, password, real_name, real_surname, rank, email, website, localization, bio, what_ask, theme, photo, status, ip, password_key, anonymous_view, reg_date) ";
		 $MySQL_Message["user"] .= "VALUES ";;
		 $MySQL_Message["user"] .= "('$this->username', '$this->password', '$this->name', '$this->surname', '$this->rank', '$this->email', ";
		 $MySQL_Message["user"] .= "'$this->website', '$this->location', '$this->about_me', '$this->what_ask', '$this->theme', '$this->photo', ";
		 $MySQL_Message["user"] .= "'$this->status', '$this->ip', '$this->pass_code', '$this->protection', '$this->reg_date')";
		 /* Mensagem MySQL - Usu�rio */
		 		 
		 /* Mensagem MySQL - Widget */
		 $MySQL_Message["widget"] = "INSERT INTO widgets ";
		 $MySQL_Message["widget"] .= "(username, size, background_color, foreground_color, height, width, status) ";
		 $MySQL_Message["widget"] .= "VALUES ";
		 $MySQL_Message["widget"] .= "('$this->username', '$this->widget_size', '$this->widget_background_color', '$this->widget_foreground_color', '$this->widget_height', '$this->widget_width', '$this->widget_status')";
		 /* Mensagem MySQL - Widget */
		 
		 /* Mensagem MySQL - Perguntas Iniciais */
		 $MySQL_Message["questions"] = 'INSERT INTO questions ';
		 $MySQL_Message["questions"] .= '(to_user, question, from_user, answer, status, anonymous, date, ip, time) ';
		 $MySQL_Message["questions"] .= 'VALUES ';
		 $MySQL_Message["questions"] .= '("'.$this->username.'", "'.Engine::langVar(81).'", "'.SITE_NAME.'", "", "0", "1", "'.Engine::getCurrentTime("date").'", "'.USER_IP.'", "'.Engine::getCurrentTime("time").'")';
		 /* Mensagem MySQL - Perguntas Iniciais */
		 
		 // Adicionar Dados do Usu�rio
		 if(MySQL::executeQuery($MySQL_Message["user"]) != 0)
		 {
			 // Adicionar Widget
			 if(MySQL::executeQuery($MySQL_Message["widget"]) != 0)
			 {
				 // Adicionar 3 Perguntas Inicias
				 if(MySQL::executeQuery($MySQL_Message["questions"]) != 0)
				 {
					 // Checar Sess�o
					 if(SESSION_STATUS != true)
					 {
						 // Tudo feito, agora logando o usu�rio no Site
						 $this->checkCookies($this->username, $password);
						 exit;
					 }
				 }
			 }
		 }
	}
	
	/* Mostrar Menu do Painel de Administra��o */
	public function serializeHmTabs($in_tab)
	{
		    // In�cio Mensagem
			$this->Message = '<ul id="topTabs">';
			
			// Tab 1
			if($in_tab == "tab-[1]") { $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
			$this->Message .= '<a href="http://'.SITE_DOMAIN.'/housemanager/index.php">'.Engine::langVar(83).'</a>';
			$this->Message .= '</li>';
			
			// Tab 2
			if($in_tab == "tab-[2]") { $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
			$this->Message .= '<a href="http://'.SITE_DOMAIN.'/housemanager/site_settings.php">'.Engine::langVar(84).'</a></li>';
			$this->Message .= '</li>';
			
			// Tab 3
			if($in_tab == "tab-[3]") { $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
			$this->Message .= '<a href="http://'.SITE_DOMAIN.'/housemanager/ranks.php">'.Engine::langVar(85).'</a></li>';
			$this->Message .= '</li>';
			
			// Tab 4
			if($in_tab == "tab-[4]") { $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
			$this->Message .= '<a href="http://'.SITE_DOMAIN.'/housemanager/manage_users.php">'.Engine::langVar(86).'</a></li>';
			$this->Message .= '</li>';
			
			// Tab 5
			if($in_tab == "tab-[5]") { $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
			$this->Message .= '<a href="http://'.SITE_DOMAIN.'/housemanager/manage_questions.php">'.Engine::langVar(87).'</a></li>';
			$this->Message .= '</li>';
			
			// Tab 6 - Sinceramente, pe�o que n�o removam essa parte dos cr�dtios...
			if($in_tab == "tab-[6]") { $this->Message .= '<li class="selected">'; } else { $this->Message .= '<li>'; }
			$this->Message .= '<a href="http://'.SITE_DOMAIN.'/housemanager/askcms.php">'.Engine::langVar(399).'</a></li>';
			$this->Message .= '</li>';
			
			// Fim da Mensagem
			$this->Message .= '</ul>';
	
		// Retornar Mensagem
		return $this->Message;
	}	
	
	/* Atualizar dados de Configura��es de Site */
	public function updateSiteSettings($site_name, $keywords, $description, $site_domain, $language, $maintenance)
	{
		// Verificar Sess�o
		if(SESSION_STATUS != false)
		{
			// Verificar Direitos de Edi��o de Dadoss
			if(Engine::userHasRights("EDIT_SITE_SETTINGS") != false)
			{
				/* In�cio Mensagem MySQL*/
				$MySQL_Message = "UPDATE site_config SET ";
				$MySQL_Message .= "website_name = '$site_name', website_domain = '$site_domain', website_keywords = '$keywords', website_description = '$description', website_language = '$language', website_maintenance  = '$maintenance'";
				/* Fim Mensagem MySQL */
				
				// Atualizando Database
				if(MySQL::executeQuery($MySQL_Message) != 0)
				{
					// Inicia Sess�o de Mensagem
					$_SESSION['msg'] = 1;
					
					// Redirecionando
					$this->headerIn("housemanager/site_settings.php");
					exit;
				}
				else { die(''.Engine::langVar(39).''); }
			}
		}
	}
	
	/* Fun��o para Exibir todas as Perguntas feitas no Site */
	public function serializeHmQuestions()
	{
		// Defini��es
		$this->Message = '';
		
		// Verificar Sess�o
		if(SESSION_STATUS != false)
		{
			// Verificar Direitos
			if(Engine::userHasRights("VIEW_QA") != false)
			{
				// Pesquisa no Banco de Daddos
				$sql = "SELECT * FROM questions ORDER BY id DESC";
				$query = mysql_query($sql);
				
				// N�mero de Perguntas Ativas <Respondidas ou N�o>
				if(@mysql_num_rows($query) != 0)
				{
					// Mensagem HTML de In�cio
					$this->Message .= '<table width="100%" border="0">';
					$this->Message .= '<tr>';
					$this->Message .= '<td width="10%" align="center"><b>'.Engine::langVar(51).'</b></td>';
					$this->Message .= '<td width="50%" align="center"><b>'.Engine::langVar(87).'</b></td>';
					$this->Message .= '<td width="35%" align="center"><b>'.Engine::langVar(88).'</b></td>';
					$this->Message .= '<td width="5%"></td>';
					$this->Message .= '</tr>';
					
					// Exibindo Resultados/Perguntas
					while($ii = mysql_fetch_assoc($query))
					{
						// Verificar Modo An�nimo da Pergunta
						switch($ii["anonymous"])
						{
							// Modo An�nimo Desativado
							case 0:
							$from_user = $ii["from_user"];
							break;
							
							// Modo An�nimo Ativado
							case 1:
							$from_user = ''.ANONYMOUS.'';
							break;
						}
						
						$this->Message .= '<tr>';
						$this->Message .= '<td width="10%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$ii["id"].'</td>';
						$this->Message .= '<td width="50%" valign="top" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$ii["question"].'</td>';
						$this->Message .= '<td width="35%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">';
						$this->Message .= ''.Engine::langVar(89).' '.$from_user.' '.Engine::langVar(90).' '.$ii["to_user"].'<br />';
						$this->Message .= ''.Engine::langVar(91).' '.$ii["date"].'        </td>';
						$this->Message .= '<td width="5%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">';
						$this->Message .= '<table>';
						$this->Message .= '<tr>';
						$this->Message .= '<td><a href="housemanager/delete_question.php?id='.$ii["id"].'"><img src="images/bin.png"></a></td>';
						$this->Message .= '</tr>';
						$this->Message .= '</table>';
						$this->Message .= '</td>';
						$this->Message .= '</tr>';
					}
					
					//Mensagem HTML do Final
					$this->Message .= '</table>';
					
				}
				
				// N�o existe Pergunta
				else
				{
					// Mensagem de Erro
					$this->Message .= '<font color="red"><p><center>'.Engine::langVar(92).'</center><p></font>';
				}
			}
		}
		
		// Retorna a Mensagem
		return $this->Message;
	}
	
	/* Fun��o para deletar uma pergunta sendo Administrador */
	public function deleteHmQuestion($q_id, $A = "SELECT", $B = "DELETE FROM")
	{
		// Checa Sess�o
		if(SESSION_STATUS != false)
		{
			// Checha Direitos
			if(Engine::userHasRights("DELETE_QA") != false || Engine::userHasRights("SUPREME_COMMANDS"))
			{
				// Checa Vari�vel e Valor
				if(isset($q_id) && is_numeric($q_id))
				{
					// Fazer Pesquisa na Database
					$sql = "$A * FROM questions WHERE id = '$q_id' LIMIT 1";
					$query = mysql_query($sql);
					
					// H� alguma pergunta com este ID ?
					if(@mysql_num_rows($query) != 0)
					{
						// Deleta Pergunta
						if(MySQL::executeQuery("$B questions WHERE id = '$q_id'") != 0)
						{
							// Exibe Mensagem de Sucesso
							$_SESSION['msg'] = 1;
							
							// Redireciona
							$this->headerIn("housemanager/manage_questions.php");
							exit;
						}
						else { die(''.Engine::langVar(39).''); }
					}
					
					// N�o existe pergunta com este ID
					else
					{
						// Exibe Mensagem de Erro
						$_SESSION['msg'] = 2;
						
						// Redireciona
						$this->headerIn("housemanager/manage_questions.php");
						exit;
					}
				}
			}
		}
	}
	
	/* Retorna Nome do Usu�rio pelo ID */
	public function getUsernameByID($uID)
	{
		// Checar Vari�vel
		if(isset($uID) && is_numeric($uID))
		{
			// Mysql Stuff
			$sql = @mysql_query("SELECT * FROM users WHERE id = '$uID'") or die(mysql_error());
			$readData = @mysql_fetch_assoc($sql);
			
			// Retorna Nome do Usu�rio
			return $readData["username"];
		}
	}
	
	/* Fun��o para Deletar um Usu�rio do Site atrav�s do Painel de Administra��o */
	public function deleteHmUser($u_id, $A = "SELECT", $B = "DELETE FROM")
	{
		// Retorna o Nome do Usu�rio pelo ID Bruto dele
		$this->username = Engine::getUsernameByID($u_id);
		
		// Checa Sess�o
		if(SESSION_STATUS != false)
		{
			// Checa Direitos
			if(Engine::userHasRights("DELETE_USER") != false || Engine::userHasRights("SUPREME_COMMANDS"))
			{
				// Checa Vari�vel e Valor
				if(isset($u_id) && is_numeric($u_id))
				{
					// Fazer Pesquisa na Database
					$sql = "$A * FROM users WHERE id = '$u_id' LIMIT 1";
					$query = mysql_query($sql);
					
					// H� algum usu�rio com este ID ?
					if(@mysql_num_rows($query) != 0)
					{
						// Deleta Usu�rio
						if(MySQL::executeQuery("$B users WHERE id = '$u_id'") != 0)
						{							
							// Deleta Widget pelo Nome de Usu�rio
							if(MySQL::executeQuery("DELETE FROM widgets WHERE username = '$this->username'") != 0)
							{
								// Exibe Mensagem de Sucesso
								$_SESSION['msg'] = 1;
								// Redireciona
								
								$this->headerIn("housemanager/manage_users.php");
								exit;
							}
						}
						else { die(''.Engine::langVar(39).''); }
					}
					
					// N�o existe pergunta com este ID
					else
					{
						// Exibe Mensagem de Erro
						$_SESSION['msg'] = 2;
						
						// Redireciona
						$this->headerIn("housemanager/manage_users.php");
						exit;
					}
				}
			}
		}
	}
	
	/* Fun��o para Atualizar os Dados de Conta de Algum usu�rio atrav�s do Painel de Administra��o */
	public function updateHmUA($id, $name, $surname, $email, $pass_key)
	{
		/* N�o acho que precisa de verifica��o dos dados inseridos, os Administradores/Moderadores
		 * devem zelar por inserir dados v�lidos que n�o prejudiquem a estadia do usu�rio e o pr�prio site.
		 * Por isso � feito apenas a atualiza��o dos dados na database, visto que j� foram feitas valida��es de seguran�a anteriormente.  */
		
		// Defini��es
		$this->id = $id;
		$this->name = $name;
		$this->surname = $surname;
		$this->email = $email;
		$this->pass_code = $pass_key;
		
		// Checar Vari�veis
		if(isset($this->id) && isset($this->name) && isset($this->surname) && isset($this->email) && isset($this->pass_code))
		{
			// Checar Sess�o
			if(SESSION_STATUS != false)
			{
				// Checar Direitos
				if(Engine::userHasRights("EDIT_USER_ACCOUNT") != false || Engine::userHasRights("SUPREME_COMMANDS"))
				{
					/* In�cio - Mensagem MySQL */
					$MySQL_Message = "UPDATE users SET ";
					$MySQL_Message .= "real_name = '$this->name', ";
					$MySQL_Message .= "real_surname = '$this->surname', ";
					$MySQL_Message .= "email = '$this->email', ";
					$MySQL_Message .= "password_key = '$this->pass_code' ";
					$MySQL_Message .= "WHERE id = '$this->id'";
					/* Fim - Mensagem MySQL */
					
					// Executa o Comando MySQL para Atualizar os Dados
					if(MySQL::executeQuery($MySQL_Message) != 0)
					{
						// Mensagem de Sucesso
						$_SESSION['msg'] = 1;
						
						// Redirecionar
						$this->headerIn("housemanager/edit_user_account.php?id=$this->id");
						exit;
					}
					else { die("MySQL Error !"); }
				}
			}
		}
	}
	
	/* Fun��o para Atualizar os Dados de Perfil de algum usu�rio pelo Painel de Administra��o */
	public function updateHmUP($id, $website, $location, $bio, $ask)
	{
		/* N�o acho que precisa de verifica��o dos dados inseridos, os Administradores/Moderadores
		 * devem zelar por inserir dados v�lidos que n�o prejudiquem a estadia do usu�rio e o pr�prio site.
		 * Por isso � feito apenas a atualiza��o dos dados na database, visto que j� foram feitas valida��es de seguran�a anteriormente.  */
		 
		// Defini��es
		$this->id = $id;
		$this->website = $website;
		$this->location = $location;
		$this->about_me = $bio;
		$this->what_ask = $ask;
		
		// Checar Vari�veis
		if(isset($this->id) && isset($this->website) && isset($this->location) && isset($this->about_me) && isset($this->what_ask))
		{
			// Checar Sess�o
			if(SESSION_STATUS != false)
			{
				// Checar Direitos
				if(Engine::userHasRights("EDIT_USER_PROFILE") != false || Engine::userHasRights("SUPREME_COMMANDS"))
				{
					/* In�cio - Mensagem MySQL */
					$MySQL_Message = "UPDATE users SET ";
					$MySQL_Message .= "website = '$this->website', ";
					$MySQL_Message .= "localization = '$this->location', ";
					$MySQL_Message .= "bio = '$this->about_me', ";
					$MySQL_Message .= "what_ask = '$this->what_ask' ";
					$MySQL_Message .= "WHERE id = '$this->id'";
					/* Fim - Mensagem MySQL */
					
					// Executa o Comando MySQL para Atualizar os Dados
					if(MySQL::executeQuery($MySQL_Message) != 0)
					{
						// Mensagem de Sucesso
						$_SESSION['msg'] = 1;
						
						// Redirecionar
						$this->headerIn("housemanager/edit_user_profile.php?id=$this->id");
						exit;
					}
					else { die(''.Engine::langVar(39).''); }
				}
			}
		}
	}
	
	/* Fun��o para Exibir os Administradores e Moderadores do Site */
	public function serializeHmMasters($modeView)
	{
		// Defini��es
		$this->Message = '';
		
		// Checar Sess�o
		if(SESSION_STATUS)
		{
			// Checar Direitos
			if(Engine::userHasRights("VIEW_RANKS") != false || Engine::userHasRights("SUPREME_COMMANDS"))
			{
				// Administradores
				if($modeView == 2)
				{
					$rank = 2;
				}
				else if($modeView == 1)
				{
					$rank = 1;
				}
				
					// Pesquisa no Banco de Dados
					$sql = "SELECT * FROM users WHERE rank = '$rank' ORDER BY id DESC";
					$query = mysql_query($sql);
				
				// N�mero de ADM/MOD
				if(@mysql_num_rows($query) != 0)
				{
					// Se for Adm mostra o In�cio de Informa��es das Tabelas sen�o, n�o mostra
					if($modeView == 2)
					{
						// Mensagem HTML de In�cio
						$this->Message .= '<table width="100%" border="0">';
						$this->Message .= '<tr>';
						$this->Message .= '<td width="10%" align="center"><b>'.Engine::langVar(51).'</b></td>';
						$this->Message .= '<td width="50%" align="center"><b>'.Engine::langVar(93).'</b></td>';
						$this->Message .= '<td width="35%" align="center"><b>'.Engine::langVar(94).'</b></td>';
						$this->Message .= '<td width="35%" align="center"><b>'.Engine::langVar(95).'</b></td>';
						$this->Message .= '<td width="5%"></td>';
						$this->Message .= '</tr>';
					}
					
					// Exibindo Resultados/Usu�rios Especiais
					while($ii = mysql_fetch_assoc($query))
					{
						// Verificar Rank de Usu�rios Especiais
						switch($ii["rank"])
						{
							// O usu�rio � um Moderador
							case 1:
							$userRank = ''.Engine::langVar(96).'';
							break;
							
							// O usu�rio � um Administrador
							case 2:
							$userRank = ''.Engine::langVar(97).'';
							break;
						}
						
						$this->Message .= '<tr>';
						$this->Message .= '<td width="10%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$ii["id"].'</td>';	$this->Message .= '</td>';
						$this->Message .= '<td width="10%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$ii["username"].'</td>';	$this->Message .= '</td>';
						$this->Message .= '<td width="10%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;">'.$userRank.'</td>';	$this->Message .= '</td>';
						$this->Message .= '<td width="10%" align="center" style="border-top: 1px dashed grey; padding: 10px 10px 10px 10px;"><a href="housemanager/ranks.php?act=remove&id='.$ii["id"].'"><font color="red"><b>('.Engine::langVar(95).')</b></font></a></td>';	$this->Message .= '</td>';
						$this->Message .= '</tr>';
						
					}
					
					/* Final do Html */
					
					// Se encontrar o Mod, exibe Html Final
					if($modeView == 1 && @mysql_num_rows($query) > 0)
					{
						$this->Message .= '</table>';
					}
					
				}
				else
				{
					/* A tag </table> deve ser exibida no SerializeHmMasters2 -> Mods, visto que � o �ltimo c�digo a ser adicionado. */
					
					// Se n�o encontrar nenhum MOD, exibe HTML Final
					if($modeView == 1 && @mysql_num_rows($query) == 0)
					{
						$this->Message .= '</table>';
					}
					
					/* Mensagem de Erro */
					if($modeView != 1)
					{
						// Exibe Mensagem de Erro
						$this->Message .= '<font color="red"><p><center>'.Engine::langVar(98).'</center><p></font>';
					}
				}
				
			}
		}
		
		// Retorna Mensagem
		return $this->Message;
	}
	
	/* Fun��o para Remover Cargo de Usu�rio */
	public function removeHmRank($id)
	{
		// Defini��es
		$this->id = $id;
		$this->username = Engine::getUsernameByID($this->id); // Retorna o Nome do Usu�rio pelo ID Bruto dele
		
		// Checar Sess�o
		if(SESSION_STATUS != false)
		{
			// Checar Direitos
			if(Engine::userHasRights("TAKE_RANK") != false || Engine::userHasRights("SUPREME_COMMANDS"))
			{
				//  Verificar se ID � n�mero
				if(is_numeric($this->id))
				{
					// Checar se Usu�rio existe e possui algum cargo, se sim, d� cargo 0 sen�o mensagem de erro.
					if(Engine::profileUserExists($this->username) != 0 && Engine::getUserData($this->username, "RANK") == 2 || Engine::getUserData($this->username, "RANK") == 1)
					{
						// Remover Cargo <MySQL> -> Para 0
						if(MySQL::executeQuery("UPDATE users SET rank = '0' WHERE id = '$this->id'") != 0)
						{
							// Mensagem de Sucesso
							$_SESSION['msg'] = 2;
							
							// Redireciona para P�gina
							$this->headerIn("housemanager/ranks.php");
							exit;
						}
					}
					// Sen�o ?
					else
					{
						// Mensagem de Erro
						$_SESSION['msg'] = 4;
						
						// Redireciona para P�gina
						$this->headerIn("housemanager/ranks.php");
						exit;
					}
				}
			}
		}
	}
	
	/* Fun��o para Adicionar um Cargo a algum usu�rio pelo Painel de Administra��o */
	public function addHmRank($id, $give_rank)
	{
		// Defini��es
		$this->id = $id;
		$this->rank = $give_rank;
		$this->username = Engine::getUsernameByID($this->id); // Retorna o Nome do Usu�rio pelo ID Bruto dele
		
		if(empty($this->id))
		{
			// Mensagem de Erro
			$_SESSION['msg'] = 5;
			
			// Redireciona para P�gina
			$this->headerIn("housemanager/ranks.php");
			exit;
		}
		
		// Checar Sess�o
		if(SESSION_STATUS != false)
		{
			// Checar Direitos
			if(Engine::userHasRights("GIVE_RANK") != false || Engine::userHasRights("SUPREME_COMMANDS"))
			{
				//  Verificar se ID � n�mero
				if(is_numeric($this->id))
				{
					// Checar se Usu�rio possui rank 0
					if(Engine::profileUserExists($this->username) != 0 && Engine::getUserData($this->username, "RANK") == 0)
					{
						// Adiciona Cargo <MySQL> -> Que o ADM escolheu
						if(MySQL::executeQuery("UPDATE users SET rank = '$this->rank' WHERE id = '$this->id'") != 0)
						{
							// Mensagem de Sucesso
							$_SESSION['msg'] = 1;
							
							// Redireciona para P�gina
							$this->headerIn("housemanager/ranks.php");
							exit;
						}
					}
					// Sen�o ?
					else
					{
						// Mensagem de Erro
						$_SESSION['msg'] = 3;
						
						// Redireciona para P�gina
						$this->headerIn("housemanager/ranks.php");
						exit;
					}
				}
			}
		}
	}
	
	/* Fun��o para checar se existe um usu�rio com o Email inserido */
	public function email_Already_Exists($email)
	{
		// Defini��es
		$this->email = $email;
		
		// Checar Vari�vel
		if(isset($this->email) === true)
		{
			// Checar Database
			$result = @mysql_query("SELECT * FROM users WHERE email = '$this->email'");
			
			// Retornar Resultados
			if (@mysql_num_rows($result) != 0)
			{
				// Email j� existe
				return "Email Exists";
			}
			else
			{
				// Email n�o existe
				return "Email Avaliable";
			}
		}
	}
}
?>