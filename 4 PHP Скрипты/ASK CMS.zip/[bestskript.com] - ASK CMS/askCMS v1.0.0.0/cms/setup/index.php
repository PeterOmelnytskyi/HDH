<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/
 
error_reporting(0);
ini_set('display_errors', 0);

/////////////////////////////////// Fun��es ///////////////////////////////////

/* Fun��o para exibir partes do HTML */
function htmlStuff($mode)
{
	if(empty($mode))
	{
		return '';
	}
	
	$mode = strtolower($mode);
	$message = '';
	
	if(isset($mode))
	{
		if($mode == "header")
		{
			$message .= "<html>";
			$message .= "<head>";
			$message .= "<title>askCMS - Instala��o (Vers�o PT-BR)</title>";
		}
		elseif($mode == "css")
		{
			require_once 'css.txt';
		}
		elseif($mode == "continue_body")
		{
			$message .= "</head>";
			$message .= "<body>";
			$message .= "<div class=\"w\">";
			$message .= "<div class=\"i\">";
			$message .= "<h1>askCMS - Instala��o</h1>";
			$message .= "<p>";
		}
		elseif($mode == "final")
		{
			$message .= "<center>";
			for ($i = 0; $i <= 63; $i++) {	$message .= "_"; }
			$message .= "<br>";
			$message .= '<a href="http://at0m.com.nu" target="_blank">at0m</a> ';
			$message .= "&copy; 2012 - http://at0m.com.nu";
			$message .= "</center>";
			$message .= "</div>";
			$message .= "<br />";
			$message .= "</div>";
			$message .= "</body>";
			$message .= "</html>";
		}
		
		if($mode != "css")
		{
			return $message;
		}
	}
}

/* Carregando Fun��es de Design */
echo(htmlStuff("header")); // Header
htmlStuff("css"); // Css
echo(htmlStuff("continue_body")); // Body
?>
			askCMS - Formspring Clone Project</em>
		</p>
        <li><b>Selecione seu Idioma</b>
        </li>
		<p>
        O primeiro passo para instalar a askCMS � escolher o Idioma.<br>Esta vers�o � a Brasileira, e est� dispon�vel como linguagem do Instalador o idioma Portugu�s-Brasileiro. Em breve voc� poder� alterar a linguagem da CMS se quiser.
		<p>
        <center>
        <br>
        Clique na Imagem para Iniciar a Instala��o<br><h3><a href="install_pt.php?step=1"><img src="../images/setup/brazil.png"><br>Portugu�s-Brasileiro</a></h3>
        </center>
        <br>
<?php // Final HTML
echo(htmlStuff("final")); ?>