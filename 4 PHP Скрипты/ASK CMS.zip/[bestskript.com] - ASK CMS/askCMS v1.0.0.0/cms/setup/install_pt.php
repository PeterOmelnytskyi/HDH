<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo "At0m" Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo "At0m" Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/
 
error_reporting(0);
ini_set('display_errors', 0);

/////////////////////////////////// Vari�veis ///////////////////////////////////
/* Defini��es */
$get["step"] = isset($_GET["step"]) ? strtolower($_GET["step"]) : FALSE; // Passo de Instala��o
$get["action"] = isset($_GET["action"]) ? strtolower($_GET["action"]) : FALSE; // A��o da Instala��o
$blocked["names"] = array('Askcms', 'At0m', 'UDontknow', 'Leoxgr', 'Css', 'Js', 'Images', 'Housemanager', 'Core');

//////////////////////////////////////////////////////////////////////////////////

// Verifica se Passo � 0
if(is_numeric($get["step"]) == false)
{
	// Redireciona para o 1� Passo
	header("Location: install_pt.php?step=1");
}

/////////////////////////////////// Fun��es ///////////////////////////////////

/* Fun��o para gerar N�meros Aleart�rios*/
function _randomVar($length, $numbers, $upper)
	{
		if (1 > $length) $length = 8;
		$chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$numChars = 62;
		
		if (!$numbers)
		{
			$numChars = 52;
			$chars = substr($chars, 10, $numChars);
		}
			
			if (!$upper)
			{
				$numChars -= 26;
				$chars = substr($chars, 0, $numChars);
			}
				
				$string = '';
				for ($i = 0; $i < $length; $i++)
				{
					$string .= $chars[mt_rand(0, $numChars - 1)];
				}
					
			return $string;
					
}

/* Fun��o para configurar site em modo prim�rio */
function updateWeb($wName, $wUrl)
{
	// Arquivo de Condigura��o
	include("../core/mysql.config.php");
	
	// Conex�es
	$sql = @mysql_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);
	$db = @mysql_select_db(DB_NAME);
	
	// Checagem
	if($sql && $db)
	{
		// Executando
		$web_query = mysql_query("UPDATE site_config SET website_name = '$wName', website_domain = '$wUrl', website_language = 'pt'");
		
		// Tudo certo ?
		if($web_query)
		{
			// Redirecionando para o passo 4
			header("Location: install_pt.php?step=4");
		}
		
	}
	
}

/* Fun��o para Criar Conta de Administrador */
function createMyAdmin($username, $password, $name, $email)
{
	// Arquivo de Condigura��o
	include("../core/mysql.config.php");
	
	// Conex�es
	$sql = @mysql_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD);
	$db = @mysql_select_db(DB_NAME);
	
	// Checagem
	if($sql && $db)
	{
		// Formatando valores
		$username = ucfirst(strtolower($username)); // Nome de Usu�rio ADM
		$password = sha1(base64_encode(md5($password))); // Senha do Usu�rio ADM
		$name = ucfirst(strtolower($name)); // Nome do Usu�rio
		$IP_ADD = getenv("REMOTE_ADDR");
		$r_pass = _randomVar(15, true, true);
		$date = date("d-m-Y");
		
		/* Mensagem MySQL - Usu�rio */
		 $MySQL_Message["user"] = "INSERT INTO users ";
		 $MySQL_Message["user"] .= "(username, password, real_name, real_surname, rank, email, website, localization, bio, what_ask, theme, photo, status, ip, password_key, anonymous_view, reg_date) ";
		 $MySQL_Message["user"] .= "VALUES ";;
		 $MySQL_Message["user"] .= "('$username', '$password', '$name', '', '2', '$email', ";
		 $MySQL_Message["user"] .= "'http://www.mywebsite.com', 'Brazil', 'askCMS - :)', 'Pergunta me ?', 'default', 'photo_default.png', ";
		 $MySQL_Message["user"] .= "'1', '$IP_ADD', '$r_pass', '1', '$date')";
		/* Mensagem SQL */
		
		/* Mensagem MySQL - Widget */
		 $MySQL_Message["widget"] = "INSERT INTO widgets ";
		 $MySQL_Message["widget"] .= "(username, size, background_color, foreground_color, height, width, status) ";
		 $MySQL_Message["widget"] .= "VALUES ";
		 $MySQL_Message["widget"] .= "('$username', 'Large', '#FFFFFF', '#000000', '275', '400', '1')";
		 /* Mensagem MySQL - Widget */
		
		// Executando
		$user_query = mysql_query($MySQL_Message["user"]);
		$widget_query = mysql_query($MySQL_Message["widget"]);
		
		// Tudo certo ?
		if($user_query && $widget_query)
		{
			// Redireciona para 3� Passo
			header("Location: install_pt.php?step=3");
		}
	}
	
}

/* Fun��o para mostrar um erro */
function bruteError()
{
	// Mensagem de Erro
	return '<p><h3>Oops! Ocorreu um Erro !</h3>Este passo de instala��o n�o existe na askCMS ! <a href="install_pt.php?step=1">Clique Aqui</a> para voltar ao primeiro passo de instala��o.';
}

/* Fun��o para criar o arquivo de configura��o */
function createConfig($dbServer, $dbUser, $dbPass, $dbDatabase)
{
	$save = "<?php
/*==========================================================================\
| askCMS - Social Network Questions Content Managment System                |
| Developed by: Leo 'At0m' Xgr (c) 2012 - http://at0m.com.nu                |
| ========================================================================= |
| Attention: Do not Remove the Official Credits of The Developer.           |
| ========================================================================= |
| Copyright (c) 2012 - Leo 'At0m' Xgr. - All Rights Reserved.               |
| http://at0m.com.nu / at0m@live.com                                        |
| ========================================================================= |
| This program is FREE SOFTWARE: you can redistribute it and/or modify      |
| it under the terms of the GNU General Public License as published by      |
| the Free Software Foundation, either version 3 of the License, or         |
| (at your option) any later version.                                       |
| ========================================================================= |
| This program is distributed in the hope that it will be useful,           |
| but WITHOUT ANY WARRANTY; without even the implied warranty of            |
| MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             |
| GNU General Public License for more details.                              |
\==========================================================================*/

###########################################################
## Dados de acesso ao BANCO DE DADOS vem aqui. N�o erre. ##
###########################################################

	/* Nome do Host */
	define('DB_SERVER', '$dbServer');

	/* Nome de Usu�rio */
	define('DB_USERNAME', '$dbUser');
	
	/* Senha */
	define('DB_PASSWORD', '$dbPass');
	
	 /* Nome da Database */
	define('DB_NAME', '$dbDatabase');
	
?>";

$openFile= fopen("../core/mysql.config.php","w");
fwrite($openFile,"$save");
fclose($openFile);
}

/* Fun��o para exibir partes do HTML */
function htmlStuff($mode)
{
	if(empty($mode))
	{
		return '';
	}
	
	$mode = strtolower($mode);
	$message = '';
	
	if(isset($mode))
	{
		if($mode == "header")
		{
			$message .= "<html>";
			$message .= "<head>";
			$message .= "<title>askCMS - Instala��o</title>";
		}
		elseif($mode == "css")
		{
			require_once 'css.txt';
		}
		elseif($mode == "continue_body")
		{
			$message .= "</head>";
			$message .= "<body>";
			$message .= "<div class=\"w\">";
			$message .= "<div class=\"i\">";
			$message .= "<h1>Instala��o askCMS - PT/BR</h1>";
			$message .= "<p>";
		}
		elseif($mode == "final")
		{
			$message .= "<center>";
			for ($i = 0; $i <= 63; $i++) {	$message .= "_"; }
			$message .= "<br>";
			$message .= '<a href="http://at0m.com.nu" target="_blank">at0m</a> ';
			$message .= "&copy; 2012 - http://at0m.com.nu";
			$message .= "</center>";
			$message .= "</div>";
			$message .= "<br />";
			$message .= "</div>";
			$message .= "</body>";
			$message .= "</html>";
		}
		
		if($mode != "css")
		{
			return $message;
		}
	}
}

/* Carregando Fun��es de Design */
echo(htmlStuff("header")); // Header
htmlStuff("css"); // Css
echo(htmlStuff("continue_body")); // Body
?>

<?php if($get["step"] > 0 && $get["step"] < 5){ ?>

        <?php if($get["step"] == 1){ ?>        
			Passo <b>1</b> de 4 - Conex�o com a Database</em>
		</p>
        <li><b>Passo 1 - Conex�o MySQL</b>
        </li>
		<p>
        Informe nos campos abaixo os dados do MySQL/Banco de Dados em que a askCMS se encontra.<br>
        Se voc� n�o sabe ou n�o t�m certeza, entre em contato com seu Host.<br>
		</p>
        <center>
        <?php
		if($get["action"] == "db")
		{
			// Checando Campos
			if(!empty($_POST["db_server"]) || !empty($_POST["db_user"]) || !empty($_POST["db_pass"]) || !empty($_POST["db_database"]))
			{
				// Tentando fazer conex�o MySQL
				$con = mysql_connect($_POST["db_server"], $_POST["db_user"], $_POST["db_pass"]);
				
				// Checando Conex�o
				if($con)
				{
					// Tentando fazer conex�o Database
					$db = mysql_select_db($_POST["db_database"], $con);
					
					// Checando Conex�o
					if($db)
					{
						// Tudo Ok, cria o arquivo de Configura��o
						createConfig($_POST["db_server"], $_POST["db_user"], $_POST["db_pass"], $_POST["db_database"]);
						
						// Redireciona para 2� Passo
						header("Location: install_pt.php?step=2");
					}
					else { echo('<font color="red"><b>Erro</b> - N�o foi poss�vel conectar com a Database, por favor, verifique seu nome e se a database existe.</font>'); }
				}
				else { echo('<font color="red"><b>Erro</b> - N�o foi poss�vel conectar com o Mysql, por favor, verifique seu os dados inseridos s�o v�lidos.</font>'); }
			}
			else { echo('<font color="red"><b>Erro</b> - H� campos que n�o foram preenchidos, por favor reveja-os.</font>'); }
		}
?>
        <form action="install_pt.php?step=1&action=db" method="post">
        Nome do Servidor MySQL<br>
        <input name="db_server" type="text" class="textfields" value="localhost" size="40">
        <br>
        Nome de Usu�rio MySQL<br>
        <input name="db_user" type="text" class="textfields" value="root" size="40">
        <br>
        Senha MySQL<br>
        <input name="db_pass" type="text" class="textfields" value="" size="40">
        <br>
        Nome da Database<br>
        <input name="db_database" type="text" class="textfields" value="" size="40">
        <br><br>
        <input name="" type="submit" value="Enviar"> &nbsp; &nbsp; <input name="" type="reset" value="Resetar">
        </form>
		</center>
		<p></p>
        
		<?php } elseif($get["step"] == 2){ ?>
        Passo <b>2</b> de 4 - Cria��o de Administrador</em>
		</p>
        <li><b>Passo 2 - Criar Conta de Administrador</b>
        </li>
		<p>
        Parab�ns, foi feita com sucesso a conex�o MySQL com a Database.<br>
        Agora voc� vai criar sua conta especial, ou seja, sua conta de administrador do website, voc� poder� editar seus detalhes mais tarde quando a instala��o terminar. Atrav�s desta conta, voc� ter� acesso ao painel de administra��o do site, onde voc� ter� o controle total de todo o site.<br>
        <font color="#FF0000">ATEN��O: Para o nome de usu�rio, n�o utilize v�rgulas, espa�os, pontos. Caso contr�rio haver� erros.</font><br>
		</p>
        <center>
        
		<?php
		if($get["action"] == "adm")
		{
			if(!empty($_POST["adm_username"]) || !empty($_POST["adm_pass"]) || !empty($_POST["adm_name"]) || !empty($_POST["adm_email"]))
			{
				$admUser = ucfirst(strtolower($_POST["adm_username"]));
				
				if(!in_array($admUser, $blocked["names"]))
				{
					if(!strstr($_POST["adm_username"], ' '))
					{
						createMyAdmin($_POST["adm_username"], $_POST["adm_pass"], $_POST["adm_name"], $_POST["adm_email"]);
					}
					else { echo('<font color="red"><b>Erro</b> - H� caracteres inv�lidos no nome de usu�rio. Reveja-os.</font>'); }				
				}
				else { echo('<font color="red"><b>Erro</b> - O nome de usu�rio que voc� digitou est� bloqueado. Tente outro.</font>'); }
			}
			else { echo('<font color="red"><b>Erro</b> - H� campos que n�o foram preenchidos. Por favor, reveja-os.</font>'); }
		}
		?>
        <form action="install_pt.php?step=2&action=adm" method="post">
        Nome de Usu�rio<br>
        <input name="adm_username" type="text" class="textfields" value="" size="40" maxlength="32">
        <br>
        Senha de Usu�rio<br>
        <input name="adm_pass" type="text" class="textfields" value="" size="40">
        <br>
        Nome Verdadeiro<br>
        <input name="adm_name" type="text" class="textfields" value="" size="40">
        <br>
        Email<br>
        <input name="adm_email" type="text" class="textfields" value="at0m@live.com" size="40">
        <br><br>
        <input name="" type="submit" value="Enviar"> &nbsp; &nbsp; <input name="" type="reset" value="Resetar">
        </form>
		</center>
		<p></p>
        <?php } elseif($get["step"] == 3){ ?>
        Passo <b>3</b> de 4 - Configura��o do Site</em>
		</p>
        <li><b>Passo 3 - Configurar Site</b>
        </li>
		<p>
        Parab�ns, sua conta de Administrador foi criada com sucesso.<br>
        Agora voc� vai configurar o site, inserindo o nome do site e o dom�nio.<br> 
        Esta, s�o as configura��es iniciais mais importantes, em breve voc� poder� acessar o painel de administra��o e edit�-las, no painel h� mais configura��es acerca do site, tais como ativar/desativar manuten��o, editar as palavras-chave e descri��o do site, dentre outros.
        <br>
		</p>
        <center>
        <?php
        if($get["action"] == "web")
		{
			if(!empty($_POST["web_name"]) || !empty($_POST["web_url"]))
			{
				if(empty($_POST["web_name"]))
				{
					echo('<font color="red"><b>Erro</b> - H� campos que n�o foram preenchidos. Por favor, reveja-os.</font>');			
				}
				else
				{
					updateWeb($_POST["web_name"], $_POST["web_url"]);
				}
			}
			else { echo('<font color="red"><b>Erro</b> - H� campos que n�o foram preenchidos. Por favor, reveja-os.</font>'); }
		}
		?>
        <form action="install_pt.php?step=3&action=web" method="post">
        Nome do Website<br>
        <input name="web_name" type="text" class="textfields" value="" size="40"><br>
        <font size="1">Exemplo: Responda Me !</font>
        <br><br>
        URL / Dom�nio do Website<br>
        http:// <input name="web_url" type="text" class="textfields" value="meusite.com" size="40">/
        <br>
        <font size="1">Obs: O dom�nio do site n�o pode conter o <b>http://</b> no in�cio e <b>/</b> no final.</font>
        <br><br>
        <input name="" type="submit" value="Enviar"> &nbsp; &nbsp; <input name="" type="reset" value="Resetar">
        </form>
		</center>
		<p></p>
        <?php } elseif($get["step"] == 4){ ?>
        Passo <b>4</b> de 4 - Instala��o Completa</em>
		</p>
        <li><b>Passo 4 - Instala��o Completa</b>
        </li>
		<p>
        Parab�ns, askCMS foi instalada com sucesso.<br>
        Agora voc� poder� desfrutar de sua rede social de perguntas e respostas an�nimas. Se quiser ir ao painel de administra��o voc� deve logar normalmente no site com sua conta de administrador.<br>
       <p>
        <center>
        <?php 
		include("../brain.php");
		include("../core/website.config.php");
		?>
        <a href="http://<?php echo SITE_DOMAIN; ?>/">Ir a P�gina Principal</a>&nbsp;&nbsp; - &nbsp;&nbsp; <a href="http://<?php echo SITE_DOMAIN; ?>/account/login">Logar-se no Site</a>&nbsp;&nbsp; - &nbsp;&nbsp; <a href="http://at0m.com.nu/" target="_blank">at0m &copy;</a>
        <font color="#009900"><p><br><b>Aten��o</b><br>
        Por raz�es de seguran�a renomeie a pasta SETUP para outro nome. Evitando assim que outros indiv�duos al�m do Administrador Principal instale novamente o script.</font>
        <?php } ?>
        
<?php } else { echo(bruteError()); } ?>
<?php // Final HTML
echo(htmlStuff("final")); ?>