-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Gera��o: Jan 03, 2012 as 11:21 
-- Vers�o do Servidor: 5.1.37
-- Vers�o do PHP: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Banco de Dados: `ask`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `to_user` varchar(400) NOT NULL,
  `question` text NOT NULL,
  `from_user` varchar(400) NOT NULL,
  `answer` text NOT NULL,
  `status` set('0','1') NOT NULL,
  `anonymous` set('0','1') NOT NULL,
  `date` varchar(20) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `time` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `questions`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `site_config`
--

CREATE TABLE IF NOT EXISTS `site_config` (
  `website_name` varchar(500) NOT NULL,
  `website_domain` text NOT NULL,
  `website_keywords` text NOT NULL,
  `website_description` text NOT NULL,
  `website_language` varchar(60) NOT NULL,
  `website_maintenance` set('0','1') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `site_config`
--

INSERT INTO `site_config` (`website_name`, `website_domain`, `website_keywords`, `website_description`, `website_language`, `website_maintenance`) VALUES
('askCMS', 'localhost', 'Leo, at0m, script, php, ask, questions, social network, anonymous, feel like a ninja', 'Make questions, give answers, know more about your friends with askCMS !', 'en', '0');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID do Usu�rio',
  `username` varchar(400) NOT NULL COMMENT 'Nome do Usu�rio',
  `password` text NOT NULL COMMENT 'Senha',
  `real_name` varchar(400) NOT NULL COMMENT 'Nome e/ou Sobrenome',
  `real_surname` varchar(400) NOT NULL,
  `rank` enum('0','1','2') NOT NULL,
  `email` varchar(200) NOT NULL COMMENT 'Email',
  `website` varchar(300) NOT NULL COMMENT 'Site',
  `localization` varchar(300) NOT NULL COMMENT 'Localiza��o',
  `bio` text NOT NULL COMMENT 'Sobre Mim',
  `what_ask` varchar(400) NOT NULL,
  `theme` enum('birch','bluedots','charcoal','chocolate','cranberry','default','django','forest','indigo','morocco','pinkdots','tartan') NOT NULL,
  `photo` text NOT NULL,
  `status` enum('0','1') NOT NULL,
  `ip` varchar(50) NOT NULL,
  `password_key` varchar(400) NOT NULL,
  `anonymous_view` enum('0','1') NOT NULL,
  `reg_date` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `users`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(400) NOT NULL,
  `size` set('Large','Medium','Small') NOT NULL,
  `background_color` varchar(200) NOT NULL,
  `foreground_color` varchar(200) NOT NULL,
  `height` varchar(10) NOT NULL,
  `width` varchar(10) NOT NULL,
  `status` varchar(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `widgets`
--

