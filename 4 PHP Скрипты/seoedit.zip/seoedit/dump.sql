﻿-- phpMyAdmin SQL Dump
-- version 3.4.3.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 02 2011 г., 09:02
-- Версия сервера: 5.0.92
-- Версия PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `alex2208_mfs`
--

-- --------------------------------------------------------

--
-- Структура таблицы `afbcomments`
--

CREATE TABLE IF NOT EXISTS `afbcomments` (
  `id` int(10) NOT NULL auto_increment,
  `idnew` int(10) NOT NULL,
  `data` varchar(16) NOT NULL,
  `user` varchar(20) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `mails`
--

CREATE TABLE IF NOT EXISTS `mails` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `mail_text` text NOT NULL,
  `plan` int(11) default '0',
  `timer` int(11) default '0',
  `date_add` int(11) default '0',
  `user` varchar(20) NOT NULL,
  `views` int(11) NOT NULL default '0',
  `color` varchar(6) NOT NULL default 'FFFFFF',
  `status` varchar(12) NOT NULL default 'pay',
  `to_user` double default '0',
  `amout` double NOT NULL default '0',
  `wmid` varchar(13) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `mails_color`
--

CREATE TABLE IF NOT EXISTS `mails_color` (
  `id` int(11) NOT NULL auto_increment,
  `amout` double default '0',
  `name_color` varchar(20) default 'НЕТ ИМЕНИ',
  `code` varchar(6) default 'FFFFFF',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `mails_color`
--

INSERT INTO `mails_color` (`id`, `amout`, `name_color`, `code`) VALUES
(2, 0.22, 'Синий ', '336699'),
(3, 0.35, 'Серый', 'CCCCCC');

-- --------------------------------------------------------

--
-- Структура таблицы `mails_timer`
--

CREATE TABLE IF NOT EXISTS `mails_timer` (
  `id` int(11) NOT NULL auto_increment,
  `timer` int(11) default '0',
  `amout` double default '0',
  `pay_to_user` double NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=16 ;

--
-- Дамп данных таблицы `mails_timer`
--

INSERT INTO `mails_timer` (`id`, `timer`, `amout`, `pay_to_user`) VALUES
(8, 15, 1.8, 1.5),
(7, 10, 1.2, 1),
(5, 5, 0.6, 0.5),
(9, 20, 2.4, 2.1),
(10, 25, 3, 2.7),
(11, 30, 3.6, 3.3),
(12, 35, 4.2, 3.9),
(13, 40, 4.8, 4.5),
(14, 45, 5.4, 5.1),
(15, 50, 6, 5.7);

-- --------------------------------------------------------

--
-- Структура таблицы `mails_views`
--

CREATE TABLE IF NOT EXISTS `mails_views` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(50) NOT NULL,
  `date_view` int(11) NOT NULL,
  `url` varchar(150) NOT NULL,
  `id_site` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=122 ;

--
-- Дамп данных таблицы `mails_views`
--

INSERT INTO `mails_views` (`id`, `user`, `date_view`, `url`, `id_site`) VALUES
(90, 'Bitoz', 1282451609, 'http://lizza.ru/?aff=andrusenok111', 9),
(98, 'margo', 1282477263, 'http://mineral.do.am/', 8),
(120, 'RommanL', 1282501285, 'http://lizza.ru/?aff=andrusenok111', 9),
(79, 'Vinki', 1282426377, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(78, 'Vinki', 1282426360, 'http://lizza.ru/?aff=andrusenok111', 9),
(77, 'Vinki', 1282426343, 'http://mineral.do.am/', 8),
(89, 'Bitoz', 1282451584, 'http://mineral.do.am/', 8),
(121, 'RommanL', 1282501301, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(109, 'admin', 1282484175, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(108, 'admin', 1282484144, 'http://lizza.ru/?aff=andrusenok111', 9),
(107, 'admin', 1282484121, 'http://mineral.do.am/', 8),
(97, 'Chalukyshy', 1282476377, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(96, 'Chalukyshy', 1282476358, 'http://lizza.ru/?aff=andrusenok111', 9),
(95, 'Chalukyshy', 1282476340, 'http://mineral.do.am/', 8),
(99, 'margo', 1282477380, 'http://lizza.ru/?aff=andrusenok111', 9),
(100, 'margo', 1282477435, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(106, 'nixons', 1282482559, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(105, 'nixons', 1282482489, 'http://lizza.ru/?aff=andrusenok111', 9),
(104, 'nixons', 1282482470, 'http://mineral.do.am/', 8),
(103, 'hawkman', 1282482394, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(102, 'hawkman', 1282482364, 'http://lizza.ru/?aff=andrusenok111', 9),
(101, 'hawkman', 1282482315, 'http://mineral.do.am/', 8),
(115, 'verholet', 1282493698, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(114, 'verholet', 1282493622, 'http://lizza.ru/?aff=andrusenok111', 9),
(113, 'verholet', 1282493562, 'http://mineral.do.am/', 8),
(112, 'nik2263', 1282492120, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(111, 'nik2263', 1282492090, 'http://lizza.ru/?aff=andrusenok111', 9),
(110, 'nik2263', 1282492063, 'http://mineral.do.am/', 8),
(118, 'robur', 1282494577, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(117, 'robur', 1282494256, 'http://lizza.ru/?aff=andrusenok111', 9),
(116, 'robur', 1282494215, 'http://mineral.do.am/', 8),
(119, 'RommanL', 1282501270, 'http://mineral.do.am/', 8),
(74, 'ttkmgk', 1282419279, 'http://lizza.ru/?aff=andrusenok111', 9),
(75, 'ttkmgk', 1282419318, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(76, 'ttkmgk', 1282419347, 'http://mineral.do.am/', 8),
(80, 'Goldwiks', 1282431335, 'http://mineral.do.am/', 8),
(81, 'Goldwiks', 1282431355, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(82, 'Goldwiks', 1282431378, 'http://lizza.ru/?aff=andrusenok111', 9),
(83, 'bijovskaya', 1282433503, 'http://mineral.do.am/', 8),
(84, 'bijovskaya', 1282433524, 'http://lizza.ru/?aff=andrusenok111', 9),
(85, 'bijovskaya', 1282433565, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(86, 'qyni', 1282433820, 'http://mineral.do.am/', 8),
(87, 'qyni', 1282433867, 'http://lizza.ru/?aff=andrusenok111', 9),
(88, 'qyni', 1282433894, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(91, 'Bitoz', 1282451628, 'http://cash-6via.narod.ru/monik-6via.htm', 10),
(92, 'anton1995', 1282454542, 'http://mineral.do.am/', 8),
(93, 'anton1995', 1282454598, 'http://lizza.ru/?aff=andrusenok111', 9),
(94, 'anton1995', 1282454630, 'http://cash-6via.narod.ru/monik-6via.htm', 10);

-- --------------------------------------------------------

--
-- Структура таблицы `mess_adm_zh`
--

CREATE TABLE IF NOT EXISTS `mess_adm_zh` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(20) NOT NULL,
  `link_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `mess_adm_zh`
--

INSERT INTO `mess_adm_zh` (`id`, `user`, `link_id`, `text`, `date`) VALUES
(1, 'admin', 2, 'GAVNO BLEAT', 1312957334);

-- --------------------------------------------------------

--
-- Структура таблицы `reyting_users`
--

CREATE TABLE IF NOT EXISTS `reyting_users` (
  `id` int(11) NOT NULL auto_increment,
  `kto` varchar(100) NOT NULL,
  `komu` varchar(100) NOT NULL,
  `skolyko` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `date_del` int(11) NOT NULL,
  `bonus` double NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `reyting_users_options`
--

CREATE TABLE IF NOT EXISTS `reyting_users_options` (
  `id` int(1) NOT NULL,
  `kupleno_raz` int(11) NOT NULL default '0',
  `na_summu` double NOT NULL default '0',
  `stoit` double default '0',
  `bonus_user` double default '0',
  `users_bonus` double NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

-- --------------------------------------------------------

--
-- Структура таблицы `rt_pakety_rekl`
--

CREATE TABLE IF NOT EXISTS `rt_pakety_rekl` (
  `id` int(250) NOT NULL auto_increment,
  `dyn` int(20) NOT NULL,
  `time` int(3) NOT NULL,
  `stat` int(20) NOT NULL,
  `frame` int(20) NOT NULL,
  `baner` int(20) NOT NULL,
  `cena` varchar(10) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rt_zk_pk_rk`
--

CREATE TABLE IF NOT EXISTS `rt_zk_pk_rk` (
  `id` int(250) NOT NULL auto_increment,
  `idpk` int(250) NOT NULL,
  `wmid` int(12) NOT NULL,
  `cena` int(50) NOT NULL,
  `url` varchar(50) NOT NULL,
  `ops` varchar(50) NOT NULL,
  `date` varchar(20) character set cp1251 collate cp1251_bulgarian_ci NOT NULL,
  `status` int(1) NOT NULL default '1',
  `starttime` int(50) NOT NULL,
  `urlpic` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo_basket`
--

CREATE TABLE IF NOT EXISTS `seo_basket` (
  `id` int(10) NOT NULL auto_increment,
  `ident` int(10) NOT NULL,
  `fromid` int(10) NOT NULL,
  `time` int(11) NOT NULL,
  `price` double NOT NULL default '0',
  `type` int(2) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=26 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo_favtasks`
--

CREATE TABLE IF NOT EXISTS `seo_favtasks` (
  `id` int(11) NOT NULL auto_increment,
  `fromid` int(11) NOT NULL,
  `ident` int(1) default '0',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo_mails`
--

CREATE TABLE IF NOT EXISTS `seo_mails` (
  `id` int(11) NOT NULL auto_increment,
  `text` text NOT NULL,
  `ident` int(11) NOT NULL,
  `fromid` int(10) NOT NULL,
  `fromus` varchar(25) NOT NULL,
  `toid` int(10) NOT NULL,
  `tous` varchar(25) NOT NULL,
  `read` int(1) NOT NULL default '0',
  `timemessage` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `seo_mails`
--

INSERT INTO `seo_mails` (`id`, `text`, `ident`, `fromid`, `fromus`, `toid`, `tous`, `read`, `timemessage`) VALUES
(5, 'theme bleat', 0, 1, 'admin', 1, 'admin', 1, 1314944412),
(6, 'text bleat', 5, 1, 'admin', 1, 'admin', 1, 1314944412),
(7, 'ответ блеать', 5, 1, 'admin', 1, 'admin', 1, 1314945614),
(8, 'бгг бле', 5, 1, 'admin', 1, 'admin', 0, 1314945645),
(9, 'ыфвыфвф', 0, 1, 'admin', 1, 'admin', 1, 1314945803),
(10, 'ыыыы', 9, 1, 'admin', 1, 'admin', 1, 1314945803);

-- --------------------------------------------------------

--
-- Структура таблицы `seo_paymails`
--

CREATE TABLE IF NOT EXISTS `seo_paymails` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(55) NOT NULL,
  `adddate` int(11) NOT NULL,
  `fromid` int(10) NOT NULL,
  `paused` int(1) default '1',
  `modered` int(1) default '0',
  `balance` double default '0',
  `price` double NOT NULL,
  `description` varchar(3200) NOT NULL,
  `many` int(1) NOT NULL,
  `highlight` int(1) default '0',
  `obper` int(1) default '0',
  `timer` int(2) NOT NULL,
  `quest` varchar(50) NOT NULL,
  `answer1` varchar(30) NOT NULL,
  `answer2` varchar(30) NOT NULL,
  `answer3` varchar(30) NOT NULL,
  `url` varchar(300) NOT NULL,
  `plan` int(5) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `seo_paymails`
--

INSERT INTO `seo_paymails` (`id`, `name`, `adddate`, `fromid`, `paused`, `modered`, `balance`, `price`, `description`, `many`, `highlight`, `obper`, `timer`, `quest`, `answer1`, `answer2`, `answer3`, `url`, `plan`) VALUES
(1, 'namebleat', 0, 1, 0, 1, 898.5, 0.5, '', 1, 0, 0, 20, 'questbleat?', 'ansgood', 'andbad', 'ansbad', 'http://getwmz.net', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `seo_paymailsviews`
--

CREATE TABLE IF NOT EXISTS `seo_paymailsviews` (
  `id` int(10) NOT NULL auto_increment,
  `ident` int(10) NOT NULL,
  `fromid` int(10) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `seo_paymailsviews`
--

INSERT INTO `seo_paymailsviews` (`id`, `ident`, `fromid`, `time`) VALUES
(3, 1, 1, 1314913719);

-- --------------------------------------------------------

--
-- Структура таблицы `seo_refbirj`
--

CREATE TABLE IF NOT EXISTS `seo_refbirj` (
  `id` int(10) NOT NULL auto_increment,
  `rid` int(10) NOT NULL,
  `rname` varchar(25) default NULL,
  `price` double NOT NULL default '0',
  `timestart` int(11) NOT NULL,
  `trid` int(10) NOT NULL,
  `bron` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo_taskcomms`
--

CREATE TABLE IF NOT EXISTS `seo_taskcomms` (
  `id` int(11) NOT NULL auto_increment,
  `fromid` int(11) NOT NULL,
  `ident` int(11) default '0',
  `time` int(11) default NULL,
  `text` varchar(3000) NOT NULL,
  `reyt` double default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo_tasks`
--

CREATE TABLE IF NOT EXISTS `seo_tasks` (
  `id` int(11) NOT NULL auto_increment,
  `fromid` int(11) NOT NULL,
  `price` double default '0',
  `text` varchar(3200) NOT NULL,
  `description` varchar(3200) NOT NULL,
  `cat` int(1) NOT NULL,
  `url` varchar(300) NOT NULL,
  `many` int(1) NOT NULL,
  `maxtime` int(11) NOT NULL,
  `goods` int(5) NOT NULL default '0',
  `waits` int(5) NOT NULL default '0',
  `no` int(5) NOT NULL default '0',
  `works` int(5) NOT NULL default '0',
  `inblock` int(11) NOT NULL default '0',
  `modered` int(1) NOT NULL default '0',
  `paused` int(1) default '1',
  `reyt` double default '0',
  `name` varchar(55) NOT NULL,
  `balance` double default '0',
  `comms` int(5) NOT NULL default '0',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `seo_tasks`
--

INSERT INTO `seo_tasks` (`id`, `fromid`, `price`, `text`, `description`, `cat`, `url`, `many`, `maxtime`, `goods`, `waits`, `no`, `works`, `inblock`, `modered`, `paused`, `reyt`, `name`, `balance`, `comms`) VALUES
(3, 1, 1.2, 'пиздец подкрался это начало кон[b]ца[/b]', 'кто подкрался оО?', 3, 'http://getwmz.net', 0, 259200, 0, 0, 0, 0, 0, 1, 1, 0, 'заголовочеГ', 900, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `seo_taskstats`
--

CREATE TABLE IF NOT EXISTS `seo_taskstats` (
  `id` int(11) NOT NULL auto_increment,
  `fromid` int(11) NOT NULL,
  `ident` double default '0',
  `answer` varchar(1500) NOT NULL,
  `anstime` int(11) NOT NULL,
  `status` int(1) NOT NULL default '0',
  `reason` varchar(250) NOT NULL,
  `starttime` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `seo_taskstats`
--

INSERT INTO `seo_taskstats` (`id`, `fromid`, `ident`, `answer`, `anstime`, `status`, `reason`, `starttime`) VALUES
(4, 1, 3, '', 0, 0, '', 1314812006),
(5, 1, 3, '', 0, 0, '', 1314812098);

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_addban88`
--

CREATE TABLE IF NOT EXISTS `sfb_addban88` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `plan` int(3) NOT NULL,
  `urlsite` varchar(150) NOT NULL,
  `urlpic` varchar(150) NOT NULL,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_advban88`
--

CREATE TABLE IF NOT EXISTS `sfb_advban88` (
  `id` int(11) NOT NULL auto_increment,
  `urlsite` varchar(150) NOT NULL,
  `urlpic` varchar(150) NOT NULL,
  `begindate` int(11) NOT NULL,
  `numdays` int(5) NOT NULL default '0',
  `wmid` varchar(12) NOT NULL,
  `title` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_advs`
--

CREATE TABLE IF NOT EXISTS `sfb_advs` (
  `id` int(10) NOT NULL auto_increment,
  `data` int(11) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  `summ` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=9 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_cloud`
--

CREATE TABLE IF NOT EXISTS `sfb_cloud` (
  `id` int(10) NOT NULL auto_increment,
  `wmid` varchar(15) NOT NULL,
  `url` varchar(100) NOT NULL,
  `description` varchar(50) NOT NULL,
  `status` varchar(5) NOT NULL default 'wait',
  `beginned` varchar(50) NOT NULL,
  `plan` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_rot100`
--

CREATE TABLE IF NOT EXISTS `sfb_rot100` (
  `id` int(10) NOT NULL auto_increment,
  `plan` int(3) NOT NULL,
  `url` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `alt` varchar(150) NOT NULL,
  `status` varchar(5) NOT NULL,
  `begindate` int(11) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  `curview` varchar(2) NOT NULL default '1',
  `email` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_runblock`
--

CREATE TABLE IF NOT EXISTS `sfb_runblock` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `plan` int(3) NOT NULL,
  `url` varchar(150) NOT NULL,
  `description` varchar(150) NOT NULL,
  `status` varchar(2) NOT NULL,
  `views` varchar(3) NOT NULL default '0',
  `endtime` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_shopforbux`
--

CREATE TABLE IF NOT EXISTS `sfb_shopforbux` (
  `id` varchar(5) NOT NULL,
  `5sd` varchar(5) NOT NULL,
  `10sd` varchar(5) NOT NULL,
  `15sd` varchar(5) NOT NULL,
  `20sd` varchar(5) NOT NULL,
  `25sd` varchar(5) NOT NULL,
  `30sd` varchar(5) NOT NULL,
  `35sd` varchar(5) NOT NULL,
  `40sd` varchar(5) NOT NULL,
  `45sd` varchar(5) NOT NULL,
  `50sd` varchar(5) NOT NULL,
  `55sd` varchar(5) NOT NULL,
  `60sd` varchar(5) NOT NULL,
  `5sec` varchar(5) NOT NULL,
  `10sec` varchar(5) NOT NULL,
  `15sec` varchar(5) NOT NULL,
  `20sec` varchar(5) NOT NULL,
  `25sec` varchar(5) NOT NULL,
  `30sec` varchar(5) NOT NULL,
  `35sec` varchar(5) NOT NULL,
  `40sec` varchar(5) NOT NULL,
  `45sec` varchar(5) NOT NULL,
  `50sec` varchar(5) NOT NULL,
  `55sec` varchar(5) NOT NULL,
  `60sec` varchar(5) NOT NULL,
  `r5sec` varchar(5) NOT NULL,
  `r10sec` varchar(5) NOT NULL,
  `r15sec` varchar(5) NOT NULL,
  `r20sec` varchar(5) NOT NULL,
  `r25sec` varchar(5) NOT NULL,
  `r30sec` varchar(5) NOT NULL,
  `r35sec` varchar(5) NOT NULL,
  `r40sec` varchar(5) NOT NULL,
  `r45sec` varchar(5) NOT NULL,
  `r50sec` varchar(5) NOT NULL,
  `r55sec` varchar(5) NOT NULL,
  `r60sec` varchar(5) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `sfb_shopforbux`
--

INSERT INTO `sfb_shopforbux` (`id`, `5sd`, `10sd`, `15sd`, `20sd`, `25sd`, `30sd`, `35sd`, `40sd`, `45sd`, `50sd`, `55sd`, `60sd`, `5sec`, `10sec`, `15sec`, `20sec`, `25sec`, `30sec`, `35sec`, `40sec`, `45sec`, `50sec`, `55sec`, `60sec`, `r5sec`, `r10sec`, `r15sec`, `r20sec`, `r25sec`, `r30sec`, `r35sec`, `r40sec`, `r45sec`, `r50sec`, `r55sec`, `r60sec`) VALUES
('1', '0.45', '0.9', '1.35', '1.8', '2.25', '2.7', '3.15', '3.6', '4.05', '4.5', '4.95', '6', '0.25', '0.5', '0.75', '1', '1.25', '1.5', '1.75', '2', '2.25', '2.5', '2.75', '6', '0.06', '0.12', '0.18', '0.24', '0.3', '0.36', '0.42', '0.48', '0.54', '0.6', '0.68', '3');

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_spam`
--

CREATE TABLE IF NOT EXISTS `sfb_spam` (
  `id` int(10) NOT NULL auto_increment,
  `text` varchar(10000) NOT NULL,
  `url` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL,
  `kolvo` varchar(10) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_taskabuses`
--

CREATE TABLE IF NOT EXISTS `sfb_taskabuses` (
  `id` int(10) NOT NULL auto_increment,
  `ident` int(5) NOT NULL,
  `text` text NOT NULL,
  `username` varchar(20) NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_taskcomments`
--

CREATE TABLE IF NOT EXISTS `sfb_taskcomments` (
  `id` int(10) NOT NULL auto_increment,
  `date` int(11) NOT NULL,
  `ident` int(5) NOT NULL,
  `login` varchar(20) NOT NULL,
  `comment` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sfb_taskreyt`
--

CREATE TABLE IF NOT EXISTS `sfb_taskreyt` (
  `id` int(10) NOT NULL auto_increment,
  `ident` int(5) NOT NULL,
  `reyt` int(1) NOT NULL,
  `user` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_accessblock`
--

CREATE TABLE IF NOT EXISTS `tb_accessblock` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_addbanner`
--

CREATE TABLE IF NOT EXISTS `tb_addbanner` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `plan` int(3) NOT NULL,
  `urlsite` varchar(150) NOT NULL,
  `urlpic` varchar(150) NOT NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_addbanner100`
--

CREATE TABLE IF NOT EXISTS `tb_addbanner100` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `plan` int(3) NOT NULL,
  `urlsite` varchar(150) NOT NULL,
  `urlpic` varchar(150) NOT NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_adminmess`
--

CREATE TABLE IF NOT EXISTS `tb_adminmess` (
  `id` int(11) NOT NULL auto_increment,
  `data` varchar(20) NOT NULL,
  `text` varchar(150) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_ads`
--

CREATE TABLE IF NOT EXISTS `tb_ads` (
  `id` int(11) NOT NULL auto_increment,
  `plan` int(5) NOT NULL,
  `highlight` int(1) NOT NULL,
  `url` varchar(150) NOT NULL,
  `description` varchar(55) NOT NULL,
  `timer` int(3) NOT NULL default '20',
  `all_zh` int(2) NOT NULL default '0',
  `obper` int(5) NOT NULL default '0',
  `texto` varchar(55) default NULL,
  `balance` double default '0',
  `paused` int(1) default '1',
  `payforad` double default '0',
  `price` double default '0',
  `modered` int(1) default '0',
  `fromus` int(10) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=11 ;

--
-- Дамп данных таблицы `tb_ads`
--

INSERT INTO `tb_ads` (`id`, `plan`, `highlight`, `url`, `description`, `timer`, `all_zh`, `obper`, `texto`, `balance`, `paused`, `payforad`, `price`, `modered`, `fromus`) VALUES
(10, 1, 0, 'http://getwmz.net', 'BLEAT SFB', 0, 0, 0, 'sddsfsdfsdf', 1000, 0, 450, 450, 1, 1),
(9, 0, 0, 'http://getwmz.net', 'BLEAT SFB', 0, 0, 0, 'sddsfsdfsdf', 0, 1, 450, 450, 1, 1),
(8, 0, 0, 'http://getwmz.net', 'BLEAT SFB', 0, 0, 0, 'sddsfsdfsdf', 0, 1, 450, 450, 1, 1),
(7, 0, 0, 'http://getwmz.net', 'BLEAT SFB', 0, 7, 0, 'sddsfsdfsdf', 550, 0, 100, 450, 2, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `tb_adsblock`
--

CREATE TABLE IF NOT EXISTS `tb_adsblock` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(150) NOT NULL,
  `url` varchar(150) NOT NULL,
  `text` varchar(150) NOT NULL,
  `views` int(11) NOT NULL default '0',
  `timestart` int(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_adsdate`
--

CREATE TABLE IF NOT EXISTS `tb_adsdate` (
  `id` int(11) NOT NULL auto_increment,
  `data` varchar(10) NOT NULL,
  `kolvo` varchar(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_advban`
--

CREATE TABLE IF NOT EXISTS `tb_advban` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(150) NOT NULL,
  `price` double default '0',
  `balance` double default '0',
  `views` int(5) NOT NULL default '0',
  `paused` int(1) NOT NULL default '1',
  `modered` int(1) default '0',
  `nametime` int(11) default NULL,
  `typeban` varchar(5) NOT NULL,
  `fromus` int(10) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `tb_advban`
--

INSERT INTO `tb_advban` (`id`, `url`, `price`, `balance`, `views`, `paused`, `modered`, `nametime`, `typeban`, `fromus`) VALUES
(1, 'http://getwmz.net', 100, 0, 0, 1, 0, 1314465670, 'gif', 0),
(2, 'http://getwmz.net', 100, 0, 0, 1, 0, 1314465750, 'gif', 0),
(3, 'http://getwmz.net', 100, 0, 0, 1, 0, 1314478081, 'gif', NULL),
(4, 'http://getwmz.net', 100, 0, 0, 1, 0, 1314478098, 'gif', NULL),
(5, 'http://getwmz.net', 100, 0, 0, 1, 0, 1314560074, 'gif', NULL),
(6, 'http://getwmz.net', 100, 10, 0, 1, 1, 1314560138, 'gif', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `tb_advban100`
--

CREATE TABLE IF NOT EXISTS `tb_advban100` (
  `id` int(11) NOT NULL auto_increment,
  `urlsite` varchar(150) NOT NULL,
  `urlpic` varchar(150) NOT NULL,
  `begindate` int(11) NOT NULL,
  `numdays` int(5) NOT NULL default '0',
  `curview` int(1) NOT NULL default '0',
  `wmid` varchar(12) NOT NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_advertisers`
--

CREATE TABLE IF NOT EXISTS `tb_advertisers` (
  `id` int(11) NOT NULL auto_increment,
  `pname` varchar(150) NOT NULL,
  `pemail` varchar(150) NOT NULL,
  `plan` varchar(150) NOT NULL,
  `url` varchar(150) NOT NULL,
  `description` varchar(55) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `bold` varchar(150) NOT NULL,
  `highlight` varchar(150) NOT NULL,
  `tipo` varchar(150) NOT NULL,
  `money` varchar(150) NOT NULL,
  `timer` varchar(3) NOT NULL default '20',
  `dopsec` varchar(1) NOT NULL default '0',
  `vip` varchar(1) NOT NULL default '0',
  `email` varchar(50) default NULL,
  `act` varchar(5) NOT NULL default '0',
  `obper` varchar(5) NOT NULL default '0',
  `cena` varchar(10) NOT NULL,
  `texto` varchar(55) default NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_allhistory`
--

CREATE TABLE IF NOT EXISTS `tb_allhistory` (
  `id` int(10) NOT NULL auto_increment,
  `idus` int(10) NOT NULL,
  `doing` int(3) NOT NULL,
  `data` int(11) NOT NULL,
  `title` varchar(150) NOT NULL default '-',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=33 ;

--
-- Дамп данных таблицы `tb_allhistory`
--

INSERT INTO `tb_allhistory` (`id`, `idus`, `doing`, `data`, `title`) VALUES
(1, 1, 1, 1314563884, 'Пользователь изменил данные профиля'),
(2, 1, 2, 1314564030, 'http://test1.ru/?idpage=2'),
(3, 1, 4, 1314709101, 'Пополнение баланса баннера № 6'),
(4, 1, 4, 1314709137, 'Пополнение баланса баннера № 6'),
(5, 1, 4, 1314709137, 'Пополнение баланса баннера № 1'),
(6, 1, 7, 1314709137, 'Ваш реферал # 1 Продан на бирже рефералов!'),
(7, 1, 4, 1314709257, 'Пополнение баланса баннера № 6'),
(8, 1, 4, 1314709257, 'Пополнение баланса баннера № 1'),
(9, 0, 7, 1314709257, 'Ваш реферал #  Продан на бирже рефералов!'),
(10, 1, 4, 1314731800, 'Пополнение баланса динамической ссылки № 7'),
(11, 1, 4, 1314731891, 'Пополнение баланса динамической ссылки № 7'),
(12, 1, 2, 1314797609, 'заголовочеГ'),
(13, 1, 2, 1314911880, ''),
(14, 1, 4, 1314941896, 'Пополнение баланса динамической ссылки № 10'),
(15, 1, 4, 1314941927, 'Пополнение баланса динамической ссылки № 9'),
(16, 1, 4, 1314941934, 'Пополнение баланса динамической ссылки № 8'),
(17, 1, 4, 1314941957, 'Пополнение баланса динамической ссылки № 9'),
(18, 1, 4, 1314942335, 'Пополнение баланса динамической ссылки № 8'),
(19, 1, 4, 1314942335, 'Пополнение баланса динамической ссылки № 10'),
(20, 1, 4, 1314942599, 'Пополнение баланса динамической ссылки № 10'),
(21, 1, 4, 1314942603, 'Пополнение баланса динамической ссылки № 9'),
(22, 1, 4, 1314942607, 'Пополнение баланса динамической ссылки № 8'),
(23, 1, 4, 1314942649, 'Пополнение баланса динамической ссылки № 10'),
(24, 1, 4, 1314942785, 'Пополнение баланса динамической ссылки № 10'),
(25, 1, 4, 1314942981, 'Пополнение баланса динамической ссылки № 10'),
(26, 1, 4, 1314943039, 'Пополнение баланса динамической ссылки № 10'),
(27, 1, 4, 1314943128, 'Пополнение баланса динамической ссылки № 8'),
(28, 1, 4, 1314943153, 'Пополнение баланса динамической ссылки № 10'),
(29, 1, 4, 1314943241, 'Пополнение баланса динамической ссылки № 10'),
(30, 1, 4, 1314943288, 'Пополнение баланса динамической ссылки № 9'),
(31, 1, 4, 1314943402, 'Пополнение баланса баннера № 6'),
(32, 1, 4, 1314943477, 'Пополнение баланса баннера № 6');

-- --------------------------------------------------------

--
-- Структура таблицы `tb_chat`
--

CREATE TABLE IF NOT EXISTS `tb_chat` (
  `id` int(15) NOT NULL auto_increment,
  `user` varchar(20) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `message` text NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_chatads`
--

CREATE TABLE IF NOT EXISTS `tb_chatads` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `link` varchar(150) NOT NULL,
  `text` varchar(100) NOT NULL,
  `enddate` varchar(150) NOT NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_chatadsreq`
--

CREATE TABLE IF NOT EXISTS `tb_chatadsreq` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `link` varchar(150) NOT NULL,
  `text` varchar(100) NOT NULL,
  `plan` varchar(5) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_chatban`
--

CREATE TABLE IF NOT EXISTS `tb_chatban` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(150) NOT NULL,
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_chatcens`
--

CREATE TABLE IF NOT EXISTS `tb_chatcens` (
  `id` int(15) NOT NULL auto_increment,
  `text` varchar(150) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_comp`
--

CREATE TABLE IF NOT EXISTS `tb_comp` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `startdate` varchar(10) NOT NULL,
  `enddate` varchar(10) NOT NULL,
  `deldate` varchar(10) NOT NULL,
  `lidername` varchar(1) NOT NULL default '0',
  `param` varchar(2) NOT NULL default '0',
  `min` varchar(10) NOT NULL default '0',
  `descr` varchar(1000) NOT NULL,
  `pris1type` varchar(1) NOT NULL default '0',
  `pris1value` varchar(10) NOT NULL,
  `pris2type` varchar(1) NOT NULL default '0',
  `pris2value` varchar(10) NOT NULL,
  `pris3type` varchar(1) NOT NULL default '0',
  `pris3value` varchar(10) NOT NULL,
  `pris1status` varchar(1) NOT NULL default '0',
  `pris2status` varchar(1) NOT NULL default '0',
  `pris3status` varchar(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_compdata`
--

CREATE TABLE IF NOT EXISTS `tb_compdata` (
  `id` int(11) NOT NULL auto_increment,
  `idk` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `resvalue` int(10) NOT NULL default '0',
  `purse` varchar(13) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_config`
--

CREATE TABLE IF NOT EXISTS `tb_config` (
  `id` int(11) NOT NULL auto_increment,
  `item` varchar(15) NOT NULL,
  `howmany` varchar(15) NOT NULL,
  `price` varchar(150) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=122 ;

--
-- Дамп данных таблицы `tb_config`
--

INSERT INTO `tb_config` (`id`, `item`, `howmany`, `price`) VALUES
(1, 'click', '1', '0.25'),
(1, 'referalclick', '1', '0.06'),
(1, 'hits', '1', '450'),
(1, 'payment', '1', '30'),
(2, 'recordonline', '307', '0'),
(7, 'advbanner', '1', '100'),
(8, 'advstatlink', '1', '40'),
(9, 'mfabanner', '1', '100'),
(10, 'mfastatlink', '1', '40'),
(11, 'mfadyn', '1', '4'),
(12, 'hldyn', '1', '30'),
(13, 'mfahldyn', '1', '30'),
(18, 'adblock', '1', '50'),
(19, 'textads', '1', '50'),
(20, 'taskminprice', '1', '0.1'),
(21, 'taskmincount', '1', '10'),
(22, 'timer5', '1', '50'),
(23, 'wmframeads', '1', '30'),
(24, 'frameads', '1', '30'),
(96, 'advbanner100', '', '2'),
(30, 'chatmess', '1', '0.01'),
(95, 'viprefclick2', '1', '0.0005'),
(1, 'referalclick2', '1', '0.05'),
(33, 'dopsec', '1', '30'),
(34, 'leftblock', '1', '50'),
(59, 'psevdoweek4', '', '4000'),
(58, 'psevdoweek3', '', '3000'),
(37, 'vipblock', '1', '100'),
(38, 'vipcount', '1', '10'),
(39, 'wmchatads', '1', '30'),
(57, 'psevdoweek2', '', '2000'),
(56, 'psevdoweek1', '', '1000'),
(42, 'maxautopay', '1', '1000'),
(43, 'refmax', '0', '999999999999999999999999'),
(44, 'refmax', '1', '70'),
(45, 'autodeluser', '1', '999999999999999999999999'),
(46, 'refbirjcomm', '1', '15'),
(47, 'refbirjminclick', '1', '0'),
(48, 'ddosmaxhits', '1', '2'),
(49, 'ddosperiod', '1', '1'),
(50, 'ddoscrits', '1', '10'),
(51, 'captcha', '1', '40'),
(54, 'taskcomm', '1', '15'),
(55, 'taskhl', '1', '10'),
(98, 'banl', '', '150'),
(99, 'ban1', '', '80'),
(100, 'ban2', '', '85'),
(101, 'ban3', '', '90'),
(102, 'ban4', '', '95'),
(103, 'ban5', '', '100'),
(104, 'spam', '', '0.5'),
(105, 'ban88', '', '50'),
(106, 'refererbonus', '', '0.50'),
(107, 'offsite', '', '0'),
(108, 'actwin', '', '0.05'),
(109, 'cloudwm', '', '10'),
(110, 'cloudma', '', '20'),
(111, 'autolink', '', '87'),
(112, 'runblock', '', '50'),
(113, 'runacc', '', '50'),
(117, 'obperehod', '', '0.05'),
(114, 'antiauto', '', '15052'),
(116, 'autotime', '', '1282636943'),
(118, 'mobper', '', '4'),
(119, 'mhighlight', '', '3'),
(120, 'mprice', '', '1'),
(121, 'mtimer', '', '2'),
(121, 'lastupdate', '', UNIX_TIMESTAMP());

-- --------------------------------------------------------

--
-- Структура таблицы `tb_frameads`
--

CREATE TABLE IF NOT EXISTS `tb_frameads` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `link` varchar(150) NOT NULL,
  `text` varchar(100) NOT NULL,
  `enddate` varchar(150) NOT NULL,
  `views` int(11) NOT NULL default '0',
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_frameadsreq`
--

CREATE TABLE IF NOT EXISTS `tb_frameadsreq` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `link` varchar(150) NOT NULL,
  `text` varchar(100) NOT NULL,
  `plan` varchar(5) NOT NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_history`
--

CREATE TABLE IF NOT EXISTS `tb_history` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(150) NOT NULL,
  `date` varchar(150) NOT NULL,
  `amount` double default '0',
  `method` varchar(150) NOT NULL,
  `status` varchar(150) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_hosts`
--

CREATE TABLE IF NOT EXISTS `tb_hosts` (
  `id` int(20) NOT NULL auto_increment,
  `ip` varchar(15) NOT NULL,
  `data` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_mail`
--

CREATE TABLE IF NOT EXISTS `tb_mail` (
  `id` int(10) NOT NULL auto_increment,
  `sender` varchar(150) NOT NULL,
  `recipient` varchar(150) NOT NULL,
  `subject` varchar(20) NOT NULL,
  `message` text,
  `status` varchar(1) NOT NULL default '0',
  `data` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_mta`
--

CREATE TABLE IF NOT EXISTS `tb_mta` (
  `id` int(11) NOT NULL auto_increment,
  `user` varchar(150) NOT NULL,
  `amount` varchar(150) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_news`
--

CREATE TABLE IF NOT EXISTS `tb_news` (
  `id` int(10) NOT NULL auto_increment,
  `data` varchar(150) NOT NULL,
  `newstext` text NOT NULL,
  `tema` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `tb_news`
--

INSERT INTO `tb_news` (`id`, `data`, `newstext`, `tema`) VALUES
(1, '26.08.2011', 'Текст новости', 'Тема'),
(2, '26.08.2011', 'Текст новости', 'Тема'),
(3, '26.08.2011', 'Текст новости', 'Тема'),
(4, '26.08.2011', '[i]пиздес[/i]\r\n[b]gg[/b]', 'Тема');

-- --------------------------------------------------------

--
-- Структура таблицы `tb_payme`
--

CREATE TABLE IF NOT EXISTS `tb_payme` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `pasword` varchar(20) NOT NULL,
  `pemail` varchar(13) NOT NULL,
  `country` varchar(150) NOT NULL,
  `money` float NOT NULL,
  `ip` varchar(15) NOT NULL,
  `datetime` int(11) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_psevdolinks`
--

CREATE TABLE IF NOT EXISTS `tb_psevdolinks` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(150) NOT NULL,
  `description` varchar(55) NOT NULL,
  `begindate` int(11) NOT NULL,
  `numdays` int(5) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  `members` int(5) NOT NULL default '0',
  `outside` int(5) NOT NULL default '0',
  `texto` varchar(55) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `tb_psevdolinks`
--

INSERT INTO `tb_psevdolinks` (`id`, `url`, `description`, `begindate`, `numdays`, `wmid`, `members`, `outside`, `texto`) VALUES
(1, 'http://getwmz.net', 'sfb bleat psevdo', 1314397501, 1, '', 0, 0, 'bugaga psevdodesc');

-- --------------------------------------------------------

--
-- Структура таблицы `tb_psevdoreq`
--

CREATE TABLE IF NOT EXISTS `tb_psevdoreq` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(150) NOT NULL,
  `description` varchar(55) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  `plan` int(3) NOT NULL,
  `texto` varchar(55) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_refbirj`
--

CREATE TABLE IF NOT EXISTS `tb_refbirj` (
  `id` int(11) NOT NULL auto_increment,
  `iduser` int(10) NOT NULL,
  `price` varchar(10) NOT NULL default '0.000',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_restorepass`
--

CREATE TABLE IF NOT EXISTS `tb_restorepass` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(150) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_site`
--

CREATE TABLE IF NOT EXISTS `tb_site` (
  `id` varchar(11) NOT NULL,
  `sitename` varchar(30) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  `purse` varchar(13) NOT NULL,
  `valuta` varchar(1) NOT NULL,
  `valutaname` varchar(10) NOT NULL,
  `startdate` varchar(150) NOT NULL default '01.01.2009',
  `comment` varchar(150) NOT NULL default 'Выплата с :sitename: пользователю :username:',
  `blockip` varchar(15) NOT NULL,
  `ctrlword` varchar(150) NOT NULL,
  `email` varchar(30) default NULL,
  `merchant` varchar(2) default NULL,
  `secretkey` varchar(50) default NULL,
  `visits` varchar(3) default NULL,
  `payforday` varchar(3) default NULL,
  `takclick` varchar(3) default NULL,
  `sitetak` varchar(150) default NULL,
  `x2` varchar(3) default NULL,
  `robopass1` varchar(50) default NULL,
  `robopass2` varchar(50) default NULL,
  `robologin` varchar(50) default NULL,
  `timerpay` varchar(3) default NULL,
  `x6` varchar(3) default NULL,
  `clrmail` varchar(10) NOT NULL,
  `icq` int(15) NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `tb_site`
--

INSERT INTO `tb_site` (`id`, `sitename`, `wmid`, `purse`, `valuta`, `valutaname`, `startdate`, `comment`, `blockip`, `ctrlword`, `email`, `merchant`, `secretkey`, `visits`, `payforday`, `takclick`, `sitetak`, `x2`, `robopass1`, `robopass2`, `robologin`, `timerpay`, `x6`, `clrmail`, `icq`) VALUES
('1', 'MFS SeoEdit', '382683591943', 'R255627588882', 'R', 'руб', '26.06.2010', 'Выплата с :sitename: пользователю :username:', '', '', 'alex0235@shopforbux.ru', '1', 'merchant', '', '0', '0', 'tak ru', '0', 'pass1', 'pass2', 'robologin', '1', '0', '1278283203', 9368722);

-- --------------------------------------------------------

--
-- Структура таблицы `tb_statlinks`
--

CREATE TABLE IF NOT EXISTS `tb_statlinks` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(150) NOT NULL,
  `description` varchar(28) default NULL,
  `views` int(11) NOT NULL default '0',
  `paused` int(1) default '1',
  `price` double default '0',
  `texto` varchar(60) default NULL,
  `modered` int(1) NOT NULL default '0',
  `fromus` int(10) NOT NULL,
  `balance` double default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `tb_statlinks`
--

INSERT INTO `tb_statlinks` (`id`, `url`, `description`, `views`, `paused`, `price`, `texto`, `modered`, `fromus`, `balance`) VALUES
(2, 'http://getwmz.net', 'BLEAT SFB', 1, 0, 40, 'bleatbleat', 1, 1, 0),
(3, 'http://test1.ru/?idpage=2', 'BLEAT SFB', 0, 1, 40, 'bleatbleat', 0, 1, 40);

-- --------------------------------------------------------

--
-- Структура таблицы `tb_statlinksreq`
--

CREATE TABLE IF NOT EXISTS `tb_statlinksreq` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(150) NOT NULL,
  `description` varchar(150) NOT NULL,
  `wmid` varchar(12) NOT NULL,
  `plan` int(5) NOT NULL,
  `leftblock` int(1) NOT NULL default '0',
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_task`
--

CREATE TABLE IF NOT EXISTS `tb_task` (
  `id` int(11) NOT NULL auto_increment,
  `author` varchar(30) NOT NULL,
  `title` varchar(50) NOT NULL,
  `descr` varchar(10000) NOT NULL,
  `amount` float NOT NULL default '0',
  `kolvo` varchar(10) NOT NULL default '0',
  `starturl` varchar(150) NOT NULL,
  `verinfo` varchar(1000) NOT NULL,
  `data` varchar(20) NOT NULL,
  `hltask` varchar(7) NOT NULL default '#ffffff',
  `good` varchar(10) NOT NULL default '0',
  `bad` varchar(10) NOT NULL default '0',
  `wait` varchar(10) NOT NULL default '0',
  `balance` varchar(10) NOT NULL default '0.00',
  `reyt` varchar(5) NOT NULL default '0',
  `abuses` varchar(5) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_taskstats`
--

CREATE TABLE IF NOT EXISTS `tb_taskstats` (
  `id` int(11) NOT NULL auto_increment,
  `idtask` int(11) NOT NULL default '0',
  `verinfo` varchar(1000) NOT NULL,
  `amount` float NOT NULL default '0',
  `status` varchar(1) NOT NULL default '0',
  `user` varchar(50) NOT NULL,
  `data` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_textads`
--

CREATE TABLE IF NOT EXISTS `tb_textads` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `url` varchar(150) NOT NULL,
  `text` varchar(255) NOT NULL,
  `enddate` int(11) NOT NULL,
  `views` int(11) NOT NULL default '0',
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_textadsreq`
--

CREATE TABLE IF NOT EXISTS `tb_textadsreq` (
  `id` int(11) NOT NULL auto_increment,
  `wmid` varchar(12) NOT NULL,
  `url` varchar(150) NOT NULL,
  `text` varchar(255) NOT NULL,
  `plan` int(3) NOT NULL,
  `email` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `tb_users`
--

CREATE TABLE IF NOT EXISTS `tb_users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `pemail` varchar(13) NOT NULL,
  `referer` int(10) NOT NULL,
  `country` varchar(30) NOT NULL,
  `visits` int(11) NOT NULL default '0',
  `referals` int(5) NOT NULL default '0',
  `referalvisits` int(10) NOT NULL default '0',
  `money` double NOT NULL default '0',
  `paid` double NOT NULL default '0',
  `joindate` varchar(15) NOT NULL,
  `lastiplog` varchar(15) NOT NULL,
  `account` varchar(8) NOT NULL default 'Базовый',
  `user_status` varchar(8) NOT NULL default 'user',
  `wmid` varchar(12) NOT NULL,
  `blockip` varchar(15) NOT NULL,
  `chatpaid` double NOT NULL default '0',
  `chatmoder` int(1) NOT NULL default '0',
  `chatmessages` int(5) default NULL,
  `avatar` varchar(50) NOT NULL default 'no.png',
  `reyting` int(11) NOT NULL default '0',
  `referer2` int(10) default NULL,
  `referalvisits2` int(6) default '0',
  `views_mails` int(11) NOT NULL default '0',
  `money_mails` double NOT NULL default '0',
  `email` varchar(30) default NULL,
  `lastpay` int(11) default NULL,
  `blockpay` varchar(3) default NULL,
  `lastcook` varchar(50) default NULL,
  `rek` varchar(50) default NULL,
  `curlink` varchar(150) NOT NULL,
  `chitor` varchar(150) NOT NULL,
  `bayref` varchar(150) NOT NULL,
  `dayvisit` varchar(150) NOT NULL,
  `timerec` varchar(150) NOT NULL,
  `finset` int(11) NOT NULL default '0',
  `auth` varchar(10) NOT NULL,
  `lastlogdate` varchar(150) default NULL,
  `actcode` varchar(15) NOT NULL,
  `passtype` varchar(5) NOT NULL,
  `lastver` varchar(50) NOT NULL,
  `taskabuses` varchar(5) NOT NULL default '0',
  `timereg` int(15) NOT NULL,
  `sell` varchar(10) NOT NULL,
  `popal` varchar(3) NOT NULL default '0',
  `popadostime` varchar(50) NOT NULL,
  `lastmail` int(15) NOT NULL,
  `autoproc` int(3) NOT NULL default '0',
  `toref` double default '0',
  `doing` int(1) default '0',
  `family` int(1) default '0',
  `mailaccess` int(1) default '0',
  `taskreyt` int(5) NOT NULL default '0',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `tb_users`
--

INSERT INTO `tb_users` (`id`, `username`, `password`, `ip`, `pemail`, `referer`, `country`, `visits`, `referals`, `referalvisits`, `money`, `paid`, `joindate`, `lastiplog`, `account`, `user_status`, `wmid`, `blockip`, `chatpaid`, `chatmoder`, `chatmessages`, `avatar`, `reyting`, `referer2`, `referalvisits2`, `views_mails`, `money_mails`, `email`, `lastpay`, `blockpay`, `lastcook`, `rek`, `curlink`, `chitor`, `bayref`, `dayvisit`, `timerec`, `finset`, `auth`, `lastlogdate`, `actcode`, `passtype`, `lastver`, `taskabuses`, `timereg`, `sell`, `popal`, `popadostime`, `lastmail`, `autoproc`, `toref`, `doing`, `family`, `mailaccess`, `taskreyt`) VALUES
(1, 'admin', 'admintest', '', 'B328199753153', 0, '', 6, 0, 0, 32.5, 0, '', '213.109.86.64', 'Базовый', 'admin', '', '', 0, 0, NULL, 'no.png', 0, 0, 0, 0, 0, 'magistr-yoda90@mail.ru', NULL, NULL, NULL, NULL, '', '', '', '', '', 0, '', '02.09.2011', 'ok', '2', '1312971098', '0', 0, '', '0', '', 0, 0, 0, 1, 2, 0, 0),
(2, 'test', 'admintest', '127.0.0.1', '', 0, '(Private Address)', 0, 0, 0, 0, 0, '28.08.2011', '', 'Базовый', 'user', '', '', 0, 0, NULL, 'no.png', 0, 0, 0, 0, 0, 'getwmz.net@mail.ru', NULL, NULL, NULL, NULL, '', '', '', '', '', 0, '', NULL, '', '', '', '0', 0, '', '0', '', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `tb_visits`
--

CREATE TABLE IF NOT EXISTS `tb_visits` (
  `id` int(10) NOT NULL auto_increment,
  `idus` int(10) NOT NULL,
  `data` int(11) NOT NULL,
  `ident` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `tb_visits`
--

INSERT INTO `tb_visits` (`id`, `idus`, `data`, `ident`) VALUES
(1, 1, 1314559258, 7),
(2, 1, 1314943135, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `users_online`
--

CREATE TABLE IF NOT EXISTS `users_online` (
  `visitor` varchar(15) NOT NULL,
  `lastvisit` int(14) NOT NULL,
  `user` varchar(25) NOT NULL,
  `urlpage` varchar(150) NOT NULL,
  `loading` int(6) NOT NULL default '0',
  `blocked` varchar(1) NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

--
-- Дамп данных таблицы `users_online`
--

INSERT INTO `users_online` (`visitor`, `lastvisit`, `user`, `urlpage`, `loading`, `blocked`) VALUES
('195.114.7.162', 1314945217, 'admin', '<font color=#ff0000>Зарабатывает</font>', 0, '0');

-- --------------------------------------------------------

--
-- Структура таблицы `user_zal`
--

CREATE TABLE IF NOT EXISTS `user_zal` (
  `id` int(11) NOT NULL auto_increment,
  `link_id` int(11) NOT NULL,
  `user` int(50) NOT NULL,
  `date` int(11) NOT NULL,
  `text` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `user_zal`
--

INSERT INTO `user_zal` (`id`, `link_id`, `user`, `date`, `text`) VALUES
(1, 2, 0, 1312957334, ''),
(2, 7, 1, 1314736136, 'выав'),
(3, 7, 1, 1314736171, 'выав'),
(4, 7, 1, 1314736174, 'выав'),
(5, 7, 1, 1314736183, 'выав'),
(6, 7, 1, 1314736194, 'выав');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;


ALTER TABLE tb_ads ADD reas TEXT not null;
ALTER TABLE seo_paymails ADD reas TEXT not null;
ALTER TABLE tb_advban ADD reas TEXT not null;
ALTER TABLE tb_statlinks ADD reas TEXT not null;
ALTER TABLE seo_tasks ADD reas TEXT not null;
CREATE TABLE IF NOT EXISTS `seo_blacklist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site` varchar(255) not null,
  `reason` text not null,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=cp1251 AUTO_INCREMENT=1 ;
CREATE TABLE IF NOT EXISTS `tb_statistic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '',
  `typ` int(1) NOT NULL DEFAULT 0,
  `date` int(3) NOT NULL DEFAULT -1,
  `total` int(11) NOT NULL DEFAULT 0,
  `mon` int(3) NOT NULL DEFAULT 0,
  `tue` int(3) NOT NULL DEFAULT 0,
  `wed` int(3) NOT NULL DEFAULT 0,
  `thu` int(3) NOT NULL DEFAULT 0,
  `fri` int(3) NOT NULL DEFAULT 0,
  `sat` int(3) NOT NULL DEFAULT 0,
  `sun` int(3) NOT NULL DEFAULT 0,
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;

INSERT INTO tb_config (item,price) values ('mpay','0.04'),
('mrefpay','0.02');


UPDATE tb_config SET price='1316362247' WHERE item='lastupdate';
ALTER TABLE tb_site ADD seoeditkey VARCHAR(40) NOT NULL;