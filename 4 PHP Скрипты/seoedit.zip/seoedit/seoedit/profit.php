<? include('header.php');
session_start();
$_GET[type]=5;
						 $kolvo=20; //���-�� ��������� �������� �� ��������
						 						$type=intval($_GET[type]);
						if($type=='') $type=0;
						$zapros=" and `doing`='$type'";
						if($type==0) $zapros='';
$allnews=mysql_num_rows(mysql_query("SELECT id FROM tb_allhistory where `doing`='5'"));$allsqls++; //����� ���-�� ��������
$vsego=intval($allnews/$kolvo);
if($vsego==0) $vsego=1;
$nowpage=$_GET[pg];
if($nowpage=='' or $nowpage<=0) { $nowpage=1; }else{ 
$nowpage=intval($_GET["pg"]);
}
if($nowpage-1>$vsego) $nowpage=$vsego;
if(!isset($_GET["pg"]) or $_GET[pg]=='') $nowpage=1;
$gg=$vsego*$kolvo;
if($gg<$allnews) { $vsego=$vsego+1; }
$pages=$vsego/$kolvo;
$pages1=floor($pages);
$pg1=$kolvo*($nowpage-1);
$pg2=$kolvo;
if($nowpage==$vsego) { $pg1=0; $pg2=$kolvo; }
if($pages>$pages1)
{
	$pages=$pages1+1;
}
///!!!

echo "                        <table width='100%' style='margin-bottom: 5px;'><tr>
						
						
						<td nowrap='nowrap'>";
						$nextp=$nowpage+1;
						$lastp=$nowpage-1;
						if($nowpage!=1) { echo "<a href='/profit.php?pg=$lastp'><span class='text14'>"; }else{ echo "<span class='textgray'>"; } echo "&larr;&nbsp;� �������</span>";if($nowpage==1) { echo "</a>"; } echo "</td>
						<td width='90%' align='center'>�������� $nowpage �� $vsego</td>
						<td nowrap='nowrap'>";
						if($nowpage==$vsego){ echo "<span class='textgray'>"; 
						}else{ echo "<a href='/profit.php?pg=$nextp'><span class='text14'>"; } echo "� �������&nbsp;&rarr;</span>"; if($nowpage==$vsego) { echo "</a>"; } echo "</td>
						</tr></table>";
?>
	
						
						<table class='history' width='100%' border='0' cellpadding='0' cellspacing='0'>
						<thead>
						<tr>
						<th></th>
						<th align='center' nowrap='nowrap'>���� � �����</th>
						<th align='center' width='80%' nowrap='nowrap'>�������</th>
						</tr>
						</thead><tbody>
						<?
						$type=intval($_GET[type]);
						if($type=='') $type=0;
						$zapros=" and `doing`='$type'";
						if($type==0) $zapros='';
						$sql=mysql_query("SELECT * FROM tb_allhistory WHERE `doing`='5' ORDER by data DESC limit $pg1,$pg2") or die(mysql_error());
						if(mysql_num_rows($sql)==0)
						{
						echo "</table>";
						include('footer.php');
						exit;
						}
						while($row=mysql_fetch_assoc($sql))
						{
						$datenow=date("d.m");
						$datedo=date("d.m",$row[data]);
						if($datedo==$datenow) { $prtdt="<b>�������</b><br />".date("H:i", $row[data]); }else{ $prtdt=date("d.m",$row[data])."<br>".date("H:i",$row[data]); }
						if($row[doing]==2) { $ico="adv";$row[title]="<b>��������� ��������� ��������</b><br>$row[title]"; }
						if($row[doing]==3) $ico="user";
						if($row[doing]==1) $ico="profile";
						$ico="money";
						?>
						<tr><td class='value'>
						
						<img src='/images/history/<?=$ico ?>.png' width='16' height='16' alt='' />
						
						</td>
						<td class='value'><?=$prtdt ?></td>
						<td>
						
						<?=$row[title] ?> ������������ � <?=$row[idus] ?>
						
						</td>
						</tr>
					<?
					}
			?></tbody></table>
			<? include('footer.php'); ?>