/*-----------------------

���� �� ������ D&G ��� �� ������� =)

-----------------------*/
this.tooltip = function(){	
	xOffset = 35;
		yOffset = 10;
        
				
		$("[title]").hover(function(e){											  
		this.t = this.title;
		this.title = "";
       	$("[title]").append("<span class='pod'><span>"+ this.t +"</span></span>");
		$(".pod")
			.css("top",(e.pageY - xOffset) + "px")
			.css("left",(e.pageX + yOffset) + "px")
			.fadeIn("slow");
			
    },
	function(){
		this.title = this.t;		
		$(".pod").remove()
		
    });	
	$("[title]").mousemove(function(e){
		$(".pod")
			.css("top",(e.pageY - xOffset) + "px")
			.css("left",(e.pageX + yOffset) + "px")
	        .fadeOut("slow");
	});			
};
$(document).ready(function(){
	tooltip()
	;
});
