<?
session_start();
require('config.php');
$ad=$_SESSION["ad"];
$active=0;
$user=$_SESSION["username"]; 
$qwe=$_GET["view"];
if($qwe!="ok")
{
	$t=time();
	$t=$t+$_SESSION["timer"];
	$_SESSION["endtime"]=$t;
}
if(mysql_result(mysql_query("SELECT many FROM seo_paymails WHERE id='$ad'"),0)==0 and mysql_num_rows(mysql_query("SELECT id FROM seo_paymailsviews WHERE ident='$ad' and fromid='$_SESSION[iduser]'"))!=0)
{
?> <font color=red>������������� �������� ��������� �������� ������! </font><?
exit; 
}
?>

<script language=javascript>
if(self==parent) self.window.location='readmails.php';
</script>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<style type="text/css">
	a, a:link, a:visited { color: #057fac; text-decoration: none; font-family: Verdana; font-size: 13px; }
	a:hover {color: #f00; text-decoration: none; font-family: Verdana; font-size: 13px; }
</style>
</head>
<body>

<?
if($active!='1')
{

?>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td width="8" height="8"><img src="/frmimg/2-1.gif" border="0"></td><td style="background:url('/frmimg/2-2.gif');"></td><td width="8" height="8"><img src="/frmimg/2-3.gif" border="0"></td>
<tr><td style="background:url('/frmimg/2-4.gif');"></td><td style="background:#ffffff;" height="60%" valign="top">
<!--�������-->
<table height=58 id="tbl" background=frmimg/header/bg.gif border="0" cellpadding="0" cellspacing="0" width="100%">

<td style="font-family: Verdana;font-size: 13px;" width="30%" rowspan=2 valign=center>
<?
if($qwe!="ok")
{
	?>
	<script type="text/javascript">
function timer(){
 var obj=document.getElementById('sfbtimer');
 obj.innerHTML--;
 if(obj.innerHTML==0){
 location.replace("vlsmail.php?view=ok");
 setTimeout(function(){},1000);}
 else{setTimeout(timer,1000);}
}
setTimeout(timer,1000);
</script>
	<noscript>
	<meta http-equiv="refresh" content="<?=$_SESSION["timer"]?>; url=vlsmail.php?view=ok">
	</noscript>

<span style="border: medium none ; padding: 0pt; font-size: 8pt; font-family: Verdana; vertical-align: top;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;���������, ����������, <span style="color:#ff0000" id="sfbtimer"><?=$_SESSION["timer"] ?></span> ������...</span><?
}else{
	include('successmail.php');
}
}else{
?><table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td width="8" height="8"><img src="/frmimg/2-1.gif" border="0"></td>
<td style="background:url('/frmimg/2-2.gif');"></td>
<td width="8" height="8"><img src="/frmimg/2-3.gif" border="0"></td>
<tr><td style="background:url('/frmimg/2-4.gif');"></td><td style="background:#ffffff;" height="60%" valign="top">
<!--�������-->
<table height=58 id="tbl" background=frmimg/header/bg.gif border="0" cellpadding="0" cellspacing="0" width="100%">

<td style="font-family: Verdana;font-size: 13px;" width="30%" rowspan=2 valign=center>
<? if($qwe!='ok')
{
?><script type="text/javascript">
var b = false;
var last = 0;
function t() {
    var c = document.getElementById('time');
    if (typeof c == "undefined") return;
    var t = parseInt(c.innerHTML);
    last = stime();
    if (t > 0) {
        if (b == true) {
            setTimeout('t()', 1000);
            return
        }--t;
        setTimeout('t()', 1000)
    } else {
        location.replace("vlsmail.php?view=ok")
    }
    c.innerHTML = t
};
function stime() {
    var d = new Date();
    return d.getTime()
};
function w_obj() {
    var wobj, i;
    for (i = 0; i < 10; ++i) {
        wobj = self.parent;
        if ((wobj && !(wobj === self)) && (wobj.frames.length != 0)) {
            wobj = self.parent
        }
    }
    return wobj
}
var w;
if (navigator.appName == "Microsoft Internet Explorer") w = w_obj();
else w = top;
setTimeout('t()', 1000);
w.onblur = function() {
    b = true
};
w.onfocus = function() {
    b = false
};
w.onmousemove = function() {
    b = false;
    if (last > 0 && last < stime() - 1500) setTimeout('t()', 1000)
};
</script>

<span style="border: medium none ; padding: 0pt; font-size: 8pt; font-family: Verdana; vertical-align: top;">     ���������, ����������, <span id="time"><?=$_SESSION["timer"] ?></span> ������...</span> 
<? }else{
include('successmail.php');
}
}
?>
</td>

<td align="right"><? include('rotator.php'); ?>
</td></table></td><td style="background:url('/frmimg/2-5.gif');"></td>
</tr>
<tr><td width="8" height="8"><img src="/frmimg/2-6.gif" border="0"></td><td style="background:url('/frmimg/2-7.gif');"></td><td width="8" height="8"><img src="/frmimg/2-8.gif" border="0"></td>
</tr></table>




</body>
</html>