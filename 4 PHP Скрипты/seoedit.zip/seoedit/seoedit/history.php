<?
session_start();

include('header.php'); ?>
        <script type="text/javascript" language="JavaScript">
            function filtertable(mode)
            {
                document.cookie="filterhistory="+mode;
                top.location = '/history.php?type='+mode;
                return false;
            }
        </script>
                        <h1>������� ��������</h1>
                        <table border='0' align='center'>
						<tr><td>
						<span class='filtermenu<? if(!isset($_GET[type]) OR $_GET[type]==0) echo "active"; ?>' title='��� ��������' onclick='javascript:filtertable(0);'>
						<img src='/images/history/all.png' width='16' height='16' border='0' alt='' /></span>
						<span class='filtermenu<?if($_GET[type]==3) echo "active"; ?>' title='����� ���������' onclick='javascript:filtertable(3);'>
						<img src='/images/history/user.png' width='16' height='16' border='0' alt='' /></span>
						<span class='filtermenu<?if($_GET[type]==4) echo "active"; ?>' title='�� ��� � ���������(�)' onclick='javascript:filtertable(4);'>
						<img src='/images/history/wallet.png' width='16' height='16' border='0' alt='' />
						</span>
						
						<span class='filtermenu<?if($_GET[type]==1) echo "active"; ?>' title='��������� �������' onclick='javascript:filtertable(1);'>
						<img src='/images/history/profile.png' width='16' height='16' border='0' alt='' />
						</span>
						<span class='filtermenu<?if($_GET[type]==5) echo "active"; ?>' title='��� �������' onclick='javascript:filtertable(5);'>
						<img src='/images/history/money.png' width='16' height='16' border='0' alt='' />
						</span>
						<span class='filtermenu<?if($_GET[type]==2) echo "active"; ?>' title='��������� ��������' onclick='javascript:filtertable(2);'>
						<img src='/images/history/adv.png' width='16' height='16' border='0' alt='' /></span>
						<span class='filtermenu<?if($_GET[type]==7) echo "active"; ?>' title='����������' onclick='javascript:filtertable(7);'>
						<img src='/images/history/drink.png' width='16' height='16' border='0' alt='' />
						</span>
						</td></tr></table>
						<?
						 $kolvo=20; //���-�� ��������� �������� �� ��������
						 						$type=intval($_GET[type]);
						if($type=='') $type=0;
						$zapros=" and `doing`='$type'";
						if($type==0) $zapros='';
$allnews=mysql_num_rows(mysql_query("SELECT id FROM tb_allhistory where idus='$_SESSION[iduser]'$zapros"));$allsqls++; //����� ���-�� ��������
$vsego=intval($allnews/$kolvo);
if($vsego==0) $vsego=1;
$nowpage=$_GET[pg];
if($nowpage=='' or $nowpage<=0) { $nowpage=1; }else{ 
$nowpage=intval($_GET["pg"]);
}
if($nowpage-1>$vsego) $nowpage=$vsego;
if(!isset($_GET["pg"]) or $_GET[pg]=='') $nowpage=1;
$gg=$vsego*$kolvo;
if($gg<$allnews) { $vsego=$vsego+1; }
$pages=$vsego/$kolvo;
$pages1=floor($pages);
$pg1=$kolvo*($nowpage-1);
$pg2=$kolvo;
if($nowpage>$vsego) { $pg1=0; $pg2=$kolvo; }
if($pages>$pages1)
{
	$pages=$pages1+1;
}
///!!!

echo "                        <table width='100%' style='margin-bottom: 5px;'><tr>
						
						
						<td nowrap='nowrap'>";
						$nextp=$nowpage+1;
						$lastp=$nowpage-1;
						if($nowpage>=1 and $nowpage<$vsego) { echo "<a href='/history.php?pg=$nextp'><span class='text14'>"; }else{ echo "<span class='textgray'>"; } echo "&larr;&nbsp;� �������</span>";if($nowpage==1) { echo "</a>"; } echo "</td>
						<td width='90%' align='center'>�������� $nowpage �� $vsego | $pg1  | $pg2</td>
						<td nowrap='nowrap'>";
						if($nowpage>1 and $nowpage<=$vsego){echo "<a href='/history.php?pg=$lastp'><span class='text14'>";
						}else{ echo "<span class='textgray'>"; 
						  } echo "� �������&nbsp;&rarr;</span>"; if($nowpage==$vsego) { echo "</a>"; } echo "</td>
						</tr></table>";
?>
	
						
						<table class='history' width='100%' border='0' cellpadding='0' cellspacing='0'>
						<thead>
						<tr>
						<th></th>
						<th align='center' nowrap='nowrap'>���� � �����</th>
						<th align='center' width='80%' nowrap='nowrap'>�������</th>
						</tr>
						</thead><tbody>
						<?
						$type=intval($_GET[type]);
						if($type=='') $type=0;
						$zapros=" and `doing`='$type'";
						if($type==0) $zapros='';
						$sql=mysql_query("SELECT * FROM tb_allhistory WHERE idus='$_SESSION[iduser]'$zapros ORDER by data DESC limit $pg1,$pg2") or die(mysql_error());
						if(mysql_num_rows($sql)==0)
						{
						echo "</table>";
						include('footer.php');
						exit;
						}
						while($row=mysql_fetch_assoc($sql))
						{
						$datenow=date("d.m");
						$datedo=date("d.m",$row[data]);
						if($datedo==$datenow) { $prtdt="<b>�������</b><br />".date("H:i", $row[data]); }else{ $prtdt=date("d.m",$row[data])."<br>".date("H:i",$row[data]); }
						if($row[doing]==2) { $ico="adv";$row[title]="<b>��������� ��������� ��������</b><br>$row[title]"; }
						if($row[doing]==3) $ico="user";
						if($row[doing]==1) $ico="profile";
						if($row[doing]==4) $ico="wallet";
						if($row[doing]==5) $ico='money';
						if($row[doing]==7) $ico="drink";
						?>
						<tr><td class='value'>
						
						<img src='/images/history/<?=$ico ?>.png' width='16' height='16' alt='' />
						
						</td>
						<td class='value'><?=$prtdt ?></td>
						<td>
						
						<?=$row[title] ?>
						
						</td>
						</tr>
					<?
					}
			?></tbody></table>

		<!--footer starts here-->
<? include('footer.php'); ?>
