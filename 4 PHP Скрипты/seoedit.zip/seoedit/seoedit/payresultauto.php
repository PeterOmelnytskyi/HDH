<?
require('config.php');
require('sfbstat.php');
$koshel=$sitepurse; //����� ������ ��� ������...
$nowtime=time();
//�����������
   require_once('config.php');
  $sql = "SELECT * FROM tb_statlinksreq ORDER BY id ASC";
  $rest = mysql_query($sql) or die(mysql_error());

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
    $id=$row["id"];
    $urlsite=$row["url"];
    $description=$row["description"];
    $wmid=$row["wmid"];
	$email=$row["email"];
    $lb=$row["leftblock"];
    $t=time();
    $plan=$row["plan"];
    $res=mysql_query("select price from tb_config where item='advstatlink'") or die(mysql_error());
    $res=mysql_fetch_array($res);
    $nado=$res["price"]*$plan;
	
    $res=mysql_query("select price from tb_config where item='leftblock'") or die(mysql_error());
    $res=mysql_fetch_array($res);
    $nado=$nado+$lb*$res["price"];
    $nado=round($nado,2); 
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "����������� ������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_statlinksreq WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
            $query = "INSERT INTO tb_statlinks (url,description,wmid,leftblock,begindate,numdays,email) VALUES('$urlsite','$description','$wmid','$lb','$t','$plan','$email')";
      	    mysql_query($query) or die(mysql_error());
			

      	    $queryz = "DELETE FROM tb_statlinksreq WHERE id='$id'";
      	    mysql_query($queryz) or die(mysql_error());

	    $res=mysql_query("select * from tb_comp where param='7'") or die(mysql_error());

	    if (mysql_num_rows($res)>0)
	    {
	      while ($row=mysql_fetch_array($res))
	      {
	        $id=$row["id"];
		$lidertype=$row["lidername"];
		$t=time();
		$sd=strtotime($row["startdate"]);
		$ed=strtotime($row["enddate"]);

		if ($t>$sd && $t<$ed)
		{
		  if ($lidertype=='0')
		  {
		    $res1=mysql_query("select username from tb_users where wmid='$wmid'");

		    if (mysql_num_rows($res1)>0)
                    {
                      $res1=mysql_fetch_array($res1);
                      $lidername=$res1["username"];
                    }
                    else
                    {
                      $lidername='';
                    }
		  }
                  else
                  {
		    $lidername=$wmid;
		  }

		  if ($lidername!='')
		  {
		    $res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");

		    if (mysql_num_rows($res1)>0)
		    {
		      $res1=mysql_Fetch_array($res1);
		      $resvalue=$res1["resvalue"]+$plan;
		      $purse=$kosheluser;
		      mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
		    }
                    else
                    {
		      $purse=$kosheluser;
		      mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
		    }
		  }
		}
	      }
	    }
          }
	}
      }
    }
  }
  //��������
    require_once('config.php');
$rest=mysql_query("select * from tb_advertisers ORDER BY id ASC");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  $pemail=$row["pemail"]; $email=$row["email"]; $plan=$row["plan"]; $url=$row["url"]; $description=$row["description"]; $highlight=$row["highlight"]; $fechainicia=time(); $timer=$row["timer"]; $dopsec=$row["dopsec"]; $vip=$row["vip"];
		$active=$row["act"];$obper=$row["obper"];

		$res=mysql_query("select price from tb_config where item='hits'");
		$res=mysql_fetch_array($res);
		$nado=$res["price"]*$plan;
	
		$res=mysql_query("select price from tb_config where item='hldyn'");
		$res=mysql_fetch_array($res);
		if ($highlight!='#ffffff') 
			           { 
				   $nado=$nado+$res["price"];
				   }else{
				   $nado=$nado;
				   }

		$sql="select price from tb_config where item='timer5'";
		$res=mysql_query($sql);
		$timer5=mysql_result($res,0,0);
		$sql="select price from tb_config where item='actwin'";
		$res=mysql_query($sql);
		$actwin=mysql_result($res,0,0);
		$sql="select price from tb_config where item='obperehod'";
		$res=mysql_query($sql);
		$obperehod=mysql_result($res,0,0);
		$sql="select price from tb_config where item='dopsec'";
		$res=mysql_query($sql);
		$ds=mysql_result($res,0,0);

		$sql="select price from tb_config where item='vipblock'";
		$res=mysql_query($sql);
		$vipprice=mysql_result($res,0,0);

		$sql="select price from tb_config where item='captcha'";
		$res=mysql_query($sql);
		$captcha=mysql_result($res,0,0);
		$tp = mysql_query("SELECT * FROM tb_site WHERE id='1'");
		$tp = mysql_fetch_array($tp);
		$timerpay = $tp["timerpay"];
	
		$timer1=($timer-20)/5;
		if($timerpay == 0)
		{
		$nado=$nado+$timer1*$timer5+$vipprice*$vip;
		if ($dopsec==1) { $nado=$nado+$ds; }
		if ($dopsec==2) { $nado=$nado+$captcha; }
		if ($active==1) { $nado=$nado+$actwin*$plan; }
		if ($obper==1) { $nado=$nado+$obperehod*$plan; }
		$nado=round($nado,2);
		}
		if($timerpay == 1)
		{
		$nado=$vipprice*$vip;
include('moneyfortimer.php');
	if($timer==5) { $precio=$plan*$dyn5;}
	if($timer==10) { $precio=$plan*$dyn10;}
	if($timer==15) { $precio=$plan*$dyn15;}
	if($timer==20) { $precio=$plan*$dyn20;}
	if($timer==25) { $precio=$plan*$dyn25;}
	if($timer==30) { $precio=$plan*$dyn30;}
	if($timer==35) { $precio=$plan*$dyn35;}
	if($timer==40) { $precio=$plan*$dyn40;}
	if($timer==45) { $precio=$plan*$dyn45;}
	if($timer==50) { $precio=$plan*$dyn50;}
	if($timer==55) { $precio=$plan*$dyn55;}
	if($timer==60) { $precio=$plan*$dyn60;}
		$nado=$nado+$precio;
		if ($dopsec==1) { $nado=$nado+$ds; }
		if ($dopsec==2) { $nado=$nado+$captcha; }
		if ($active==1) { $nado=$nado+$actwin*$plan; }
		if ($obper==1) { $nado=$nado+$obperehod*$plan; }
		$nado=round($nado,2);
		}
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������������ ������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring); 
      $pos2 = strpos($desc, $dyn);
      if ($pemail == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_advertisers WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
		  $wmid=$pemail;
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
		$query = "INSERT INTO tb_ads (fechainicia, obper, act, email, paypalemail, plan, url, description, tipo, highlight, timer, dopsec, vip) VALUES('$fechainicia','$obper','$active','$email','$pemail','$plan','$url','$description','ads','$highlight', '$timer', '$dopsec','$vip')";
		mysql_query($query) or die(mysql_error());

		$queryz = "DELETE FROM tb_advertisers WHERE id='$id'";
		mysql_query($queryz) or die(mysql_error());

		$t=date("d.m.Y", time());
		$res=mysql_query("select count(id) as kol from tb_adsdate where data='$t'");
		$res=mysql_fetch_array($res);
		if($res["kol"]>0)
		{
			mysql_query("update tb_adsdate set kolvo=kolvo+1 where data='$t'");
		}else{
			mysql_query("insert into tb_adsdate (data,kolvo) values ('$t','1')");
		}

		$res=mysql_query("select * from tb_comp where param='6'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='0')
					{
						$res1=mysql_query("select username from tb_users where wmid='$pemail'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';}
					}else{
						$lidername=$pemail;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$plan;
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
						}
					}
				}
			}
		}
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
  //�������
  //����� � ����
    require_once('config.php');
$rest=mysql_query("select * from tb_chatadsreq ORDER BY id ASC");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  $wmid=$row["wmid"]; $email=$row["email"]; $linksite=$row["link"]; $text=$row["text"]; $plan=$row["plan"]; $t=time(); $t=$t+$plan*24*3600;
		
		$res=mysql_query("select price from tb_config where item='wmchatads'");
		$res=mysql_fetch_array($res);
		$nado=$res["price"]*$plan;
		$nado=round($nado,2);
	
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������ � ����";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_chatadsreq WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
		$query = "INSERT INTO tb_chatads (wmid,link,text,enddate,email) VALUES('$wmid','$linksite','$text','$t','$email')";
		mysql_query($query) or die(mysql_error());

		$queryz = "DELETE FROM tb_chatadsreq WHERE id='$id'";
		mysql_query($queryz) or die(mysql_error());

		$res=mysql_query("select * from tb_comp where param='10'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='0')
					{
						$res1=mysql_query("select username from tb_users where wmid='$wmid'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';}
					}else{
						$lidername=$wmid;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$plan;
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
						}
					}
				}
			}
		}
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
  //�������
    require_once('config.php');
$rest=mysql_query("select * from tb_addbanner ORDER BY id ASC");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  $urlsite=$row["urlsite"]; $email=$row["email"]; $urlpic=$row["urlpic"]; $t=time(); $plan=$row["plan"]; $wmid=$row["wmid"];

		$res=mysql_query("select price from tb_config where item='advbanner'");
		$res=mysql_fetch_array($res);
		$nado=$res["price"]*$plan;
		$nado=round($nado,2);
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������� 468�60";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_addbanner WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
		mysql_query("INSERT INTO tb_advban (urlsite,urlpic,begindate,numdays,wmid,email) VALUES('$urlsite','$urlpic','$t','$plan','$wmid','$email')");
		mysql_query("DELETE FROM tb_addbanner WHERE id='$id'");

		$res=mysql_query("select * from tb_comp where param='8'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='0')
					{
						$res1=mysql_query("select username from tb_users where wmid='$wmid'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';}
					}else{
						$lidername=$wmid;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$plan;
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
						}
					}
				}
			}
		}
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
  
  
  //�����������
    require_once('config.php');
$rest=mysql_query("select * from tb_psevdoreq ORDER BY id ASC");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
   $urlsite=$row["url"]; 
  $description=$row["description"]; 
  $wmid=$row["wmid"]; 
  $plan=$row["plan"]; 
  $t=time(); 
/////////��������� ���� �� ����� 
$sql="select price from tb_config where item='psevdoweek1'";  
$res=mysql_query($sql);  
$psevdoweek1=mysql_result($res,0,0);  

$sql="select price from tb_config where item='psevdoweek2'";  
$res=mysql_query($sql);  
$psevdoweek2=mysql_result($res,0,0);  

$sql="select price from tb_config where item='psevdoweek3'";  
$res=mysql_query($sql);  
$psevdoweek3=mysql_result($res,0,0);  

$sql="select price from tb_config where item='psevdoweek4'";  
$res=mysql_query($sql);  
$psevdoweek4=mysql_result($res,0,0);  
///////////���������� ������ ��� ������ ���������� ����� 
  if ($plan=="1") { $price=$psevdoweek1; }  
  if ($plan=="2") { $price=$psevdoweek2; }  
  if ($plan=="3") { $price=$psevdoweek3; }  
  if ($plan=="4") { $price=$psevdoweek4; }  
/////////////////////////////////����� ���������� � ������ ������� � � ��������� ������ 
$nado=round($price,2);
	
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "��������������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_psevdoreq WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
	 $query = "INSERT INTO tb_psevdolinks (url,description,wmid,begindate,numdays) VALUES('$urlsite','$description','$wmid','$t','$plan')"; 
  mysql_query($query) or die(mysql_error()); 
  $queryz = "DELETE FROM tb_psevdoreq WHERE id='$id'"; 
  mysql_query($queryz) or die(mysql_error()); 
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }

    //����� �� ������
    require_once('config.php');
$rest=mysql_query("select * from tb_frameadsreq ORDER BY id ASC");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  $wmid=$row["wmid"]; $email=$row["email"]; $linksite=$row["link"]; $text=$row["text"]; $plan=$row["plan"]; $t=time(); $t=$t+$plan*24*3600;

		$res=mysql_query("select price from tb_config where item='wmframeads'");
		$res=mysql_fetch_array($res);
		$nado=$res["price"]*$plan;
		$nado=round($nado,2);
	
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������ �� ������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
	  if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_frameadsreq WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
	$query = "INSERT INTO tb_frameads (email,wmid,link,text,enddate) VALUES('$email','$wmid','$linksite','$text','$t')";
		mysql_query($query) or die(mysql_error());

		$queryz = "DELETE FROM tb_frameadsreq WHERE id='$id'";
		mysql_query($queryz) or die(mysql_error());

		$res=mysql_query("select * from tb_comp where param='9'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='0')
					{
						$res1=mysql_query("select username from tb_users where wmid='$wmid'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';}
					}else{
						$lidername=$wmid;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$plan;
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
						}
					}
				}
			}
		}
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
  //��������� ������
    require_once('config.php');
$rest=mysql_query("select * from tb_textadsreq ORDER BY id ASC");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  $wmid=$row["wmid"]; $email=$row["email"]; $urlsite=$row["url"]; $text=$row["text"]; $plan=$row["plan"]; $t=time(); $t=$t+$plan*24*3600;

		$res=mysql_query("select price from tb_config where item='textads'");
		$res=mysql_fetch_array($res);
		$nado=$res["price"]*$plan;
		$nado=round($nado,2);
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "��������� ����������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_textadsreq WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
	$query = "INSERT INTO tb_textads (email,wmid,url,text,enddate) VALUES('$email','$wmid','$urlsite','$text','$t')";
		mysql_query($query) or die(mysql_error());

		$queryz = "DELETE FROM tb_textadsreq WHERE id='$id'";
		mysql_query($queryz) or die(mysql_error());

		$res=mysql_query("select * from tb_comp where param='11'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='0')
					{
						$res1=mysql_query("select username from tb_users where wmid='$wmid'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';}
					}else{
						$lidername=$wmid;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$plan;
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse=$_POST['LMI_PAYEE_PURSE'];
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
						}
					}
				}
			}
		}
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }  
  //����������
    require_once('config.php');
$rest=mysql_query("select * from tb_mta ORDER BY id ASC");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
   $id=$row["id"];
    $nado=$row["amount"];
    $user=$row["user"];
	$sql = "SELECT * FROM tb_users WHERE username='$user'";
    $result = mysql_query($sql);
    $row = mysql_fetch_array($result);
    $wmid = $row["wmid"];
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "���������� �������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM tb_mta WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  
$sql="update tb_users set money=money+'$amount' where username='$user'";
	    mysql_query($sql);

	    mysql_query("delete from tb_mta where id='$id'");
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
   //������
    require_once('config.php');
$rest=mysql_query("SELECT amout,wmid,date_add FROM mails WHERE status = 'wait'") or die(mysql_error());

  while ($row = mysql_fetch_array($rest)) { $id=$row["date_add"];
  //����1
  $nado=$row["amout"];
  $wmid=$row["wmid"];
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "��������� ������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM mails WHERE date_add='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
mysql_query("UPDATE mails SET status = 'pay' WHERE status = 'wait' AND date_add = '$id'");
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
     //������� 100
    require_once('config.php');
$rest=mysql_query("SELECT * FROM sfb_rot100 WHERE status!='1' AND status!='2' AND status!='3' AND status!='4' AND status!='5' AND status!='l'");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  require('sfbstat.php');
  
		$stat=$row["status"];
		if($stat=='waitl') { $status='l'; $ban=$banl; }
	if($stat=='wait1') { $status='1'; $ban=$ban1; }
	if($stat=='wait2') { $status='2'; $ban=$ban2; }
	if($stat=='wait3') { $status='3'; $ban=$ban3; }
	if($stat=='wait4') { $status='4'; $ban=$ban4; }
	if($stat=='wait5') { $status='5'; $ban=$ban5; }
		$plan=$row["plan"];
		$nado=$ban*$plan;
		$nowtime=time();
		$wmid=$row["wmid"];
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������� 100�100";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM sfb_rot100 WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
mysql_query("UPDATE sfb_rot100 SET status='$status', begindate='$nowtime' WHERE id='$id'");
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
       //��������
    require_once('config.php');
$rest=mysql_query("SELECT * FROM sfb_spam WHERE status!='ok'");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
 $wmid=$row["wmid"];
$kolvo=$row["kolvo"]; 
$text=$row["text"]; 
$url=$row["url"]; 
require('sfbstat.php');
$nado=$spam*$kolvo; 
$date=time(); 
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "�������� ��������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM sfb_spam WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
 	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
/// 
$row1=mysql_query("SELECT username,lastlogdate FROM tb_users order by lastlogdate desc") or die(mysql_error()); 
mysql_query("UPDATE sfb_spam SET status='ok' WHERE id='$id'"); 
while($row=mysql_fetch_array($row1)) 
{ 
if($i<=$kolvo) 
{ 
$recipient=$row["username"]; 
$sender=""; 
$subject="��������� ��������"; 
$message="$text <br> <a href=$url target=\"_blank\">$url</a>"; 
mysql_query("insert into tb_mail (sender,recipient,subject,message,data) values ('$sender','$recipient','$subject','$message','$date')"); 
} 
$i++; 
} 
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
  
       //������� 88
    require_once('config.php');
$rest=mysql_query("SELECT * FROM sfb_addban88");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  $urlsite=$row["urlsite"]; $urlpic=$row["urlpic"]; $t=time(); $plan=$row["plan"]; $wmid=$row["wmid"]; $title=$row["title"]; 

  $res=mysql_query("select price from tb_config where item='ban88'"); 
  $res=mysql_fetch_array($res); 
  $nado=$res["price"]*$plan; 
  $nado=round($nado,2); 
   
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������� 88�31";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM sfb_addban88 WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1

	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
  mysql_query("INSERT INTO sfb_advban88 (urlsite,urlpic,begindate,numdays,wmid,title) VALUES('$urlsite','$urlpic','$t','$plan','$wmid','$title')"); 
   
  mysql_query("DELETE FROM sfb_addban88 WHERE id='$id'"); 

  $res=mysql_query("select * from tb_comp where param='8'"); 
  if(mysql_num_rows($res)>0) 
  { 
  while($row=mysql_fetch_array($res)) 
  { 
  $id=$row["id"]; 
  $lidertype=$row["lidername"]; 
  $t=time(); 
  $sd=strtotime($row["startdate"]); 
  $ed=strtotime($row["enddate"]); 
  if($t>$sd && $t<$ed) 
  { 
  if($lidertype=='0') 
  { 
  $res1=mysql_query("select username from tb_users where wmid='$wmid'"); 
  if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';} 
  }else{ 
  $lidername=$wmid; 
  } 
  if($lidername!='') 
  { 
  $res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'"); 
  if(mysql_num_rows($res1)>0) 
  { 
  $res1=mysql_Fetch_array($res1); 
  $resvalue=$res1["resvalue"]+$plan; 
  $purse=$_POST['LMI_PAYEE_PURSE']; 
  mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'"); 
  }else{ 
  $purse=$_POST['LMI_PAYEE_PURSE']; 
  mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')"); 
  } 
  } 
  } 
  } 
  } 
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }
//������
    require_once('config.php');
$rest=mysql_query("SELECT * FROM sfb_cloud WHERE status!='paid'");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1
  $clsql=mysql_query("SELECT price FROM tb_config WHERE item='cloudwm'");
$cl=mysql_result($clsql,0,0);

$plan=$row["plan"];
$nado=$plan*$cl;
$wmid=$row["wmid"];
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������ ������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
	  

      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM sfb_cloud WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
$time=time();
mysql_query("UPDATE sfb_cloud SET status='paid',beginned='$time' WHERE id='$id'");
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }  
  
  //������� ������
    require_once('config.php');
$rest=mysql_query("SELECT * FROM sfb_runblock WHERE status!='1'");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1

$cena=mysql_result(mysql_query("SELECT price FROM tb_config WHERE item='runblock'"),0,0);
$plan=$row["plan"];
$nado=$plan*$cena;
$nado=round($nado,2);
$nowtime=time();
$ed=$plan*86400;
$ed=$nowtime+$ed;
$wmid=$row["wmid"];
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "������� ������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn); 
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM sfb_runblock WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  	  $dateadv=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$nado','$dateadv')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
	  //����1
 mysql_query("UPDATE sfb_runblock SET status='1',endtime='$ed' WHERE id='$id'") or die(mysql_error());
		//����2
	  
	  
	  
	  
	  }
	}
      }
    }
  }  
  
    //������ ������� ����))
    require_once('config.php');
$rest=mysql_query("SELECT * FROM rt_zk_pk_rk");

  while ($row = mysql_fetch_array($rest)) { $id=$row["id"];
  //����1

$url=$row["url"];
$urlimage=$row["urlpic"];
$ops=$row["ops"];
$wmid=$row["wmid"];
$idpk=$row["idpk"];
$res=mysql_fetch_array(mysql_query("SELECT * FROM rt_pakety_rekl WHERE id='$idpk'"));
$nado=$res["cena"];
$banner=$res["baner"];
$dyn=$res["dyn"];
$timer=$res["time"];
$frame=$res["frame"];
$stat=$res["stat"];
		//����2
	$datestart = date("Ymd H:i:s", $nowtime-86400);
    $datefinish = date("Ymd H:i:s", $nowtime+84600); //������ �������� ������ 24 ���� � ������� ������
		
    require_once("xml/xml.php");
    $response = $wmxi->X3($koshel, intval(0), intval(0), intval(0), intval(0), trim($datestart), trim($datefinish));
    $structure = $parser->Parse($response, DOC_ENCODING);
    $transformed = $parser->Reindex($structure, false);

    $items = @$structure["0"]["node"]["1"]["node"];
    $items = is_array($items) ? $items : array();

    foreach($items as $k => $v)
    {
      $vv = $parser->Reindex($v["node"], true);

      $desc = htmlspecialchars(@$vv["desc"], ENT_QUOTES);
      $amount = htmlspecialchars(@$vv["amount"], ENT_QUOTES);
      $checkwmid = htmlspecialchars(@$vv["corrwm"], ENT_QUOTES);
      $opertype = htmlspecialchars(@$vv["opertype"], ENT_QUOTES);
      $kosheluser = htmlspecialchars(@$vv["pursesrc"], ENT_QUOTES);
      $dyn = "����� �������";
      $searchstring="�($id)";

      $pos = strpos($desc, $searchstring);
      $pos2 = strpos($desc, $dyn);
      if ($wmid == $checkwmid && $pos == true && $pos2 == true)  //�������� ������ ������� � ������ �� ���� ������
      {
        if ($opertype == 0)
	{
          $sql = "SELECT * FROM rt_zk_pk_rk WHERE id='$id'";
  	  $rests = mysql_query($sql) or die(mysql_error());

	  if  ($nado<=$amount && mysql_num_rows($rests)>0)
	  {
	  //����1
 
$time=time();


mysql_query("INSERT INTO tb_advban (urlsite,urlpic,begindate,numdays,wmid) VALUES('$url','$urlimage','$time','$banner', '$wmid')");
///////////
mysql_query("INSERT INTO tb_ads (paypalemail, plan, url, description, tipo, highlight, timer, dopsec, vip) VALUES('$wmid','$dyn','$url','$ops','ads','1', '$timer', '2','0')");
///////////

$t=$time+$frame*24*3600;
mysql_query("INSERT INTO tb_frameads (wmid,link,text,enddate) VALUES('$wmid','$url','$ops','$t')");

mysql_query("INSERT INTO tb_statlinks (url,description,wmid,leftblock,begindate,numdays) VALUES('$url','$ops','$wmid','0','$time','$stat')");
		//����2
	  mysql_query("UPDATE rt_zk_pk_rk SET status='0',starttime='$time' WHERE id='$id'");
	  
	  
	  
	  }
	}
      }
    }
  }  
  
  
  
  
  ?>
  	<meta http-equiv="refresh" content="0; url=index.php">
	<?
  
  
  
  
  
  
  
  
  ?>


