<?PHP
require('config.php');
$link=intval($_GET[link]);
$row=mysql_fetch_assoc(mysql_query("SELECT * FROM tb_advban WHERE id='$link'"));
$url_go[url]=$row[url];
mysql_query("UPDATE tb_advban set views=views+1,balance=balance-price WHERE id='$link'") or die(mysql_error());
?>
		<meta http-equiv="refresh" content="0; url=<?=$url_go["url"]; ?>">
		<?PHP
		
?>