<?
session_start();

include('funciones.php');

if($_SESSION["endtime"]>time())
{
	echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #ff0000;\">&nbsp;<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;������! �������� �� ��������</span>";
	exit();
}
if(isset($_SESSION[iduser]))
{

	if(preg_match("|^[\d]*$|",$_SESSION['ad'])) 
	{
		$adse=$_SESSION["ad"]; 
	}else{
		echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #ff0000;\">&nbsp;<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;������! �������� �� ��������</span>";
		exit();
	}



	$captcha=''; $ver='';


		$captcha=md5(strtolower($_POST['code']));
		$ver=strtolower($_SESSION["texto"]);
	
	
	if(!isset($_GET["ds"]))
	{
		$checkad = mysql_query("SELECT * FROM seo_paymails WHERE id='$adse' and paused!=1 and modered=1");
		$ad_exist = mysql_num_rows($checkad);

		if ($ad_exist<1)
		{
			echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #ff0000;\">&nbsp;<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;������ �� ����������</span>";
			exit();
		}

	
	
	?>
	                  
                  <style type="text/css" media="all">
.captcha {
   margin-left: 1px;
   position: relative;
   top: 10px;
   vertical-align: bottom;
}
.captcha font{
   font-family:arial;
   font-weight: bold;
   color:#2cbde9;
   font-size:14px;
}

.capfont{
   font-family:arial;
   font-weight: bold;
   color:#2cbde9;
   font-size:14px;
}
input.regnum {
    font: 12px Tahoma, Arial, sans-serif;
    text-align: center;
    color: #ffffff;
    text-shadow: 1px 1px 1px #304f12;
    background: url(css/img/btn-pin.png) no-repeat left top;
    height: 26px;
    width: 25px;
    vertical-align: middle;
    display: block;
    display: inline-block; /*ie*/
    text-decoration: none;
    outline: none;
    border: none;
    margin: 2px 0;
    padding: 0 0 2px 0;
    cursor: pointer;
}

input.regnum:hover {
    background-position: left bottom;
}

</style>
			
						<font color='#2cbde9' size='1' style='margin-left:25px;'> ������� ������� �� ������?</font>
			 <form action='vlsmail.php?view=ok&ds=clicked' method='post'><table border="0" cellpadding="0" cellspacing="0" align="center"><tr>
      <td valign="middle"><img src="image.php?<?php echo $res; ?>" class="imgcap" alt="" /></td>
      <td valign="middle"><input type="hidden" name="code" value="0">
       <input class="regnum" name="code" value="1" onclick="vernum(this.form,1); submit();" type="submit">
       <input class="regnum" name="code" value="2" onclick="vernum(this.form,2); submit();" type="submit">
       <input class="regnum" name="code" value="3" onclick="vernum(this.form,3); submit();" type="submit">
       <input class="regnum" name="code" value="4" onclick="vernum(this.form,4); submit();" type="submit"><br />
       <input class="regnum" name="code" value="5" onclick="vernum(this.form,5); submit();" type="submit">
       <input class="regnum" name="code" value="6" onclick="vernum(this.form,6); submit();" type="submit">
       <input class="regnum" name="code" value="7" onclick="vernum(this.form,7); submit();" type="submit">
       <input class="regnum" name="code" value="8" onclick="vernum(this.form,8); submit();" type="submit"></td>
     </tr></table>
</form>
</td></table></td><td style="background:url('/frmimg/2-5.gif');"></td></tr>
<tr><td width="8" height="8"><img src="/frmimg/2-6.gif" border="0"></td><td style="background:url('/frmimg/2-7.gif');"></td><td width="8" height="8"><img src="/frmimg/2-8.gif" border="0"></td>
</tr></table>			
			<?
			exit;
	
	}
	if(!isset($_GET["ds"]) or ($_GET["ds"]=='clicked' and $ver==$captcha))
	{
		$adse=$_SESSION["ad"];

		$querye = mysql_query("SELECT * FROM seo_paymailsviews WHERE fromid = '$_SESSION[iduser]' and ident= '$adse'") or die(mysql_error());
		$rowe = mysql_fetch_array($querye);

		$time=$rowe['time'];

		$crok1 = date(time());
		$crok2 = date($time + 86400);

		if($crok1 >= $crok2)
		{
			$checkvisit = mysql_query("SELECT * FROM seo_paymailsviews WHERE fromid='$_SESSION[iduser]' and ident='$adse'");
			$referer_visit = mysql_num_rows($checkvisit);

			$sqlz = "SELECT * FROM seo_paymails WHERE id='$adse'";
			$resultz = mysql_query($sqlz);        
			$myrowz = mysql_fetch_array($resultz);
$numero=intval($myrowz[balance]/$myrowz[price]);

			$jo=$myrowz["plan"];

			if ($numero =0)
			{
				echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #ff0000;\">&nbsp;<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;������ �� ����������</span>";
				exit();
			}

			if ($referer_visit>0)
			{
				$queryzx = "UPDATE seo_paymailsviews SET time='$crok1' WHERE fromid='$_SESSION[iduser]' and ident='$adse'";
				mysql_query($queryzx) or die(mysql_error());
			}else{
				$queryzz = "INSERT INTO seo_paymailsviews (fromid,ident,time) VALUES('$_SESSION[iduser]','$adse','$crok1')";
				mysql_query($queryzz) or die(mysql_error());
			}

			
			


			$sqlex = "UPDATE seo_paymails SET plan=plan+1,balance=balance-price WHERE id='$adse'";
			$resultex = mysql_query($sqlex);

			$sqlze = "SELECT * FROM tb_users WHERE id='$_SESSION[iduser]'";
			$resultze = mysql_query($sqlze);        
			$myrowze = mysql_fetch_array($resultze);
			if($myrowze[referer]!='')
			{
				$refelprecio=mysql_result(mysql_query("SELECT price FROM tb_config WHERE item='mrefpay'"),0);
				mysql_query("UPDATE tb_users SET money=money+'$refelprecio' WHERE id='$myrowze[referer]'") or die(mysql_error());
			}

			$visitas=$myrowze["visits"];
			$dinero=$myrowze["money"];
			$level=$myrowze["account"];



		$elprecio=mysql_result(mysql_query("SELECT price FROM tb_config WHERE item='mpay'"),0);

			$sqlexzz = "UPDATE tb_users SET visits=visits+1, money=money+'$elprecio',toref=toref+'$refelprecio' WHERE id='$_SESSION[iduser]'";
			$resultexzz = mysql_query($sqlexzz);
			$nowtime=time();

			
	$user=$_SESSION["username"];
  $varstr=date("w");
  $day="";
  if($varstr==1) $day='mon';
  if($varstr==2) $day='tue';
  if($varstr==3) $day='wed';
  if($varstr==4) $day='thu';
  if($varstr==5) $day='fri';
  if($varstr==6) $day='sat';
  if($varstr==0) $day='sun';

  $sqlstat= "UPDATE tb_statistic SET total=total+1, ".$day."=".$day."+1 WHERE username='$user' and typ=2"; 
  mysql_query($sqlstat);
			echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #00dd00;\">&nbsp;<img src=\"frmimg/ok.png\" align=\"middle\">&nbsp;�������� ��������</span>";
		}else{
			echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #ff0000;\">&nbsp;<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;�� ��� ������������� ��� ������!</span>";
		}
	}else{
		echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #ff0000;\">&nbsp;<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;������! �������� �� ��������</span>";
	}
	$obper=mysql_result(mysql_query("SELECT obper FROM seo_paymails WHERE id='$adse'"),0,0);
	if($obper==1)
	{
	                ?>    <script type="text/javascript">
                alert('������������� ������� �������������� ������� �� ���� ����� ���������!');
    window.top.location.replace("<?=$_SESSION["urlsite"]; ?>");
    </script><?
	}
}else{

	$juaz=date("n/j/Y H:i:s", $crok1);
	$juaze=date("n/j/Y H:i:s", $crok2);

	echo "<span style=\"border: medium none; padding: 0pt; font-size: 10pt; font-family: Verdana; font-weight: bold; vertical-align: top; color: #ff0000;\">&nbsp;<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;��� ���������� ��������������</span>";
}
?>