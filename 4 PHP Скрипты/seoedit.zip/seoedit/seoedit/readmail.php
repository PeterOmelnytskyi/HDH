<?
session_start();
require('funciones.php');
include('sfb.php');
$nameus=$_SESSION["username"];
$urlpage='<font color=#ff0000>������������</font>';

$uo_sessionTime = 1;
error_reporting(E_ERROR | E_PARSE);
$uo_ip = $_SERVER['REMOTE_ADDR'];
$uo_query = "DELETE FROM users_online WHERE unix_timestamp() - lastvisit >= $uo_sessionTime * 60";
mysql_query($uo_query);

$uo_query = "SELECT lastvisit FROM users_online WHERE visitor = '$uo_ip'";
$uo_result = mysql_query($uo_query);
if(mysql_num_rows($uo_result) == 0) {
	$uo_query = "INSERT INTO users_online (visitor,lastvisit,user,urlpage) VALUES('$uo_ip', unix_timestamp(), '$nameus', '$urlpage')";
	mysql_query($uo_query);
} else {
	$uo_query = "UPDATE users_online SET lastvisit = unix_timestamp(), urlpage='$urlpage', user='$nameus' WHERE visitor = '$uo_ip'";
	mysql_query($uo_query);
}


$ad=$_GET["ad"];
if(!ereg("^[0-9]{1,255}$", $ad))
{
	$ad=-1;
}
$ad=intval($ad);

$res=mysql_query("select count(*) as kolvo from seo_paymails where id='$ad' and modered='1' and balance>price and paused=0") or die(mysql_error());
$res=mysql_fetch_array($res);

$kolvo=$res["kolvo"];
if ($kolvo<1)
{
	echo "<img src=\"frmimg/error.png\" align=\"middle\">&nbsp;������ �� ����������";
	exit();
}


$res=mysql_query("select url, name, timer from seo_paymails where id='$ad'");
$res=mysql_fetch_array($res);

$urlsite=$res["url"];

$_SESSION["urlsite"]=$res["url"];
$_SESSION["desc"]=$res["name"];


$_SESSION["timer"]=$res["timer"];
$_SESSION["ad"]=$ad;

if($_SESSION["username"]==NULL)
{



	?>
	<script type="text/javascript">
	location.replace("<?=$urlsite?>");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=<?=$urlsite?>">
	</noscript>
	<?
}
?>

<html>
<head>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="-1">
<title><?
function title($gg)
{
	$gg=str_ireplace('<span>','',$gg);
	$gg=str_ireplace('</span>','',$gg); 
	return $gg;
}
 echo title($sitename) ?> - ������� �������� �������</title>

<frameset rows="*,76" border="0">

<frame name="frmsite" src="<?=$urlsite ?>"><frame marginwidth="0" marginheight="0" border=0 frameborder=0 framespacing=0 name="frminfo" scrolling="no" noresize src="vlsmail.php">
</frameset>

</head>
</html>