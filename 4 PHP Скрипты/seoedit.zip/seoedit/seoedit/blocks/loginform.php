<? if(!isset($_SESSION["username"])) { ?> 

                        
<script type="text/javascript" language="JavaScript">
    function LoginClick() {
        document.getElementById('logfrm').style.display = '';
        document.getElementById('logbtn').style.display = 'none';
        document.forms['logsubmit'].logsuccess.value = '�';
    }
    function SbmForm() {
        if (document.forms['logsubmit'].logusername.value == '') {
            alert('�� ������ ��������������� e-mail');
            document.forms[0].username.focus();
            return false;
        }
        if (document.forms['logsubmit'].logpassword.value == '') {
            alert('�� ������ ������ ��� �����');
            document.forms[0].password.focus();
            return false;
        }
        /*var re = /^\w+([\.-]?\w+)*@(((([a-z0-9]{1,})|([a-z0-9][-][a-z0-9]+))[\.][a-z0-9])|([a-z0-9]+[-]?))+[a-z0-9]+\.([a-z]{2}|(com|net|org|edu|int|mil|gov|arpa|biz|aero|name|coop|info|pro|museum))$/i;
        if (!re.test(eval("document.forms['logsubmit'].username.value"))) {
            alert('����� e-mail ������ �����������');
            document.forms[0].username.focus();
            return false;
        }*/

        document.forms['logsubmit'].logpar.value = '9b1631cc8cdca50fad75ee2a18338929';
        document.forms['logsubmit'].logsuccess.value += 'o';
        document.forms['logsubmit'].submit();
        return true;
    }
</script>


<a name="login"></a>
<a class="btnreg" href="<? if(isset($_COOKIE["referer"])) { echo $_COOKIE["referer"]; echo "-"; } ?>reg.html">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�����������</a>
<a id="logbtn" class="btnlogin" href="login.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;����</a>

<div id="logfrm" class="formlogin" style="display: none;">
    <form id="logsubmit" action="login.html" method="post" onsubmit="return SbmForm(); return false">
                <table>
            <tr>
                <td>E-Mail</td>
                <td><input type="text" name="logusername" maxlength="40" /></td>
            </tr>
            <tr>
                <td>������</td>
                <td><input type="password" name="logpassword" maxlength="40" /></td>
            </tr>
        </table>
        <input class="loginsubmit" type="submit" name="submit" value="�����" />
    </form>
    <a href="/restorepass.php">������ ������?</a>
</div>

<? }?>