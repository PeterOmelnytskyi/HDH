<style>
.post-date {
    width: 45px;
    height: 49px;
    float:left;
    background: url(../mfs/date-bg.gif) no-repeat;
    margin-right:5px;
}
.post-month {
    font-size: 10px;
    color: #FFFFFF;
    text-align: center;
    display:block;
    line-height: 11px;
    padding-top: 2px;
    margin-left: -3px;
}
.post-day {
    font-size: 18px;
    text-transform: uppercase;
    color: #999999;
    text-align: center;
    display:block;
    line-height: 18px;
    padding-top: 7px;
    margin-left: -3px;
}
</style><?
$datetime=strtotime($datenew);
$m=date("m", $datetime);
if($m=='01') { $month="���"; }
if($m=='02') {  $month="���"; }
if($m=='03') {  $month="����"; }
if($m=='04') {  $month="���"; }
if($m=='05') {  $month="���"; }
if($m=='06') {  $month="����"; }
if($m=='07') {  $month="���"; }
if($m=='08') {  $month="���"; }
if($m=='09') {  $month="���"; }
if($m=='10') {  $month="���"; }
if($m=='11') {  $month="���"; }
if($m=='12') {  $month="���"; }
$day=date("d", $datetime);
?><left>
<span class="post-date"><span class="post-month"><?=$month ?></span> <span class="post-day"><?=$day ?></span></span> -
<?
echo " <b>$temanew </b><br>";
echo $textnew;
?>
</left>
<table width=100%>
<td align=left>
<img src=/mfs/comments.png align=absmiddle> <a href="<?=$newid?>-new.html">�����������: <?=$newcomms ?></a></td>
<td align=right> <img src=/mfs/new.png align=absmiddle> <a href="news.html">��� �������</a></td></table>
