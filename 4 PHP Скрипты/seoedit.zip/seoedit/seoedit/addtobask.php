<?
session_start();
if(!isset($_SESSION[iduser])) exit;
require('config.php');
$nowtime=time();
$type=$_GET[type];
$id=intval($_GET[id]);
$price=$_GET[price];

switch($type) {
	case 'dyn': 
	$sql=mysql_query("SELECT price FROM tb_ads WHERE id='$id' and modered=1 and fromus='$_SESSION[iduser]'");
	if(mysql_num_rows($sql)!=0)
	{
		if($price==10 OR $price==20 OR $price==50 OR $price==100 OR $price==200 OR $price==500)
		{
		mysql_query("INSERT INTO seo_basket (ident,price,fromid,time,type) values ('$id','$price','$_SESSION[iduser]','$nowtime','1')") or die(mysql_error());
		}
	}
	break;
		case 'mails': 
	$sql=mysql_query("SELECT price FROM seo_paymails WHERE id='$id' and modered=1 and fromid='$_SESSION[iduser]'");
	if(mysql_num_rows($sql)!=0)
	{
		if($price==10 OR $price==20 OR $price==50 OR $price==100 OR $price==200 OR $price==500)
		{
		mysql_query("INSERT INTO seo_basket (ident,price,fromid,time,type) values ('$id','$price','$_SESSION[iduser]','$nowtime','6')") or die(mysql_error());
		}
	}
	break;
	case 'stat':
	$sql=mysql_query("SELECT price FROM tb_statlinks WHERE id='$id' and modered=1 and fromus='$_SESSION[iduser]'");
	if(mysql_num_rows($sql)!=0)
	{
		if($price==10 OR $price==20 OR $price==50 OR $price==100 OR $price==200 OR $price==500)
		{
		mysql_query("INSERT INTO seo_basket (ident,price,fromid,time,type) values ('$id','$price','$_SESSION[iduser]','$nowtime','2')") or die(mysql_error());
		}
	}
	break;
	case 'ban':
	$sql=mysql_query("SELECT price FROM tb_advban WHERE id='$id' and modered=1 and fromus='$_SESSION[iduser]'");
	if(mysql_num_rows($sql)!=0)
	{
		if($price==10 OR $price==20 OR $price==50 OR $price==100 OR $price==200 OR $price==500)
		{
		mysql_query("INSERT INTO seo_basket (ident,price,fromid,time,type) values ('$id','$price','$_SESSION[iduser]','$nowtime','3')") or die(mysql_error());
		}
	}
	break;
	case 'ref':
	$sql=mysql_query("SELECT count(id) FROM tb_users WHERE id IN(SELECT rid FROM seo_refbirj WHERE rid='$id' and bron=0)");
	if(mysql_num_rows($sql)!=0)
	{
		$price=mysql_result(mysql_query("SELECT price FROM seo_refbirj WHERE rid='$id'"),0);
		
		mysql_query("INSERT INTO seo_basket (ident,price,fromid,time,type) values ('$id','$price','$_SESSION[iduser]','$nowtime','4')") or die(mysql_error());
		mysql_query("UPDATE seo_refbirj SET bron=1 WHERE id='$id'");
	}
	break;
	case 'task':
	$sql=mysql_query("SELECT price FROM seo_tasks WHERE id='$id' and modered=1 and fromid='$_SESSION[iduser]'");
	if(mysql_num_rows($sql)!=0)
	{
		if($price==10 OR $price==20 OR $price==50 OR $price==100 OR $price==200 OR $price==500)
		{
		mysql_query("INSERT INTO seo_basket (ident,price,fromid,time,type) values ('$id','$price','$_SESSION[iduser]','$nowtime','5')") or die(mysql_error());
		}
	}
	break;
};
?>
	<script type="text/javascript">
	location.replace("basket.php");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=basket.php">
	</noscript>
	<?
	exit; ?>