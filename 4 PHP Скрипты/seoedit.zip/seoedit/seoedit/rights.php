<table class="serfbotname" height='2' width="900" cellpadding="0" cellspacing="0"><tr><td><center><font size=-2></font></center></td></tr></table>
<table width="900" background="img/fak3.jpg" bclass="serfbotname" cellpadding="0" cellspacing="0">
<tr>
<td>
<table width="100%" background="img/fak3.jpg" cellpadding="0" cellspacing="0">
<tr height='50'>
<td width="15"></td>
<td width="10" background="img/"></td>
<td background="img/"><center>
<!--��� ��������-->
<a target="_blank" href="http://hostia.ru/billing/host.php?uid=4029&bid=4"><img border="0" src="http://www.hostia.ru/banner/2.gif" width="" width="150" height="31" alt="������� �������"></a>
<a href="http://www.mexnap.info"><img src="http://www.mexnap.info/images/c.gif" alt="�������� �������������" width="88" height="31" border="0"></a>
<a href="http://www.webmoney.ru/" target="_blank"><img src="http://www.megastock.ru/Doc/88x31_accept/grey_rus.gif" alt="www.webmoney.ru" border="0"></a>
<!-- end WebMoney Transfer : accept label -->&nbsp;<!-- begin WebMoney Transfer : attestation label -->
<a href="https://passport.webmoney.ru/asp/certview.asp?wmid=109808360602" target=_blank><IMG SRC="img/atpr.gif" title="����� ��������� ��� �������� - WMID 109808360602" border="1"></a>
<a href="http://wmbonus.org/?pr=8897"><img alt="������� WM ������� - ����������� �����������"  src=http://wmbonus.org/100.gif width=60></a>
<!-- HotLog -->
<script type="text/javascript" language="javascript">
hotlog_js="1.0"; hotlog_r=""+Math.random()+"&s=2050739&im=101&r="+
escape(document.referrer)+"&pg="+escape(window.location.href);
document.cookie="hotlog=1; path=/"; hotlog_r+="&c="+(document.cookie?"Y":"N");
</script>
<script type="text/javascript" language="javascript1.1">
hotlog_js="1.1"; hotlog_r+="&j="+(navigator.javaEnabled()?"Y":"N");
</script>
<script type="text/javascript" language="javascript1.2">
hotlog_js="1.2"; hotlog_r+="&wh="+screen.width+"x"+screen.height+"&px="+
(((navigator.appName.substring(0,3)=="Mic"))?screen.colorDepth:screen.pixelDepth);
</script>
<script type="text/javascript" language="javascript1.3">
hotlog_js="1.3";
</script>
<script type="text/javascript" language="javascript">
hotlog_r+="&js="+hotlog_js;
document.write('<a href="http://click.hotlog.ru/?2050739" target="_top"><img '+
'src="http://hit33.hotlog.ru/cgi-bin/hotlog/count?'+
hotlog_r+'" border="0" width="88" height="31" alt="HotLog"><\/a>');
</script>
<noscript>
<a href="http://click.hotlog.ru/?2050739" target="_top"><img
src="http://hit33.hotlog.ru/cgi-bin/hotlog/count?s=2050739&im=101" border="0"
width="88" height="31" alt="HotLog"></a>
</noscript>
<!-- /HotLog -->



<a href="http://webplus.info/index.php?page=47&add_top_url=60323"><img alt="������� webplus.info" border=0 src="http://webplus.info/getres.php?infoforurl=60323&color=blue"></a><A Href="http://www.savechange.ru/index.php?ref=vituk26"><IMG src="http://www.savechange.ru/b468-savechange2.gif" border=0 width=150 height=31 alt="����� ����������� �����. �������� WMZ, WMR, WME, WMU, WMB � RBK-Money."></A>
</center></td>
<td width="10" background="img/"></td>
<td width="15"></td>
</tr>
</table>
</td>
</tr>
</table>
<table  width="900" cellpadding="0" cellspacing="0">
<tr>
<td background="img/nl.gif" width='10' height='10'>
</td>
<td background="img/ns.gif" width='980' height='10'>
</td>
<td background="img/np.gif" width='10' height='10'>
</td>
</tr>
</table>
