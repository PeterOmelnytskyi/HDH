<style type="text/css">
   table.profitreestr {
    text-align: center;
    border-collapse: collapse;
}
table.profitreestr thead {
    background: #378ac4 url(../images/adv/bg-table.png) repeat-x bottom;
    
}
table.profitreestr thead th {
    color: #ffffff;
    font-size: 11px;
    font-weight: normal;
    padding: 2px 2px;
}
table.profitreestr tbody td {
    font-size: 11px;
    padding: 2px 2px;
    border-bottom: solid 1px #DBDFBE;
    background-color: #ffffff;
}


table.profitreestr tbody td.high {
    text-align: left;
    font-size: 11px;
    background: #F1F2DA;
}
table.profitreestr tbody td.high2 {
    font-size: 11px;
    background: #F1F2DA;
}
</style>
<?
function initstat($user,$seoedit)
{
$tmpstr=date("w"); // �������� ������� ���� � ���� 1 2 3 ...
$u1=day($tmpstr-6);
$u2=day($tmpstr-5);
$u3=day($tmpstr-4);
$u4=day($tmpstr-3);
$u5=day($tmpstr-2);
$u6=day($tmpstr-1);
$u7=day($tmpstr); // ������� ���� ������
// �������������� ���� ������ � url �������
$datalabel=dayurl($u1).'|'.dayurl($u2).'|'.dayurl($u3).'|'.dayurl($u4).'|'.dayurl($u5).'|'.dayurl($u6).'|'.dayurl($u7);
// ����������� ��� ������ � ������� ������������
$row0=mysql_fetch_array(mysql_query("select * from tb_statistic where typ=0 and username='$user'"));
$row1=mysql_fetch_array(mysql_query("select * from tb_statistic where typ=1 and username='$user'"));
$row2=mysql_fetch_array(mysql_query("select * from tb_statistic where typ=2 and username='$user'"));
// �����
$s0=$row0[dayin($u1)];
$s1=$row0[dayin($u2)];
$s2=$row0[dayin($u3)];
$s3=$row0[dayin($u4)];
$s4=$row0[dayin($u5)];
$s5=$row0[dayin($u6)];
$s6=$row0[dayin($u7)];
// ��������
$z0=$row1[dayin($u1)];
$z1=$row1[dayin($u2)];
$z2=$row1[dayin($u3)];
$z3=$row1[dayin($u4)];
$z4=$row1[dayin($u5)];
$z5=$row1[dayin($u6)];
$z6=$row1[dayin($u7)];
// ������
$m0=$row2[dayin($u1)];
$m1=$row2[dayin($u2)];
$m2=$row2[dayin($u3)];
$m3=$row2[dayin($u4)];
$m4=$row2[dayin($u5)];
$m5=$row2[dayin($u6)];
$m6=$row2[dayin($u7)];

$ss=array ($s0,$s1,$s2,$s3,$s4,$s5,$s6,$z0,$z1,$z2,$z3,$z4,$z5,$z6,$m0,$m1,$m2,$m3,$m4,$m5,$m6);

arsort($ss);
$max = current($ss);

$color0='3dc536';
$color1='ED5A62';
$color2='368ac5';

$colorarray=$color0.','.$color1.','.$color2; // ������ ������ ��� ��������
$step=0;
if($max>=1&&$max<=10) $step=1;
if($max>=11&&$max<=20) $step=2;
if($max>=21&&$max<=50) $step=4;
if($max>=51&&$max<=100) $step=10;

$max=$max+$step;
if($max==0) $max=1;
$linestep=(100/$max)*$step;

$data0=m($s0,$max).','.m($s1,$max).','.m($s2,$max).','.m($s3,$max).','.m($s4,$max).','.m($s5,$max).','.m($s6,$max);
$data1=m($z0,$max).','.m($z1,$max).','.m($z2,$max).','.m($z3,$max).','.m($z4,$max).','.m($z5,$max).','.m($z6,$max);
$data2=m($m0,$max).','.m($m1,$max).','.m($m2,$max).','.m($m3,$max).','.m($m4,$max).','.m($m5,$max).','.m($m6,$max);
$data=$data0.'|'.$data1.'|'.$data2;
if($seoedit!=1)
{

?>

<img src="http://chart.apis.google.com/chart?cht=lc&chco=<?=$colorarray?>&chg=16.667,<?=$linestep?>,1,1&chf=c,s,FFFFFF|bg,s,F3F2E7&chs=360x180&chd=t:<?=$data?>&chxt=t,r&chxl=0:|<?=$datalabel?>&chxr=1,0,<?=$max?>,<?=$step?>&chm=o,<?=$color0?>,0,0,6|o,<?=$color0?>,0,1,6|o,<?=$color0?>,0,2,6|o,<?=$color0?>,0,3,6|o,<?=$color0?>,0,4,6|o,<?=$color0?>,0,5,6|o,<?=$color0?>,0,6,6|o,<?=$color1?>,1,0,6|o,<?=$color1?>,1,1,6|o,<?=$color1?>,1,2,6|o,<?=$color1?>,1,3,6|o,<?=$color1?>,1,4,6|o,<?=$color1?>,1,5,6|o,<?=$color1?>,1,6,6|o,<?=$color2?>,2,0,6|o,<?=$color2?>,2,1,6|o,<?=$color2?>,2,2,6|o,<?=$color2?>,2,3,6|o,<?=$color2?>,2,4,6|o,<?=$color2?>,2,5,6|o,<?=$color2?>,2,6,6">
<br>
<?

?>
 <br>
 
    <table class="ref-stat"><thead>
    <tr>
    <th width="18%"></th>
    <th width="12%">�����</th>
    <th width="10%"><?=$u1?></th>
    <th width="10%"><?=$u2?></th>
    <th width="10%"><?=$u3?></th>
    <th width="10%"><?=$u4?></th>
    <th width="10%"><?=$u5?></th>
    <th width="10%"><?=$u6?></th>
    <th width="10%" class="current"><?=$u7?></th>
    </tr></thead><tbody>
    <tr>
    <td><span style="color: #<?=$color0?>;">�������</span></td><td class="high2"><?=$row0["total"] ?></td><td><?=$s0?></td><td class="high2"><?=$s1?></td><td><?=$s2?></td><td class="high2"><?=$s3?></td><td><?=$s4?></td><td class="high2"><?=$s5?></td><td><?=$s6?></td>
    </tr>
    <tr>
    <td><span style="color: #<?=$color1?>;">�������</span></td><td class="high2"><?=$row1["total"] ?></td><td><?=$z0?></td><td class="high2"><?=$z1?></td><td><?=$z2?></td><td class="high2"><?=$z3?></td><td><?=$z4?></td><td class="high2"><?=$z5?></td><td><?=$z6?></td>
    </tr>
    <tr>
    <td><span style="color:#<?=$color2?>;">������</span></td><td class="high2"><?=$row2["total"] ?></td><td><?=$m0?></td><td class="high2"><?=$m1?></td><td><?=$m2?></td><td class="high2"><?=$m3?></td><td><?=$m4?></td><td class="high2"><?=$m5?></td><td><?=$m6?></td>
    </tr>
    </tbody></table>
    
   
<?

}else{
?>
	<tr id='statblock'>
	<td class='ext' colspan='2' style='padding: 2px;'>
   
 <table class="ref-stat"><thead>
    <tr>
    <th width="18%"></th>
    <th width="12%">�����</th>
    <th width="10%"><?=$u1?></th>
    <th width="10%"><?=$u2?></th>
    <th width="10%"><?=$u3?></th>
    <th width="10%"><?=$u4?></th>
    <th width="10%"><?=$u5?></th>
    <th width="10%"><?=$u6?></th>
    <th width="10%" class="current"><?=$u7?></th>
    </tr></thead><tbody>
    <tr>
    <td><span style="color: #<?=$color0?>;">�������</span></td><td class="high2"><?=$row0["total"] ?></td><td><?=$s0?></td><td class="high2"><?=$s1?></td><td><?=$s2?></td><td class="high2"><?=$s3?></td><td><?=$s4?></td><td class="high2"><?=$s5?></td><td><?=$s6?></td>
    </tr>
    <tr>
    <td><span style="color: #<?=$color1?>;">�������</span></td><td class="high2"><?=$row1["total"] ?></td><td><?=$z0?></td><td class="high2"><?=$z1?></td><td><?=$z2?></td><td class="high2"><?=$z3?></td><td><?=$z4?></td><td class="high2"><?=$z5?></td><td><?=$z6?></td>
    </tr>
    <tr>
    <td><span style="color:#<?=$color2?>;">������</span></td><td class="high2"><?=$row2["total"] ?></td><td><?=$m0?></td><td class="high2"><?=$m1?></td><td><?=$m2?></td><td class="high2"><?=$m3?></td><td><?=$m4?></td><td class="high2"><?=$m5?></td><td><?=$m6?></td>
    </tr>
    </tbody></table>
   
   </td>
   <td class='ext' colspan='4'>
						
						
						
<img src="http://chart.apis.google.com/chart?cht=lc&chco=<?=$colorarray?>&chg=16.667,<?=$linestep?>,1,1&chf=c,s,FFFFFF|bg,s,F3F2E7&chs=220x165&chd=t:<?=$data?>&chxt=t,r&chxl=0:|<?=$datalabel?>&chxr=1,0,<?=$max?>,<?=$step?>&chm=o,<?=$color0?>,0,0,6|o,<?=$color0?>,0,1,6|o,<?=$color0?>,0,2,6|o,<?=$color0?>,0,3,6|o,<?=$color0?>,0,4,6|o,<?=$color0?>,0,5,6|o,<?=$color0?>,0,6,6|o,<?=$color1?>,1,0,6|o,<?=$color1?>,1,1,6|o,<?=$color1?>,1,2,6|o,<?=$color1?>,1,3,6|o,<?=$color1?>,1,4,6|o,<?=$color1?>,1,5,6|o,<?=$color1?>,1,6,6|o,<?=$color2?>,2,0,6|o,<?=$color2?>,2,1,6|o,<?=$color2?>,2,2,6|o,<?=$color2?>,2,3,6|o,<?=$color2?>,2,4,6|o,<?=$color2?>,2,5,6|o,<?=$color2?>,2,6,6">
						

</td></tr>


   
    
   
<?

}
}
function m($r,$m)
{
 return ($r/$m)*100;
}

function dayurl($varstr)
{
 if($varstr=='��') $day='%D0%9F%D0%BD';
 if($varstr=='��') $day='%D0%92%D1%82';
 if($varstr=='��') $day='%D0%A1%D1%80';
 if($varstr=='��') $day='%D0%A7%D1%82';
 if($varstr=='��') $day='%D0%9F%D1%82';
 if($varstr=='��') $day='%D0%A1%D0%B1';
 if($varstr=='��') $day='%D0%92%D1%81';
 return $day;
}
function dayin($varstr)
{
 if($varstr=='��') $day='mon';
 if($varstr=='��') $day='tue';
 if($varstr=='��') $day='wed';
 if($varstr=='��') $day='thu';
 if($varstr=='��') $day='fri';
 if($varstr=='��') $day='sat';
 if($varstr=='��') $day='sun';
 return $day;
}
function day($varstr)
{
 if($varstr<0)$varstr=$varstr+7;
 $day="";
 if($varstr==1) $day='��';
 if($varstr==2) $day='��';
 if($varstr==3) $day='��';
 if($varstr==4) $day='��';
 if($varstr==5) $day='��';
 if($varstr==6) $day='��';
 if($varstr==0) $day='��';
 return $day;
} 
?>