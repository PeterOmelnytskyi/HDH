<?

$lastupd = "1314946739";

$spam = "0.5";

$ban1 = "80";

$ban2 = "85";

$ban3 = "90";

$ban4 = "95";

$ban5 = "100";

$banl = "150";

$maxhits = "2";

$period = "1";

$maxcrit = "10";

$click = "0.25";

$rclick2 = "0.05";

$rclick = "0.06";

$hits = "450";

$recordonline = "307";

$payment = "30";

$minpay = "30";

$advbanner = "100";

$advbanner100 = "2";

$advstatlink = "40";

$mfabanner = "100";

$mfastatlink = "40";

$mfadyn = "4";

$hldyn = "30";

$mfahldyn = "30";

$adblock = "50";

$textads = "50";

$taskminprice = "0.1";

$taskmincount = "10";

$timer5 = "50";

$wmframeads = "30";

$frameads = "30";

$chatmess = "";

$dopsec = "30";

$leftblock = "50";

$vipblock = "100";

$vipcount = "10";

$wmchatads = "30";

$maxautopay = "1000";

$refmax0 = "999999999999999999999999";

$refmax1 = "70";

$autodeluser = "999999999999999999999999";

$refbirjcomm = 15;

$refbirjminclick = "0";

$captcha = "40";

$taskcomm = "15";

$taskhl = "10";

$sitename = "MFS SeoEdit";

$sitewmid = "382683591943";

$siteemail = "alex0235@shopforbux.ru";

$sitepurse = "R255627588882";

$siteval = "R";

$sitetak = 'tak ru';

$x2 = "0";

$x6 = "0";

$rpass1 = "pass1";

$rpass2 = "pass2";

$rlogin = "robologin";

$sitevalname = "���";

$sitestartdate = "26.06.2010";

$merchant = "1";

$timerpay = "1";

$payvsits = "";

$payforday = "0";

$takclick = "0";

$siteurl = "http://lseed.name";

$paycomm = "������� � :sitename: ������������ :username:";

$newtoday = "0";

$worked = "1";

$allvis = "6";

$totalpaid = "0";

$waitpay = "0";

$moneytoaccs = "0";

$viplat = "0";

$admin = "admin";

$adminonline = "<center><b>�������������: <span style=color:#00dd00>on-line</span><br></b>";

$vozrast = "434";

$datenew = "26.08.2011";

$textnew = "[i]������[/i]
[b]gg[/b]";

$temanew = "����";

$newid =  "4";

$refererbonus = "0.50";

$actwin = "0.05";

$cloudwm = "10";

$siteicq = "9368722";

$psevdoweek1 = "1000";

$psevdoweek2 = "2000";

$psevdoweek3 = "3000";

$psevdoweek4 = "4000";

$ban88 = "50";

$runblock = "50";

$vipmest1 = "";

$vipmest2 = "";

$payfor5 = "0.25";

$payfor10 = "0.5";

$payfor15 = "0.75";

$payfor20 = "1";

$payfor25 = "1.25";

$payfor30 = "1.5";

$payfor35 = "1.75";

$payfor40 = "2";

$payfor45 = "2.25";

$payfor50 = "2.5";

$payfor55 = "2.75";

$payfor60 = "6";

$refpayfor5 = "0.06";

$refpayfor10 = "0.12";

$refpayfor15 = "0.18";

$refpayfor20 = "0.24";

$refpayfor25 = "0.3";

$refpayfor30 = "0.36";

$refpayfor35 = "0.42";

$refpayfor40 = "0.48";

$refpayfor45 = "0.54";

$refpayfor50 = "0.6";

$refpayfor55 = "0.68";

$refpayfor60 = "3";

$dyn5 = "0.45";

$dyn10 = "0.9";

$dyn15 = "1.35";

$dyn20 = "1.8";

$dyn25 = "2.25";

$dyn30 = "2.7";

$dyn35 = "3.15";

$dyn40 = "3.6";

$dyn45 = "4.05";

$dyn50 = "4.5";

$dyn55 = "4.95";

$dyn60 = "6";

$runacc = "50";

$nasvsego = "2";

$vchera = "0";

$newcomms = "0";

$obperehod = "0.05";

?>