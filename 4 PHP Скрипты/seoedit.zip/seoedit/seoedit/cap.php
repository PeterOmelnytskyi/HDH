<?php
session_start();
$text=$_SESSION["captcha"];
header("Content-type: image/png");
$im = imagecreate(160, 25);
$res=imagettfbbox(14, 0, "./cap.ttf", $text);
$width=$res[2]-$res[0]+20;
imagedestroy($im);

$im=imagecreate($width,25);

$white = imagecolorallocatealpha($im, 255, 255, 255, 127); 
$black = imagecolorallocate($im, 0, 140, 255); 

imagettftext($im, 14, 0, 10, 20, $black, "./cap.ttf", $text);
imagepng($im);
imagedestroy($im); 
?>