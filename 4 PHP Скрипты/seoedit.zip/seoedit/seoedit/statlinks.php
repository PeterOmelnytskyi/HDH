<?
$sql=mysql_query("SELECT * FROM tb_statlinks WHERE balance>0 and modered=1 and paused=0 ORDER BY RAND() LIMIT 10") or die(mysql_error());
while($row=mysql_fetch_assoc($sql))
{
	if(intval($row[balance]/$row[price])==0 or $row[balance]<$row[price]) mysql_query("UPDATE tb_statlinks SET paused=1,balance=0 WHERE id='$row[id]'") or die(mysql_error());
	?><div class='contextlink'>
	<a href='/sl_url.php?link=<?=$row[id] ?>' target='_blank' title='<?=$row[views] ?> ���������'>
	<?=$row[description] ?><span><?=$row[texto] ?><br />
	<span class='urlcontext'><?=$row[url] ?>&hellip;</span></span></a></div>
	
<?
}
?>