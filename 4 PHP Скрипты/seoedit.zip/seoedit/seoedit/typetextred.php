<?php
header("Content-type: image/png");
$text=$_GET["text"];
$size=$_GET["size"];

$im = imagecreate(160, $size+11);
$res=imagettfbbox($size, 0, "./image2.ttf", $text);
$width=$res[2]-$res[0]+20;
imagedestroy($im);

$im=imagecreate($width,$size+11);

$white = imagecolorallocatealpha($im, 255, 255, 255, 127); 
$black = imagecolorallocate($im, 255, 0, 0); 

imagettftext($im, $size, 0, 10, $size+6, $black, "./image2.ttf", $text);
imagepng($im);
imagedestroy($im); 
?>