<?session_start();  //������ ������
require('config.php'); //������������ ����������� � ��!� �������� ���������� ����� ������ �� �� ������ ������ �� ���� </html>
$nowdate = date('d.m.Y'); //����� ����
$nowtime = date(time()); //����� �����
$nameus = $_SESSION["username"]; //���������� ������������
include('blocks/inf.php');
require('sfbstat.php');
if($lastupd+600 < time())
{

///� ���� ������
$ld=date("d.m.Y", time()-86400);
$res=mysql_fetch_array(mysql_query("SELECT 
(SELECT price FROM tb_config WHERE item='spam') spam,
(select price from tb_config where item='runblock') runblock,
(select price from tb_config where item='runacc') runacc,
(select price from tb_config where item='ban88') ban88,
(SELECT price FROM tb_config WHERE item='cloudwm') cloudwm,
(SELECT price FROM tb_config WHERE item='mprice') mprice,
(SELECT price FROM tb_config WHERE item='mobper') mobper,
(SELECT price FROM tb_config WHERE item='mhighlight') mhighlight,
(SELECT price FROM tb_config WHERE item='mtimer') mtimer,
(SELECT price FROM tb_config WHERE item='cloudma') cloudma,
(SELECT price FROM tb_config WHERE item='ban1') ban1,
(SELECT price FROM tb_config WHERE item='ban2') ban2,
(SELECT price FROM tb_config WHERE item='ban3') ban3,
(SELECT price FROM tb_config WHERE item='ban4') ban4,
(SELECT price FROM tb_config WHERE item='ban5') ban5,
(SELECT price FROM tb_config WHERE item='banl') banl,
(SELECT price FROM tb_config WHERE item='ddosmaxhits') ddosmaxhits,
(SELECT price FROM tb_config WHERE item='ddosperiod') ddosperiod,
(SELECT price FROM tb_config WHERE item='ddoscrits') ddoscrits,
(SELECT price FROM tb_config WHERE item='click') click,
(SELECT price FROM tb_config WHERE item='referalclick') referalclick,
(SELECT price FROM tb_config WHERE item='referalclick2') referalclicktwo,
(SELECT howmany FROM tb_config WHERE item='recordonline') recordonline,
(SELECT price FROM tb_config WHERE item='hits') hits,
(SELECT price FROM tb_config WHERE item='payment') payment,
(SELECT price FROM tb_config WHERE item='payment' AND howmany='1') minpay,
(SELECT price FROM tb_config WHERE item='advbanner') advbanner,
(SELECT price FROM tb_config WHERE item='advbanner100') advbanner100,
(SELECT price FROM tb_config WHERE item='advstatlink') advstatlink,
(SELECT price FROM tb_config WHERE item='mfabanner') mfabanner,
(SELECT price FROM tb_config WHERE item='mfastatlink') mfastatlink,
(SELECT price FROM tb_config WHERE item='obperehod') obperehod,
(SELECT price FROM tb_config WHERE item='mfadyn') mfadyn,
(SELECT price FROM tb_config WHERE item='mfahldyn') mfahldyn,
(SELECT price FROM tb_config WHERE item='hldyn') hldyn,
(SELECT price FROM tb_config WHERE item='adblock') adblock,
(SELECT price FROM tb_config WHERE item='taskminprice') taskminprice,
(SELECT price FROM tb_config WHERE item='taskmincount') taskmincount,
(SELECT price FROM tb_config WHERE item='textads') textads,
(SELECT price FROM tb_config WHERE item='timer5') timer5,
(SELECT price FROM tb_config WHERE item='wmframeads') wmframeads,
(SELECT price FROM tb_config WHERE item='frameads') frameads,
(SELECT price FROM tb_config WHERE item='chatmess') chatmess,
(SELECT price FROM tb_config WHERE item='dopsec') dopsec,
(SELECT price FROM tb_config WHERE item='leftblock') leftblock,
(SELECT price FROM tb_config WHERE item='vipblock') vipblock,
(SELECT price FROM tb_config WHERE item='vipcount') vipcount,
(SELECT price FROM tb_config WHERE item='wmchatads') wmchatads,
(SELECT price FROM tb_config WHERE item='maxautopay') maxautopay,
(select price from tb_config where item='psevdoweek1') psevdoweek1,
(select price from tb_config where item='psevdoweek2') psevdoweek2,
(select price from tb_config where item='psevdoweek3') psevdoweek3,
(select price from tb_config where item='psevdoweek4') psevdoweek4,
(select price from tb_config where item='refmax' and howmany='0') refmax0,
(select price from tb_config where item='refmax' and howmany='1') refmax1,
(SELECT price FROM tb_config WHERE item='refbirjcomm') refbirjcomm,
(SELECT price FROM tb_config WHERE item='autodeluser') autodeluser,
(SELECT price FROM tb_config WHERE item='refbirjminclick') refbirjminclick,
(SELECT price FROM tb_config WHERE item='captcha') captcha,
(SELECT price FROM tb_config WHERE item='taskcomm') taskcomm,
(SELECT price FROM tb_config WHERE item='taskhl') taskhl,
(SELECT price FROM tb_config WHERE item='refererbonus') refererbonus,
(SELECT price FROM tb_config WHERE item='actwin') actwin,
(SELECT count(id) FROM tb_users WHERE joindate='$nowdate') newtoday,
(SELECT count(id) FROM tb_users WHERE joindate='$ld') vchera,
(SELECT sum(visits) FROM tb_users) allvis,
(SELECT sum(amount) FROM tb_history) totalpaid,
(SELECT count(id) FROM tb_payme) waitpay,
(SELECT sum(money) FROM tb_users WHERE user_status='user') moneytoaccs,
(SELECT count(id) FROM tb_history) viplat,
(SELECT count(id) FROM tb_users) nasvsego,
(SELECT price FROM tb_config WHERE item='mpay') mpay,
(SELECT price FROM tb_config WHERE item='mrefpay') mrefpay,
(SELECT username FROM tb_users WHERE user_status='admin' order by id desc limit 1) admin LIMIT 1"));$allsqls++;
$newtoday=$res["newtoday"];
$worked=$res["worked"];
$allvis=$res["allvis"];
if($res["totalpaid"]=='') $res["totalpaid"]="0.00";
$totalpaid=round($res["totalpaid"],2);
$waitpay=$res["waitpay"];
////////////////////
$admindynpercent=25;
////////////////////
if($res["moneytoaccs"]=='') $res["moneytoaccs"]="0.00";
$moneytoaccs=round($res["moneytoaccs"],2);
$viplat=$res["viplat"];
$admin=$res["admin"];
$spam=$res["spam"];
$cloudwm=$res["cloudwm"];
$cloudma=$res["cloudma"];
$ban1=$res["ban1"];
$ban2=$res["ban2"];
$mpay=$res[mpay];
$mrefpay=$res[mrefpay];
$ban3=$res["ban3"];
$ban4=$res["ban4"];
$ban5=$res["ban5"];
$banl=$res["banl"];
$mprice=$res[mprice];
$pmhighlight=$res[mhighlight];
$pmobper=$res[mobper];
$pmtimer=$res[mtimer];
$vipmest1=$res["vipmest1"];
$vipmest2=$res["vipmest2"];
$runblock=$res["runblock"];
$runacc=$res["runacc"];
$ban88=$res["ban88"];
$maxhits=$res["ddosmaxhits"];
$period=$res["ddosperiod"];
$maxcrit=$res["ddoscrits"];
$obperehod=$res["obperehod"];
$click=$res["click"];
$rclick=$res["referalclick"];
$rclick2=$res["referalclicktwo"];
$hits=$res["hits"];
$recordonline=$res["recordonline"];
$payment=$res["payment"];
$minpay=$res["minpay"];
$advbanner=$res["advbanner"];
$advbanner100=$res["advbanner100"];
$advstatlink=$res["advstatlink"];
$mfabanner=$res["mfabanner"];
$mfastatlink=$res["mfastatlink"];
$mfadyn=$res["mfadyn"];
$hldyn=$res["hldyn"];
$mfahldyn=$res["mfahldyn"];
$adblock=$res["adblock"];
$textads=$res["textads"];
$psevdoweek1=$res["psevdoweek1"];
$psevdoweek2=$res["psevdoweek2"];
$psevdoweek3=$res["psevdoweek3"];
$psevdoweek4=$res["psevdoweek4"];
$taskminprice=$res["taskminprice"];
$taskmincount=$res["taskmincount"];
$timer5=$res["timer5"];
$wmframeads=$res["wmframeads"];
$frameads=$res["frameads"];
$vhatmess=$res["chatmess"];
$dopsec=$res["dopsec"];
$leftblock=$res["leftblock"];
$vipblock=$res["vipblock"];
$vipcount=$res["vipcount"];
$wmchatads=$res["wmchatads"];
$maxautopay=$res["maxautopay"];
$refmax0=$res["refmax0"];
$refmax1=$res["refmax1"];
$autodeluser=$res["autodeluser"];
$refbirjcomm=$res["refbirjcomm"];
$refbirjminclick=$res["refbirjminclick"];
$captcha=$res["captcha"];
$taskcomm=$res["taskcomm"];
$taskhl=$res["taskhl"];
$vchera=$res["vchera"];
$refererbonus=$res["refererbonus"];
$actwin=$res["actwin"];
$sql1=mysql_query("SELECT * FROM tb_site WHERE id='1'") or die(mysql_error());$allsqls++;
$o=mysql_fetch_array($sql1);
$sitename = $o["sitename"];
$sitewmid = $o["wmid"];
$siteicq = $o["icq"];
$siteemail = $o["email"];
$sitepurse = $o["purse"];
$siteval = $o["valuta"];
$sitetak = $o["sitetak"];
$x2 = $o["x2"];
$x6=$o["x6"];
$rpass1 = $o["robopass1"];
$rpass2 = $o["robopass2"];
$rlogin = $o["robologin"];
$sitevalname = $o["valutaname"];
$sitestartdate = $o["startdate"];
$merchant = $o["merchant"];
$timerpay = $o["timerpay"];
$payvisits = $o["visits"];
$payforday = $o["payforday"];
$takclick = $o["takclick"];
$sitehost=$_SERVER["HTTP_HOST"];
$siteurl="http://$sitehost";
$paycomm = $o["comment"];
$nasvsego=$res["nasvsego"];
include('moneyfortimer.php');
//

}
$ip=getrealip(); 

$res=mysql_query("select count(*) as kolvo from tb_accessblock where ip like '$ip%'");		$allsqls++;	
$res=mysql_Fetch_array($res);										 
if($res["kolvo"]>0)											 
{													  
	echo "<img src=\"/mfs/error.png\" align=middle>&nbsp;������ IP ������������ ������ � �����";    
	exit();												  
}													  	

if(isset($_SESSION["username"]))
{
$sql2=mysql_query("SELECT * FROM tb_users WHERE id='$_SESSION[iduser]'") or die(mysql_error());$allsqls++;
$byme=mysql_fetch_array($sql2);
$passwd=$byme["password"];
$pemail=$byme["pemail"];
$referer=$byme["referer"];
$country=$byme["country"];
$user_status=$byme["user_status"];
$chatmoder=$byme["chatmoder"];
$visits=$byme["visits"];
$maccess=$byme[mailaccess];
$family=$byme[family];
$doing=$byme[doing];
$lastpay=$byme["lastpay"];
$obrr=mysql_query("SELECT 
(SELECT count(id) FROM tb_users WHERE referer='$_SESSION[iduser]') refov,
(SELECT sum(visits) FROM tb_users WHERE referer='$_SESSION[iduser]') visitov1");$allsqls++;
$obrr=mysql_fetch_array($obrr);
$referalvisits=$obrr["visitov1"];
if($referalvisits==NULL) $referalvisits=0;
$referalvisits2=$obrr["visitov2"];
if($referalvisits2==NULL) $referalvisits2=0;
$referals=$obrr["refov"];
$referals2=$obrr["refov2"];
$money=round($byme["money"],3);
$moneynoround=round($byme["money"],2)-0.01;
$blockpay=$byme["blockpay"];
$lastcook=$byme["lastcook"];
$paid=$byme["paid"];
$email=$byme["email"];
$joindate=$byme["joindate"];
$lastlogdate=$byme["lastlogdate"];
$lastiplog=$byme["lastiplog"];
$wmid=$byme["wmid"];
$blockip=$byme["blockip"];
$chatpaid=$byme["chatpaid"];
$avatar=$byme["avatar"];
$avatar="avp/$avatar";
$chatmessages=$byme["chatmessages"];
if($chatmessages==NULL) $chatmessages=0;
}
if($lastupd+600<time())
{

$res=mysql_query("select count(*) as kolvo from users_online where user IN(SELECT username FROM tb_users WHERE user_status='admin')");$allsqls++;
$res=mysql_fetch_array($res);
if($res["kolvo"]>0)
{
$adminonline="<center><b>�������������: <span style=color:#00dd00>on-line</span><br></b>";
}else{
$adminonline="<center><b>�������������: <span style=color:#ff0000>off-line</span><br></b>";
}
$d0=strtotime($sitestartdate);
$d1=time();
$d=($d1-$d0)/(24*3600);
$vozrast=ceil($d);
/////////////**���������� ���������**/////
$printnew="select * from tb_news order by id desc limit 1";
$printnew=mysql_query($printnew);$allsqls++;
$printnew=mysql_fetch_array($printnew);
$datenew=$printnew["data"];
$textnew=$printnew["newstext"];
$temanew=$printnew["tema"];
$newid=$printnew["id"];
$newcomms=mysql_num_rows(mysql_query("SELECT id FROM afbcomments WHERE idnew='$newid'"));$allsqls++;

//
}
///��������� ������� ������

if($lastupd+600<time())
{
$lastupd=time();
$content_stats = "<?\n
\$lastupd = \"{$lastupd}\";\n
\$spam = \"{$spam}\";\n
\$ban1 = \"{$ban1}\";\n
\$ban2 = \"{$ban2}\";\n
\$ban3 = \"{$ban3}\";\n
\$ban4 = \"{$ban4}\";\n
\$ban5 = \"{$ban5}\";\n
\$banl = \"{$banl}\";\n
\$maxhits = \"{$maxhits}\";\n
\$period = \"{$period}\";\n
\$maxcrit = \"{$maxcrit}\";\n
\$click = \"{$click}\";\n
\$rclick2 = \"{$rclick2}\";\n
\$rclick = \"{$rclick}\";\n
\$hits = \"{$hits}\";\n
\$recordonline = \"{$recordonline}\";\n
\$payment = \"{$payment}\";\n
\$minpay = \"{$minpay}\";\n
\$advbanner = \"{$advbanner}\";\n
\$advbanner100 = \"{$advbanner100}\";\n
\$advstatlink = \"{$advstatlink}\";\n
\$mfabanner = \"{$mfabanner}\";\n
\$mfastatlink = \"{$mfastatlink}\";\n
\$mfadyn = \"{$mfadyn}\";\n
\$hldyn = \"{$hldyn}\";\n
\$mfahldyn = \"{$mfahldyn}\";\n
\$adblock = \"{$adblock}\";\n
\$textads = \"{$textads}\";\n
\$taskminprice = \"{$taskminprice}\";\n
\$taskmincount = \"{$taskmincount}\";\n
\$timer5 = \"{$timer5}\";\n
\$wmframeads = \"{$wmframeads}\";\n
\$frameads = \"{$frameads}\";\n
\$chatmess = \"{$chatmess}\";\n
\$dopsec = \"{$dopsec}\";\n
\$leftblock = \"{$leftblock}\";\n
\$vipblock = \"{$vipblock}\";\n
\$vipcount = \"{$vipcount}\";\n
\$wmchatads = \"{$wmchatads}\";\n
\$maxautopay = \"{$maxautopay}\";\n
\$refmax0 = \"{$refmax0}\";\n
\$refmax1 = \"{$refmax1}\";\n
\$autodeluser = \"{$autodeluser}\";\n
\$refbirjcomm = {$refbirjcomm};\n
\$refbirjminclick = \"{$refbirjminclick}\";\n
\$captcha = \"{$captcha}\";\n
\$taskcomm = \"{$taskcomm}\";\n
\$taskhl = \"{$taskhl}\";\n
\$sitename = \"{$sitename}\";\n
\$sitewmid = \"{$sitewmid}\";\n
\$siteemail = \"{$siteemail}\";\n
\$sitepurse = \"{$sitepurse}\";\n
\$siteval = \"{$siteval}\";\n
\$sitetak = '{$sitetak}';\n
\$x2 = \"{$x2}\";\n
\$x6 = \"{$x6}\";\n
\$rpass1 = \"{$rpass1}\";\n
\$rpass2 = \"{$rpass2}\";\n
\$rlogin = \"{$rlogin}\";\n
\$sitevalname = \"{$sitevalname}\";\n
\$sitestartdate = \"{$sitestartdate}\";\n
\$merchant = \"{$merchant}\";\n
\$timerpay = \"{$timerpay}\";\n
\$payvsits = \"{$payvisits}\";\n
\$payforday = \"{$payforday}\";\n
\$takclick = \"{$takclick}\";\n
\$siteurl = \"{$siteurl}\";\n
\$paycomm = \"{$paycomm}\";\n
\$newtoday = \"{$newtoday}\";\n
\$worked = \"{$worked}\";\n
\$allvis = \"{$allvis}\";\n
\$totalpaid = \"{$totalpaid}\";\n
\$waitpay = \"{$waitpay}\";\n
\$moneytoaccs = \"{$moneytoaccs}\";\n
\$viplat = \"{$viplat}\";\n
\$admin = \"{$admin}\";\n
\$adminonline = \"{$adminonline}\";\n
\$vozrast = \"{$vozrast}\";\n
\$datenew = \"{$datenew}\";\n
\$textnew = \"{$textnew}\";\n
\$temanew = \"{$temanew}\";\n
\$newid =  \"{$newid}\";\n
\$refererbonus = \"{$refererbonus}\";\n
\$actwin = \"{$actwin}\";\n
\$cloudwm = \"{$cloudwm}\";\n
\$siteicq = \"{$siteicq}\";\n
\$psevdoweek1 = \"{$psevdoweek1}\";\n
\$psevdoweek2 = \"{$psevdoweek2}\";\n
\$psevdoweek3 = \"{$psevdoweek3}\";\n
\$psevdoweek4 = \"{$psevdoweek4}\";\n
\$ban88 = \"{$ban88}\";\n
\$runblock = \"{$runblock}\";\n
\$vipmest1 = \"{$vipmest1}\";\n
\$vipmest2 = \"{$vipmest2}\";\n
\$payfor5 = \"{$payfor5}\";\n
\$payfor10 = \"{$payfor10}\";\n
\$payfor15 = \"{$payfor15}\";\n
\$payfor20 = \"{$payfor20}\";\n
\$payfor25 = \"{$payfor25}\";\n
\$payfor30 = \"{$payfor30}\";\n
\$payfor35 = \"{$payfor35}\";\n
\$payfor40 = \"{$payfor40}\";\n
\$payfor45 = \"{$payfor45}\";\n
\$payfor50 = \"{$payfor50}\";\n
\$payfor55 = \"{$payfor55}\";\n
\$payfor60 = \"{$payfor60}\";\n
\$refpayfor5 = \"{$refpayfor5}\";\n
\$refpayfor10 = \"{$refpayfor10}\";\n
\$refpayfor15 = \"{$refpayfor15}\";\n
\$refpayfor20 = \"{$refpayfor20}\";\n
\$refpayfor25 = \"{$refpayfor25}\";\n
\$refpayfor30 = \"{$refpayfor30}\";\n
\$refpayfor35 = \"{$refpayfor35}\";\n
\$refpayfor40 = \"{$refpayfor40}\";\n
\$refpayfor45 = \"{$refpayfor45}\";\n
\$refpayfor50 = \"{$refpayfor50}\";\n
\$refpayfor55 = \"{$refpayfor55}\";\n
\$refpayfor60 = \"{$refpayfor60}\";\n
\$dyn5 = \"{$dyn5}\";\n
\$dyn10 = \"{$dyn10}\";\n
\$dyn15 = \"{$dyn15}\";\n
\$dyn20 = \"{$dyn20}\";\n
\$dyn25 = \"{$dyn25}\";\n
\$dyn30 = \"{$dyn30}\";\n
\$dyn35 = \"{$dyn35}\";\n
\$dyn40 = \"{$dyn40}\";\n
\$dyn45 = \"{$dyn45}\";\n
\$dyn50 = \"{$dyn50}\";\n
\$dyn55 = \"{$dyn55}\";\n
\$dyn60 = \"{$dyn60}\";\n
\$mpay = \"{$mpay}\";\n
\$mrefpay = \"{$mrefpay}\";\n
\$runacc = \"{$runacc}\";\n
\$nasvsego = \"{$nasvsego}\";\n
\$vchera = \"{$vchera}\";\n
\$newcomms = \"{$newcomms}\";\n
\$obperehod = \"{$obperehod}\";\n
\$mprice = \"{$mprice}\";\n
\$pmhighlight = \"{$pmhighlight}\";\n
\$pmtimer = \"{$pmtimer}\";\n
\$pmobper = \"{$pmobper}\";\n
?>";

$fstats = @fopen("sfbstat.php","w+");
@fwrite($fstats,$content_stats);
@fclose($fstats);
}

?>