<?
require('config.php');
$sql="select * from tb_psevdolinks";
$res=mysql_query($sql);

if ($res)
{
	while ($row=mysql_fetch_assoc($res))
	{
		$bd=$row["begindate"];
		$d=$row["numdays"];
		$days=$d*7;
		$t=time();
		
		$d1=($t-$bd)/86400;
		
		if ($d1>$days)
		{
			$id=$row["id"];
			$sql="delete from tb_psevdolinks where id='$id'";
			mysql_query($sql);
		}
	}
}
?>
<?
session_start();

$nameus=$_SESSION["username"];
$urlpage='<font color=#ff0000>������������</font>';

$agent = $_SERVER['HTTP_USER_AGENT'];
$uri = $_SERVER['REQUEST_URI'];
$ref = $_SERVER['HTTP_REFERER'];
$uo_ip = $_SERVER['REMOTE_ADDR'];

require('config.php');

$uo_sessionTime = 1;
error_reporting(E_ERROR | E_PARSE);
$uo_ip = $_SERVER['REMOTE_ADDR'];
$uo_query = "DELETE FROM users_online WHERE unix_timestamp() - lastvisit >= $uo_sessionTime * 60";
mysql_query($uo_query);

$uo_query = "SELECT lastvisit FROM users_online WHERE visitor = '$uo_ip'";
$uo_result = mysql_query($uo_query);
if(mysql_num_rows($uo_result) == 0) {
	$uo_query = "INSERT INTO users_online (visitor,lastvisit,user,urlpage,agent,uri,ref) VALUES('$uo_ip', unix_timestamp(), '$nameus', '$urlpage', '$agent', '$uri', '$ref')";
	mysql_query($uo_query);
} else {
	$uo_query = "UPDATE users_online SET lastvisit = unix_timestamp(), urlpage='$urlpage', user='$nameus', agent='$agent', uri='$uri', ref='$ref' WHERE visitor = '$uo_ip'";
	mysql_query($uo_query);
}

mysql_close($con);

$ad=$_GET["ad"];
if(!ereg("^[0-9]{1,255}$", $ad))
{
	$ad=-1;
}
$ad=intval($ad);

require('config.php');
$res=mysql_query("select count(*) as kolvo from tb_psevdolinks where id='$ad'");
$res=mysql_fetch_array($res);
mysql_close($con);

$kolvo=$res["kolvo"];
if ($kolvo<1)
{
	echo "<img src=\"images/error.png\" align=\"middle\">&nbsp;������ ������� �� ���� ������";
	exit();
}

require('config.php');
$res=mysql_query("select url, description, members, outside from tb_psevdolinks where id='$ad'");
$res=mysql_fetch_array($res);
mysql_close($con);

$urlsite=$res["url"];

$_SESSION["urlsite"]=$res["url"];
$_SESSION["desc"]=$res["description"];
$_SESSION["ad"]=$ad;

if($_SESSION["username"]==NULL)
{
	$outside=$res["outside"]+1;
	
	require('config.php');
	mysql_query("update tb_psevdolinks set outside='$outside' where id='$ad'");
	mysql_close($con);

	?>
	<script type="text/javascript">
	location.replace("<?=$urlsite?>");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=<?=$urlsite?>">
	</noscript>
	<?
}

if($_SESSION["username"]!=NULL)
{
	$members=$res["members"]+1;
	
	require('config.php');
	mysql_query("update tb_psevdolinks set members='$members' where id='$ad'");
	mysql_close($con);

	?>
	<script type="text/javascript">
	location.replace("<?=$urlsite?>");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=<?=$urlsite?>">
	</noscript>
	<?
}
?>