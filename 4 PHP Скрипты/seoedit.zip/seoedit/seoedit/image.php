<?php require 'images/my-bg.png'; ?>
<?php
// Тип содержимого – картинка формата PNG 
header("Content-type: image/png");
// создаем картинку размером 130X40
//$img=imagecreatetruecolor(130, 40) or die('Cannot create image');
$bgcapcha=rand(0,4); 
$img = imageCreateFromPng('images/bgcapcha'.$bgcapcha.'.png');
$star1 = imageCreateFromPng('images/ico16/star1.png');
$star2 = imageCreateFromPng('images/ico16/star2.png');
$star3 = imageCreateFromPng('images/ico16/star3.png');
// заполняем фон картинки белым цветом
//imagefill($img, 0, 0, 0xFFFFFF);
/*
$x=0;

$sum = "";
$fonts = array(
'ttf/glasten.ttf', 
'ttf/addict2.ttf',
'ttf/captcha.ttf'
);
$font = $fonts[rand(0, sizeof($fonts)-1)];*/
$kstar=0;

if(rand(0,1)) {
$kstar++; $startyp=rand(1,3); 
$startyp=rand(1,3);
if($startyp==1) $star=$star1;
if($startyp==2) $star=$star2;
if($startyp==3) $star=$star3;

ImageCopy ($img,$star, 16*0+1 , rand(0,1)*16+2, 0, 0, 16, 16);
}

if(rand(0,1)) {
$kstar++; $startyp=rand(1,3); 
$startyp=rand(1,3);
if($startyp==1) $star=$star1;
if($startyp==2) $star=$star2;
if($startyp==3) $star=$star3;

ImageCopy ($img,$star, 16*1+1 , rand(0,1)*16+2, 0, 0, 16, 16);
}

if(rand(0,1)) {
$kstar++; $startyp=rand(1,3); 
$startyp=rand(1,3);
if($startyp==1) $star=$star1;
if($startyp==2) $star=$star2;
if($startyp==3) $star=$star3;

ImageCopy ($img,$star, 16*2+1 , rand(0,1)*16+2, 0, 0, 16, 16);
}

if(rand(0,1)) {
$kstar++; $startyp=rand(1,3); 
$startyp=rand(1,3);
if($startyp==1) $star=$star1;
if($startyp==2) $star=$star2;
if($startyp==3) $star=$star3;

ImageCopy ($img,$star, 16*3+1 , rand(0,1)*16+2, 0, 0, 16, 16);
}

if(rand(0,1)) {
$kstar++; $startyp=rand(1,3); 
$startyp=rand(1,3);
if($startyp==1) $star=$star1;
if($startyp==2) $star=$star2;
if($startyp==3) $star=$star3;

ImageCopy ($img,$star, 16*5+1 , rand(0,1)*16+2, 0, 0, 16, 16);
}

if(rand(0,1)) {
$kstar++; $startyp=rand(1,3); 
$startyp=rand(1,3);
if($startyp==1) $star=$star1;
if($startyp==2) $star=$star2;
if($startyp==3) $star=$star3;

ImageCopy ($img,$star, 16*6+1 , rand(0,1)*16+2, 0, 0, 16, 16);
}

if(rand(0,1)) {
$kstar++; $startyp=rand(1,3); 
$startyp=rand(1,3);
if($startyp==1) $star=$star1;
if($startyp==2) $star=$star2;
if($startyp==3) $star=$star3;

ImageCopy ($img,$star, 16*7+1 , rand(0,1)*16+2, 0, 0, 16, 16);
}

if($kstar==0)
{
  $kstar=1;
  $startyp=rand(1,3);
  if($startyp==1) $star=$star1;
  if($startyp==2) $star=$star2;
  if($startyp==3) $star=$star3;
  ImageCopy ($img,$star, rand(0,113), rand(0,23), 0, 0, 16, 16);
}


//$i=1;
// выводим одну цифру за один проход цикла (всего 5 цифр)
/*while ($i++ <= 5)
{
   // выводим текст поверх картинки
   imagettftext(
   $img,          // идентификатор ресурса
   rand(24,24),   // размер шрифта в пикселях
   rand(-25,25),  // угол поворота текста
   $x=$x+17, 30, // координаты (x,y), соответствующие левому нижнему
                            // углу первого символа
   imagecolorallocate($img, rand(0,128), rand(0,128), rand(0,128)), // цвет шрифта
   $font, // имя файла со шрифтом
   $rnd=rand(0,9)); // случайная цифра от 0 до 9
   // Собираем в одну строку все символы на картинке
   $sum = $sum.(string)$rnd;
}*/
session_start();

// выводим готовую картинку в формате PNG
imagepng($img);
// освобождаем память, выделенную для картинки
imagedestroy($img);

$_SESSION["texto"] = $kstar;
?> 
