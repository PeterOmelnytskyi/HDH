<?
session_start();
unset($_SESSION["logcaptcha"]);
$logc=rand(1000,9999);
$_SESSION["logcaptcha"]=$logc;
$text=$logc;
header("Content-type: image/png");
$img = @ImageCreateFromPNG("mfs/concap.png");
$text=$logc;
$text_color = imagecolorallocate($img, 34, 139, 34);
imagestring($img, 3, 1, 4, $text, $text_color);
imagepng($img);
imagedestroy($img);
?>


