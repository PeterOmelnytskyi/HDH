<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<title>���� �� ������������</title>
<style>
html,body{background:url(../offimg/bg.jpg); font-size:15px; font-family:Arial, Helvetica, sans-serif; margin:0;}
#index{width:768px; height:100%; margin-top:50px;}
.header{background:url(../offimg/header.png) no-repeat; width:768px; height:120px; display:block;}
.head_title{color:#a46c6c; font-weight:bold; padding-top:53px; float:left; margin-left:55px;}

#content{width:680px; height:100%;}
.fon{background:url(../offimg/fon.jpg) repeat-y; width:680px; background-position:center; min-height:75px;}
.logo{background:url(../offimg/logo.jpg) no-repeat; width:114px; height:104px; margin-top:-32px; float:left; margin-left:12px;}
.footer{background:url(../offimg/footer.png) no-repeat; height:22px; width:680px;}

.cn{width:533px;}
.cn_l{background:url(../offimg/cn_l.jpg) no-repeat; height:104px; width:125px; float:left; margin-top:-31px; margin-left:9px; overflow:hidden;}
.cn_r{background:url(../offimg/cn_r.jpg) no-repeat; height:104px; width:411px; float:right; margin-right:-64px; margin-top:-104px;}

.cn_title{color:#cccccc; font-weight:bold; padding-top:47px; margin-left:12px;}
.cont{width:382px; text-align:left; color:#5f5f5f; font-weight:bold; padding-top:40px;}


</style>
</head>
<body>
<div align="center">
<div id="index">

<!-- Head -->
	<div class="header">
    	<div class="head_title">� ���������,���� ������ ��������� �� ������������� !</div>
    </div>
<!-- End Head -->

<!-- Content -->
	<div id="content">
    	<div class="fon">
        	<div class="logo"></div>
            <div class="cn">
            	<div class="cn_l">
                	<div class="cn_title">����:</div>
                </div>
            	<div class="cn_r">
                	<div class="cont">
					<form action='config.php' method='POST'>
<table width="100%" border="0" align="center">
    <td>E-mail: <input type='text' size='15' maxlength='25' name='username' autocomplete="off" value="" tabindex="1" /></td>
	<td>������: <input type='password' size='15' maxlength='25' name='password' autocomplete="off" value="" tabindex="2" /></td>
	<td><br><input type="submit" value="�����" class="submit" tabindex="4" /></td>
  </table>
</form>
					
					
					</div>
                </div>
            </div>
        </div>
        <div class="footer"></div>
    </div>
<!-- End Content -->

</div>
</div>
</body>
</html>

