<?php
require('blocks/inf.php');
function check_email($email) {
// ��������� ������������ ���������� email �� ������ ������� 
if (ereg( "/[0-9a-z_]+@[0-9a-z_^\.]+\.[a-z]{2,3}/i", $email)) { 
    return ''; 
} else {
  return $email;
}
}

function check_text($text)
{
	$text=strip_tags($text);
	$text=str_replace('"','&quot;',$text);
	$text=str_replace("'",'',$text);
	$text=str_replace(';','',$text);
	$text=str_replace('`','',$text);
	$text=trim($text);
	return $text;
}function bbcode($text, $mode) {
  $str_search = array(
  "#\[br\]#is",
  "#\[p\](.+?)\[\/p\]#is",
  "#\[b\](.+?)\[\/b\]#is",
  "#\[i\](.+?)\[\/i\]#is",
  "#\[s\](.+?)\[\/s\]#is",
  "#\[u\](.+?)\[\/u\]#is",
  "#\[url=(.+?)\](.+?)\[\/url\]#is",
  "#\[url\](.+?)\[\/url\]#is",
  "#\[img\](.+?)\[\/img\]#is",
  "#\[size=(.+?)\](.+?)\[\/size\]#is",
  "#\[color=(.+?)\](.+?)\[\/color\]#is",
  "#\[list\](.+?)\[\/list\]#is",
  "#\[list=(1|a|I)\](.+?)\[\/list\]#is",
  "#\[\*\](.*)#",
  "#\[h(1|2|3|4|5|6)\](.+?)\[/h\\1\]#is");
  $str_replace = array(
  "<br />",
  "</p><p>\\1</p>",
  "<strong>\\1</strong>",
  "<span style='font-style:italic'>\\1</span>",
  "<span style='text-decoration:line-through'>\\1</span>",
  "<span style='text-decoration:underline'>\\1</span>",
  "<a href='\\1'>\\2</a>",
  "<a href='\\1'>\\1</a>",
  "<img src='\\1' />",
  "<span style='font-size:\\1pt'>\\2</span>",
  "<span style='color:\\1'>\\2</span>",
  "<ul>\\1</ul>",
  "<ol type='\\1'>\\2</ol>",
  "<li>\\1</li>",
  "<h \\1>\\2</h>");
  if ($mode=="html")
  {
  return preg_replace($str_search, $str_replace, $text);
  }else{
  return preg_replace($str_replace, $str_search, $text);
  }
}
function getCountryByIp($ipAddress)
{
$f=file_get_contents("https://www.nic.ru/whois/?query=".$ipAddress);
$f=explode("country:&nbsp; &nbsp; &nbsp; &nbsp; ",$f);
$f=substr($f[1],0,2);
RETURN $f;
}
function send_mime_mail($name_from, // ��� �����������
                         $email_from, // email �����������
                         $email_to, // email ����������
                         $data_charset, // ��������� ���������� ������
                         $send_charset, // ��������� ������
                         $subject, // ���� ������
                         $body // ����� ������
                         ) {
   $to = $email_to;
   $subject = mime_header_encode($subject, $data_charset, $send_charset);
   $from =  mime_header_encode($name_from, $data_charset, $send_charset).' <' . $email_from . '>';
   if($data_charset != $send_charset) {
     $body = iconv($data_charset, $send_charset, $body);
   }
  
   $headers ="Content-type: text/html; charset=\"".$send_charset."\"\n";
   $headers .="From: $from\n";
   $headers.="Mime-Version: 1.0\n";

   return mail($to, $subject, $body, $headers);
}

function mime_header_encode($str, $data_charset, $send_charset) {
   if($data_charset != $send_charset) {
     $str = iconv($data_charset, $send_charset, $str);
   }
   return '=?' . $send_charset . '?B?' . base64_encode($str) . '?=';
}
function tuc($mensaje)
{
	if (ereg("^[a-zA-Z0-9\-_]{1,255}$", $mensaje))
	{
		return $mensaje;
	}else{
		$mensaje='';
		return $mensaje;
	}
}
function limitatexto( $texto, $limite )
  {
    if( strlen($texto)>$limite )
      {
        $texto = substr( $texto,0,$limite );
      }
    return $texto;

  }


function mostrarTemplate($tema, $variables)
{
    extract($variables);
    eval("?>".$tema."<?");
}

function parsearTags($mensaje)
{
    $mensaje = str_replace("[citar]", "<blockquote><hr width='100%' size='2'>", $mensaje);
    $mensaje = str_replace("[/citar]", "<hr width='100%' size='2'></blockquote>", $mensaje);
    return $mensaje;
}



function limpiar($mensaje)
{
$mensaje = htmlentities(stripslashes(trim($mensaje)));
$mensaje = str_replace("'"," ",$mensaje);
$mensaje = str_replace(";"," ",$mensaje);
$mensaje = str_replace("$"," ",$mensaje);
return $mensaje;
}
  function generate_password()
  {
    $arr = array('a','b','c','d','e','f',
                 'g','h','i','j','k','l',
                 'm','n','o','p','r','s',
                 't','u','v','x','y','z',
                 'A','B','C','D','E','F',
                 'G','H','I','J','K','L',
                 'M','N','O','P','R','S',
                 'T','U','V','X','Y','Z',
                 '1','2','3','4','5','6',
                 '7','8','9','0');
    // ���������� ������
    $pass = "";
    for($i = 0; $i < 9; $i++)
    {
      // ��������� ��������� ������ �������
      $index = rand(0, count($arr) - 1);
      $pass .= $arr[$index];
    }
    return $pass;
  }
function uc($mensaje)
{
   if (!ereg("^[a-zA-Z�-��-�0-9\-_]{1,255}$", $mensaje)) {
	$mensaje = htmlentities(stripslashes(strtolower(trim($mensaje))));
	$mensaje = str_replace("'"," ",$mensaje);
	$mensaje = str_replace(";"," ",$mensaje);
	$mensaje = str_replace("$"," ",$mensaje);
	return $mensaje;
   }else{ return $mensaje; }
}

function getRealIP()
{

   if( $_SERVER['HTTP_X_FORWARDED_FOR'] != '' )
   {
      $client_ip =
         ( !empty($_SERVER['REMOTE_ADDR']) ) ?
            $_SERVER['REMOTE_ADDR']
            :
            ( ( !empty($_ENV['REMOTE_ADDR']) ) ?
               $_ENV['REMOTE_ADDR']
               :
               "unknown" );
      $entries = split('[, ]', $_SERVER['HTTP_X_FORWARDED_FOR']);

      reset($entries);
      while (list(, $entry) = each($entries))
      {
         $entry = trim($entry);
         if ( preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $entry, $ip_list) )
         {
            // http://www.faqs.org/rfcs/rfc1918.html
            $private_ip = array(
                  '/^0\./',
                  '/^127\.0\.0\.1/',
                  '/^192\.168\..*/',
                  '/^172\.((1[6-9])|(2[0-9])|(3[0-1]))\..*/',
                  '/^10\..*/');

            $found_ip = preg_replace($private_ip, $client_ip, $ip_list[1]);

            if ($client_ip != $found_ip)
            {
               $client_ip = $found_ip;
               break;
            }
         }
      }
   }
   else
   {
      $client_ip =
         ( !empty($_SERVER['REMOTE_ADDR']) ) ?
            $_SERVER['REMOTE_ADDR']
            :
            ( ( !empty($_ENV['REMOTE_ADDR']) ) ?
               $_ENV['REMOTE_ADDR']
               :
               "unknown" );
   }

   return $client_ip;

}
?>

