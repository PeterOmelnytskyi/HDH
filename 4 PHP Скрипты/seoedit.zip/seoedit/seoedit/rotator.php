<?
	
	

	$sql="select * from tb_advban where paused=0 and modered=1";$allsqls++;
	$res=mysql_query($sql);
	$i=0;
while($row=mysql_fetch_array($res))
{
if(intval($row[balance]/$row[price])==0 or $row[balance]<$row[price]) mysql_query("UPDATE tb_advban SET paused=1,balance=0 WHERE id='$row[id]'");
	$i++;
	$id[$i]=$row[id];
	$banpic[$i]=$row[nametime];
	$banformat[$i]=$row[typeban];
}
if($i==0)
{
$banpict="banners/noban.png";
echo "<img src='/$banpict' width=468 height=60>";
}else{
	$newi=rand(1,$i);
	$i=$newi;
	$banpict="banners/
$banpic[$i].$banformat[$i]";
echo "<a href='/ban_url.php?link=$id[$i]' target='_blank'><img src='/$banpict' width=468 height=60></a>";
}
		?>