<? include('checkcookie.php'); ?>
<h3>������ ��������</h3>
<br>

<?
if (isset($_GET["id"]))
{

$id=$_GET["id"];
$option=$_GET["option"];
$plan=$_POST["plan"];
$urlsite=$_POST["urlsite"];
$urlpic=$_POST["urlpic"];
$title=$_POST["title"];
$wmid=$_POST["wmid"];
$t=time();
require("$root/sfbstat.php");
	$precio=$ban*$plan;
$precio=$ban88*$plan;

if ($option=="approve"){
//
$date=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$precio','$date')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
    $query = "INSERT INTO sfb_advban88 (urlsite,urlpic,begindate,numdays,wmid,title) VALUES('$urlsite','$urlpic','$t','$plan','$wmid','$title')";
    mysql_query($query) or die(mysql_error());

    $queryz = "DELETE FROM sfb_addban88 WHERE id='$id'";
    mysql_query($queryz) or die(mysql_error());

		$res=mysql_query("select * from tb_comp where param='8'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='0')
					{
						$res1=mysql_query("select username from tb_users where wmid='$wmid'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';}
					}else{
						$lidername=$wmid;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$plan;
							$purse='';
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse='';
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
						}
					}
				}
			}
		}

    echo "<font color=\"red\"><b>������ ��������.</b></font><br><br>";
}

if ($option=="deny"){

    $queryz = "DELETE FROM sfb_addban88 WHERE id='$id'";
    mysql_query($queryz) or die(mysql_error());

    echo "<font color=\"#cc0000\"><b>����� ������� ������.</b></font><br><br>";
}


}
?>

<table class="adn">
<tr class="lineb">
		<td>�</td>
		<td>WMID</td>
		<td>���� ������</td>
		<td>URL �����</td>
		<td>URL ��������</td>
		<td>�����</td>
		<td></td>
		<td></td>
	</tr>
<?
$tabla = mysql_query("SELECT * FROM sfb_addban88 ORDER BY id ASC");
while ($registro = mysql_fetch_array($tabla)) {

echo "
<tr class='liney ell'>
<td>". $registro["id"] ."</td>
<td>". $registro["wmid"] ."</td>
<td>". $registro["plan"] ."</td>
<td><a href=\"". $registro["urlsite"] ."\" target=\"_blank\">". $registro["urlsite"] ."</a></td>
<td><a href=\"". $registro["urlpic"] ."\" target=\"_blank\">". $registro["urlpic"] ."</a></td>
<td>". $registro["title"] ."</td>
<td>";
?>
<form method="post" action="adminmain.php?p=bannerreq88&id=<?= $registro["id"] ?>&option=approve">
<input type="hidden" name="plan" value="<?= $registro["plan"] ?>">
<input type="hidden" name="urlsite" value="<?= $registro["urlsite"] ?>">
<input type="hidden" name="urlpic" value="<?= $registro["urlpic"] ?>">
<input type="hidden" name="wmid" value="<?= $registro["wmid"] ?>">
<input type="hidden" name="title" value="<?= $registro["title"] ?>">
<input type="submit" value="��������" class="button">
</form>
</td><td>
<form method="post" action="adminmain.php?p=bannerreq88&id=<?= $registro["id"] ?>&option=deny">
<input type="submit" value="�������" class="button">
</form>
</td>
</tr>

<?

} 

?>
</table>