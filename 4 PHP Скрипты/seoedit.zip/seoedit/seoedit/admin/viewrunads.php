<?include('checkcookie.php'); ?>

<?
if(isset($_POST["action"]))
{
$ide=$_GET["id"];
$act=$_POST["action"];
if($act=='del')
{
mysql_query("DELETE FROM sfb_runblock WHERE id='$ide'") or die(mysql_error());
echo "<b>������ �������</b>";
}
}
?>
<?
$sql=mysql_query("SELECT * FROM sfb_runblock WHERE status='1'");
?>
<table class="adn">
<tr class="lineb">
<th align=center>URL</th>
<th align=center>�����</th>
<th align=center>���-�� ����</th>
<th></th>
</tr>
<?
while($res=mysql_fetch_array($sql))
{
?>
<tr class='liney ell'>
<td align=center><a href="<?=$res["url"] ?>" target="_blank"><?=$res["url"] ?></a></td>
<td align=center><?=$res["description"]; ?></td>
<td align=center><?=$res["plan"]; ?></td>
<td>
<form action="adminmain.php?p=viewrunads&id=<?=$res["id"] ?>" method="POST">
<input type="hidden" name="action" value="del">
<input type="submit" value="�������"></form></td>
</tr>
<?
}
?>