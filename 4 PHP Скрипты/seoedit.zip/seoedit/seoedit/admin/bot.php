<b>������</b>
<?
if (isset($_GET["id"]))
{
$option=$_GET["option"];
$id=$_GET["id"];
if ($option=="delete")
{

    //Todo parece correcto procedemos con la inserccion
    $queryz = "DELETE FROM tb_cheaters WHERE id='$id'";
    mysql_query($queryz) or die(mysql_error());

    echo "<br><font color=\"#cc0000\"><b>��������� � ���������� �������</b></font><br><br>";
}

}

?>

<table>
<tr>
<th>Id</th>
<th>�����</th>
<th>IP</th>
<th>����</th>
<th></th>
</tr>
<?

$tabla = mysql_query("SELECT * FROM tb_cheaters ORDER BY id ASC"); // selecciono todos los registros de la tabla usuarios, ordenado por nombre

while ($registro = mysql_fetch_array($tabla)) { // comienza un bucle que leera todos los registros y ejecutara las ordenes que siguen

echo "
<tr>
<td>". $registro["id"] ."</td>
<td>". $registro["username"] ."</td>
<td>". $registro["ip"] ."</td>
<td>". $registro["date"]."</td>
<td>";
?>

<form method="post" action="adminmain.php?p=bot&id=<?= $registro["id"] ?>&option=delete">
<input type="submit" value="�������" class="button">
</form>
</td>
<tr>

<?

} // fin del bucle de ordenes

?>
</table>
