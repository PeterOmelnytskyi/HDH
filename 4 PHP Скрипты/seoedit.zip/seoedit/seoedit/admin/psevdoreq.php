<? include('checkcookie.php'); ?>
<h3>������ ������������������ ������</h3>
<br>

<?
if (isset($_GET["id"]))
{
	$id=$_GET["id"];
	$option=$_GET["option"];
	$urlsite=$_POST["urlsite"];
	$description=$_POST["description"];
	$wmid=$_POST["wmid"];
	$plan=$_POST["plan"];
	$t=time();
///������ � ��.�����
require("$root/sfbstat.php");
	if ($plan=="1") { $price=$psevdoweek1; }
	if ($plan=="2") { $price=$psevdoweek2; }
	if ($plan=="3") { $price=$psevdoweek3; }
	if ($plan=="4") { $price=$psevdoweek4; }	
	$precio=$price;
	if ($option=="approve")
	{
	$date=time();
		$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$precio','$date')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
		$query = "INSERT INTO tb_psevdolinks (url,description,wmid,begindate,numdays) VALUES('$urlsite','$description','$wmid','$t','$plan')";
		mysql_query($query) or die(mysql_error());

		$queryz = "DELETE FROM tb_psevdoreq WHERE id='$id'";
		mysql_query($queryz) or die(mysql_error());


		echo "<font color=\"red\"><b>������������������ ������ ���������.</b></font><br><br>";
	}

	if ($option=="deny")
	{
		$queryz = "DELETE FROM tb_psevdoreq WHERE id='$id'";
		mysql_query($queryz) or die(mysql_error());

		echo "<font color=\"#ff0000\"><b>����� ������ ������.</b></font><br><br>";
	}
}
?>

<table>
	<tr class="lineb">
		<td>�</td>
		<td>WMID</td>
		<td>URL �����</td>
		<td>����� ������</td>
		<td>�����</td>
		<td></td>
		<td></td>
	</tr>
<?
$tabla = mysql_query("SELECT * FROM tb_psevdoreq ORDER BY id ASC");
while ($registro = mysql_fetch_array($tabla)) {

echo "
<tr class='liney ell'>
<td>". $registro["id"] ."</td>
<td>". $registro["wmid"] ."</td>
<td><a href=\"". $registro["url"] ."\" target=\"_blank\">". $registro["url"] ."</a></td>
<td>". $registro["description"] ."</td>
<td>". $registro["plan"] ."</td>";
echo "<td>";
?>
<form method="post" action="adminmain.php?p=psevdoreq&id=<?= $registro["id"] ?>&option=approve">
<input type="hidden" name="urlsite" value="<?= $registro["url"] ?>">
<input type="hidden" name="description" value="<?= $registro["description"] ?>">
<input type="hidden" name="wmid" value="<?= $registro["wmid"] ?>">
<input type="hidden" name="plan" value="<?= $registro["plan"] ?>">
<input type="submit" value="��������" class="button">
</form>
</td><td>
<form method="post" action="adminmain.php?p=psevdoreq&id=<?= $registro["id"] ?>&option=deny">
<input type="submit" value="�������" class="button">
</form>
</td>
</tr>

<?

} 

?>
</table>