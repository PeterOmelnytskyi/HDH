<? include('checkcookie.php'); ?>
<h3>�������� ��������. ������ ������� ������������ ������</h3>
<br>
<?
	function fuckquot($newstext)
	{
	$newstext=str_replace("'","&quot;",$newstext);
	$newstext=str_replace('"',"&quot;",$newstext);
	RETURN $newstext;
	}
	?>
<?
if(isset($_POST["id"]))
{
	$id=$_POST["id"];
	$data=$_POST["data"];
	$newstext=fuckquot($_POST["newstext"]);
	$tema=fuckquot($_POST["tema"]);


	mysql_query("UPDATE tb_news SET data='$data', tema='$tema', newstext='$newstext' where id='$id'");

	echo "<font color=\"green\"><b>������.</b></font><br><br>";
}

if(isset($_GET["id"]))
{
	$id=$_GET["id"];
	if ($_GET["option"]=="edit")
	{
		$tablae = mysql_query("SELECT * FROM tb_news where id='$id'"); 
		while ($registroe = mysql_fetch_array($tablae))
		{ 
			?>
			         <script>   function appendtag(text1, text2)
            {
                if ((document.selection))
                {
                    document.surforder.newstext.focus();
                    document.surforder.document.selection.createRange().text = text1+document.surforder.document.selection.createRange().text+text2;
                } else if(document.surforder.newstext.selectionStart != undefined) {
                    var element    = document.surforder.newstext;
                    var str     = element.value;
                    var start    = element.selectionStart;
                    var length    = element.selectionEnd - element.selectionStart;
                    element.value = str.substr(0, start) + text1 + str.substr(start, length) + text2 + str.substr(start + length);
                } else document.surforder.newstext.value += text1+text2;
            }</script>
			<style>
			.knopka {
			background: #ccc;
			border: 1px solid black;
			padding: 5px;
			}
			.knopka:hover{
			background: #fff;
			border: 1px solid blue;
				padding: 5px;
			}
			</style>
<table class='adn'>
<tr class='lineb'>
<td align=center>��������</td>
<td align="left"><table class="adn"><tr><td align="left" style="border: none; padding: 0">��������</td><td align="right" style="border: none; padding: 0"><a href="#" onclick="document.getElementById('MainForm').submit(); return false" class="liv">���������</a></td></tr></table></td>
</tr><tr class='liney ell'><td align=left>
<form action="adminmain.php?p=newsview" id='MainForm' method="POST" name='surforder'>
<input type='hidden' name='id' value='<?=$registroe[id]; ?>'>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  type="text" value='<?=$registroe[tema]; ?>' name="tema"></td><td algin=left>���� �������</td></tr>
<tr class='liney ell'><td align=left>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="data" value='<?=$registroe[data]; ?>' ></td><td algin=left>���� �������</td></tr>

<tr class='liney ell'>
<td align=left>
<textarea rows="9" cols="70" name="newstext"><?=$registroe[newstext]; ?></textarea>
<div style='float:left'>
<span class='knopka' onClick="javascript:appendtag('[url]','[/url]'); return false;">[URL]</span><br><br><br>
<span class='knopka' onClick="javascript:appendtag('[b]','[/b]'); return false;"><b>[B]</b></span><br><br><br>
<span class='knopka' onClick="javascript:appendtag('[u]','[/u]'); return false;"><u>[U]</u></span><br><br><br>
<span class='knopka' onClick="javascript:appendtag('[i]','[/i]'); return false;"><i>[I]</i></span><br>
</div>

</td><td align=left>����� �������</td>
</tr>
</table>

<br>* - ��������� �� ����:<br>
[url],[b],[u],[i],[s],[img],[color=],[size=],[h1],[h2]-[h6]

** � SeoEdit �� ����������� ���� [h1]-[h6] - �������� ������� ���...

</form>

			<?
		}
		exit;
	}
	if ($_GET["option"]=="delete")
	{
		$id=$_GET["id"];
		mysql_query("DELETE FROM tb_news WHERE id='$id'");

		echo "<font color=\"#cc0000\"><b>������� �������.</b></font><br><br>";
	}
}
?>

<br>
<table class="adn">
<tr class="lineb">
		<td width="50">�</td>
		<td>���� ��������� �������</td>
		<td>����� �������</td>
		<td></td>
		<td></td>
	</tr>
	<?

	$sql="SELECT * FROM tb_news order by id desc";

	$tabla = mysql_query($sql); 
	while ($registro = mysql_fetch_array($tabla))
	{
		?>
		<tr class='liney ell'>
			<td align=center><?=$registro["id"] ?></td>
			<td align=center><?=$registro["data"] ?></td>
			<td><?=$registro["newstext"] ?></td>
			<td align=center>
				<form method="post" action="adminmain.php?p=newsview&id=<?= $registro["id"] ?>&option=edit">
				<input type="submit" value="�������������" class="button">
				</form>
			</td>
			<td align=center>
				<form method="post" action="adminmain.php?p=newsview&id=<?= $registro["id"] ?>&option=delete">
				<input type="submit" value="�������" class="button">
				</form>
			</td>
		</tr>
		<?
	} 
	?>
</table>