<?
$bd_host = "localhost"; 
$bd_user = "bux"; // ����
$bd_password = "bux";  // ����
$bd_base = "bux"; // ��
$url = $_SERVER[HTTP_HOST];
$con = mysql_connect($bd_host, $bd_user, $bd_password); 
mysql_select_db($bd_base, $con); $mysql_queries++; 
mysql_query("set names cp1251"); 
?>