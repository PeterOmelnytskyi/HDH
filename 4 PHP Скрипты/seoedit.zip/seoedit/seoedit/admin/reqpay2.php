<? include('checkcookie.php'); ?>
<h3>������� �� �������</h3>
<br>

<?

if (isset($_POST["paid"]))
{
foreach ($_REQUEST['usr'] as $usr=>$value)
{
$usr=$value;
$tablae = mysql_query("SELECT * FROM tb_users where username='$usr'"); 
$res=mysql_fetch_array(mysql_query("SELECT money,id FROM tb_payme WHERE username='$usr' ORDER BY id ASC"));
$money=$res["money"];
$id=$res["id"];
$registroe = mysql_fetch_array($tablae);
$eltiempo=time();
$lafecha=date("d-m-Y",$eltiempo);

    $query = "INSERT INTO tb_history (user, date, amount, method, status) VALUES('$usr','$lafecha','$money','WebMoney','������� �������')";
    mysql_query($query) or die(mysql_error());

    $queryz = "DELETE FROM tb_payme WHERE id='$id'";
    mysql_query($queryz) or die(mysql_error());
}
echo "<font color=\"red\"><b>������</b></font><br><br>";

}


?>

����� ������ �������� ��������.
<br><br>
<form action="" method="post" name="paidform">
<script type="text/javascript">
function checkAll(oForm, cbName, checked)
{
for (var i=0; i < oForm[cbName].length; i++) oForm[cbName][i].checked = checked;
}
</script>

<table class="adn">
<tr class="lineb">
<td width=25 align=center>
<input type="checkbox" onClick="checkAll(this.form,'usr[]',this.checked)" name="usr">
</td>
<td width=50 align=center>�</td>
<td width=200 align=center>���</td>
<td align=center>WMR</td>
<td width=100 align=center>����� ������</td>
<td align=center>Ip</td>
<td></td>
</tr>

<?
$res=mysql_query("select sitename, comment from tb_site where id='1'");
$res=mysql_fetch_array($res);
$sitename=$res["sitename"];
$comment=$res["comment"];
$comment=str_ireplace(":sitename:",$sitename,$comment);

$tabla = mysql_query("SELECT * FROM tb_payme ORDER BY id ASC"); 
while ($registro = mysql_fetch_array($tabla)) { 

echo "
<tr class='liney ell'>
<td width=25 align=center><input type=\"checkbox\" value=\"". $registro["username"] ."\" name=\"usr[]\"></td>
<td width=50 align=center>". $registro["id"] ."</td>
<td width=200 align=center>". $registro["username"] ."</td>
<td align=center>". $registro["pemail"] ."</td>
<td width=100 align=center>". $registro["money"] ."</td>
<td align=center>". $registro["ip"] ."</td>";
$text=str_ireplace(":username:",$registro["username"],$comment);
?>
<td><a href='wmk:payto?Purse=<?= $registro["pemail"] ?>&Amount=<?= $registro["money"] ?>&Desc=<?=$text ?>&BringToFront=Y'><button>&nbsp&nbsp&nbsp&nbsp�������� �����&nbsp&nbsp&nbsp&nbsp</button></td>
</tr>

<?

}

?>
</table><center><input type="submit" value="�������� �����������" name="paid"></center></form>
