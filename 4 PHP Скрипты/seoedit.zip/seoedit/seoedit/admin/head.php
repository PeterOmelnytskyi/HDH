<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html class="admin">
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-1251">
<link rel="stylesheet" href="design/admin/images/style.css" type="text/css">
<link rel="icon" href="design/admin/images/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="design/admin/images/favicon.ico" type="image/x-icon">
<title>�����������������</title>
<script type="text/javascript" src="design/admin/images/admin.js"></script>

<!--[if lte IE 6]>
<style type="text/css">
body {behavior:url("design/admin/images/csshover.htc");}
label{
   // display:inline-block;
}
</style>
<![endif]-->

</head>
<body class="ibody">
<table class="adn">
    <tr>
      <td colspan="2">
        <table class="adn">
          <tr>
            <td class="head"><img src="design/admin/images/sep.gif" alt=""></td>
            <td class="head toph">&nbsp;&nbsp;�� ����� ���: <b><?=$_SESSION["username"];?></b></td>
            <td class="head"><img src="design/admin/images/sep2.gif" alt=""></td>
            <td class="head last toph" width="100%"><a href="adminmain.php?p=reqpay">���� �������: <b><?require('config.php');
$waitpay = "SELECT count( * ) FROM `tb_payme`";
$waitpay = mysql_query($waitpay);
$waitpay=mysql_result($waitpay,0,0);
echo $waitpay; ?></b></a></td>
            <td class="head">
              <table class="adw">
                <tr>
				  <td class="head last toph"><a href="adminmain.php?p=updates">����������</a></td>
                  <td class="head"><img src="design/admin/images/sep2.gif" alt=""></td>
                  <td class="head last toph"><a href="http://shopforbux.ru">���� ������</a></td>
                  <td class="head"><img src="design/admin/images/sep2.gif" alt=""></td>
                  <td class="head last toph2 toph"><a href="http://<?=$_SERVER["HTTP_HOST"]; ?>">�����</a></td>
                </tr>
              </table>
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr>
      <td class="indexb1"> <table class="adn"><tr><td class="se"></td></tr></table>
<table width="186" class="adw" style="margin: auto;"><?include('left.php');?>