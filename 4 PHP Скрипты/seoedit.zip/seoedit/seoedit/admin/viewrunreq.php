<? include('checkcookie.php'); ?>
<h3>������ ������� ������� � ������� ������</h3>

<?if(isset($_POST["action"]))
{
$id=$_GET["id"];
$action=$_POST["action"];

if($action=='delete')
{
	mysql_query("DELETE FROM sfb_runblock WHERE id='$id'");
	echo "<font color=red>����� �����</font>";
}
if($action=='add')
{
$t=time();
$plan=$_POST["plan"];
$endtime=$t+24*3600*$plan;
require("$root/sfbstat.php");
$precio=$runblock*$plan;
$wmid=$_POST["wmid"];
$date=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$precio','$date')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
	mysql_query("UPDATE sfb_runblock SET status='1',endtime='$endtime' WHERE id='$id'");
	echo "<font color=green>������ ���������</font>";
}
}

$sql=mysql_query("SELECT * FROM sfb_runblock WHERE status='0'");
?>

<table class="adn">
<tr class="lineb">
<th align=center>WMID</th>
<th align=center>URL</th>
<th align=center>�����</th>
<th align=center>���-�� ����</th>
<th></th>
<th></th>
</tr>
<?

while($res=mysql_fetch_array($sql))
{
	?>
<tr class='liney ell'>
<td align=center><?=$res["wmid"]; ?></td>
<td align=center><?=$res["url"]; ?></td>
<td align=center><?=$res["description"]; ?></td>
<td align=center><?=$res["plan"] ?></td>
<td align=center>
<form action="adminmain.php?p=viewrunreq&id=<?=$res["id"] ?>" method="POST">
<input type="hidden" name="action" value="add">
<input type="hidden" name="plan" value="<?=$res["plan"] ?>">
<input type="submit" value="��������"></form></td>
<td align=center>
<form action="adminmain.php?p=viewrunreq&id=<?=$res["id"] ?>" method="POST">
<input type="hidden" name="action" value="delete">
<input type="hidden" name="wmid" value="<?=$res["wmid"]; ?>">
<input type="submit" value="�������"></form></td>
</tr>
<?
}
?>