<? include('checkcookie.php'); ?>
<h3>������ ��������</h3>
<br>

<?
$sql="select price from tb_config where item='ban1'";
$res=mysql_query($sql);
$ban1=mysql_result($res,0,0);
$sql="select price from tb_config where item='ban2'";
$res=mysql_query($sql);
$ban2=mysql_result($res,0,0);
$sql="select price from tb_config where item='ban3'";
$res=mysql_query($sql);
$ban3=mysql_result($res,0,0);
$sql="select price from tb_config where item='ban4'";
$res=mysql_query($sql);
$ban4=mysql_result($res,0,0);
$sql="select price from tb_config where item='ban5'";
$res=mysql_query($sql);
$ban5=mysql_result($res,0,0);
$sql="select price from tb_config where item='banl'";
$res=mysql_query($sql);
$banl=mysql_result($res,0,0);
if (isset($_GET["id"]))
{

$id=$_GET["id"];
$opop=mysql_fetch_array(mysql_query("SELECT * FROM sfb_rot100 WHERE id='$id'"));
$wmid=$opop["wmid"];
$plan=$opop["plan"];

$option=$_GET["option"];
$stat=$_GET["status"];
$t=time();
if($option=='add')
{
	if($stat=='waitl') { $status='l'; $ban=$banl; }
	if($stat=='wait1') { $status='1'; $ban=$ban1; }
	if($stat=='wait2') { $status='2'; $ban=$ban2; }
	if($stat=='wait3') { $status='3'; $ban=$ban3; }
	if($stat=='wait4') { $status='4'; $ban=$ban4; }
	if($stat=='wait5') { $status='5'; $ban=$ban5; }
	$precio=$ban*$plan;$date=time();
mysql_query("UPDATE sfb_rot100 SET status='$status', begindate='$t' WHERE id='$id'");
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$precio','$date')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
   echo "<font color=\"red\"><b>������ ��������.</b></font><br><br>";
}

if ($option=="del"){

    $queryz = "DELETE FROM sfb_rot100 WHERE id='$id'";
    mysql_query($queryz) or die(mysql_error());

    echo "<font color=\"#cc0000\"><b>����� ������� ������.</b></font><br><br>";
}


}
?>

<table class="adn">
<tr class="lineb">
		<td>�</td>
		<td>WMID</td>
		<td>���� ������</td>
<td>����� ��� ���������</td>
		<td>URL �����</td>
		<td>URL ��������</td>
<td>�����������������</td>
		<td></td>
		<td></td>
	</tr>
<?
$tabla = mysql_query("SELECT * FROM sfb_rot100 WHERE status!='l' AND status!='1' AND status!='2' AND status!='3' AND status!='4' AND status!='5' ORDER BY id ASC");
while ($registro = mysql_fetch_array($tabla)) {
$mm=$registro["status"];
if($mm=='waitl') $mesto="� ����� ����";
if($mm=='wait1') $mesto="������ 1";
if($mm=='wait2') $mesto="������ 2";
if($mm=='wait3') $mesto="������ 3";
if($mm=='wait4') $mesto="������ 4";
if($mm=='wait5') $mesto="������ 5";
echo "
<tr class='liney ell'>
<td>". $registro["id"] ."</td>
<td>". $registro["wmid"] ."</td>
<td>". $registro["plan"] ."</td>
<td>". $registro["alt"] ."</td>
<td><a href=\"". $registro["url"] ."\" target=\"_blank\">". $registro["url"] ."</a></td>
<td><a href=\"". $registro["image"] ."\" target=\"_blank\">". $registro["image"] ."</a></td>
<td>$mesto</td>
<td>";
?>
<form method="post" action="adminmain.php?p=bannerreq100&id=<?= $registro["id"] ?>&option=add&status=<?=$registro["status"] ?>">
<input type="submit" value="��������" class="button">
</form>
</td><td>
<form method="post" action="adminmain.php?p=bannerreq100&id=<?= $registro["id"] ?>&option=del">
<input type="submit" value="�������" class="button">
</form>
</td>
</tr>

<?

} 

?>
</table>