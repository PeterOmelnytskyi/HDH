<? include('checkcookie.php'); ?>
<?
	$d=time();
	$d=$d-3600*24*3;
	
	$sql="select * from tb_users";
	$res=mysql_query($sql);
	
	while ($act=mysql_fetch_assoc($res))
	{
		$t=strtotime($act["lastlogdate"]);
		if ($t>$d) $kol++;
	}
	
	$sql="select * from tb_users";
	$res=mysql_query($sql);
	
	$vsego=mysql_num_rows($res);

	echo $kol;
	echo "<br>("; 
	echo round($kol/$vsego*100, 2);
	echo "%)";
?>