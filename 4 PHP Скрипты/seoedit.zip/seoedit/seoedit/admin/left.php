<td class="head2">
                                       <table class="adn">
                                           <tr>
                                               <td class="head4" onclick="menuresetit('menu1');">������������</td>
                                               <td align="right" class="head7"><img src="design/admin/images/004.gif" alt="" onclick="menuresetit('menu1')" id="menu12" style="cursor: pointer;"></td>
                                           </tr>
                                       </table>
                                   </td>
                               </tr>
                               <tr id='menu13' style="display: none">
<td>
<div class="dvmenu">
<table class="adn"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=reqpay">������ �������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=userlist">������ �������������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=refbirj">�����(�������) ���������</a></td></tr></table>
</div></td>
                               </tr>
                         
                               <tr>
                                   <td class="se"></td>
                               </tr>
                               <tr>
                                   <td class="head2">
                                       <table class="adn">
                                           <tr>
                                               <td class="head4" onclick="menuresetit('menu3');">���������</td>
                                               <td align="right" class="head7"><img src="design/admin/images/004.gif" alt="" onclick="menuresetit('menu3')" id="menu32" style="cursor: pointer;"></td>
                                           </tr>
                                       </table>
                                   </td>
                               </tr>
                               <tr id='menu33' style="display: none">
<td>
<div class="dvmenu">
<table class="adn"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=basecfg">��������� �����</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=usercfg">��������� ��� (USERS)</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=reklcfg">��������� ��� (ADV-S)</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=psevdolinks">��������� ������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=blacklist">׸���� ������</a></td></tr></table>
</div></td>
                               </tr>
                             <tr>
                                   <td class="se"></td>
                               </tr>          <tr>
                                   <td class="head2">
                                       <table class="adn">
                                           <tr>
                                               <td class="head4" onclick="menuresetit('menu4');">�������</td>
                                               <td align="right" class="head7"><img src="design/admin/images/004.gif" alt="" onclick="menuresetit('menu4')" id="menu42" style="cursor: pointer;"></td>
                                           </tr>
                                       </table>
                                   </td>
                               </tr>
                               <tr id='menu43' style="display: none">
<td>
<div class="dvmenu">
<table class="adn"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=newsadd">���������� �������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=newsview">�������������� ��������</a></td></tr></table>
</div></td>
                               </tr>
                             <tr>
                                   <td class="se"></td>
                               </tr>  <tr>
                                       <td class="head2">
                                           <table class="adn">
                                               <tr>
                                                   <td class="head4" onclick="menuresetit('menu6');">��������� ���������� ������</td>
                                               <td align="right" class="head7"><img src="design/admin/images/004.gif" alt="" onclick="menuresetit('menu6')" id="menu62" style="cursor: pointer;"></td>
                                               </tr>
                                           </table>
                                       </td>
                                   </tr>
                                   <tr id='menu63' style="display: none">
<td>
<div class="dvmenu">
<table class="adn"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=viewreklreq">������������ ������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=bannerreq">������� � ��������(468�60)</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=statlinkreq">����������� ������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=mailsreq">����.������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=taskreq">�������</a></td></tr></table>
<table class="adn topj"><tr><td><img src="design/admin/images/drs.gif" alt=""></td><td width="100%"><a href="adminmain.php?p=cartreq">�������</a></td></tr></table>
</div></td>
                                   </tr>
				<tr>
                                   <td class="se"></td>
                               </tr>
                               
                               </table><SCRIPT type="text/javascript">
megamenu();
</SCRIPT>
</td>
      <td valign="top"><table class="adn">
  <tr>
    <td class="zeb2 nbc">
      <table class="adn ggg">
         <tr>
           <td>
            <table class="adn">
              <tr>
               <td class="nbc2"><span class="titlecol">MFS SeoEdit &copy; 2011.Powered by <a href="http://shopforbux.ru/user/Alex/" target="_blank">Alex</a><div align="right">������� ������ �� ���� ������ <u>�����������</u>!!!������� ������� ����� ����!</div></span></td>
              </tr>
              <tr>
               <td class="nbcl"></td>
              </tr>
            </table>
           </td>
         </tr>
      </table>
    </td>
  </tr>
  <tr><td valign="top" align="left" class="zeb">