<? include('checkcookie.php'); ?>
<h3>������ ���������</h3>
<br>

<?
if ($_GET["option"]=="success")
{
	$refcount=$_POST["refcount"];
	$user=$_POST["username"];
	$id=$_POST["id"];

	$sql="select * from tb_users where referer='' and user_status='user'  and username!='$user' order by visits desc";
	$res=mysql_query($sql);
	for($i=1;$i<=$refcount;$i++)
	{
		$row=mysql_fetch_array($res);
		$idref=$row["id"];
		$sql="update tb_users set referer='$user', buying='1' where id='$idref'";
		mysql_query($sql);
	}
	$sql="select * from tb_users where username='$user'";
	$res=mysql_query($sql);
	$row=mysql_fetch_array($res);
	
	$refs=$row["referals"]+$refcount;

	$sql="update tb_users set referals='$refs' where username='$user'";
	mysql_query($sql);

	$sql="delete from tb_refreq where id='$id'";
	mysql_query($sql);

		$res=mysql_query("select * from tb_comp where param='1'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='1')
					{
						$res1=mysql_query("select wmid from tb_users where username='$user'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["wmid"];}else{$lidername='';}
					}else{
						$lidername=$user;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$refcount;
							$purse='';
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse='';
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$refcount','$purse')");
						}
					}
				}
			}
		}

	echo "������";
}

if ($_GET["option"]=="cancel")
{
	$id=$_POST["id"];	

	$sql="delete from tb_refreq where id='$id'";
	mysql_query($sql);

	echo "�������";
}
?>

<table>
<tr>
<th>������������</th>
<th>���������� �����</th>
<th></th><th></th>
</tr>
<?
$sql="select * from tb_refreq order by id";
$res=mysql_query($sql);

if (mysql_num_rows($res)>0)
{
	while ($row=mysql_fetch_assoc($res))
	{
		?><tr><td><?
		echo $row["referer"]; 
		?></td><td><?
		echo $row["refcount"];
		?></td>
		<td>
		<form method="post" action="adminmain.php?p=reqref&option=success">
		<input type="hidden" name="username" value="<?= $row["referer"] ?>">
		<input type="hidden" name="refcount" value="<?= $row["refcount"] ?>">
		<input type="hidden" name="id" value="<?= $row["id"] ?>">
		<input type="submit" value="�����������" class="button">
		</form>
		</td>
		<td>
		<form method="post" action="adminmain.php?p=reqref&option=cancel">
		<input type="hidden" name="id" value="<?= $row["id"] ?>">
		<input type="submit" value="�������" class="button">
		</form>
		</td>
		</tr>
		<?
	}
}
?>
</table>