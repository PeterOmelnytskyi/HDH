<? include('checkcookie.php'); ?>
<h3>������ ������� �� ������</h3>
<br>

<?
if (isset($_GET["id"]))
{

$id=$_GET["id"];
$option=$_GET["option"];
$wmid=$_POST["wmid"];
$plan=$_POST["plan"];
$linksite=$_POST["linksite"];
$text=$_POST["text"];
$email=$_POST["email"];
$t=time();
$t=$t+$plan*24*3600;
require("$root/sfbstat.php");
	$precio=$wmframeads*$plan;

if ($option=="approve")
{
//
$date=time();
	$nums=mysql_num_rows(mysql_query("SELECT * FROM sfb_advs WHERE wmid='$wmid'"));
	if($nums==0) mysql_query("INSERT INTO sfb_advs (wmid,summ,data) VALUES ('$wmid','$precio','$date')");
	if($nums==1) mysql_query("UPDATE sfb_advs SET data='$date',summ=summ+'$precio' WHERE wmid='$wmid'");
	$query = "INSERT INTO tb_frameads (wmid,email,link,text,enddate) VALUES('$wmid','$email','$linksite','$text','$t')";
	mysql_query($query) or die(mysql_error());

	$queryz = "DELETE FROM tb_frameadsreq WHERE id='$id'";
	mysql_query($queryz) or die(mysql_error());

		$res=mysql_query("select * from tb_comp where param='9'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='0')
					{
						$res1=mysql_query("select username from tb_users where wmid='$wmid'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["username"];}else{$lidername='';}
					}else{
						$lidername=$wmid;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$plan;
							$purse='';
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse='';
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$plan','$purse')");
						}
					}
				}
			}
		}

	echo "<font color=\"red\"><b>������� �� ������ ���������.</b></font><br><br>";
}

if ($option=="deny")
{
	$queryz = "DELETE FROM tb_frameadsreq WHERE id='$id'";
	mysql_query($queryz) or die(mysql_error());

	echo "<font color=\"#cc0000\"><b>����� ������� �� ������ ������.</b></font><br><br>";
}

}
?>
<table class="adn">
<tr class="lineb">
		<td width="50">�</td>
		<td>WMID</td>
		<td>E-Mail</td>
		<td>URL</td>
		<td>����� ������</td>
		<td width="50">���� ��� ������</td>
		<td></td>
		<td></td>
	</tr>
<?
$tabla = mysql_query("SELECT * FROM tb_frameadsreq ORDER BY id ASC");
while ($registro = mysql_fetch_array($tabla)) {

echo "
<tr class='liney ell'>
<td align=center>". $registro["id"] ."</td>
<td align=center>". $registro["wmid"] ."</td>
<td align=center>". $registro["email"] ."</td>
<td align=center><a href=\"". $registro["link"] ."\" target=\"_blank\">". $registro["link"] ."</a></td>
<td>". $registro["text"] ."</td>
<td align=center>". $registro["plan"] ."</td>
<td align=center>";
?>
<form method="post" action="adminmain.php?p=frameadsreq&id=<?= $registro["id"] ?>&option=approve">
<input type="hidden" name="plan" value="<?= $registro["plan"] ?>">
<input type="hidden" name="linksite" value="<?= $registro["link"] ?>">
<input type="hidden" name="text" value="<?= $registro["text"] ?>">
<input type="hidden" name="wmid" value="<?= $registro["wmid"] ?>">
<input type="hidden" name="email" value="<?= $registro["email"] ?>">
<input type="submit" value="��������" class="button">
</form>
</td><td align=center>
<form method="post" action="adminmain.php?p=frameadsreq&id=<?= $registro["id"] ?>&option=deny">
<input type="submit" value="�������" class="button">
</form>
</td>
</tr>

<?

} 

?>
</table>