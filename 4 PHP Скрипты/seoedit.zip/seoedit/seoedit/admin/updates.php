<? include('checkcookie.php');
// ��������� ������ � �������
if(isset($_GET[ok]))
{
	$ok=intval($_GET[ok]);
	mysql_query("UPDATE tb_config SET price='$ok' WHERE item='lastupdate'") or die(mysql_error());
}
function parse_rss($reg_exp, $xml_data) {
preg_match_all($reg_exp, $xml_data, $temp);
return array(
'count'=>count($temp[0]),
'title'=>$temp[1],
'link'=>$temp[2],
'desc'=>$temp[3]
);
}
function output_rss($pattern, $rss_data) {
if($rss_data['count'] >= 10){ $count=10; } else { $count=$rss_data['count']; }
for($i=0; $i<$count; $i++) {
print '
<tr class="liney ell">
<td align=center>'.date("d.m - H:i", $rss_data['title'][$i]).'</td>
<td align=left>'.$rss_data['desc'][$i].'</td><td align=center>
<a href="'.$rss_data['link'][$i].'" target="_blank"><img src="download.png" title="������� ����������"></a> <a href="adminmain.php?p=updates&ok='.$rss_data['title'][$i].'"><img src="http://'.$_SERVER[HTTP_HOST].'/mfs/ok.png"></a>
</td></tr>
';
}
return $temp;
}
$context = stream_context_create(
array(
'http'=>array(
'header' => "User-Agent: Opera/9.62 (Windows NT 5.1; U; ru) Presto/2.1.1\r\n".
"Referer: $_SERVER[HTTP_HOST]\r\n".
"Content-type: application/x-www-form-urlencoded\r\n".
"Expires: Thu, 01 Jan 1970 00:00:01 GMT\r\n".
"Cache-Control: no-store, no-cache, must-revalidate\r\n".
"Pragma: no-cache\r\n".
"Connection: Close\r\n\r\n"
)));

//������...

$sql=mysql_query("SELECT price FROM tb_config WHERE item='lastupdate'") or die(mysql_error());
$upd=mysql_fetch_assoc($sql);
$upd=$upd[price];
if($upd=='' OR $upd==0) $upd=1;

$key=mysql_fetch_array(mysql_query("SELECT * FROM tb_site WHERE id='1'"));
$mykey=$key[seoeditkey];
$urlxml = 'http://update.shopforbux.ru/get_update.php?lastupdate='.$upd.'&key='.$mykey;

$reg_exp = '#<item>.*?<title>(.*?)</title>.*?';
$reg_exp .='<link>(.*?)</link>.*?<description>';
$reg_exp .='(.*?)</description>.*?</item>#si';
$pattern = '<a href="%s">%s</a>< br>%s<hr>';

?><table class='adn' width=100%>
<tr class='lineb'>
<td width=70>�����</td>
<td align=center>��������</td>
<td align=center>��������</td>
</tr>
<?
if($xml_data = file_get_contents($urlxml,false,$context)){
$rss_data = parse_rss($reg_exp, $xml_data);
echo output_rss($pattern, $rss_data);
}
?>
</table>
��������� ����������: <?=date("d.m.y - H:i", mysql_result(mysql_query("SELECT price FROM tb_config WHERE item='lastupdate'"),0,0)); ?>
