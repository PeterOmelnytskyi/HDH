<? include('checkcookie.php'); ?>
<h3>������� �� �������</h3>
<br>

<?

if(isset($_POST["user"])) 
{ 
$useru=$_POST["user"]; 
$money=$_POST["money"]; 
$delwaitid=$_POST["id"]; 
mysql_query("UPDATE tb_users SET money=money+'$money' WHERE id='$useru'"); 
mysql_query("DELETE FROM tb_payme WHERE id='$delwaitid'"); 
echo "<b><font color=green>�������� ���������� � ������� ������������ $useru</font></b>"; 
}
if (isset($_GET["id"]))
{

$id=$_GET["id"];
$option=$_GET["option"];

if ($option=="paid")
{

$usr=$_POST["usr"];

$tablae = mysql_query("SELECT * FROM tb_users where id='$usr'"); 
$registroe = mysql_fetch_array($tablae);

$money=$_POST["money"];

$paid=$registroe["paid"];
$paid=$paid+$money;

    $query = "UPDATE tb_users SET paid='$paid' where id='$usr'";
    mysql_query($query) or die(mysql_error());							$nowtime=time();
			mysql_query("InSERT InTO tb_allhistory (idus,data,doing,title) values ('$registroe[id]','$nowtime','5','������� WebMoney')"); 

$eltiempo=time();
$lafecha=date("d-m-Y",$eltiempo);

    $query = "INSERT INTO tb_history (user, date, amount, method, status) VALUES('$usr','$lafecha','$money','WebMoney','������� �������')";
    mysql_query($query) or die(mysql_error());

    $queryz = "DELETE FROM tb_payme WHERE id='$id'";
    mysql_query($queryz) or die(mysql_error());

echo "<font color=\"red\"><b>������</b></font><br><br>";

}

if ($option=="del")
{
	$queryz = "DELETE FROM tb_payme WHERE id='$id'";
    	mysql_query($queryz) or die(mysql_error());

	echo "<font color=\"red\"><b>�������</b></font><br><br>";
}

}

?>

����� ������ �������� ��������.
<br><br>
<table class="adn">
<tr class="lineb">
<td width=50 align=center>�</td>
<td width=200 align=center>���</td>
<td align=center>WMR</td>
<td width=100 align=center>����� ������</td>
<td align=center>Ip</td>
<td></td>
<td></td>
<td></td>
<td></td>
</tr>

<?
$res=mysql_query("select sitename, comment from tb_site where id='1'");
$res=mysql_fetch_array($res);
$sitename=$res["sitename"];
$comment=$res["comment"];
$comment=str_ireplace(":sitename:",$sitename,$comment);

$tabla = mysql_query("SELECT * FROM tb_payme ORDER BY id ASC"); 
while ($registro = mysql_fetch_array($tabla)) { 

echo "
<tr class='liney ell'>
<td width=50 align=center>". $registro["id"] ."</td>
<td width=200 align=center>". $registro["username"] ."</td>
<td align=center>". $registro["pemail"] ."</td>
<td width=100 align=center>". $registro["money"] ."</td>
<td align=center>". $registro["ip"] ."</td>";
$text=str_ireplace(":username:",$registro["username"],$comment);


?>
<td><a href='wmk:payto?Purse=<?= $registro["pemail"] ?>&Amount=<?= $registro["money"] ?>&Desc=<?=$text ?>&BringToFront=Y'><b>�������� �����&nbsp;</b></a></td>
<td>
<form method="post" action="adminmain.php?p=reqpay&id=<?= $registro["id"] ?>&option=paid">
<input type="hidden" name="money" value="<?= $registro["money"] ?>">
<input type="hidden" name="usr" value="<?= $registro["username"] ?>">
<input type="submit" value="��������" class="button">
</form>
</td>
<td>
<form method="post" action="adminmain.php?p=reqpay&id=<?= $registro["id"] ?>&option=del">
<input type="submit" value="�������" class="button">
</form>
</td>
<td> 
<form action="" method="POST"> 
<input type="hidden" name="user" value="<?=$registro["username"]; ?>"> 
<input type="hidden" name="money" value="<?=$registro["money"]; ?>"> 
<input type="hidden" name="id" value="<?=$registro["id"]; ?>"> 
<input type="submit" value="������� ��������"></form> 
</td>
</tr>

<?

}

?>
</table>
