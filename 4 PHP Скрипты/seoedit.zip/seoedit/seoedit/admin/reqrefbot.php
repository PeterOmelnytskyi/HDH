<? include('checkcookie.php'); ?>
<h3>������ ���. �����</h3>
<br>

<?
if ($_GET["option"]=="success")
{
	$tarif=$_POST["tarif"];
	$user=$_POST["username"];
	$t=time();
	$id=$_POST["id"];

	mysql_query("insert into tb_refbot (user,refbottarif,data) values ('$user','$tarif','$t')");
	mysql_query("update tb_users set refbots=refbots+1 where username='$user'");
	mysql_query("delete from tb_refbotreq where id='$id'");

		$res=mysql_query("select * from tb_comp where param='2'");
		if(mysql_num_rows($res)>0)
		{
			while($row=mysql_fetch_array($res))
			{
				$id=$row["id"];
				$lidertype=$row["lidername"];
				$t=time();
				$sd=strtotime($row["startdate"]);
				$ed=strtotime($row["enddate"]);
				if($t>$sd && $t<$ed)
				{
					if($lidertype=='1')
					{
						$res1=mysql_query("select wmid from tb_users where username='$user'");
						if(mysql_num_rows($res1)>0){$res1=mysql_fetch_array($res1); $lidername=$res1["wmid"];}else{$lidername='';}
					}else{
						$lidername=$user;
					}
					if($lidername!='')
					{
						$res1=mysql_query("select * from tb_compdata where idk='$id' and user='$lidername'");
						if(mysql_num_rows($res1)>0)
						{
							$res1=mysql_Fetch_array($res1);
							$resvalue=$res1["resvalue"]+$tarif;
							$purse='';
							mysql_query("update tb_compdata set resvalue='$resvalue', purse='$purse' where id='".$res1["id"]."'");
						}else{
							$purse='';
							mysql_query("insert into tb_compdata (idk,user,resvalue,purse) values ('$id','$lidername','$tarif','$purse')");
						}
					}
				}
			}
		}

	echo "������";
}

if ($_GET["option"]=="cancel")
{
	$id=$_POST["id"];	

	$sql="delete from tb_refbotreq where id='$id'";
	mysql_query($sql);

	echo "�������";
}
?>

<table>
<tr>
<th>������������</th>
<th>�������� ����</th>
<th></th><th></th>
</tr>
<?
$sql="select * from tb_refbotreq order by id";
$res=mysql_query($sql);

if (mysql_num_rows($res)>0)
{
	while ($row=mysql_fetch_assoc($res))
	{
		?><tr><td><?
		echo $row["user"]; 
		?></td><td><?
		echo $row["tarif"];
		?></td>
		<td>
		<form method="post" action="adminmain.php?p=reqrefbot&option=success">
		<input type="hidden" name="username" value="<?= $row["user"] ?>">
		<input type="hidden" name="tarif" value="<?= $row["tarif"] ?>">
		<input type="hidden" name="id" value="<?= $row["id"] ?>">
		<input type="submit" value="�����������" class="button">
		</form>
		</td>
		<td>
		<form method="post" action="adminmain.php?p=reqrefbot&option=cancel">
		<input type="hidden" name="id" value="<?= $row["id"] ?>">
		<input type="submit" value="�������" class="button">
		</form>
		</td>
		</tr>
		<?
	}
}
?>
</table>