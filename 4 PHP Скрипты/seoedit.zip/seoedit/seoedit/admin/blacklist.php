<? include('checkcookie.php');
if(isset($_POST[del]))
{
	mysql_query("DELETE FROM seo_blacklist WHERE id='$_POST[del]'");
}
if(isset($_POST[add]))
{
	$reason=$_POST[add];
	$site=$_POST[urlsite];
	function getHost($Address) {
   $parseUrl = parse_url(trim($Address));
   return trim($parseUrl[host] ? $parseUrl[host] : array_shift(explode('/', $parseUrl[path], 2)));
}
$site=getHost($site);
$site=str_ireplace("www.","",$site);
mysql_query("INSERT INTO seo_blacklist (site,reason) values ('$site','$reason')") or die(mysql_error());
}
$sql=mysql_query("SELECT * FROM seo_blacklist");
?>
<table class='adn'>
<tr class='lineb'>
<td align=center>URL</td>
<td align=center>�������</td>
<td align=center>��������</td>
</tr>
<?
while($row=mysql_fetch_array($sql))
{
	?><tr class='liney ell'>
	<td align=center><a href='http://<?=$row[site]; ?>/' target='_blank'><?=$row[site]; ?></a>
	</td>
	<td align=center><?=$row[reason]; ?></td>
	<td align=center><form action='' method='post'><input type='hidden' name='del' value='<?=$row[id]; ?>'>
	<input type='submit' value='�������'>
	</form></td></tr><?
}
?></table><form action='' method='post' id='MainForm'>
<table class="adn">
<tr class="lineb">
<td align="left">��������</td>
<td align="left"><table class="adn"><tr><td align="left" style="border: none; padding: 0">��������</td><td align="right" style="border: none; padding: 0"><a href="#" onclick="document.getElementById('MainForm').submit(); return false" class="liv">��������</a></td></tr></table></td>
</tr>
<tr class="liney ell">
 <td class="settab listsr"><input type=text value='' name='urlsite'></td>
 <td class="listsl"><b>URL �����</b><br>������ �� �����������</td>
</tr>
<tr  class="liney">
 <td class="settab listsr"><input type=text value='' name='add' ></td>
 <td class="listsl"><b>�������</b><br>������� ����������</td>
</tr></table></form>