	<script type="text/javascript">
	location.replace("adminmain.php");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=adminmain.php">
	</noscript>