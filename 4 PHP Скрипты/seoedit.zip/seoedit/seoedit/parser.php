<?
require('backlist.php');
if($lastpursetime+3600<time())
{

    FUNCTION goods($server){
	$purse=file_get_contents("http://advisor.wmtransfer.com/FeedBackList.aspx?url=".$server);
	if(strpos($purse,'<span class="gt">'))
	{
    $ARR = explode('<span class="gt020">', $purse);
    $ARR = explode('</span></span>', $ARR[1]);
	}else{ $ARR[0]="0";
	}
    RETURN $ARR[0];
	
    }
	FUNCTION bads($server){
	$purse=file_get_contents("http://advisor.wmtransfer.com/FeedBackList.aspx?url=".$server);
	if(strpos($purse,'<span class="lt">'))
	{
    $ARRb = explode('<span class="lt020">', $purse);
    $ARRb = explode('</span></span>', $ARRb[1]);
    RETURN $ARRb[0];
	}else{
	RETURN "0";
	}
    }
	$server=$_SERVER["HTTP_HOST"];
	$goods=goods($server);
	$bads=bads($server);
	$lastpursetime=time();
	$writen = "<? \n
	\$lastpursetime = {$lastpursetime}; \n
	\$goods = \"{$goods}\";\n
	\$bads = \"{$bads}\";\n
	?>";
	$fstats = @fopen("backlist.php","w+");
	@fwrite($fstats,$writen);
	@fclose($fstats);
}
?>