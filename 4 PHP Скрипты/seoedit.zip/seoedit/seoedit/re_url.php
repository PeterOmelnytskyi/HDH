<?PHP
	if(isset($_GET["id"]))
	{
	$id = (intval($_GET["id"]) > 0) ? intval($_GET["id"]) : 1;
		
		require("config.php");
		$con_db = mysql_query("SELECT id, url FROM tb_adsblock WHERE id = '$id'");$allsqls++;
		
		if(mysql_num_rows($con_db) > 0)
		{
			mysql_query("UPDATE tb_adsblock SET views = views + 1 WHERE id = '$id'");$allsqls++;
			$url_go = mysql_fetch_array($con_db);
		?>
		<meta http-equiv="refresh" content="0; url=<?=$url_go["url"]; ?>">
		<?PHP
		}else{
		echo "<center><font color='red'><b>������ � ����� ID �� ����������</b></font></center>";
		}
	}
?>